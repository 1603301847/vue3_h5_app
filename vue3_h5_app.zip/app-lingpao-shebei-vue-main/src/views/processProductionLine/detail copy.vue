<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>


        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <!-- <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">保养设备信息</span>
                </v-col>
                <v-col cols="6">
                    <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</p>
                </v-col> -->
                <v-col cols="12">
                    <p @click="GlobalTooltipFunc(`${ bufferRow.nodeLevelNo||''}-${bufferRow.nodeLevelName||''}`)" style="color:#00E5FF" class="font-weight-light">{{ bufferRow.nodeLevelNo }}-{{ bufferRow.nodeLevelName }}</p>
                </v-col>
            </v-row>
            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验产品:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.partNo }}-{{ bufferRow.partName }}</p>
                </v-col>
            </v-row> -->
            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">配送单号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.receiptNo  }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验任务:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.taskNo  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">申请人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.productBy  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">申请人时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.productDate  }}</p>
                </v-col>
            </v-row>


        </v-sheet>
        <div style="height: 16px;"></div>



        <v-sheet v-if="showLi1" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                    <v-col cols="6">
                        <v-icon icon="mdi-file-edit-outline" size="16" color="primary"></v-icon>
                        <span class="font-weight-medium">检验信息</span>
                    </v-col>
                    <v-col v-show="readonlyPage || readonlyPage111" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
                </v-row>
                <v-row no-gutters class="text">
                    <v-col cols="4" style="padding-left:5px;">
                        <p class="font-weight-medium text">检测类型:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ FormatDictionary('test_type',bufferRow.taskType)['lable']   }}</p>
                    </v-col>
                </v-row>
                <div style="height: 12px;"></div>
                <div v-for="(o,i) in dataList" :key="i">

                    

                    <v-row no-gutters class="text" style="margin-bottom: 10px;">

                        <!-- <v-col cols="4" style="padding-left:5px;">
                            <p class="font-weight-medium text">检验类别:</p>
                        </v-col> -->
                        <v-col cols="12">
                            <p class="font-weight-light">
                                <span class="font-weight-medium text">检验类别: </span>
                                <span style="color:#00E5FF">{{ o.inspectDetailName  }}</span>
                            </p>
                        </v-col>
                    </v-row>

                    <v-row no-gutters class="text" style="margin-bottom: 10px;">
                        <v-col cols="4" style="padding-left:5px;">
                            <p class="font-weight-medium text">检验项目:</p>
                        </v-col>
                        <v-col cols="8">
                            <p class="text-truncate font-weight-light">{{ o.parameterRange  }}</p>
                        </v-col>
                    </v-row>
                    <v-row no-gutters class="text" style="margin-bottom: 10px;">
                        <v-col cols="4" style="padding-left:5px;">
                            <p class="font-weight-medium text">检验结果:</p>
                        </v-col>
                        <v-col cols="8">
                            <p class="text-truncate font-weight-light">{{ o.resultValue  }}</p>
                        </v-col>
                    </v-row>
                    <van-field v-model="o.reasonDesc" :disabled="readonlyPage || readonlyPage111" autocomplete="off" label="不良描述" placeholder="请输入" />
                    <div style="height: 12px;"></div>
                    
                </div>


                <SelectComponents 
                    v-model="type"
                    ref="select33"
                    label="不良类别"
                    required
                    :disabled="readonlyPage || readonlyPage111"
                    :option="typeSelectOption"
                />

                
                <!-- <van-field v-model="opinion2" :disabled="readonlyPage || readonlyPage111" required autocomplete="off" label="问题描述" placeholder="请输入" /> -->

                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px;">
                        <p class="font-weight-medium text">检验人:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.productBy  }}</p>
                    </v-col>
                </v-row>

                <v-row no-gutters class="text" style="margin-bottom:14px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">检验时间:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.productDate  }}</p>
                    </v-col>
                </v-row>
   
                <v-row no-gutters class="text">
                    <v-col cols="12" style="text-align:right;">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:productFrom')"
                            block
                            color="warning"
                            :disabled="readonlyPage || readonlyPage111"
                            @click="submitMessage"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi2" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-file-edit-outline" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">整改信息</span>
                </v-col>
                <v-col v-show="readonlyPage || readonlyPage222" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>

            <SelectComponents 
                v-model="department"
                ref="select99"
                label="处理部门"
                
                :disabled="readonlyPage || readonlyPage222"
                :option="departmentSelectOption"
            />


            <SelectComponents 
                v-if="department"
                v-model="conductor7"
                ref="select77788"
                label="部门处理人"
                showSearch
                required
                :disabled="readonlyPage || readonlyPage222"

                :option="conductorSelectOption7"
                @onSearchChange="conductorSearchChange7"

            />

            <van-field v-model="opinion3" :disabled="readonlyPage || readonlyPage222" required autocomplete="off" label="整改结果" placeholder="请输入" />
            <!-- <van-field v-model="opinion4" :disabled="readonlyPage || readonlyPage222" required autocomplete="off" label="处理措施" placeholder="请输入" /> -->


                <SelectComponents 
                    v-model="opinion4"
                    ref="select81167"
                    :disabled="readonlyPage || readonlyPage222"
                    label="处理措施"
                    required
                    :option="opinion4SelectOption"
                />


                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">整改人:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.repairBy  }}</p>
                    </v-col>
                </v-row>

                <v-row no-gutters class="text" style="margin-bottom: 14px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">整改时间:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.repairDate  }}</p>
                    </v-col>
                </v-row>


                <v-row no-gutters class="text">
                    <v-col cols="12" style="text-align:right;">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:repairFrom')"
                            color="warning"
                            block
                            :disabled="readonlyPage || readonlyPage222"
                            @click="submitRemould"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi3" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-quality-high" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">质量处理</span>
                </v-col>
                <v-col v-show="readonlyPage || readonlyPage333" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>



            <van-field v-model="opinion7" :disabled="readonlyPage || readonlyPage333" required autocomplete="off" label="处理意见" placeholder="请输入" />



            <v-row no-gutters class="text" style="margin-bottom: 10px;">
                <v-col cols="4" style="padding-left:5px">
                    <p class="font-weight-medium text">处理人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.qualityEngineerBy  }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text" style="margin-bottom: 14px;">
                <v-col cols="4" style="padding-left:5px">
                    <p class="font-weight-medium text">处理时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.qualityEngineerTime  }}</p>
                </v-col>
            </v-row>


                <v-row no-gutters class="text">
                    <v-col cols="12" style="text-align:right;">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:qualityEngineerCommit')"
                            color="warning"
                            block
                            :disabled="readonlyPage || readonlyPage333"
                            @click="submitDepartmentQuality"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi4" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-wrench-clock" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">技术处理</span>
                </v-col>
                <v-col v-show="readonlyPage || readonlyPage333" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>



            <van-field v-model="opinion8" :disabled="readonlyPage || readonlyPage333" required autocomplete="off" label="处理意见" placeholder="请输入" />



            <v-row no-gutters class="text" style="margin-bottom: 10px;">
                <v-col cols="4" style="padding-left:5px">
                    <p class="font-weight-medium text">处理人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.technologyBy  }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text" style="margin-bottom: 14px;">
                <v-col cols="4" style="padding-left:5px">
                    <p class="font-weight-medium text">处理时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.technologyTime  }}</p>
                </v-col>
            </v-row>


                <v-row no-gutters class="text">
                    <v-col cols="12" style="text-align:right;">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:technologyCommit')"
                            color="warning"
                            block
                            :disabled="readonlyPage || readonlyPage333"
                            @click="submitDepartmentTechnology"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi5" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-minecraft" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">工艺处理</span>
                </v-col>
                <v-col v-show="readonlyPage || readonlyPage333" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>



            <van-field v-model="opinion9" :disabled="readonlyPage || readonlyPage333" required autocomplete="off" label="处理意见" placeholder="请输入" />



            <v-row no-gutters class="text" style="margin-bottom: 10px;">
                <v-col cols="4" style="padding-left:5px">
                    <p class="font-weight-medium text">处理人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.technologicalBy   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text" style="margin-bottom: 14px;">
                <v-col cols="4" style="padding-left:5px">
                    <p class="font-weight-medium text">处理时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.technologicalTime  }}</p>
                </v-col>
            </v-row>


                <v-row no-gutters class="text">
                    <v-col cols="12" style="text-align:right;">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:technologicalCommit')"
                            color="warning"
                            block
                            :disabled="readonlyPage || readonlyPage333"
                            @click="submitDepartmentCraft"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi6" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-file-edit-outline" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">放行信息</span>
                </v-col>
                <v-col v-show="readonlyPage" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>


                <van-field v-model="opinion5" :disabled="readonlyPage" required autocomplete="off" label="放行说明" placeholder="请输入" />



                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">放行人:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.releaseBy  }}</p>
                    </v-col>
                </v-row>

                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">放行时间:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.releaseTime  }}</p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text" style="text-align:right;">
                    <v-col cols="12">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:releaseFrom')"
                            block
                            color="warning"
                            :disabled="readonlyPage"
                            @click="submitThrough"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi7" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-animation" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">整改人员确认</span>
                </v-col>
                <v-col v-show="readonlyPage" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text" style="margin-bottom: 10px;margin-top:8px;">
                <v-col cols="4" style="padding-left:5px">
                    <p class="font-weight-medium text">确认时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light">{{ bufferRow.confirmTime  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text" style="text-align:right;">
                <v-col cols="12">
                    <v-btn
                        block
                        color="warning"
                        :disabled="readonlyPage || readonlyPage444"

                        @click="submitResult"
                    >
                        确定
                    </v-btn>
                </v-col>
            </v-row>
        </v-sheet>

        <div style="height: 60px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import SelectComponents from '@/packages/Select.vue'

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant'
    import { showDialog  } from 'vant'

  export default {
    components:{
        AppBarPage,
        SelectComponents,
        TableComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据
        dataList:[],   // 列表数据

        type:"",   // 不良类别
        typeSelectOption:[],   // 不良类别 数据  


        conductor7:"",   // 部门处理人
        conductorSelectOption7:[],    // 部门处理人 数据


        department:"",   // 下发到处理部门
        departmentSelectOption:[],   // 下发到处理部门 数据  


        opinion1:"",   // 不良描述
        opinion2:"",   // 问题描述
        opinion3:"",   // 整改结果

        opinion4:"",   // 处理措施
        opinion4SelectOption:[],   // 处理措施 数据

        opinion5:"",   // 放行说明

        opinion7:"",   // 处理意见  质量
        opinion8:"",   // 处理意见  技术
        opinion9:"",   // 处理意见  工艺



        showLi1:false,   // 显示 检验信息
        showLi2:false,   // 显示 整改信息
        showLi3:false,   // 显示 质量处理
        showLi4:false,   // 显示 技术处理
        showLi5:false,   // 显示 工艺处理
        showLi6:false,   // 显示 放行信息
        showLi7:false,   // 显示 整改人员确认



        readonlyPage:true,   // 只读


        readonlyPage111:false,   // 只读  检验信息
        readonlyPage222:false,   // 只读  整改信息 
        readonlyPage333:false,   // 只读  质量处理   技术处理  工艺处理
        readonlyPage444:false,   // 只读  整改人员确认



    }),
    watch:{
        department(value){
            if(!value){
                this.conductor7=""
            }
        }
    },
    created(){
        this.initFunc()

        this.typeHTTP()


        this.initRepairman7()   // 部门处理人  


        this.chuliGetData()  // 处理措施

    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 按钮权限
        ControlBtnPermission(key=""){
            const _page="/processDisqualification/index"
            const _bufferGlobalBtnPermissionlocalStorage=JSON.parse(localStorage.getItem("bufferGlobalBtnPermission")||{})
            const _result=(_bufferGlobalBtnPermissionlocalStorage[_page]||[]).filter(o=>o.perms==key).length?true:false

            // return _result
            return true

        },
        // 初始化
        async initFunc(){
            const {ttQmDefectId}=this.$route.query

            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            // 处理部门
            const _departmentAttribute=_bufferDictionaries["qm_process_dept"]||[]    // 属性
            this.departmentSelectOption=_departmentAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

            
            // 详情 基础数据
            const {code,data={}}= await httpHandle({
               url:`/iiot/qmDefect/${ttQmDefectId}`,
               method: "get",
            })
           
            if(code==200){
                this.bufferRow=data


                // 控制页面
                // data.defectStatus='90'
                // data.issueProcessDept='3'
                switch ( data.defectStatus ) {
                    case '10':   // 检验信息
                        this.showLi1=true
                        this.showLi2=false
                        this.showLi3=false
                        this.showLi4=false
                        this.showLi5=false
                        this.showLi6=false
                        this.showLi7=false
                        this.readonlyPage=false

                        break;
                    case '20':  // 整改信息
                        this.showLi1=true
                        this.showLi2=true
                        this.showLi3=false
                        this.showLi4=false
                        this.showLi5=false
                        this.showLi6=false
                        this.showLi7=false

                        this.readonlyPage=false


                        this.readonlyPage111=true  // 只读  检验信息

                        break;
                    case '30':  

                        this.readonlyPage111=true  // 只读  检验信息
                        this.readonlyPage222=true  // 只读  整改信息


                        // 质量处理
                        if(data.issueProcessDept=='1'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=true
                            this.showLi4=false
                            this.showLi5=false
                            this.showLi6=false
                            this.showLi7=false

                            this.readonlyPage=false
                        }

                        // 技术处理
                        if(data.issueProcessDept=='2'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=false
                            this.showLi4=true
                            this.showLi5=false
                            this.showLi6=false
                            this.showLi7=false

                            this.readonlyPage=false

                        }

                        // 工艺处理
                        if(data.issueProcessDept=='3'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=false
                            this.showLi4=false
                            this.showLi5=true
                            this.showLi6=false
                            this.showLi7=false

                            this.readonlyPage=false
                        }


                        break;
                    case '40': // 放行信息
                        this.readonlyPage111=true  // 只读  检验信息
                        this.readonlyPage222=true  // 只读  整改信息
                        this.readonlyPage333=true  // 只读  


                        // 质量处理
                        if(data.issueProcessDept=='1'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=true
                            this.showLi4=false
                            this.showLi5=false
                            this.showLi6=true
                            this.showLi7=false

                            this.readonlyPage=false
                        }

                        // 技术处理
                        if(data.issueProcessDept=='2'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=false
                            this.showLi4=true
                            this.showLi5=false
                            this.showLi6=true
                            this.showLi7=false

                            this.readonlyPage=false
                        }

                        // 工艺处理
                        if(data.issueProcessDept=='3'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=false
                            this.showLi4=false
                            this.showLi5=true
                            this.showLi6=true
                            this.showLi7=false

                            this.readonlyPage=false
                        }


                        break;

                    case '50': // 整改人员确认
                        this.readonlyPage111=true  // 只读  检验信息
                        this.readonlyPage222=true  // 只读  整改信息
                        this.readonlyPage333=true  // 只读  
                        // this.readonlyPage444=true  // 只读  


                        // 质量处理
                        if(data.issueProcessDept=='1'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=true
                            this.showLi4=false
                            this.showLi5=false
                            this.showLi6=false
                            this.showLi7=true

                            this.readonlyPage=false
                        }

                        // 技术处理
                        if(data.issueProcessDept=='2'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=false
                            this.showLi4=true
                            this.showLi5=false
                            this.showLi6=false
                            this.showLi7=true

                            this.readonlyPage=false
                        }

                        // 工艺处理
                        if(data.issueProcessDept=='3'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=false
                            this.showLi4=false
                            this.showLi5=true
                            this.showLi6=false
                            this.showLi7=true

                            this.readonlyPage=false
                        }


                        break;


                    case '90': // 不可编辑

                        // 质量处理
                        if(data.issueProcessDept=='1'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=true
                            this.showLi4=false
                            this.showLi5=false
                            this.showLi6=true
                            this.showLi7=true

                            this.readonlyPage=true
                        }

                        // 技术处理
                        if(data.issueProcessDept=='2'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=false
                            this.showLi4=true
                            this.showLi5=false
                            this.showLi6=true
                            this.showLi7=true

                            this.readonlyPage=true
                        }

                        // 工艺处理
                        if(data.issueProcessDept=='3'){
                            this.showLi1=true
                            this.showLi2=true
                            this.showLi3=false
                            this.showLi4=false
                            this.showLi5=true
                            this.showLi6=true
                            this.showLi7=true

                            this.readonlyPage=true
                        }

                        break;
                    default:
                        break;
                }


                // 初始化
                this.opinion5=data.releaseMeasures||'' // 放行说明
                this.opinion3= data.repairResult||''   // 整改结果
                this.opinion4= data.repairMeasures||''   // 处理措施   
                this.opinion2=data.scrapReason||''  // 问题描述
                // this.type= data.tmBasReasonId   // 不良类别

                this.opinion7=data.qualityEngineerD||''  // 处理意见  质量 
                this.opinion8=data.technologyD||''  // 处理意见     技术
                this.opinion9=data.technologicalD||''  // 处理意见   工艺



                this.department=data.issueProcessDept // 处理部门
                this.conductor7=data.deptHandleBy    // 部门处理人


                setTimeout(()=>{

                    this.$refs.select81167 && this.$refs.select81167.setValue( data.repairMeasures||'' ) // 处理措施 下拉框


                    this.$refs.select99 && this.$refs.select99.setValue( data.issueProcessDept )  // 处理部门
                    this.$refs.select77788 && this.$refs.select77788.setValue( data.deptHandleBy )  // 部门处理人
                    
                },1000)
            }

            // 列表 数据
            const _result= await httpHandle({
                url:`/iiot/qmDefectDetail/list`,
                method: "get",
                url_params:{
                    ttQmDefectId: ttQmDefectId
                }
            })

            if(code==200){
                this.dataList= _result.data||[]
            }

        },
        // 处理措施
        async chuliGetData(){

            const {code,data=[]}= await httpHandle({
            url:'/iiot/measure/list',
            method: "get",
            url_params:{
                    enabled:"1"
                }
            })

            if(code==200){

                this.opinion4SelectOption=data.map(o=>Object.assign({
                    text: o.measureDeac,
                    value:o.tmBasTreatmentMeasureId
                }))
            }

        },

        // 部门处理人 777
        async initRepairman7(key=''){
            const {code,data=[]}= await httpHandle({
                url:'/system/user/list',
                method:"get",
                url_params:{
                    userKey:key
                }
            }) 

            if(code==200){
                this.conductorSelectOption7=data.map(o=>Object.assign({
                    text:`${o.userName}-${o.nickName}`,
                    value:o.userName
                }))
            }
        },
        // 部门处理人 模糊查询
        conductorSearchChange7(text){
            this.initRepairman7(text)
        },
        // 不良类别
        async typeHTTP(){
            const {code,data=[]}= await httpHandle({
                url:`/iiot/reason/list`,
                method: "post",
                payload:{
                    // pageNum:1,
                    // pageSize:10,          
                    reasonNo:"",
                    params:{
                        reasonTypeList:['MS','F']
                    }
                }
            })
           
            if(code==200){
                this.typeSelectOption=data.map(o=>Object.assign({text:o.reasonNo+'-'+o.reasonName,value:o.tmBasReasonId}))   // 不良类别
            
                setTimeout(()=>{
                    // console.log(data)
                    this.$refs.select33 && this.$refs.select33.setValue( this.bufferRow.tmBasReasonId )  // 不良类别
                },600);
            }
        },
        // 检验信息提交
        async submitMessage(){
            const {bufferRow}=this

            if(!this.type){
                showFailToast("不良类别必填！")
                return
            }

            if(!this.opinion2.trim()){
                showFailToast("问题描述必填！")
                return
            }

            const _json={
                tmBasReasonId: this.type,   // 不良类别
                scrapReason: this.opinion2,  // 问题描述
                dataList: this.dataList,  // 明细列表reasonDesc
                ttQmDefectId: bufferRow.ttQmDefectId

            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmDefect/productDefect',
               method: "post",
               payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/processProductionLine/index', 
                    query:{  }
                }) 
            }

 
        },
        // 整改信息 
        async submitRemould(){
            const {bufferRow}=this

            
            if( this.department && !this.conductor7){
                showFailToast("部门处理人必填！")
                return
            }

            if(!(this.opinion3.trim())){
                showFailToast("整改结果必填！")
                return
            }

            if(!this.opinion4.trim()){
                showFailToast("处理措施必填！")
                return
            }

            const _json={
                issueProcessDept: this.department,  // 处理部门
                deptHandleBy: this.conductor7,   // 部门处理人

                repairResult: this.opinion3,   // 整改结果
                repairMeasures: this.opinion4,   // 处理措施    
                ttQmDefectId: bufferRow.ttQmDefectId

            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmDefect/repairDefect',
               method: "post",
               payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/processProductionLine/index', 
                    query:{  }
                }) 
            }

        },
        // 质量处理
        async submitDepartmentQuality(){
            const {bufferRow}=this

            if(!(this.opinion7.trim())){
                showFailToast("处理意见必填！")
                return
            }


            const _json={
                qualityEngineerD: this.opinion7,  // 处理意见  
                ttQmDefectId: bufferRow.ttQmDefectId
            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmDefect/qualityEngineerCommit',
               method: "post",
               payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$router.push({
                    path:'/processProductionLine/index', 
                    query:{  }
                }) 
            }

        },
        // 技术处理
        async submitDepartmentTechnology(){
            const {bufferRow}=this

            if(!(this.opinion8.trim())){
                showFailToast("处理意见必填！")
                return
            }


            const _json={
                technologyD: this.opinion8,  // 处理意见  
                ttQmDefectId: bufferRow.ttQmDefectId
            }

            const {code,data={}}= await httpHandle({
                url:'/iiot/qmDefect/technologyCommit',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$router.push({
                    path:'/processProductionLine/index', 
                    query:{  }
                }) 
            }
        },
        // 工艺处理
        async submitDepartmentCraft(){
            const {bufferRow}=this

            if(!(this.opinion9.trim())){
                showFailToast("处理意见必填！")
                return
            }


            const _json={
                technologicalD: this.opinion9,  // 处理意见  
                ttQmDefectId: bufferRow.ttQmDefectId
            }

            const {code,data={}}= await httpHandle({
                url:'/iiot/qmDefect/technologicalCommit',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$router.push({
                    path:'/processProductionLine/index', 
                    query:{  }
                }) 
            }
        },
        // 放行说明
        async submitThrough(){
            const {bufferRow}=this


            if(!this.opinion5.trim()){
                showFailToast("放行说明必填！")
                return
            }

            const _json={
                releaseMeasures: this.opinion5, // 放行说明
                ttQmDefectId: bufferRow.ttQmDefectId

            }


            const {code,data={}}= await httpHandle({
               url:'/iiot/qmDefect/releaseDefect',
               method: "post",
               payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/processProductionLine/index', 
                    query:{  }
                }) 
            }

        },
        // 整改人员确认
        async submitResult(){

            const {bufferRow}=this


            const {code,data={}}= await httpHandle({
                url:'/iiot/qmDefect/rectifyConfirm',
                method: "post",
                payload:{
                    ttQmDefectId: bufferRow.ttQmDefectId
                }
            })

            if(code==200){
                showSuccessToast('提交成功！')

                setTimeout(()=>{
                    this.$router.go(-1)
                },600)
            }
        }


    },
  }
</script>