<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>未完成</v-tab>
                    <v-tab value="2" hide-slider>已完成</v-tab>
                </v-tabs>
            </template>

        </AppBarPage>


        <v-btn style="position:fixed;top:200px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="resetFunc">重置</v-btn>

 
        <div style="height: 50px;"></div>

        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">


                <ScanBarComponents 
                    ref="ScanBar1"
                    placeholder="请输入 任务流水号"
                    :showScanIcon="false"
                    @searchClick="barSearchClick1"
                />

                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    url="/iiot/qmDefect/list"
                    :showSearchBtn="true"
                    :params="{
                        taskNo: _taskNo1,
                        qmType:'LQC',
                        defectStatusList:'10,20,30,40,50',
                        ...pageSearchConfig
                    }"
                    @searchClick="searchClick"
                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="1" >

                                    <!-- <p @click="GlobalTooltipFunc(props.items.partName)" class="text-truncate font-weight-light">{{ props.items.nodeLevelName + props.items.nodeLevelNo }}</p> -->
                                </v-col>
                                <v-col cols="10" class="text-right">
                                    <p class="font-weight-medium text-right text-right text-teal-lighten-1" color="primary">{{ FormatDictionary('qm_defect_status',props.items.defectStatus)['lable']   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text" style="color:#00E5FF">{{ props.items.nodeLevelNo  +'-'+ props.items.nodeLevelName }}</p>
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">供应商:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.supperName   }}</p>
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">检验任务:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.taskNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">任务流水号:  </span>
                                        {{ props.items.taskNo }}
                                    </p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">申请人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.productBy   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">申请时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.productDate }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12" class="text-right">
                                    <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">不合格处理</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <v-window-item value="2" class="v-window-item-table">

                <ScanBarComponents 
                    ref="ScanBar2"
                    placeholder="请输入 任务流水号"
                    :showScanIcon="false"
                    @searchClick="barSearchClick2"
                />

                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    url="/iiot/qmDefect/list"
                    :showSearchBtn="!true"
                    :params="{
                        taskNo: _taskNo2,
                        qmType:'LQC',
                        defectStatus:'90',
                        ...pageSearchConfig2
                    }"
                    @searchClick="searchClick2"
                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="1" >

                                    <!-- <p @click="GlobalTooltipFunc(props.items.partName)" class="text-truncate font-weight-light">{{ props.items.nodeLevelName + props.items.nodeLevelNo }}</p> -->
                                </v-col>
                                <v-col cols="10" class="text-right">
                                    <p class="font-weight-medium text-right text-right text-teal-lighten-1" color="primary">{{ FormatDictionary('qm_defect_status',props.items.defectStatus)['lable']   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text" style="color:#00E5FF">{{ props.items.nodeLevelNo  +'-'+ props.items.nodeLevelName }}</p>
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">供应商:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.supperName   }}</p>
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">检验任务:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.taskNo  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">任务流水号:  </span>
                                        {{ props.items.taskNo }}
                                    </p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">申请人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.productBy   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">申请时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.productDate }}</p>
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="12" class="text-right">
                                    <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">不合格处理</v-btn>
                                </v-col>
                            </v-row> -->
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>
        </v-window>


 

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

        <SearchPage2 
            ref="searchPage2" 
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './search.vue' 
    import  SearchPage2 from './search2.vue' 
    import ScanBarComponents from '@/packages/ScanBar.vue'


    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        SearchPage,
        SearchPage2,
        ScanBarComponents,
        TableComponents
    },
    data: () => ({
        tab: '1',

        _taskNo1:"",
        _taskNo2:"",


        pageSearchConfig:{},  // 查询信息 
        pageSearchConfig2:{},  //  查询信息 222
  
    }),

    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 重置
        resetFunc(){
            this._taskNo1=""
            this._taskNo2=""

            this.$refs.ScanBar1 && this.$refs.ScanBar1.reset() 
            this.$refs.ScanBar2 && this.$refs.ScanBar2.reset() 


            this.$nextTick(()=>{
                if( this.tab=='1' ){
                    this.$refs.table1.initFunc(1)
                }
                if( this.tab=='2' ){
                    this.$refs.table2.initFunc(1)
                }
            })
        },
        // 头部 查询 111
        async barSearchClick1(value=''){
            this._taskNo1=value.trim()

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },

        // 头部 查询 222
        async barSearchClick2(value=''){
            this._taskNo2=value.trim()

            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },

        // 查看工时
        async detailClick(props){
            const {items}=props
            
            
            this.$router.push({
                path:'/processProductionLine/detail', 
                query:{ ttQmDefectId:items.ttQmDefectId  }
            }) 

        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}
            

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
            
        },    
        // 查询 22
        searchClick2(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage2.showDrawer()
        },
        // 查询结果   222
        searchHandle2(option){
            this.pageSearchConfig2=option
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置  222
        resetHandle2(opiton){
            this.pageSearchConfig2={}
            
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
            
        }, 

    },
  }
</script>