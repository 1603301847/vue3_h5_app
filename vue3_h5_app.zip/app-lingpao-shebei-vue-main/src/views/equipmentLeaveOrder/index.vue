<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <div class="v-window-item-table">
            <!-- :params="{ warinState:'MA' }" -->
            <TableComponents
                ref="table1"
                url="/iiot/leave/list"
                :showSearchBtn="true"
                :params="{  
                    ...pageSearchConfig
                }"
                @searchClick="searchClick"

            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                            <v-col cols="3">
                                <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                <!-- <span class="font-weight-medium">维修设备</span> -->
                            </v-col>
                            <v-col cols="8">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.nodeLevelName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <!-- <span class="font-weight-medium text"></span> -->
                                <span class="font-weight-medium text">设备:{{ props.items.equipmentName }}</span>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">遗留原因:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.leaveReason)">{{ props.items.leaveReason }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">状态:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ FormatDictionary('assay_state',props.items.leaveState)['lable']   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">根本问题:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.rootWarin)">{{ props.items.rootWarin }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">解决措施:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.solvingMeasures)">{{ props.items.solvingMeasures }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">维修用时:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.repairTime }} 分钟</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">影响时长:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.productAffectTime }} 分钟</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">提报人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.leaveReportBy }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">提报时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.leaveReportDate }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">遗留描述:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.leaveProcessReason)">{{ props.items.leaveProcessReason }}</p>
                            </v-col>
                        </v-row>
       


                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.leaveProcessBy }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.leaveProcessDate }}</p>
                            </v-col>
                        </v-row>



                        <v-row v-if="props.items.leaveState=='10'" no-gutters class="text">
                            <v-col cols="12" class="text-right">
                                <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">关闭</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>

        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round 
            closeable
        >
            <div>
                <p>关闭确认</p>
                <div style="height: 12px;"></div>

                <van-field v-model="closeReason" placeholder="请输入" type="textarea" autocomplete="off" label="关闭原因" required  />
                
                <div style="height: 12px;"></div>

                <v-btn @click="closeAffirmFunc" color="error mt-1" density="compact" block>关闭</v-btn>
                <div style="height: 12px;"></div>
            </div>
        </van-popup>


        <SearchPage
            ref="searchPage"
            :hideStatus="false"
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './search.vue'
    import {httpHandle} from '@/http/http'  // api


    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        SearchPage,
        TableComponents
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息   

        showPicker:false,
        bufferRow:{},   // 行数据
        closeReason:"",   // 关闭原因

    }),

    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 关闭
        async detailClick(props){
            const {items}=props

            this.showPicker=true
            this.bufferRow=items   // 行数据
            this.closeReason=""


        },
        // 关闭 确认
        async closeAffirmFunc(){
            const {bufferRow}=this

            if(!this.closeReason.trim()){
                showFailToast("关闭原因必填！")
                return
            }

            const _json={
                tmEquipmentLeaveId: bufferRow.tmEquipmentLeaveId,
                leaveProcessReason: this.closeReason
            }

            const {code,data={}}= await httpHandle({
                url:'/iiot/leave/closeLeave',
                method: "put",
                payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$refs.table1.initFunc()
                this.showPicker=false
            }


        },
        // 查询 
        searchClick(){
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果 
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置 
        resetHandle(opiton){
            this.pageSearchConfig={}
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

        },

    },
  }
</script>
