<template>
    <span>

        <van-popup
            v-model:show="drawer"
            closeable
            position="right"
            :style="{padding:'12px',width:'90%',height:'100%' }"
        >

            <div style="height: 36px;"></div>

<!--             <SelectComponents-->
<!--               v-model="process"-->
<!--               ref="select123"-->
<!--               label="工厂"-->
<!--               :option="processSelectOption"-->
<!--             />-->
<!--            <SelectComponents-->
<!--              v-model="property22"-->
<!--              ref="select2"-->
<!--              label="仓库"-->
<!--              :option="propertySelectOption22"-->

<!--            />-->
<!--          <van-field v-model="partNo" placeholder="请输入" autocomplete="off" label="零件编码1"  />-->
          <van-field v-model="taskNo" placeholder="请输入" autocomplete="off" label="任务编码"  />

           <SelectComponents
             v-model="property99"
             ref="select4"
             label="移动类型"
             :option="propertySelectOption99"
           />

               <SelectComponents
                 v-model="plantId"
                 ref="select123"
                 label="工厂"
                 :option="processSelectOption"
               />

            <SelectComponents
              v-model="property22"
              ref="select2"
              label="源仓库"
              :option="propertySelectOption22"

            />

                 <SelectComponents
                   v-model="property23"
                   ref="select3"
                   label="目的仓库"
                   :option="propertySelectOption22"
                 />


          <van-field v-model="partNo" placeholder="请输入" autocomplete="off" label="零件编号"  />
          <van-field v-model="partName" placeholder="请输入" autocomplete="off" label="零件名称"  />


            <div style="margin-top:32px;">
                <v-row no-gutters>
                    <v-col cols="3" class="text-center">
                        <v-btn @click="()=> drawer=false " density="compact"  variant="plain">关闭</v-btn>
                    </v-col>
                    <v-col cols="3" class="text-center">
                        <v-btn @click="resetClick" density="compact" color="warning" variant="plain">重置</v-btn>
                    </v-col>
                    <v-col cols="3" class="text-center">
                        <v-btn @click="searchClick" density="compact" color="primary" variant="plain">查询</v-btn>
                    </v-col>

<!--                  <v-col cols="3" class="text-center">-->
<!--                        <v-btn @click="searchClickTwo" density="compact" color="primary" variant="plain">查询实时数据</v-btn>-->
<!--                    </v-col>-->
                </v-row>
            </div>


        </van-popup>


    </span>
</template>
<script>
    import SelectComponents from '@/packages/Select.vue'
    import {httpHandle} from '@/http/http'  // api
    import DatePickerComponents from '@/packages/DatePicker.vue'
    import { showSuccessToast,showFailToast } from 'vant';


    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import {FormatTree} from '@/utils/data'   // utils
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api

  export default {
    components:{
        SelectComponents,
        DatePickerComponents
    },
    emits: ["searchHandle","resetHandle"],
    data: () => ({
        hideFactory:true,
        drawer: false,


        text11:"",   // 设备编码
        text22:"",   // 设备名称
        plantId:"",
        plantNo:"",
        storageNo:"",
        taskNo:"",
        partNo:"",
        partName:"",
        property22:"",
        property99:"",
        property23:"",
        propertySelectOption22:[],
        propertySelectOption99:[],

        show:false,   // 工厂 show
        fieldValue:"",  // 工厂显示值
        options:[],    // 工厂 数据

        process:"",   // 计量区域
        processSelectOption:[],   // 计量区域 数据

        dateStart:"",  // 开始时间
        dateOver:"",    // 结束时间

        factoryID:"",   // 工厂选中ID

        type:"",   // 类型
        typeSelectOption:[],   // 类型数据

        property:"",   // 状态
        propertySelectOption:[],   // 状态数据

        status:"",  // 状态
        statusSelectOption:[],   // 状态数据
    }),
    created(){
        this.initFunc()

      //  this.getContentHttp()
        this.getContentHttpPlant()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 计量区域 数据
        // async getContentHttp(){
        //     const {code,data=[]}= await httpHandle({
        //         url:'/iiot/equipmentArea/list',
        //         method:"get",
        //         url_params:{
        //             // ttQmAbnormalId:ttQmAbnormalId
        //             // contentNo: key,
        //             // ...option
        //         }
        //
        //     })
        //     if(code==200){
        //         this.processSelectOption=data.map(o=>Object.assign({
        //             text: `${o.name}`,
        //             value:o.tmBasEquipmentAreaId
        //         }))
        //     }
        // },

        // 工厂 数据
        async getContentHttpPlant(){
            const {code,data=[]}= await httpHandle({
                url:'/iiot/nodeLevel/selectPlant',
                method:"get",
                url_params:{
                    // ttQmAbnormalId:ttQmAbnormalId
                    // contentNo: key,
                    // ...option
                }

            })
            if(code==200){
                this.processSelectOption=data.map(o=>Object.assign({
                    text:`${o.nodeLevelNo}${o.nodeLevelName}`,
                    value:o.tmBasNodeLevelId
                }))
            }
        },


        // 重置
        resetClick(){
            this.fieldValue="" // 工厂显示值
            this.factoryID=""  // 工厂选中ID
            // this.type=""   // 异常类型
            // this.property=""  // 属性
            // this.status="" // 状态
            // this.dateStart='' // 开始日期
            // this.dateOver=''   // 结束日期
            this.property22=''
            this.property99=''
            this.property23=''
            this.process=""   // 计量区域
            this.text11=""   // 设备编码
            this.text22=""   // 设备名称
            this.plantId=""   // 设备名称

            this.plantNo="",
                this.storageNo="",
                this.partNo="",
                this.taskNo="",
                this.partNo="",
                this.partName="",

            // this.$refs.select1.reset()
            this.$refs.select123 && this.$refs.select123.reset()
            this.$refs.select2 && this.$refs.select2.reset()
            this.$refs.select3 && this.$refs.select3.reset()
            // this.$refs.dateTimeStart.reset()
            // this.$refs.dateTimeOver.reset()
            // this.$refs.select3.reset()

            this.hideFactory=false
            this.$nextTick(()=>{
                this.hideFactory=true
            })


            this.$emit("resetHandle",{})


        },
        // 初始化 下拉框
        async initFunc(){
            // 数据字典
            // 属性   abnormal_type
            // 状态     abnormal_state
            // 紧急程度   urgent_degree

            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")


            const _selectAttribute=_bufferDictionaries["CHECK_STATE"]||[]    // 状态
            // const _selectStatus=_bufferDictionaries["abnormal_state"]||[]     // 状态
            // // const _selectUrgentDegree=_bufferDictionaries["urgent_degree"]||[]     // 紧急程度

            this.propertySelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据
            // this.statusSelectOption=_selectStatus.map(o=>Object.assign({text:o.lable,value:o.value}))   // 状态数据

            const _selectAttribute2=_bufferDictionaries["relation_storage_no"]||[]    // 业务类型
            this.propertySelectOption22=_selectAttribute2.map(o=>Object.assign({text:o.value+ '-' +o.lable,value:o.value}))   // 业务类型

            const _selectAttribute99=_bufferDictionaries["move_type"]||[]    // 业务类型
            this.propertySelectOption99=_selectAttribute99.map(o=>Object.assign({text:o.value+ '-' +o.lable,value:o.value}))   // 业务类型



            // 工厂节点数据
            const {data=[]} = await FactoryTreeHTTP()
            const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")
            this.options=_tree
        },
        // 异常类型
        async getTypeHttp(key=""){
            // 展示  abnormalNo + abnormalName
            // 取值  tmBasAbnormalTypeId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/abnormalType/listAbnormalTypeForSelect',
                method:"get",
                url_params:{
                    // ttQmAbnormalId:ttQmAbnormalId
                    abnormalNo:key
                }

            })

            if(code==200){
                this.typeSelectOption=data.map(o=>Object.assign({
                    text:`${o.abnormalNo}${o.abnormalName}`,
                    value:o.tmBasAbnormalTypeId
                }))
            }
        },
        // 工厂 完成
        onFinish ({ selectedOptions }){


            if(!selectedOptions.length) return

            // tmBasNodeLevelId:“465621691089092608
            let _tmBasNodeLevelId= (selectedOptions[ selectedOptions.length-1 ]||{})["tmBasNodeLevelId"]

            this.factoryID=_tmBasNodeLevelId
            this.fieldValue = selectedOptions.map((o) => o.nodeLevelName).join('/')
        },
        // 查询
        searchClick(){
            const {factoryID,type,property,status,process,plantId}=this;
            const _json={
                // tmBasNodeLevelId:factoryID,  // 工厂
                // // taskState:property,    // 状态
                // equipmentNo: this.text11,  // 设备编码
                // equipmentName: this.text22,  // 设备名称
                //
                // plantNo:this.plantNo,
                //
                // partNo:this.partNo,
                //
                // plantId: this.process, // 计量区域
                 sStorageNo: this.property22,
                moveType: this.property99,
                 dStorageNo: this.property23,


                taskNo:this.taskNo,
                partNo:this.partNo,
                partName:this.partName,
                plantId:this.plantId,
                // tmBasEquipmentTypeIds: process ? process.split(",") :[],   // 设备类型
                // tmBasAbnormalTypeId:type,       // 异常类型
                // abnormalState:status,     // 状态


                // beginTime:this.dateStart , // 开始日期
                // endTime:this.dateOver,  // 结束日期

            }

            // console.log(_json)
            this.$emit("searchHandle",_json)
            this.drawer=false

        },

        showDrawer(){
            this.drawer=true
        }
    },
    props: {
        // 隐藏 状态
        hideStatus:{
            type: Boolean,
            default: ()=> true
        },
    }
  }
</script>
