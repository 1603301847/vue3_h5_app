<template>
    <span>
            <AppBarPage>


            </AppBarPage>

            <div style="height: 12px;"></div>

<!--            <van-field-->
<!--              v-model="fieldValue"-->
<!--              is-link-->
<!--              readonly-->
<!--              label="工厂节点"-->
<!--              placeholder="请选择工厂节点"-->
<!--              type="textarea"-->
<!--              autocomplete="off"-->
<!--              required-->
<!--              @click="show = true"-->
<!--            />-->
<!--            <van-popup v-model:show="show" round position="bottom">-->
<!--                <v-btn-->
<!--                  block-->
<!--                  color="cyan"-->
<!--                  elevation="0"-->
<!--                  style="border-radius: 0px;"-->
<!--                  @click="()=> show=false"-->
<!--                >-->
<!--                    确定-->
<!--                </v-btn>-->
<!--                <van-cascader-->
<!--                  v-if="showFactory"-->
<!--                  title="请选择工厂节点"-->
<!--                  :options="options"-->
<!--                  active-color="#4CAF50"-->
<!--                  :field-names="{text:'nodeLevelName',value:'tmBasNodeLevelId',children:'children'}"-->
<!--                  @close="show = false"-->
<!--                  @change="onFinish"-->
<!--                />-->
<!--            </van-popup>-->

<!--            <SelectComponents-->
<!--              v-model="supplier"-->
<!--              ref="select6785"-->
<!--              label="订单"-->
<!--              required-->
<!--              showSearch-->
<!--              :option="supplierSelectOption"-->
<!--              @onSearchChange="supplierSearchChange"-->
<!--              @onChange="onSupplierChange"-->

<!--            />-->

<!--            <SelectComponents-->
<!--              v-model="serial"-->
<!--              ref="select1212"-->
<!--              label="产品序列号"-->
<!--              required-->
<!--              showSearch-->
<!--              :option="serialSelectOption"-->
<!--              @onSearchChange="serialSearchChange"-->
<!--            />-->


            <SelectComponents
              v-model="plantId"
              ref="select5678"
              label="工厂"
              required
              showSearch
              :option="partSelectOption"
              @onSearchChange="partSearchChange"
            />

      <SelectComponents
        v-model="tmBasEquipmentId"
        ref="select56789"
        label="设备"
        showSearch
        :option="equSelectOption"
        @onSearchChange="equSearchChange"
      />

            <SelectComponents
              v-model="businessType"
              ref="select228"
              required
              label="业务类型"
              :option="processSelectOption"
            />

       <SelectComponents
         v-model="sStorageNo"
         ref="select228"
         required
         label="源仓库"
         :option="processSelectOptionTwo"
       />

       <SelectComponents
         v-model="dStorageNo"
         ref="select2282"
         required
         label="目的仓库"
         :option="processSelectOption3"
       />

       <SelectComponents
         v-model="tiMomWmsStockId"
         ref="select56"
         label="零件"
         required
         showSearch
         :option="partSelectOptionTwo"
         @onSearchChange="partSearchChangeTwo"
       />

       <van-field v-model="qty" placeholder="请输入" required autocomplete="off" type="number" label="调拨数量"  />

<!--            <SelectComponents-->
<!--              v-model="classes"-->
<!--              ref="select353"-->
<!--              label="班次"-->
<!--              :option="classesSelectOption"-->
<!--            />-->

<!--            <van-field v-model="receiptNo" placeholder="请输入" required autocomplete="off" label="批次号"  />-->
<!--            <van-field v-model="receiptline" placeholder="请输入" autocomplete="off" label="箱号"  />-->
<!--            <van-field v-model="taskQty" placeholder="请输入" required autocomplete="off" type="number" label="任务数量"  />-->

      <!-- <van-field v-model="receiptQty" placeholder="请输入" required autocomplete="off" type="number" label="收货数量"  /> -->



<!--            <v-row no-gutters>-->
<!--                <v-col cols="4">-->
<!--                    <p style="padding-left:16px;margin-top:14px;">是否紧急</p>-->
<!--                </v-col>-->
<!--                <v-col cols="8" style="height: 42px;">-->
<!--                    <v-switch-->
<!--                      v-model="switchUrgency"-->
<!--                      :label="switchUrgency?'是':'否'"-->
<!--                      color="primary"-->
<!--                      density="comfortable"-->
<!--                      style="height:48px;display:inline-block;height:48px;width:104px;margin-left:14px;"-->
<!--                    ></v-switch>-->
<!--                </v-col>-->
<!--            </v-row>-->

      <!-- <v-row no-gutters>
          <v-col cols="4">
              <p style="padding-left:16px;margin-top:14px;">是否已收货</p>
          </v-col>
          <v-col cols="8" style="height: 42px;">
              <v-switch
              v-model="switchReceived"
              :label="switchReceived?'是':'否'"
              color="primary"
              density="comfortable"
              style="height:48px;display:inline-block;height:48px;width:104px;margin-left:14px;"
              ></v-switch>
          </v-col>
      </v-row> -->

      <!-- <v-row no-gutters>
          <v-col cols="4">
              <p style="padding-left:16px;margin-top:14px;">是否外检</p>
          </v-col>
          <v-col cols="8" style="height: 42px;">
              <v-switch
              v-model="switchOutInspect"
              :label="switchOutInspect?'是':'否'"
              color="primary"
              density="comfortable"
              style="height:48px;display:inline-block;height:48px;width:104px;margin-left:14px;"
              ></v-switch>
          </v-col>
      </v-row> -->



            <div style="margin-top:32px;margin-bottom: 62px;">
                <v-row no-gutters>
                    <!-- <v-col cols="4" class="text-center">
                        <v-btn @click="()=> drawer=false " density="compact"  variant="plain">关闭</v-btn>
                    </v-col> -->
<!--                    <v-col cols="6" class="text-center">-->
<!--                        <v-btn @click="resetClick" color="warning" >重置</v-btn>-->
<!--                    </v-col>-->
                    <v-col cols="6" class="text-center">
                        <v-btn @click="searchClick" color="primary" >提交</v-btn>
                    </v-col>
                </v-row>
            </div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'

    import SelectComponents from '@/packages/Select.vue'
    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast } from 'vant'


    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import {FormatTree} from '@/utils/data'   // utils
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api

    export default {
        components:{
            AppBarPage,
            SelectComponents
        },
        emits: ["searchHandle","resetHandle"],
        data: () => ({
            drawer: false,
            showFactory:true,  // 重置工厂

            show:false,   // 工厂 show
            fieldValue:"",  // 工厂显示值
            options:[],    // 工厂 数据

            factoryID:"",   // 工厂选中ID

            process:"",   // 过程类型
            processSelectOption:[],   // 过程类型 数据
            processSelectOptionTwo:[],   // 过程类型 数据
            processSelectOption3:[],   // 过程类型 数据

            switchUrgency:false,   // 是否紧急
            switchReceived:false,   // 是否已收货
            switchOutInspect:false,   // 是否外检


            classes:"",     // 班次
            classesSelectOption:[],   // 班次 数据

            taskQty:"",   // 任务数量
            receiptNo:"",   // 批号
            receiptline:"",   // 包号
            receiptQty:"",   // 收货数量
            qty:"",   // 收货数量



            supplier:"",   // 订单
            supplierSelectOption:[],   // 订单 数据

            serial:"",   // 序列号
            serialSelectOption:[],   // 序列号 数据

            part:"",   // 零件
            plantId:"",   // 零件
            tmBasEquipmentId:"",   // 零件
            sStorageNo:"",   // 零件
            dStorageNo:"",   // 零件
            tiMomWmsStockId:"",   // 零件
            businessType:"",   // 零件
            partSelectOption:[],   // 零件 数据
            partSelectOptionTwo:[],   // 零件 数据
            equSelectOption:[],   // 设备 数据

        }),
        created(){
            this.initFunc()

            this.getSupplierHttp()
            this.partHttp()
            this.partHttpTwo()
            this.equHttp()
            this.serialHttp()


        },
        methods: {
            // 数据字典 格式化
            FormatDictionary(key="",valueKey=""){
                const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
                const _obj=(_bufferDictionaries[key] || [] )
                const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
                return _option
            },
            // 重置
            resetClick(){
                // this.factoryID=""    //工厂节点，选择值
                // this.part=""     //零件，选择值
                 this.plantId=""     //工厂
                 this.tmBasEquipmentId=""     //设备
                 this.sStorageNo=""     //设备
                 this.dStorageNo=""     //设备
                 this.tiMomWmsStockId=""     //设备
                 this.businessType=""     //设备

                // this.supplier=""     //供应商，选择值
                // this.process=""     //过程类型，数据字典 QC_TASK_TYPE，选择值
                // this.switchUrgency=false     //是否紧急，数据字典 yes_no，选择值


                this.classes=""     //班次，数据字典 shiftno，选择值
                // this.taskQty=''     //任务数量，手动输入
                // this.receiptNo=""     //收货单号，手动输入
                // this.receiptline=""     //收货单行号，手动输入
                // this.receiptQty=""     //收货数量，手动输入
                // this.switchReceived=false    //是否已收货，数据字典 yes_no
                // this.switchOutInspect=false     //是否外检，数据字典 yes_no
                //
                //
                //
                // this.$refs.select6785.reset()
                // this.$refs.select1212.reset()
                // this.$refs.select5678.reset()
                // this.$refs.select228.reset()
                // this.$refs.select353.reset()
                //
                //
                // this.fieldValue=""
                // this.showFactory=false
                // this.$nextTick(()=>{
                //     this.showFactory=true
                // })
                // this.$emit("resetHandle",{})


            },
            // 初始化 下拉框
            async initFunc(){
                // 数据字典
                // 属性   abnormal_type
                // 状态     abnormal_state
                // 紧急程度   urgent_degree

                const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")


                // 过程类型
                const _processAttribute=_bufferDictionaries["ccgl_bpbj_business_type"]||[]
                this.processSelectOption=_processAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

                // 源仓库
                const _processAttributeTwo=_bufferDictionaries["relation_storage_no"]||[]
                this.processSelectOptionTwo=_processAttributeTwo.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

                // 目的仓库
                const _processAttribute3=_bufferDictionaries["relation_storage_no"]||[]
                this.processSelectOption3=_processAttribute3.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据


                // 班次
                const _classesAttribute=_bufferDictionaries["shiftno"]||[]
                this.classesSelectOption=_classesAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据



                // 工厂节点数据
                const {data=[]} = await FactoryTreeHTTP()
                const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")
                this.options=_tree
            },
            // 订单
            async getSupplierHttp(key=""){

                // 展示  abnormalNo + abnormalName
                // 取值  tmBasAbnormalTypeId
                const {code,data=[]}= await httpHandle({
                    url:'/iiot/order/listOrderForSelect',
                    method:"get",
                    url_params:{
                        // aufnr:key
                        aufnr:key
                    }

                })

                if(code==200){
                    this.supplierSelectOption=data.map(o=>Object.assign({
                        text:`${o.aufnr}`,
                        value:o.ttPpOrderId
                    })).splice(0,100)
                }
            },
            // 订单查询
            supplierSearchChange(key){
                this.getSupplierHttp(key)
            },
            // 订单切换
            onSupplierChange(value){
                this.serialHttp("",value)

                this.$nextTick(()=>{
                    this.serial=""
                    this.$refs.select1212.reset()
                })
            },
            // 序列号
            async serialHttp(key="",ttPpOrderId=""){

                // 展示  abnormalNo + abnormalName
                // 取值  tmBasAbnormalTypeId
                const {code,data=[]}= await httpHandle({
                    url:'/iiot/orderSn/listOrderSnForSelect',
                    method:"get",
                    url_params:{
                        sernr:key,
                        ttPpOrderId:ttPpOrderId
                    }

                })

                if(code==200){
                    this.serialSelectOption=data.map(o=>Object.assign({
                        text:`${o.sernr}`,
                        value:o.ttPpOrderSnId
                    })).splice(0,100)
                }
            },
            // 序列号 查询
            serialSearchChange(key){
                this.serialHttp(key)
            },
            // 工厂
            async partHttp(key=""){

                // 展示  abnormalNo + abnormalName
                // 取值  tmBasAbnormalTypeId
                const {code,data=[]}= await httpHandle({
                    url:'/iiot/nodeLevel/selectPlant',
                    method:"get",
                    url_params:{
                        nodeLevelNo:key
                    }

                })

                if(code==200){
                    this.partSelectOption=data.map(o=>Object.assign({
                        text:`${o.nodeLevelNo||''}-${o.nodeLevelName||''}`,
                        value:o.tmBasNodeLevelId
                    })).splice(0,100)
                }
            },
            // 工厂切换
            partSearchChange(key){
                this.partHttp(key)
            },
            // 设备
            async equHttp(key=""){

                // 展示  abnormalNo + abnormalName
                // 取值  tmBasAbnormalTypeId
                const {code,data=[]}= await httpHandle({
                    url:'/iiot/equipment/list',
                    method:"get",
                    url_params:{
                        equipmentNo:key
                    }

                })

                if(code==200){
                    this.equSelectOption=data.map(o=>Object.assign({
                        text:`${o.equipmentNo}-${o.equipmentName}`,
                        value:o.tmBasEquipmentId
                    })).splice(0,100)
                }
            },
            // 设备切换
            equSearchChange(key){
                this.equHttp(key)
            },



            // 零件
            async partHttpTwo(key=""){

                // 展示  abnormalNo + abnormalName
                // 取值  tmBasAbnormalTypeId
                const {code,data=[]}= await httpHandle({
                    url:'/iiot/stock/selectAllPart',
                    method:"get",
                    url_params:{
                        partNo:key
                    }

                })

                if(code==200){
                    this.partSelectOptionTwo=data.map(o=>Object.assign({
                        text:`${o.partNo||''}-${o.partName||''}`,
                        value:o.tiMomWmsStockId
                    })).splice(0,100)
                }
            },
            // 零件切换
            partSearchChangeTwo(key){
                this.partHttpTwo(key)
            },




            // 工厂 完成
            onFinish ({ selectedOptions }){


                if(!selectedOptions.length) return

                // tmBasNodeLevelId:“465621691089092608
                let _tmBasNodeLevelId= (selectedOptions[ selectedOptions.length-1 ]||{})["tmBasNodeLevelId"]

                this.factoryID=_tmBasNodeLevelId
                this.fieldValue = selectedOptions.map((o) => o.nodeLevelName).join('/')
            },
            // 查询
            async searchClick(){

                if(!this.plantId){
                    showFailToast("工厂必填！")
                    return
                }


                if(!this.businessType){
                    showFailToast("业务类型必填！")
                    return
                }

                if(!this.sStorageNo){
                    showFailToast("源仓库必填！")
                    return
                }

                if(!this.dStorageNo){
                    showFailToast("目的仓库必填！")
                    return
                }
                if (this.sStorageNo==this.dStorageNo){
                    showFailToast("源仓库不能和目的仓库相同！")
                    return
                }

                if(!this.tiMomWmsStockId){
                    showFailToast("零件必填！")
                    return
                }

                if(!Number(this.qty)){
                    showFailToast("调拨数量必填！")
                    return
                }


                //
                // if(!this.supplier){
                //     showFailToast("生产订单必填！")
                //     return
                // }
                //
                // if(!this.serial){
                //     showFailToast("序列号必填！")
                //     return
                // }
                //
                // if(!this.part){
                //     showFailToast("零件必填！")
                //     return
                // }
                //
                // if(!this.receiptNo.trim()){
                //     showFailToast("批号必填！")
                //     return
                // }
                //
                // if(!Number(this.taskQty)){
                //     showFailToast("任务数量必填！")
                //     return
                // }

                const _json={

                    // "taskType": "IPQC",       //检验类型，固定   IQC
                    // "tmBasNodeLevelId": this.factoryID,     //工厂节点，选择值
                    // "tmBasPartId": this.part,     //零件，选择值
                     "plantId": this.plantId,     //零件，选择值
                     "tmBasEquipmentId": this.tmBasEquipmentId,     //设备，选择值
                     "sStorageNo": this.sStorageNo,     //设备，选择值
                     "dStorageNo": this.dStorageNo,     //设备，选择值
                     "tiMomWmsStockId": this.tiMomWmsStockId,     //设备，选择值
                     "businessType": this.businessType,     //设备，选择值
                     "qty": Number(this.qty),     //任务数量，手动输入
                    // "lotNo": this.receiptNo,   //批号，手动输入
                    // "packageNo": this.receiptline,   //包号，手动输入
                    //
                    // "processType": this.process,     //过程类型，数据字典 QC_TASK_TYPE，选择值
                    // "isUrgent": this.switchUrgency?'1':'0',     //是否紧急，数据字典 yes_no，选择值
                   // "shiftno": this.classes,     //班次，数据字典 shiftno，选择值
                    // "taskQty": Number(this.taskQty),     //任务数量，手动输入
                    //
                    // "ttPpOrderId": this.supplier,   //生产订单，选择值
                    // "ttPpOrderSnId": this.serial  //序列号，选择值，感觉生产订单联动过滤


                }


                const {code,data={}}= await httpHandle({
                    url:'/iiot/trasfer',
                    method: "post",
                    payload:_json
                })

                if(code==200){
                    showSuccessToast("提交成功！")
                    // this.$router.push({
                    //     path:'/process/index',
                    //     query:{ tabs:'1' }
                    // })

                    setTimeout(()=>{
                        this.$router.go(-1)
                    },700)
                }


            },
            showDrawer(){
                this.drawer=true
            }
        },
        props: {

        }
    }
</script>
