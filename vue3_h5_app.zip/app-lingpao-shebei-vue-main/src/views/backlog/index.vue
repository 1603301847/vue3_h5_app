<template>
    <div class="backlog-html">
        <AppBarPage>
        </AppBarPage>

        <v-row no-gutters class="top-titlle">
            <v-col cols="1">
                <v-icon icon="mdi-dns-outline" size="16" color="primary"></v-icon>
            </v-col>
            <v-col cols="7">
                <p class="font-weight-medium text">待办事项</p>
            </v-col>
            <!-- <v-col cols="5">
                <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{211}}</p>
            </v-col> -->
        </v-row>

        <v-card
          elevation="2"
          class="custem-card"
          v-if="FormatMenu(itemList5).length"
        >
            <v-row no-gutters style="padding-left: 12px;">
                <v-col cols="1">
                    <v-icon icon="mdi-quality-high" size="24" color="warning"></v-icon>
                </v-col>
                <v-col cols="11">
                    <p class="font-weight-medium">异常管理</p>
                </v-col>
                <!-- <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{211}}</p>
                </v-col> -->
            </v-row>
            <v-list density="compact" nav>
            <!-- <v-list-item 
                prepend-icon="mdi-view-dashboard" 
                title="Home" 
                value="home"
                active-color="primary"
                rounded="shaped"
            ></v-list-item> -->
            <v-list-item 
                v-for="(item,i) in FormatMenu(itemList5)"
                :key="i"
                active-color="primary"
                @click="itemHandle(item)"
            >
            <v-row no-gutters class="custem-card-title">
                <v-col cols="10">
                    <div class="list-li-menu">
                    <!-- <v-badge
                        color="error"
                         :content="item.number"
                        >
                        </v-badge> -->
                    <span v-if="item.number" class="backlog-li-bage-mark">{{ item.number }}</span>
                    <span class="text">{{ item.title }}</span>


                </div>
                </v-col>
                <v-col cols="2" class="text-right">
                    <v-icon class="right-icon" icon="mdi-chevron-right" size="26" ></v-icon>
                </v-col>
                </v-row>


            </v-list-item>

            </v-list>
        </v-card>

        <v-card
          elevation="2"
          class="custem-card"
          v-if="FormatMenu(itemList4).length"
        >
            <v-row no-gutters style="padding-left: 12px;">
                <v-col cols="1">
                    <v-icon icon="mdi-quality-high" size="24" color="warning"></v-icon>
                </v-col>
                <v-col cols="11">
                    <p class="font-weight-medium">质量检验</p>
                </v-col>
                <!-- <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{211}}</p>
                </v-col> -->
            </v-row>
            <v-list density="compact" nav>
            <!-- <v-list-item 
                prepend-icon="mdi-view-dashboard" 
                title="Home" 
                value="home"
                active-color="primary"
                rounded="shaped"
            ></v-list-item> -->
            <v-list-item 
                v-for="(item,i) in FormatMenu(itemList4)"
                :key="i"
                active-color="primary"
                @click="itemHandle(item)"
            >
            <v-row no-gutters class="custem-card-title">
                <v-col cols="10">
                    <div class="list-li-menu">
                    <!-- <v-badge
                        color="error"
                         :content="item.number"
                        >
                        </v-badge> -->
                    <span v-if="item.number" class="backlog-li-bage-mark">{{ item.number }}</span>
                    <span class="text">{{ item.title }}</span>


                </div>
                </v-col>
                <v-col cols="2" class="text-right">
                    <v-icon class="right-icon" icon="mdi-chevron-right" size="26" ></v-icon>
                </v-col>
                </v-row>


            </v-list-item>

            </v-list>
        </v-card>
            
        <v-card
          elevation="2"
          class="custem-card"
          v-if="FormatMenu(itemList).length"
        >
            <v-row no-gutters style="padding-left: 12px;">
                <v-col cols="1">
                    <v-icon icon="mdi-hammer-wrench" size="20" color="warning"></v-icon>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-medium">维修任务</p>
                </v-col>
                <!-- <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{211}}</p>
                </v-col> -->
            </v-row>
            <v-list density="compact" nav>
            <!-- <v-list-item 
                prepend-icon="mdi-view-dashboard" 
                title="Home" 
                value="home"
                active-color="primary"
                rounded="shaped"
            ></v-list-item> -->
            <v-list-item 
                v-for="(item,i) in FormatMenu(itemList)"
                :key="i"
                active-color="primary"
                @click="itemHandle(item)"
            >
            <v-row no-gutters class="custem-card-title">
                <v-col cols="10">
                    <div class="list-li-menu">
                    <!-- <v-badge
                        color="error"
                         :content="item.number"
                        >
                        </v-badge> -->
                    <span v-if="item.number" class="backlog-li-bage-mark">{{ item.number }}</span>
                    <span class="text">{{ item.title }}</span>


                </div>
                </v-col>
                <v-col cols="2" class="text-right">
                    <v-icon class="right-icon" icon="mdi-chevron-right" size="26" ></v-icon>
                </v-col>
                </v-row>


            </v-list-item>

            </v-list>
        </v-card>



        <v-card
          elevation="2"
          class="custem-card"
          v-if="FormatMenu(itemList3).length"
        >
            <v-row no-gutters style="padding-left: 12px;">
                <v-col cols="1">
                    <v-icon icon="mdi-feature-search" size="24" color="warning"></v-icon>
                </v-col>
                <v-col cols="11">
                    <p class="font-weight-medium">点检任务</p>
                </v-col>
                <!-- <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{211}}</p>
                </v-col> -->
            </v-row>
            <v-list density="compact" nav>
            <!-- <v-list-item 
                prepend-icon="mdi-view-dashboard" 
                title="Home" 
                value="home"
                active-color="primary"
                rounded="shaped"
            ></v-list-item> -->
            <v-list-item 
                v-for="(item,i) in FormatMenu(itemList3)"
                :key="i"
                active-color="primary"
                @click="itemHandle(item)"
            >
            <v-row no-gutters class="custem-card-title">
                <v-col cols="10">
                    <div class="list-li-menu">
                    <!-- <v-badge
                        color="error"
                         :content="item.number"
                        >
                        </v-badge> -->
                    <span v-if="item.number" class="backlog-li-bage-mark">{{ item.number }}</span>
                    <span class="text">{{ item.title }}</span>


                </div>
                </v-col>
                <v-col cols="2" class="text-right">
                    <v-icon class="right-icon" icon="mdi-chevron-right" size="26" ></v-icon>
                </v-col>
                </v-row>


            </v-list-item>

            </v-list>
        </v-card>

        <v-card
          elevation="2"
          class="custem-card"
          v-if="FormatMenu(itemList1).length"

        >
            <v-row no-gutters style="padding-left: 12px;">
                <v-col cols="1">
                    <v-icon icon="mdi-dns" size="20" color="warning"></v-icon>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-medium">保养任务</p>
                </v-col>
                <!-- <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{211}}</p>
                </v-col> -->
            </v-row>
            <v-list density="compact" nav>
            <!-- <v-list-item 
                prepend-icon="mdi-view-dashboard" 
                title="Home" 
                value="home"
                active-color="primary"
                rounded="shaped"
            ></v-list-item> -->
            <v-list-item 
                v-for="(item,i) in FormatMenu(itemList1)"
                :key="i"
                active-color="primary"
                @click="itemHandle(item)"
            >
            <v-row no-gutters class="custem-card-title">
                <v-col cols="10">
                    <div class="list-li-menu">
                    <!-- <v-badge
                        color="error"
                         :content="item.number"
                        >
                        </v-badge> -->
                    <span v-if="item.number" class="backlog-li-bage-mark">{{ item.number }}</span>
                    <span class="text">{{ item.title }}</span>


                </div>
                </v-col>
                <v-col cols="2" class="text-right">
                    <v-icon class="right-icon" icon="mdi-chevron-right" size="26" ></v-icon>
                </v-col>
                </v-row>


            </v-list-item>

            </v-list>
        </v-card>




        <div style="height: 32px;"></div>
    </div>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 待办

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast, showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage
    },
    emits: [],
    data: () => ({
        // 设备
        itemList:[
            {
                icon:"mdi-send-outline",
                title:"等待维修", 
                number:0,
                index:1,
                router:"page0-1",
                path:"/equipment/maintain"
            },
            {
                icon:"mdi-send-outline",
                title:"维修中", 
                number:0,
                query:{tabs:2},
                index:2,
                router:"page0-2",
                path:"/equipment/maintain"
            },
            {
                icon:"mdi-send-outline",
                title:"维修确认", 
                number:0,
                index:3,
                router:"page0-3",
                path:"/equipment/equipmentAffirm"
            }
        ],

        // 保养
        itemList1:[
            // /maintain/index

            {
                icon:"mdi-send-outline",
                title:"待指派", 
                number:0,
                index:1,
                query:{tabs:1},
                router:"page1-1",
                path:"/maintain/index"
            },
            {
                icon:"mdi-send-outline",
                title:"待保养", 
                number:0,
                index:2,
                query:{tabs:2},
                router:"page1-2",
                path:"/maintain/index"
            },

            // {
            //     icon:"mdi-send-outline",
            //     title:"已到期", 
            //     number:0,
            //     index:1,
            //     query:{tabs:2},
            //     router:"page1-1",
            //     path:"/maintain/index"
            // },
            // {
            //     icon:"mdi-send-outline",
            //     title:"7天内到期", 
            //     number:0,
            //     index:2,
            //     router:"page1-2",
            //     path:"/maintain/index"
            // },
            // {
            //     icon:"mdi-send-outline",
            //     title:"正常", 
            //     number:0,
            //     index:3,
            //     router:"page1-3",
            //     path:"/maintain/index"
            // }
        ],

        // 点检
        itemList3:[
            {
                icon:"mdi-feature-search-outline",
                title:"待点检", 
                number:0,
                index:1,
                query:{tabs:1},
                router:"page3-1",
                path:"/examineHistory/index"
            },
            // {
            //     icon:"mdi-send-outline",
            //     title:"点检中", 
            //     number:0,
            //     index:2,
            //     query:{tabs:2},
            //     router:"page8",
            //     path:"/examineHistory/index"
            // },
            // {
            //     icon:"mdi-send-outline",
            //     title:"点检待确认", 
            //     number:0,
            //     index:3,
            //     router:"page9",
            //     path:"/examineConfirm/index"
            // }
        ],


        // 质量检验
        itemList4:[
            {
                icon:"mdi-feature-search-outline",
                title:"来料检验", 
                number:0,
                index:1,
                router:"page4-1",
                path:"/qualityMaterial/index"
            },
            {
                icon:"mdi-send-outline",
                title:"来料不合格", 
                number:0,
                index:2,
                router:"page4-2",
                path:"/qualityMaterialDisqualification/index"
            },
            // {
            //     icon:"mdi-send-outline",
            //     title:"过程检验", 
            //     number:0,
            //     index:3,
            //     router:"page12",
            //     path:"/process/index"
            // },

            {
                icon:"mdi-send-outline",
                title:"工序检验", 
                number:0,
                index:5,
                router:"page4-5",
                path:"/process/index/working"
            },
            {
                icon:"mdi-send-outline",
                title:"调试检验", 
                number:0,
                index:6,
                router:"page4-6",
                path:"/process/index/adjustment"
            },
            {
                icon:"mdi-send-outline",
                title:"入库检验", 
                number:0,
                index:7,
                router:"page4-7",
                path:"/process/index/put"
            },
            {
                icon:"mdi-send-outline",
                title:"自制件", 
                number:0,
                index:8,
                router:"page4-8",
                path:"/process/index/self"
            },

            {
                icon:"mdi-send-outline",
                title:"过程不合格", 
                number:0,
                index:4,
                router:"page4-4",
                path:"/processDisqualification/index"
            },


            {
                icon:"mdi-send-outline",
                title:"产线检验", 
                number:0,
                index:9,
                router:"page4-9",
                path:"/processQualifiedProductionLine/index"
            },
            {
                icon:"mdi-send-outline",
                title:"产线检验不合格", 
                number:0,
                index:10,
                router:"page4-10",
                path:"/processProductionLine/index"
            },

        ],

        // 异常
        itemList5:[
            {
                icon:"mdi-feature-search-outline",
                title:"异常转发", 
                number:0,
                index:1,
                router:"page5-1",
                path:"/anomalyInitiate/index/transpond"
            },
            {
                icon:"mdi-send-outline",
                title:"异常指派", 
                number:0,
                index:2,
                router:"page5-2",
                path:"/anomalyInitiate/index/appointIndex"
            },
            {
                icon:"mdi-send-outline",
                title:"异常处理", 
                number:0,
                index:3,
                router:"page5-3",
                path:"/anomalyInitiate/index/disposeIndex"
            },
            {
                icon:"mdi-send-outline",
                title:"异常关闭", 
                number:0,
                index:4,
                router:"page5-4",
                path:"/anomalyInitiate/index/closeIndex"
            }
        ],   

    }),
    created(){
        this.initFunc()
    },
    methods: {
        async initFunc(){
            const {code,data={}}= await httpHandle({
                url:'/iiot/equipmentRepair/queryBacklog',
                method:"post",
            })

            if(code==200){




                // 设备维修
                this.itemList=this.itemList.map(o=>{
                    let _number=0
                    switch (o.index) {
                        case 1:  // 等待维修
                            _number=data.waitForRepairNum
                            break;
                        case 2:  // 维修中
                            _number=data.repairingNum
                            break;
                        case 3:  // 维修确认
                            _number=data.confirmedNum
                            break;
                        default:
                            break;
                    }

                    return Object.assign(o,{number:_number})
                })


                // 设备保养
                this.itemList1=this.itemList1.map(o=>{
                    let _number=0
                    switch (o.index) {
                        // case 1:  // 已到期
                        //     _number=data.expireNum
                        //     break;
                        // case 2:  // 7内期
                        //     _number=data.expireIn7daysNum
                        //     break;
                        // case 3:  // 正常
                        //     _number=data.normalNum
                        //     break;

                        case 1:  // 待指派
                            _number=data.waitDesignate
                            break;
                        case 2:  // 待保养
                            _number=data.waitMaintain
                            break;

                        default:
                            break;
                    }

                    return Object.assign(o,{number:_number})
                })


                // 点检
                this.itemList3=this.itemList3.map(o=>{
                    let _number=0
                    switch (o.index) {
                        case 1:  // 待点检
                            _number=data.newInspectionNum
                            break;
                        // case 2:  // 点检中
                        //     _number=data.inspectioningNum
                        //     break;
                        // case 3:  // 点检待确认
                        //     _number=data.waitForConfirmNum
                        //     break;
                        default:
                            break;
                    }

                    return Object.assign(o,{number:_number})
                })

                // 质量检测
                this.itemList4=this.itemList4.map(o=>{
                    let _number=0
                    switch (o.index) {
                        case 1:  // 来料检验
                            _number=data.tiQmQualityCheckApplyNum
                            break;
                        case 2:  // 来料不合格
                            _number=data.ttQmDefectNum
                            break;
                        // case 3:  // 过程检验
                        //     _number=data.processCheckApplyNum
                        //     break;
                        case 4:  // 过程不合格
                            _number=data.ipqcDefectNum
                            break;

                        case 5:  // 工序检验
                            _number=data.productionCheckApplyNum
                            break;
                        case 6:  // 调试检验
                            _number=data.shakedownCheckApplyNum
                            break;
                        case 7:  // 入库检验
                            _number=data.wareHousingCheckApplyNum
                            break;
                        case 8:  // 自制件
                            _number=data.selfPartCheckApplyNum
                            break;

                        case 9:  // 产线检验  
                            _number=data.lineCheckApplyNum
                            break;
                        case 10:  // 产线检验不合格 
                            _number=data.lineDefectNum
                            break;


                        default:
                            break;
                    }

                    return Object.assign(o,{number:_number})
                })

                // 异常
                this.itemList5=this.itemList5.map(o=>{
                    let _number=0
                    switch (o.index) {
                        case 1:  // 异常转发
                            _number=data.abnormalResNum
                            break;
                        case 2:  // 异常指派
                            _number=data.abnormalApointNum
                            break;
                        case 3:  // 异常处理
                            _number=data.abnormalProcessNum
                            break;
                        case 4:  // 异常关闭
                            _number=data.abnormalCloseNum
                            break;
                        default:
                            break;
                    }

                    return Object.assign(o,{number:_number})
                })
            }
        },
        // 过滤菜单
        FormatMenu(list=[]){
            let _menuList=[]
            const _bufferGlobalMenuList=(JSON.parse(localStorage.getItem("bufferGlobalMenuList")||"[]").filter(o=>o.path=="backlog")[0]||{}).children||[]

            _bufferGlobalMenuList.map(o=>{
                (o.children||[]).map(k=>{
                    _menuList.push(k.path)
                })
            })

            // console.log(_menuList)
            return list.filter(j=> _menuList.includes(j.router)  )
        },
        itemHandle(option){
            const { $emitter } = this.$root
            const {path,query={}}=option

            this.$router.push({
                path:path, 
                query:{ ...query }
            })    

            // 点检
            if(path=="/examineHistory/index"){
                setTimeout(() => {
                    $emitter.emit("update_examineHistory_page")
                }, 200);
            }



            // 设备保养
            if(path=="/maintain/index"){
                setTimeout(() => {
                    $emitter.emit("update_maintain_page")
                }, 200);
            }

        }
    },
    props: {

    }
  }
</script>
<style lang="scss">
.backlog-html{

    .top-titlle{
        margin-top: 12px;
        padding-left: 5px;
        margin-bottom: 6px;

        .text{
            font-size: 18px;
        }
    }

    .backlog-li-bage-mark{
        background-color: #B71C1C;
        color: #fff;
        padding: 2px 6px 2px 6px;
        border-radius: 12px;
        position: relative;
        bottom: 4px;
    }

    .v-badge{
        position: relative;
        top: -13px;
        left: 14px;
    }
    .custem-card{
        margin-top: 12px;
    }

    .v-list{
        border-bottom: 1px solid #ccc;
        border: none;
    }
    .right-icon{
            position: relative;
            top: 5px;
            color: #90A4AE;
        }

    .list-li-menu{
        margin-top: 12px;
        span.text{
            padding-left: 8px;
            position: relative;
            top: -4px;
            font-size: 16px;
        }


    }
}
</style>