<template>
    <span>
        <AppBarPage>
        </AppBarPage>

        <!-- <v-row no-gutters style="margin-bottom:2px;">
            <v-col cols="12">
                <v-icon icon="mdi-tools" size="16" color="#3F51B5"></v-icon>
                <span style="padding-left:6px;">设备维修信息</span>
            </v-col>
            <v-col cols="6" class="text-right" style="padding-right:6px">
                <span class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</span>
            </v-col> 
        </v-row> -->
        <v-row no-gutters style="margin-bottom:4px;padding-left: 6px;">
            <v-col cols="12">
                <span class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</span>
            </v-col>
        </v-row>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">报修信息</span>
                </v-col>
                <!-- <v-col cols="6">
                    <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ 111 }}</p>
                </v-col> -->
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">故障类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.faultTypeCn }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">故障位置:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.faultStationCn }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">故障详情描述:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(bufferRow.problemDesc)" >{{ bufferRow.problemDesc }}</p>
                </v-col>
            </v-row>

            <UploaderImageComponents 
                :initPath="bufferRow.filePath"
                preview
            />


            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ FormatDictionary('equipment_repair_type',bufferRow.reportType)['lable']   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">报修人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.reportBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">报修时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.reportTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">响应人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.responseBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">响应时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.responseTime }}</p>
                </v-col>
            </v-row>

            <v-row v-if="bufferRow.cancelReason" no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">取消原因:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.cancelReason }}</p>
                </v-col>
            </v-row>
        </v-sheet>

        <!-- <van-field v-model="reasonCancellation" required label="取消原因" placeholder="请输入" autocomplete="off"  /> -->


        <!-- <v-btn style="margin-bottom:8px;" @click="cancelReimbursement" block color="error" variant="outlined">
            取消报修
        </v-btn> -->



        <v-sheet v-if="!bufferRow.cancelReason" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-check-bold" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">维修确认</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">是否外修:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.isRepair==1?'是':'否' }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修单位:</p>
                </v-col>
                <v-col cols="8">         
                    <p class="text-truncate font-weight-light">{{ bufferRow.repairUnit }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修费用:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.repairCost }}</p>
                </v-col>
            </v-row>


            <!-- <van-field name="switch" placeholder="请输入" autocomplete="off" label="是否外修">
                <template #input>
                    <van-switch v-model="checked" />
                </template>
            </van-field> -->

            <!-- <van-field v-model="repairUnit" v-if="checked" placeholder="请输入" autocomplete="off" label="维修单位"  /> -->
            <!-- <van-field v-model="repairCost" v-if="checked" type="number" placeholder="请输入" autocomplete="off" label="维修费用"  /> -->


            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">是否报废:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.isScrap==1?'是':'否' }}</p>
                </v-col>
            </v-row>

            <!-- <van-field name="switch" placeholder="请输入" autocomplete="off" label="是否报废">
                <template #input>
                    <van-switch v-model="checked2" />
                </template>
            </van-field> -->

            <!-- <van-field v-model="value" placeholder="请输入" autocomplete="off" label="维修人" readonly /> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.maintainRepairBy }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">协助人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.helpers }}</p>
                </v-col>
            </v-row>

            <!-- <SelectComponents
                v-model="user"
                label="协助人"
                multiple
                :option="repairmanSelectOption"
                @on-change="repairmanChange"
            /> -->

            <!-- <van-field v-model="time" placeholder="请输入" autocomplete="off" label="确认时间" readonly /> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">确认时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.maintainRepairTime }}</p>
                </v-col>
            </v-row>

        </v-sheet>


        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-file-chart" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">维修报告</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">根本问题: </span>
                    <span>{{bufferRow.rootWarin}}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">解决措施: </span>
                    <span>{{bufferRow.solvingMeasures}}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">改进建议: </span>
                    <span>{{bufferRow.suggestionsImprovement}}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修用时:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.repairTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">维修内容: </span>
                    <span>{{bufferRow.repairContent}}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">工具:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.tool }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">影响时长:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.productAffectTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">是否遗留:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.isLeave==1?'是':'否' }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">遗留原因:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.leaveReason }}</p>
                </v-col>
            </v-row>

        </v-sheet>

        <!-- <v-row no-gutters class="global-botom-btn-box">
            <v-col cols="4">
                <v-btn
                    color="#00E5FF"
                    @click="onReceiveFunc"
                >
                    备件领用
                </v-btn>
            </v-col>
            <v-col cols="4"></v-col>
            <v-col cols="4">
                <v-btn
               
                    color="primary"
                    @click="onSubmit"
                >
                    确认维修
                </v-btn>
            </v-col>

            <v-col cols="4" class="text-right">
                <v-btn
          
                    color="secondary"
                    @click="editExperience"
                >
                    维修经验填写
                </v-btn> 
            </v-col>
        </v-row> -->
        <div style="height: 30px;"></div>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import SelectComponents from '@/packages/Select.vue'
    import {httpHandle} from '@/http/http'  // api
    import UploaderImageComponents from '@/packages/UploaderImage.vue'


    import { showSuccessToast,showFailToast } from 'vant'
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api
    import { showDialog,showToast  } from 'vant'


    import moment from "moment"

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents,
        SelectComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据

        reasonCancellation:"",   // 取消原因

        repairUnit:"",   // 维修单位
        repairCost:"",  //  维修费用


        checked:false,  // 是否外修
        checked2:false,  // 是否报废

        value:"",   // 维修人
        user:"",     // 协助人
        time:"",   // 时间


        value1:"",  //根本问题
        value2:"",  //解决措施
        value3:"",  //改进建议

        value4:"",   // 维修用时
        value5:"",   //  维修内容
        value6:"",   // 工具


        checked3:false,  // 是否遗留 
        value7:"",   // 遗留原因
        value8:"",   // 影响时长



        // 协助人 数据
        repairmanSelectOption:[

        ],
    }),
    created(){
        this.initFunc()
        // this.initRepairman()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {teAdRepairId,filePath=''}=this.$route.query
            const _loginInfo=JSON.parse(localStorage.getItem("bufferUserInfo")||"{}")

            this.value=_loginInfo.userName

            // this.bufferRow=JSON.parse(row)
            this.time=moment(new Date()).format('YYYY-MM-DD HH:mm')



            const {code,data={}}= await httpHandle({
                // url:`/iiot/equipmentRepair/${teAdRepairId}`,
                url:`/iiot/equipmentRepair/equipmentForApp/${teAdRepairId}`,
                method:"get",
            })

            if(code==200){
                this.bufferRow=data
                this.bufferRow.filePath=filePath


                this.$nextTick(()=>{
                    this.value4=Number(this.bufferRow.repairTime||0);   // 维修用时
                    this.value8=Number(this.bufferRow.productAffectTime||0);   // 影响时长
                })
            }
            

        },
        // 查看维修经验
        checkExpress(){
            const {bufferRow}=this


            this.$router.push({
                path:'/equipment/maintain/experience',
                query:{
                    state:"1",
                  teAdRepairId:bufferRow.teAdRepairId,
                  tmBasEquipmentId:bufferRow.tmBasEquipmentId
                }
            })
        },
        // 取消报销
        async cancelReimbursement(){
            const {bufferRow}=this
            const _reasonCancellation=this.reasonCancellation.trim()

            if( !_reasonCancellation  ){
                showFailToast("取消原因必填！")
                return
            }

            showDialog({
                title: '取消',
                message: '取消后数据不可恢复，确认取消！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {

                const {code,data={}}= await httpHandle({
                    url:'/iiot/equipmentRepair/cancelRepairWbForceForApp',
                    method: "post",
                    payload:{
                        teAdRepairId: bufferRow.teAdRepairId,
                        cancelReason: _reasonCancellation,   // 取消原因
                        tmBasEquipmentId: bufferRow.tmBasEquipmentId //当前数据的tmBasEquipmentId字段值
                    }
                })

                if(code==200){
                    showSuccessToast('提交成功！')

                    this.$router.push({
                        path:'/equipment/maintain',
                        query:{ tabs:2 }
                    })
                }

            });




        },
        // 确认维修
        async onSubmit(){
            const {bufferRow,checked,checked2,user}=this

            const {value1='',value2='',value3='',value7=''}=this

            if(!value1.trim()){
                showFailToast("根本问题必填!")
                return
            }

            if( !Number(this.value4) ){
                showFailToast("维修用时必填!")
                return
            }

            if(!this.value5.trim()){
                showFailToast("维修内容必填!")
                return
            }



            if( !Number(this.value8) ){
                showFailToast("影响时长必填!")
                return
            }


            // if(!value3.trim()){
            //     showFailToast("改进建议必填!")
            //     return
            // }

            if(this.checked3 && !value7.trim()){
                showFailToast("遗留原因必填!")
                return
            }

            const _json={
                tmBasEquipmentId: bufferRow.tmBasEquipmentId,  // 当前数据的tmBasEquipmentId字段值,
                teAdRepairId: bufferRow.teAdRepairId,  // 当前数据的tmBasEquipmentId字段值,
                isRepair:checked?1:0, // 当前数据的isRepair字段值 ,
                isScrap:checked2?1:0, // 当前数据的isScrap字段值,
                helpers: user,

                repairUnit: this.repairUnit,   // 维修单位
                repairCost: this.repairCost,  //  维修费用

                rootWarin: value1, // 根本问题
                solvingMeasures: value2,   // 解决措施
                suggestionsImprovement: value3, // 改进建议
                repairTime: this.value4,   // 维修用时
                repairContent : this.value5, // 维修内容
                tool: this.value6, // 工具

                productAffectTime:this.value8, // 影响时长

                productAffectTime: this.value8,    //与生产确认影响时长一致
                isLeave: this.checked3?1:0, //是否遗留 遗留需要填写遗留原因
                leaveReason: this.value7 //根据是否遗留状态显现
            }

            // console.log(_json)
            // return
            const {code,data={}}= await httpHandle({
                url:'/iiot/equipmentRepair/repConfirmWbForApp',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$router.push({
                    path:'/equipment/maintain',
                    query:{ tabs:2 }
                })
            }

        },
        // 报修人
        async initRepairman(){
            const {data=[]}=await RepairmanHTTP()
            this.repairmanSelectOption=data.map(o=> Object.assign({text:`${o.userName}-${o.nickName}`,value:o.userId}))
        },
        // 维修经验填写
        editExperience(){
            const {bufferRow}=this
            // console.log( bufferRow )

            // return
            this.$router.push({
                path:'/equipment/maintain/experienceEdit',
                query:{ teAdRepairId: bufferRow.teAdRepairId }
            })
        },
        // 协助人
        repairmanChange(list){
            // console.log(list)
        },
        // 备件领用
        onReceiveFunc(){
            const {bufferRow,value}=this

            this.$router.push({
                path: '/replacement/index',
                query: {
                    activeType:"equipment",  // 设备
                    row: JSON.stringify( Object.assign(bufferRow,{
                        reportBy:value
                    }))
                    // tmBasEquipmentId: bufferRow.tmBasEquipmentId,
                    // equipmentNo: bufferRow.equipmentNo,
                    // equipmentName: bufferRow.equipmentName,
                }
            })
        }
    },
  }
</script>
