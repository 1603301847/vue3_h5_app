<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <div class="v-window-item-table">
            <!-- :params="{ warinState:'MA' }" -->
            <TableComponents
                ref="table1"
                url="/iiot/equipmentRepair/list"
                :params="{
                    warinState:'MC',
                    reportBy:reportBy
                }"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                            <v-col cols="5">
                                <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                <span class="font-weight-medium">维修设备</span>
                            </v-col>
                            <v-col cols="1">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">故障类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.faultTypeCn }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">故障位置:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.faultStationCn }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">故障详细描述:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.problemDesc)">{{ props.items.problemDesc }}</p>
                            </v-col>
                        </v-row>

                        <UploaderImageComponents
                            :key="props._index"
                            :initPath="props.items.filePath"
                            preview
                        />

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">维修类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ FormatDictionary('equipment_repair_type',props.items.reportType)['lable']   }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">是否外修:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.isRepair?'是':'否' }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">是否报废:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.isStop?'是':'否' }}</p>
                            </v-col>
                        </v-row>
                        <span v-if="props.items.cancelBy">
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">取消人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  props.items.cancelBy }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">取消时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  props.items.cancelTime }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <span class="font-weight-medium text">取消原因:</span>
                                    <span @click="GlobalTooltipFunc(props.items.cancelReason)">{{ props.items.cancelReason }}</span>
                                </v-col>
                            </v-row>
                        </span>

                        <span v-if="!props.items.cancelBy">
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">维修人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  props.items.maintainRepairBy }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">维修结束时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.maintainRepairTime }}</p>
                                </v-col>
                            </v-row>
                        </span>

                        <v-row no-gutters class="text">
                            <v-col cols="4" class="text-left">
                                <p class="font-weight-medium text" style="position: relative;top: 4px;">影响时长:</p>
                            </v-col>
                            <v-col cols="8" class="text-left">
                                <van-field v-model="props.items.productAffectTime" style="padding:0px;" class="custem-input-index1" placeholder="请输入" autocomplete="off" type="number" />
                            </v-col>
                        </v-row>


                         <SelectComponents
                           v-model="props.items.iqcBy"
                           label="质量确认人"
                           showSearch
                           filterSearch
                           single
                           :option="repairmanSelectOption"
                           @on-change="repairmanChange"
                         />


                      <SelectComponents
                        v-model="props.items.technologyBy"
                        label="技术确认人"
                        showSearch
                        filterSearch
                        single
                        :option="repairmanSelectOption"
                        @on-change="repairmanChange"
                      />





                        <v-row no-gutters class="text">
                            <v-col cols="6" class="text-left">
                                <v-btn @click="detailCheckClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">确认维修结束</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'
    import SelectComponents from '@/packages/Select.vue'
    import {RepairmanHTTP} from '@/http/equipment/repairs'
    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';
import { DOMDirectiveTransforms } from '@vue/compiler-dom';

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents,
        TableComponents,
        SelectComponents
    },
    data: () => ({
        reportBy:'',
        iqcBy:"",     // 协助人
        technologyBy:"",     // 协助人
        // 协助人 数据
        repairmanSelectOption:[

        ],

    }),
    created(){
        this.reportBy=JSON.parse( localStorage.getItem("bufferUserInfo")||"{}")["userName"]
        this.initRepairman()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 确认维修  结束
        async detailClick(props){
            const {items}=props


            const {code}=await OverHTTP({
                payload:{
                    productAffectTime: Number(items.productAffectTime||0),   // 影响时长
                    iqcBy:items.iqcBy,
                    technologyBy:items.technologyBy,
                    teAdRepairId: items.teAdRepairId,  // 当前数据的teAdRepairId字段
                    tmBasEquipmentId: items.tmBasEquipmentId,  // 当前数据的tmBasEquipmentId字段值
                    productRepairBy: items.productRepairBy  // 当前数据的productRepairBy字段值


                }
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$refs.table1.initFunc()
            }
        },
        async initRepairman(){
            const {data=[]}=await RepairmanHTTP()
            this.repairmanSelectOption=data.map(o=> Object.assign({text:`${o.userName}-${o.nickName}`,value:o.userName}))
        },
        // 协助人
        repairmanChange(list){
            // console.log(list)
        },
        // 查看详情
        async detailCheckClick(props){
            const {items}=props
            this.$router.push({
                path:'/equipment/equipmentAffirm/detail2',
                query:{
                    teAdRepairId:items.teAdRepairId,
                    filePath: items.filePath
                }
            })
        }


    },
  }
</script>
