<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>已填写</v-tab>
                    <v-tab value="2" hide-slider>未填写</v-tab>
                </v-tabs>
            </template>
        </AppBarPage>
        <div style="height: 50px;"></div>

        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    url="/iiot/equipmentRepairHistory/list"
                    :params="{ 
                        state:'1' ,
                        ...pageSearchConfig1
                    }"
                    :showSearchBtn="true"
                    @searchClick="searchClick1"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="3">
                                    <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                    <span class="font-weight-medium">维修设备</span>
                                </v-col>
                                <v-col cols="8">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.faultTypeCn }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">维修类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ FormatDictionary('equipment_repair_type',props.items.reportType)['lable']    }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障位置:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.faultStationCn }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障详细描述:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.problemDesc)">{{ props.items.problemDesc }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">报修人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.reportBy }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">报修时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.reportTime }}</p>
                                </v-col>
                            </v-row>

                            <span v-if="props.items.cancelBy">
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">取消人:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="text-truncate font-weight-light">{{  props.items.cancelBy }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">取消时间:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="text-truncate font-weight-light">{{  props.items.cancelTime }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="12">
                                        <span class="font-weight-medium text">取消原因:</span>
                                        <span @click="GlobalTooltipFunc(props.items.cancelReason)">{{ props.items.cancelReason }}</span>
                                    </v-col>
                                </v-row>
                            </span>

                            <span v-if="!props.items.cancelBy">
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">维修人:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="text-truncate font-weight-light">{{ props.items.maintainRepairBy }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">维修结束时间:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="text-truncate font-weight-light">{{ props.items.maintainRepairTime }}</p>
                                    </v-col>
                                </v-row>
                            </span>   
                            <v-row no-gutters class="text">
                                <!-- <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col> -->
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-medium text">是否外修: {{ props.items.isRepair?'是':'否' }}</p>
                                </v-col>
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-medium text">是否报废: {{ props.items.isStop?'是':'否' }}</p>
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col>
  
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="6"></v-col>
                                <v-col cols="6" class="text-right">
                                    <v-btn @click="detailClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>
                                </v-col>
                            </v-row>
   
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <v-window-item value="2" class="v-window-item-table">
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    url="/iiot/equipmentRepairHistory/list"
                    :params="{ 
                        state:'0',
                        ...pageSearchConfig2
                    }"
                    :showSearchBtn="true"
                    @searchClick="searchClick2"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="3">
                                    <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                    <span class="font-weight-medium">维修设备</span>
                                </v-col>
                                <v-col cols="8">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.faultTypeCn }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">维修类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ FormatDictionary('equipment_repair_type',props.items.reportType)['lable']    }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障位置:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.faultStationCn }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障详细描述:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.problemDesc)">{{ props.items.problemDesc }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">报修人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.reportBy }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">报修时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.reportTime }}</p>
                                </v-col>
                            </v-row>

                            <span v-if="props.items.cancelBy">
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">取消人:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="text-truncate font-weight-light">{{  props.items.cancelBy }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">取消时间:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="text-truncate font-weight-light">{{  props.items.cancelTime }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="12">
                                        <span class="font-weight-medium text">取消原因:</span>
                                        <span @click="GlobalTooltipFunc(props.items.cancelReason)">{{ props.items.cancelReason }}</span>
                                    </v-col>
                                </v-row>
                            </span>

                            <span v-if="!props.items.cancelBy">
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">维修人:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="text-truncate font-weight-light">{{ props.items.maintainRepairBy }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">维修结束时间:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="text-truncate font-weight-light">{{ props.items.maintainRepairTime }}</p>
                                    </v-col>
                                </v-row>
                            </span>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">是否外修:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.isRepair?'是':'否' }}</p>
                                </v-col>
                            </v-row> -->
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">是否报废:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.isStop?'是':'否' }}</p>
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <!-- <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col> -->
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-medium text">是否外修: {{ props.items.isRepair?'是':'否' }}</p>
                                </v-col>
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-medium text">是否报废: {{ props.items.isStop?'是':'否' }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4" class="text-center">
                                    
                                </v-col>
                                <v-col cols="4" class="text-right">
                                    <v-btn @click="experienceEdit(props)" color="orange mt-1" density="compact" :rounded="0" variant="plain">经验填写</v-btn>
                                </v-col>
                                <v-col cols="4" class="text-center">
                                    <v-btn @click="detailClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>
        </v-window>

        <SearchPage1 
            ref="searchPage1" 
            @resetHandle="resetHandle1"
            @searchHandle="searchHandle1"
        />

        <SearchPage2
            ref="searchPage2" 
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        />


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage1 from './search1.vue' 
    import  SearchPage2 from './search2.vue' 


    import {PreemptHTTP} from '@/http/equipment/maintain'   // api
    import {CancelHTTP} from '@/http/equipment/maintain'   // api

    import { showSuccessToast,showFailToast,showToast } from 'vant';

  export default {
    components:{
        AppBarPage,
        SearchPage1,
        SearchPage2,
        TableComponents
    },
    data: () => ({
        tab: '1',

        pageSearchConfig1:{},  // 查询信息 111
        pageSearchConfig2:{},  // 查询信息 222


    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        initFunc(){
            const {tabs}=this.$route.query

            if(tabs){
                this.tab=tabs
            }
        },
        // 经验填写
        async experienceEdit(props){
            const {items}=props

            this.$router.push({
                path:'/equipmentMessage/detail', 
                query:{ ttAdRepairId: items.ttAdRepairId }
            }) 
        },
        detailClick(props){
            const {items}=props

            this.$router.push({
                path:'/equipmentMessage/maintainDetail',
                query:{
                    ttAdRepairId: props.items.ttAdRepairId,
                    filePath: props.items.filePath
                }
            })
        },
        // 查询 111
        searchClick1(){
            // console.log( this.$refs )
            this.$refs.searchPage1.showDrawer()
        },
        // 查询结果 111
        searchHandle1(option={}){

            this.pageSearchConfig1=option

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置 111
        resetHandle1(opiton){
            this.pageSearchConfig1={}

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 111
        searchClick2(){
            // console.log( this.$refs )
            this.$refs.searchPage2.showDrawer()
        },
        // 查询结果 222
        searchHandle2(option={}){

            this.pageSearchConfig2=option

            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置 222
        resetHandle2(opiton){
            this.pageSearchConfig2={}

            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
    },
  }
</script>