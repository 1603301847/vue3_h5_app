<template>
    <span>



        <van-popup 
            v-model:show="drawer" 
            closeable
            position="right"
            :style="{padding:'12px',width:'90%',height:'100%' }"

        >


            <div style="height: 52px;"></div>

            <!-- <van-field
                v-model="fieldValue"
                is-link
                readonly
                label="工厂节点"
                placeholder="请选择工厂节点"
                type="textarea"
                autocomplete="off"
                @click="show = true"
            />
            <van-popup v-model:show="show" round position="bottom">
                <v-btn
                    block
                    color="cyan"
                    elevation="0"
                    style="border-radius: 0px;"
                    @click="()=> show=false"
                >
                    确定
                </v-btn>
                <van-cascader
                    v-if="showFactory"
                    title="请选择工厂节点"
                    :options="options"
                    active-color="#4CAF50"
                    :field-names="{text:'nodeLevelName',value:'tmBasNodeLevelId',children:'children'}"
                    @close="show = false"
                    @change="onFinish"
                />
            </van-popup> -->

            <SelectComponents 
                v-model="equipment"
                ref="selectContent"
                label="设备"
                placeholderSearch="请输入设备编号"
                showSearch
                :option="equipmentSelectOption"
                @onSearchChange="equipmentSearchChange"

            />

            <DatePickerComponents 
                v-model="dateStart"
                label="报修开始日期" 
                ref="dateTimeStart"
                :columns-type="['year','month','day']"
            />


            <DatePickerComponents 
                v-model="dateOver"
                label="报修结束时间" 
                ref="dateTimeOver"
                :columns-type="['year','month','day']"
            />

            <SelectComponents 
                v-model="user"
                label="报修人"
                ref="user"
                :option="userSelectOption"
            />

            <SelectComponents 
                v-model="userAffirm"
                label="维修人"
                ref="userAffirm"
                :option="userAffirmSelectOption"
            />


            <SelectComponents 
                v-model="property"
                ref="select2"
                label="维修类型"
                :option="propertySelectOption"

            />
            <!-- <SelectComponents 
                v-model="status"
                ref="select3"
                label="状态"
                :option="statusSelectOption"

            /> -->

            <div style="margin-top:32px;">
                <v-row no-gutters>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="()=> drawer=false " density="compact"  variant="plain">关闭</v-btn>
                    </v-col>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="resetClick" density="compact" color="warning" variant="plain">重置</v-btn>
                    </v-col>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="searchClick" density="compact" color="primary" variant="plain">查询</v-btn>
                    </v-col>
                </v-row>
            </div>


        </van-popup>


    </span>
</template>
<script>
    import SelectComponents from '@/packages/Select.vue'
    import {httpHandle} from '@/http/http'  // api
    import DatePickerComponents from '@/packages/DatePicker.vue'
    import { showSuccessToast,showFailToast } from 'vant';


    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import {FormatTree} from '@/utils/data'   // utils
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api

  export default {
    components:{
        SelectComponents,
        DatePickerComponents
    },
    emits: ["searchHandle","resetHandle"],
    data: () => ({
        showFactory:true,  // 工厂
        drawer: false,

        dateStart:"",  // 开始时间
        dateOver:"",    // 结束时间

        show:false,   // 工厂 show
        fieldValue:"",  // 工厂显示值
        options:[],    // 工厂 数据

        factoryID:"",   // 工厂选中ID

        equipment:"",  // 设备
        equipmentSelectOption:[],   // 设备 数据
        equipmentSelectOptionBuffer:[],   // 设备 数据 原始数据


        user:"",              // 点检人
        userSelectOption:[],  // 点检人 数据

        userAffirm:"",              // 确认人
        userAffirmSelectOption:[],  // 确认人 数据


        property:"",   // 任务类型 
        propertySelectOption:[],   // 任务类型  数据

        // status:"",  // 状态
        // statusSelectOption:[],   // 状态数据
    }),
    created(){
        this.initFunc()

        this.equipmentHTTP()
        this.initUserHTTP()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 重置
        resetClick(){
            this.factoryID=''  // 工厂
            this.equipment=''       // 设备
            this.dateStart='' // 开始日期
            this.dateOver=''   // 结束日期
            this.user='' // 实施人
            this.userAffirm='' // 计划人

            this.fieldValue=""  // 工厂


            this.property=""
            this.$refs.select2.reset()

            this.$refs.selectContent.reset()
            this.$refs.dateTimeStart.reset()
            this.$refs.dateTimeOver.reset()

            this.$refs.user.reset()
            this.$refs.userAffirm.reset()

            
            this.showFactory=false
            this.$nextTick(()=>{
                this.showFactory=true
            })
            
            
            this.$emit("resetHandle",{})


        },
        // 初始化 下拉框
        async initFunc(){
            // 数据字典
            // 属性   abnormal_type
            // 状态     abnormal_state
            // 紧急程度   urgent_degree

            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")


            const _selectAttribute=_bufferDictionaries["equipment_repair_type"]||[]    // 维修类型
            // const _selectStatus=_bufferDictionaries["abnormal_state"]||[]     // 状态
            // const _selectUrgentDegree=_bufferDictionaries["urgent_degree"]||[]     // 紧急程度

            this.propertySelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 维修类型
            // this.statusSelectOption=_selectStatus.map(o=>Object.assign({text:o.lable,value:o.value}))   // 状态数据
      


            // 工厂节点数据
            const {data=[]} = await FactoryTreeHTTP()
            const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")
            this.options=_tree
        },
        // 初始化 设备 
        async equipmentHTTP(keyNo=""){
            const {fieldSelectValue={}}=this


            // 展示  equipmentNo +  equipmentName  值  tmBasEquipmentId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipment/list',
                method:"get",
                url_params:{
                    // tmBasNodeLevelId: fieldSelectValue.tmBasNodeLevelId||"",
                    // equipmentType:'星邦设备区域',
                    equipmentNo:keyNo
                }

            }) 

            if(code==200){
                this.equipmentSelectOptionData=data
                this.equipmentSelectOptionBuffer=data

                this.equipmentSelectOption=data.map(o=>Object.assign({
                    text:`${o.equipmentNo}-${o.equipmentName}`,
                    value:o.tmBasEquipmentId
                })).splice(0,100)  
            }
        },
        // 点检人
        async initUserHTTP(){
            const {data=[]}=await RepairmanHTTP()
            this.userSelectOption=data.map(o=> Object.assign({text:`${o.userName}-${o.nickName}`,value:o.userName}))
            this.userAffirmSelectOption=data.map(o=> Object.assign({text:`${o.userName}-${o.nickName}`,value:o.userName}))
        },
        // 工厂 完成
        onFinish ({ selectedOptions }){


            if(!selectedOptions.length) return

            // tmBasNodeLevelId:“465621691089092608
            let _tmBasNodeLevelId= (selectedOptions[ selectedOptions.length-1 ]||{})["tmBasNodeLevelId"]
            
            this.factoryID=_tmBasNodeLevelId
            this.fieldValue = selectedOptions.map((o) => o.nodeLevelName).join('/')
        },
        // 查询
        searchClick(){

            
            if( this.dateStart && !this.dateOver ){
                showFailToast("结束日期必填！")
                return
            }

            if( !this.dateStart && this.dateOver ){
                showFailToast("开始日期必填！")
                return
            }


            if( (new Date( this.dateStart).getTime()) > (new Date( this.dateOver).getTime()) ){
                showFailToast("结束日期必须大于开始日期！")
                return
            }



            // const _listBuffer=this.equipmentSelectOptionBuffer.filter(o=>o.tmBasEquipmentId==this.equipment)[0]||{}
            // console.log( _listBuffer["equipmentName"] )
            // console.log(  )


            const _json={
                // tmBasNodeLevelId : this.factoryID,  // 工厂
                tmBasEquipmentId:  this.equipment,       // 设备
                beginTime:this.dateStart , // 开始日期
                endTime:this.dateOver,  // 结束日期

                reportBy:  this.user, // 维修人
                maintainRepairBy:  this.userAffirm, // 报修人
                reportType: this.property  //   维修类型
            }

            // console.log(_json)
            // return
            this.$emit("searchHandle",_json)
            this.drawer=false

        },
        showDrawer(){
            this.drawer=true
        },
        // 设备查询
        async equipmentSearchChange(key=""){
            this.equipmentHTTP(key)
            // console.log(key)
        },
    },
  }
</script>