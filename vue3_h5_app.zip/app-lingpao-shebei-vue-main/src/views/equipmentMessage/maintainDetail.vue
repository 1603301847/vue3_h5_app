<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">维修设备信息</span>
                </v-col>
                <v-col cols="6" class="text-right">
                    <v-btn @click="checksParePart" color="primary mt-1" density="compact" :rounded="0" variant="plain">备件信息</v-btn>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">故障类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.faultTypeCn }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">故障位置:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.faultStationCn }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">故障详情描述: </span>
                    <span>{{ bufferRow.problemDesc }}</span>
                </v-col>
            </v-row>

            <UploaderImageComponents 
                :initPath="bufferRow.filePath"
                preview
            />

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ FormatDictionary('equipment_repair_type',bufferRow.reportType)['lable']   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">报修人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.reportBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">报修时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.reportTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">响应人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.responseBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">响应时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.responseTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.productRepairBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.productRepairTime }}</p>
                </v-col>
            </v-row>

        </v-sheet>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-tag-text" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">维修经验</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkFile" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修文件</p> -->
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">根本问题:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.rootWarin }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">解决措施:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.solvingMeasures }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">改进建议:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.suggestionsImprovement }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修用时:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.repairTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修内容:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light">{{ bufferRow.repairContent }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">影响时长:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ `${bufferRow.productAffectTime||'0'} 分钟` }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">工具:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.tool }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">经验提交人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.tmWbTalkBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">提交时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.createDate }}</p>
                </v-col>
            </v-row>


        </v-sheet>
            <!-- <v-btn
            elevation="2"
            block
            @click="backList"
            >返回列表</v-btn>    -->
    </span>

    <div style="height:38px;"></div>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import {ExperienceDetailHTTP} from '@/http/equipment/maintain'   // api
    import { showSuccessToast,showFailToast } from 'vant';

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents,
        TableComponents
    },
    data: () => ({
        bufferRow:{}
    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttAdRepairId,filePath=''}=this.$route.query

    
            const {data={}}=await ExperienceDetailHTTP({
                // url_params:{
                //     // "ttAdRepairId":ttAdRepairId, // "当前数据的ttAdRepairId字段值"
                // }
                url_RESTful:`/${ttAdRepairId}`   
            })

            this.bufferRow=data
            this.bufferRow.filePath=filePath
        },
        // 查看维修文件
        checkFile(){
            showSuccessToast('正在建设中！')
        },
        // 返回列表
        backList(){
            this.$router.push({
                path:'/equipment/maintain', 
                query:{ tabs:2 }
            }) 
        },
        // 查看 备件信息
        checksParePart(){
            this.$router.push({
                path:'/outPutHistory/detail',
                query:{ _page:"equipmentMessage",partNo:this.bufferRow.partNo  }
            })
        }

    },
  }
</script>