<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <v-btn style="position:fixed;top:226px;right:16px;z-index: 11;color: #fff !important;width:60px;height:60px;" icon="mdi-plus" color="secondary" @click="AllClick">批量<br/>整改</v-btn>


        <ScanBarComponents 
            :searchLength="10"
            placeholder="请扫描或输入 产品序列号"
            @searchClick="barSearchClick"
        />

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                url="/iiot/qmDefect/list"
                :showSearchBtn="true"
                :auto="false"
                :params="{
                    qmType:'IPQC',
                    ...pageSearchConfig,
                    snNo:_snNo,
                    ttQmDefectMainId: _ttQmDefectMainId
                }"
                @searchClick="searchClick"

            >
                <template v-slot:tableBody="props">
                    <!-- <v-card> -->
                    <v-sheet :elevation="2" rounded style="padding:8px 8px;margin-bottom: 12px;">

                        <v-row no-gutters class="table-title">
                            <v-col cols="11">
                                <van-checkbox v-if="props.items.defectStatus=='20'" v-model="props.items._checked" checked-color="#4CAF50" shape="square" style="position:relative;top:4px;display:inline-block;margin-right:12px;"></van-checkbox>

                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                <span class="font-weight-medium text-right text-right text-teal-lighten-1" color="primary">{{ FormatDictionary('qm_defect_status',props.items.defectStatus)['lable']   }}</span>
                            </v-col>
                            <v-col cols="1" >
                                <!-- <p @click="GlobalTooltipFunc(props.items.partName)" class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                            </v-col>
                            <!-- <v-col cols="10" class="text-right">

                            </v-col> -->
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text" style="color:#00E5FF">{{ props.items.partName }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">供应商:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.supperName   }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">产品类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.partType  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">数量:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.taskQty   }}</p>
                            </v-col>
                        </v-row> -->

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">产品序列号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.snNo }}</p>
                            </v-col>
                        </v-row> -->

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验项目:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.inspectName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验明细:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.inspectDetailName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">不良类别:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.reasonName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">问题描述:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.scrapReason }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">是否通过:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ FormatDictionary('OK_NG',props.items.isOkNg)['lable'] }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">退回原因:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.backReason }}</p>
                            </v-col>
                        </v-row>


                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验员:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.productBy }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验时间 :</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.productDate }}</p>
                            </v-col>
                        </v-row>

                        
                        <v-row v-if="props.items.defectStatus=='20'" no-gutters class="text" style="margin-top:12px;">
      
                            <v-col cols="3">
                                <p style="margin-top:3px;" class="font-weight-medium text input-lable">处理措施:</p>
                            </v-col> 

                            <v-col cols="9" style="position:relative;top:-7px;">
                  
                                <SelectComponents 
                                    v-model="props.items.repairMeasures" 
                                    label=""
                                    :option="opinion4SelectOption"
                                />

                                <!-- <van-field 
                                    v-model="props.items.repairMeasures" 
                                    size="large"
                                    placeholder="请输入"
                                    autocomplete="off"
                                    class="custem-input-index1 custem-input-big"
                                    :style="'padding:0px;'"
                                /> -->
                            </v-col>
                        </v-row>
                        <v-row v-else no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理措施 :</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.repairMeasuresName }}</p>
                            </v-col>
                        </v-row>
              
                        <v-row  v-if="props.items.defectStatus=='20'" no-gutters class="text" style="margin-top:12px;">

                            <v-col cols="3">
                                <p style="margin-top:3px;" class="font-weight-medium text input-lable">整改结果:</p>
                            </v-col> 

                            <v-col cols="9" style="position:relative;top:-7px;">
                            
                                <SelectComponents 
                                    v-model="props.items.repairResult" 
                                    label=""
                                    :option="opinion3SelectOption"
                                />

                                <!-- <van-field 
                                    v-model="props.items.repairResult" 
                                    size="large"
                                    placeholder="请输入"
                                    autocomplete="off"
                                    class="custem-input-index1 custem-input-big"
                                    :style="'padding:0px;'"
                                /> -->
                            </v-col>
                        </v-row>
                        <v-row v-else no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">整改结果 :</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.repairResultName }}</p>
                            </v-col>
                        </v-row>
               

                        <v-row v-if="props.items.defectStatus=='20'" style="margin-top:6px;" no-gutters class="text processDisqualification-index">
                            <v-col cols="12" style="position: relative;left: -14px;">                             
                                <SelectComponents 
                                    v-model="props.items.issueProcessDept"
                                    label="处理部门"
                                    :option="departmentSelectOption"
                       
                                />
                            </v-col>
                        </v-row>

                        <v-row v-if="props.items.issueProcessDept && props.items.defectStatus=='20'" no-gutters class="text processDisqualification-index">
                            <v-col cols="12" style="position: relative;left: -14px;">                             
                                <SelectComponents 
                                    v-model="props.items.deptHandleBy"
                                    label="部门处理人"
                                    showSearch
                                    filterSearch
                                    :option="conductorSelectOption"
                                />
                            </v-col>
                        </v-row>

                        <div style="height:6px;"></div>
                        

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">提报时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.requireTime }}</p>
                            </v-col>
                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="12" class="text-right">
                                <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">不合格处理</v-btn>
                            </v-col>
                        </v-row>
                    </v-sheet>
                    <!-- </v-card> -->
                </template>
            </TableComponents>
        </div>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './search.vue' 
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import SelectComponents from '@/packages/Select.vue'
    import {httpHandle} from '@/http/http'  // api


    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        SearchPage,
        ScanBarComponents,
        TableComponents,
        SelectComponents
    },
    data: () => ({
        _ttQmDefectMainId:"",
        _snNo:'',
        pageSearchConfig:{},  // 查询信息 

        opinion4SelectOption:[],   // 处理措施 数据
        opinion3SelectOption:[],  // 整改结果


        departmentSelectOption:[],   // 处理部门
        conductorSelectOption:[],   // 部门处理人

  
    }),
    created(){
        this.departmentHTTP()
        this.conductortHTTP()

        this.initHandle()
        
        this.chuliGetData()
    },
    methods: {
        // 初始化
        async initHandle(){
            const {ttQmDefectMainId}=this.$route.query



            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            // 整改结果 数据
            const _opinion3SelectOption=_bufferDictionaries["rectify_result"]||[]    // 
            this.opinion3SelectOption=_opinion3SelectOption.map(o=>Object.assign({text:o.lable,value:o.value}))   // 


            this._ttQmDefectMainId=ttQmDefectMainId

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 处理措施
        async chuliGetData(){

            const {code,data=[]}= await httpHandle({
            url:'/iiot/measure/list',
            method: "get",
            url_params:{
                    enabled:"1"
                }
            })

            if(code==200){

                this.opinion4SelectOption=data.map(o=>Object.assign({
                    text: o.measureDeac,
                    value:o.tmBasTreatmentMeasureId
                }))
            }

        },
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()
            
            this._snNo=_value
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

        },
        // 处理部门
        async departmentHTTP(){
            const {code,data=[]}= await httpHandle({
                url: "/system/dict/data/list",
                method: "get",
                url_params:{      
                    enabled:"1",
                    dictType:"qm_process_dept"
                }
            })
           
            if(code==200){
                this.departmentSelectOption=data.map(o=>Object.assign({text:o.dictLabel,value:o.dictValue}))  
            }
        },
        // 部门处理人
        async conductortHTTP(){
            const {code,data=[]}= await httpHandle({
                url: "/system/user/list",
                method: "get",
                url_params:{      
                    enabled:"1",
                }
            })
           
            if(code==200){
                this.conductorSelectOption=data.map(o=>Object.assign({text:o.nickName,value:o.userName}))  
            }
        },
        // 查看工时
        async detailClick(props){
            const {items}=props
            
            
            this.$router.push({
                path:'/processDisqualification/detail', 
                query:{ ttQmDefectId:items.ttQmDefectId  }
            }) 

        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}
            

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
            
        },   
        // 批量整改
        async AllClick(){
            const _select=this.$refs.table1.resultData().filter(o=>o._checked)
            // console.log(_select)

            if(!_select.length){
                showFailToast('未选择数据！')
                return
            }

            const _slect2=_select.map(o=> Object.assign({issueProcessDept:o.issueProcessDept,deptHandleBy:o.deptHandleBy,_index:o._index}) ).filter(k=>k.issueProcessDept&&!k.deptHandleBy)

            if(_slect2.length){
                showFailToast(`第[${_slect2.map(o=>o._index).join()}]条数据，部门处理人必填！`)
                return
            }


            const {code,data=[]}= await httpHandle({
                url:'/iiot/qmDefect/defectRectifyCommit',
                method: "post",
                payload:{
                    defectList:_select
                }
            })

            if(code==200){
                this.$nextTick(()=>{
                    this.$refs.table1.initFunc(1)
                })
            }
        }

    },
  }
</script>

<style lang="scss">
.processDisqualification-index{

    .van-cell.van-field{
        background: inherit;
    }

    .van-cell__title.van-field__label{
        // line-height: 32px;
    }

    .van-cell__value.van-field__value{
        // position: relative;
        // top: 4px;
    }

    .van-badge__wrapper.van-cell__right-icon{
        // margin-top: 4px;
    }
}
</style>