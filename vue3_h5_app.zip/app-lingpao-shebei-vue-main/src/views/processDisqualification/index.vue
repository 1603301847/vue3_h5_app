<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>未完成</v-tab>
                    <v-tab value="2" hide-slider>已完成</v-tab>
                </v-tabs>
            </template>

        </AppBarPage>

        <div style="height: 50px;"></div>


        <ScanBarComponents 
            v-show="tab=='1'"
            ref="ScanBar"
            :searchLength="10"
            placeholder="请扫描或输入 产品序列号"
            @searchClick="barSearchClick"
        />

        <ScanBarComponents 
            v-show="tab=='2'"
            ref="ScanBar2"
            :searchLength="10"
            placeholder="请扫描或输入 产品序列号"
            @searchClick="barSearchClick2"
        />



        <SelectComponents 
            v-show="tab=='1'"
            v-model="measures"
            ref="select11"
            label="质检过程状态"
            :option="measuresSelectOption"
        />
        <SelectComponents 
            v-show="tab=='2'"
            v-model="measures2"
            ref="select22"
            label="质检过程状态"
            :option="measuresSelectOption2"
        />



        <DatePickerComponents 
            v-show="tab=='1'"
            v-model="dateStart"
            label="任务开始日期" 
            ref="dateTimeStart"
            :columns-type="['year','month','day']"
        />
        <DatePickerComponents 
            v-show="tab=='2'"
            v-model="dateStart2"
            label="任务开始日期" 
            ref="dateTimeStart2"
            :columns-type="['year','month','day']"
        />


        <DatePickerComponents 
            v-show="tab=='1'"
            v-model="dateOver"
            label="任务结束时间" 
            ref="dateTimeOver"
            :columns-type="['year','month','day']"
        />
        <DatePickerComponents 
            v-show="tab=='2'"
            v-model="dateOver2"
            label="任务结束时间" 
            ref="dateTimeOver2"
            :columns-type="['year','month','day']"
        />

        <v-btn v-if="tab=='1'" style="position:fixed;top:260px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="secondary" @click="searchFunc">查询</v-btn>
        <v-btn v-if="tab=='1'" style="position:fixed;top:320px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="resetFunc">重置</v-btn>

        <v-btn v-if="tab=='2'" style="position:fixed;top:260px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="secondary" @click="searchFunc2">查询</v-btn>
        <v-btn v-if="tab=='2'" style="position:fixed;top:320px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="resetFunc2">重置</v-btn>


        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">

                <TableComponents
                    ref="table1"
                    url="/iiot/qmDefectMain/list"
                    :showSearchBtn="false"
                    :params="{  
                        queryType:'10',
                        snNo:_snNo,
                        processState: measures,
                        beginTime: dateStart,
                        endTime:dateOver
                    }"
                >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>

                            <v-col cols="8">
                                <p class="text-truncate font-weight-medium text-left text-teal-lighten-1" color="primary">{{ FormatDictionary('defect_finish_state',props.items.status)['lable'] }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-light text-teal-lighten-1">{{ props.items.conversionNo }}</p>
                            </v-col>
                        </v-row> -->
      
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">工厂节点:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.nodeLevelName }}</p>
                            </v-col>
                        </v-row>
                        
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">任务流水号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.taskNo }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">产品序列号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.snNo }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">零件编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.partNo }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验产品:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.partName }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">任务请求时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.requireTime }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">状态 :</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.status }}</p>
                            </v-col>
                        </v-row> -->




                        <v-row no-gutters class="text">
                            <v-col cols="6" class="text-left">
                                <!-- <v-btn  @click="dischargedClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">整改</v-btn> -->
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn  @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">不合格处理列表</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
                </TableComponents>

            </v-window-item>
            <v-window-item value="2" class="v-window-item-table">
                <TableComponents
                    ref="table2"
                    url="/iiot/qmDefectMain/list"
                    :showSearchBtn="false"
                    :params="{  
                        queryType:'20',
                        snNo:_snNo2,
                        processState: measures2,
                        beginTime: dateStart2,
                        endTime:dateOver2
                    }"
                >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>

                            <v-col cols="8">
                                <p class="text-truncate font-weight-medium text-left text-teal-lighten-1" color="primary">{{ FormatDictionary('defect_finish_state',props.items.status)['lable'] }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-light text-teal-lighten-1">{{ props.items.conversionNo }}</p>
                            </v-col>
                        </v-row> -->
      
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">工厂节点:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.nodeLevelName }}</p>
                            </v-col>
                        </v-row>
                        
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">任务流水号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.taskNo }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">产品序列号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.snNo }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">零件编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.partNo }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验产品:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.partName }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">任务请求时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.requireTime }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">状态 :</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.status }}</p>
                            </v-col>
                        </v-row> -->




                        <v-row no-gutters class="text">
                            <v-col cols="6" class="text-left">
                                <!-- <v-btn  @click="dischargedClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">整改</v-btn> -->
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn  @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">不合格处理列表</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
                </TableComponents>
            </v-window-item>
        </v-window>






    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';
    import SelectComponents from '@/packages/Select.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'
    import DatePickerComponents from '@/packages/DatePicker.vue'
    import moment from "moment"


  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        SelectComponents,
        UploaderImageComponents,
        DatePickerComponents,
        TableComponents
    },
    watch: {
        tab: { 
            handler(value){
                if(value=='1'){
                    this.$refs.table1 && this.$refs.table1.initFunc(1)
                }
                if(value=='2'){
                    this.$refs.table2 && this.$refs.table2.initFunc(1)
                }
            },
            deep: true, 
            immediate: true, 
        }
    },
    data: () => ({

        tab: '1',


        _snNo:"",   // 产品序列号
        dateStart:"",  // 开始时间
        dateOver:"",    // 结束时间
        measures:"",            // 质检类别
        measuresSelectOption:[],    // 质检类别 数据


        _snNo2:"",   // 产品序列号2
        dateStart2:"",  // 开始时间2
        dateOver2:"",    // 结束时间2
        measures2:"",            // 质检类别2
        measuresSelectOption2:[],    // 质检类别 数据2
    }),
    created(){
        // this.measuresHTTP()

        this.initHandle()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        initHandle(){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            // 质检类别
            const _selectAttribute=_bufferDictionaries["process_state"]||[]   
            this.measuresSelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   

            this.measuresSelectOption2=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   

            

            this.$nextTick(()=>{

                setTimeout(()=>{

                    // 初始化时间
                    const _date=moment(new Date()).format('YYYY-MM-DD')

                    this.dateStart=_date
                    this.dateOver=_date

                    this.$refs.dateTimeStart && this.$refs.dateTimeStart.setValue(_date)
                    this.$refs.dateTimeOver && this.$refs.dateTimeOver.setValue(_date)



                    this.dateStart2=_date
                    this.dateOver2=_date
                    this.$refs.dateTimeStart2 && this.$refs.dateTimeStart2.setValue(_date)
                    this.$refs.dateTimeOver2 && this.$refs.dateTimeOver2.setValue(_date)

                    setTimeout(()=>{
                        this.$refs.table1.initFunc(1)

                    },200)
                },200)
            })

        },
        // 发起工序
        async measuresHTTP(key=""){
            const {bufferRow}=this


            const {code,data=[]}= await httpHandle({
                url:'/iiot/nodeLevel/listNodeLevelForSelect',
                method:"get",
                url_params:{
                    noOrName:key,
                    templateLevelNodeNo:'uloc',
                    // tmBasNodeLevelId:this.tmBasNodeLevelId,
                    status:"1"
                }

            }) 

            if(code==200){
                this.measuresSelectOption=data.map(o=>Object.assign({
                    text:o.nodeLevelNo +o.nodeLevelName,
                    value:o.tmBasNodeLevelId 
                }))
            } 
        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            this._snNo=_value

            this.$nextTick(()=>{
                setTimeout(()=>{
                    this.$refs.table1.initFunc(1)
                },300)
            })
        },
        // 头部 查询 222
        async barSearchClick2(value=''){
            const _value=value.trim()

            this._snNo2=_value

            this.$nextTick(()=>{
                setTimeout(()=>{
                    this.$refs.table2.initFunc(1)
                },300)
            })
        },

        // 查询
        searchFunc(){

            if( (new Date( this.dateStart).getTime()) > (new Date( this.dateOver).getTime()) ){
                showFailToast("结束日期必须大于开始日期！")
                return
            }

            this.$refs.table1.initFunc(1)
        },

        // 查询22
        searchFunc2(){

            if( (new Date( this.dateStart2).getTime()) > (new Date( this.dateOver2).getTime()) ){
                showFailToast("结束日期必须大于开始日期！")
                return
            }

            this.$refs.table2.initFunc(1)
        },

        // 发起
        addFunc(){
            
            // this.$router.push({
            //     path:'/anomalyInitiateSection/add', 
            //     query:{ }
            // }) 
        },
        // 不合格详情
        async detailClick(props){
            const {items}=props
            // console.log(items)
            // return
            this.$router.push({
                path:'/processDisqualification/index2', 
                query:{ 
                    ttQmDefectMainId: items.ttQmDefectMainId
                }
            }) 

        },
        // 重置
        resetFunc(){


            this._snNo=''
            this.measures=""
            this.dateStart=""  // 开始时间
            this.dateOver=""    // 结束时间

            this.$refs.ScanBar && this.$refs.ScanBar.setInputText('')
            this.$refs.select11 && this.$refs.select11.reset(  )  // 发起工序
            this.$refs.dateTimeStart.reset()
            this.$refs.dateTimeOver.reset()

            this.$nextTick(()=>{
                setTimeout(()=>{
                    this.$refs.table1.initFunc(1)
                },300)
            })
        },
        // 重置 22
        resetFunc2(){


            this._snNo2=''
            this.measures2=""
            this.dateStart2=""  // 开始时间
            this.dateOver2=""    // 结束时间

            this.$refs.ScanBar2 && this.$refs.ScanBar2.setInputText('')
            this.$refs.select22 && this.$refs.select22.reset(  )  // 发起工序
            this.$refs.dateTimeStart2.reset()
            this.$refs.dateTimeOver2.reset()

            this.$nextTick(()=>{
                setTimeout(()=>{
                    this.$refs.table2.initFunc(1)
                },300)
            })
        },
        // 整改
        dischargedClick(props){
            // const {items}=props

            // this.$router.push({
            //     path:'/anomalyInitiateSection/discharged', 
            //     query:{ ttQmAbnormalConversionId: items.ttQmAbnormalConversionId  }
            // }) 
        }


    },
  }
</script>
