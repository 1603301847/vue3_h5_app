<template>
    <div class="backlog-html">
        <AppBarPage>
        </AppBarPage>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-file-edit" size="16" color="indigo"></v-icon>
                    <span class="font-weight-medium">修改密码</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>

            <van-field v-model="oldPassword" :type="showPassword1?'text':'password'" autocomplete="off" required placeholder="请输入" label="旧密码">
                <template #button>
                    <v-icon :icon="!showPassword1 ? 'mdi-eye-off':'mdi-eye'" size="16" @click="showPassword1=!showPassword1"></v-icon>
                </template>
            </van-field>
            <van-field v-model="newPassword" :type="showPassword2?'text':'password'" autocomplete="off" required placeholder="请输入" label="新密码">
                <template #button>
                    <v-icon :icon="!showPassword2 ? 'mdi-eye-off':'mdi-eye'" size="16" @click="showPassword2=!showPassword2"></v-icon>
                </template>
            </van-field>
            <van-field v-model="newPassword2" :type="showPassword3?'text':'password'" autocomplete="off" required placeholder="请输入" label="确认密码">
                <template #button>
                    <v-icon :icon="!showPassword3 ? 'mdi-eye-off':'mdi-eye'" size="16" @click="showPassword3=!showPassword3"></v-icon>
                </template>
            </van-field>

            <div style="height: 16px;"></div>
            <v-row no-gutters style="padding-left: 12px;padding-right: 12px;">
                <v-col cols="12">
                    <v-btn @click="submitHandle" color="primary" block>
                        提交
                    </v-btn>
                </v-col>
            </v-row>

            <div style="height: 12px;"></div>

        </v-sheet>




        <div style="height: 32px;"></div>
    </div>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 待办

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast, showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage
    },
    data: () => ({
        oldPassword:"",   // 旧密码
        newPassword:"",   // 新密码1
        newPassword2:"",   // 新密码2


        showPassword1:false,
        showPassword2:false,
        showPassword3:false,


    }),
    created(){

    },
    methods: {
        async submitHandle(){

            const _oldPassword=this.oldPassword.trim()
            const _newPassword=this.newPassword.trim()
            const _newPassword2=this.newPassword2.trim()


            if(!_oldPassword){
                showFailToast("旧密码必填！")
                return
            }

            const reg=/^(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*,\._\+(){}])[0-9a-zA-Z!@#$%^&*,\\._\+(){}]{8,16}$/;
            if (!reg.test(_newPassword)){
                showFailToast("密码应含有大小写字母，数字，特殊符号(~!@#$%^&*()_.)组合，8-16位")
                return
            }

            if(!_newPassword){
                showFailToast("新密码必填！")
                return
            }

            if(!_newPassword2){
                showFailToast("确认密码必填！")
                return
            }

            if(_newPassword!=_newPassword2){
                showFailToast("新密码与确认密码不一致！")
                return
            }



            const _json={
                oldPassword:_oldPassword,   // 旧密码
                newPassword:_newPassword2,  // 新密码
            }

            const {code}= await httpHandle({
                url:'/system/user/profile/updatePwd',
                method: "put",
                url_params:_json
            })

            if(code==200){
                showSuccessToast("修改成功！")
            }

        }
    },
    props: {

    }
  }
</script>
<style lang="scss">

</style>
