<template>
    <div class="backlog-html">
        <AppBarPage>
        </AppBarPage>

        <ScanBarComponents 
            ref="scanBar"
            placeholder="扫描或输入 工位"
            @searchClick="barSearchClick"
        />

        <v-sheet elevation="2" rounded class="custem-card">

            <SelectComponents 
                v-model="product"
                ref="select8"
                label="选择工位"
                showSearch
                multiple
                :option="productSelectOption"
                @onSearchChange="productSearchChange"
                @onChange="selectPropertyChange"
            />
            <div style="height: 30px;"></div>


            <!-- <v-row no-gutters class="text">
                <v-col cols="3">
                    <p class="font-weight-medium text">当前工位:</p>
                </v-col>
                <v-col cols="9">
                    <p class="font-weight-light text-left">{{ text }}</p>
                </v-col>
            </v-row> -->





            <v-row style="margin-bottom: 18px;margin-top: 12px;" no-gutters class="text">
                <v-col cols="3">
                    <p class="font-weight-medium text">当前工位:</p>
                </v-col>
                <v-col cols="9">

                </v-col>
            </v-row>
            <v-row v-if="stationList.length" v-for="(k,i) in stationList" :key="i" no-gutters class="text">
                <v-col cols="10">
                    <p class="font-weight-light text-left" style="color:#4CAF50;padding-left: 8px;margin-bottom: 6px;">{{ k }}</p>
                </v-col>
                <v-col cols="2">
                    <v-icon color="error" @click="removeHandle(k)">mdi-close-circle</v-icon>
                </v-col>
            </v-row>
            <p v-else style="padding-left: 32px;">未绑定!</p>

            <div style="height: 12px;"></div>
            
        </v-sheet>


        <v-row no-gutters>
            <v-col cols="12">
                <v-btn @click="submitHandle" color="primary" block>
                    提交
                </v-btn>
            </v-col>
        </v-row>
        
        <div style="height: 32px;"></div>
    </div>
</template>
<script>
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import SelectComponents from '@/packages/Select.vue'

    import AppBarPage from '@/components/AppBar.vue' // 待办

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast, showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        SelectComponents
    },
    data: () => ({
        text:"", 
        scanValue:"",

        stationList:[],   // 工位list   

        product:"",   // 工位
        productSelectOption:[],   // 工位数据
    }),
    created(){
        this.initHandle()
        this.productHTTP()

        this.getStation()
    },
    methods: {
        // 获取 绑定工位
        async getStation(){
          const {code,data=[]}= await httpHandle({
            url:'/iiot/userUloc/getUserUlocByUser',
            method:'GET'
          })

          if(code==200){
            this.stationList=data.map(o=> o.nodeLevelNo)
          }
        },

        initHandle(){
            // const _text=JSON.parse( localStorage.getItem("bufferUserStation")||"{}" )


            // if(_text.nodeLevelNo || _text.nodeLevelName){
            //     this.text=`${_text.nodeLevelNo}-${_text.nodeLevelName}`
            // }

        },
        // 头部 查询 
        async barSearchClick(value=''){
            const _value=value.trim()
            // this.scanValue=_value

            if( this.stationList.includes(_value) ){
                showFailToast(`${_value} 已添加！`)
                return
            }


            this.stationList=this.stationList.concat([_value])
        },
        async submitHandle(){

            if( !this.stationList.length ){
                showFailToast("请扫描或选择工位！")
                return
            }

      
            const _json={
                // ulocNo:this.scanValue,
                ulocNos:this.stationList
            }

            const {code}= await httpHandle({
                url:'/iiot/userUloc/saveUserUloc',
                method: "post",
                payload: _json
            }) 

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.push("/")
            }

        },
        // 工位 数据
        async productHTTP(key=''){

            const {code,data=[]}= await httpHandle({
                url:'/iiot/nodeLevel/listNodeLevelForSelect',
                method:"get",
                url_params:{
                    templateLevelNodeNo:'uloc',
                    status:"1",
                    noOrName:key
                    // tmBasNodeLevelId = this.tmBasNodeLevelId;
                }

            }) 

            if(code==200){
                this.productSelectOption=data.map(o=>Object.assign({
                    text:`${o.nodeLevelNo}-${o.nodeLevelName}`,
                    value:o.nodeLevelNo
                })).splice(0,100)
            }
        }, 
        // 工位 查询
        productSearchChange(key){
            this.productHTTP(key)
        },
        // 工位切换
        selectPropertyChange(value=""){
            // this.scanValue=value

            const _list=value.split(",")

            const _result=_list.filter( o=> this.stationList.includes(o) )

            if(_result.length){
                showFailToast(`${JSON.stringify(_result)} 已添加！`)
                return
            }

            this.stationList=this.stationList.concat(_list)

        },
        // 删除
        removeHandle(value){
            this.stationList=this.stationList.filter(o=> o!=value )
        }
    },
    props: {

    }
  }
</script>
<style lang="scss">

</style>