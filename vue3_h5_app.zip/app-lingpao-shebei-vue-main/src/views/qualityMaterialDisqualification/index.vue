<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <v-btn style="position:fixed;top:170px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="resetFunc">重置</v-btn>


        <ScanBarComponents 
            ref="ScanBar"
            placeholder="请输入 任务流水号"
            :showScanIcon="false"
            @searchClick="barSearchClick"
        />

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                url="/iiot/qmDefect/list"
                :showSearchBtn="true"
                :params="{
                    taskNo:_taskNo,
                    qmType:'IQC',
                    ...pageSearchConfig
                }"
                @searchClick="searchClick"

            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="1">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                            </v-col>
                            <v-col cols="10">
                                <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ FormatDictionary('qm_defect_status',props.items.defectStatus)['lable']   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text" style="color:#00E5FF">{{ props.items.partName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <!-- <v-col cols="4">
                                <p class="font-weight-medium text">供应商:</p>
                            </v-col> -->
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">供应商: </span>
                                    {{ props.items.supperName }}
                                </p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-light">
                                    <span class="font-weight-medium text">产品类型: </span>
                                    {{ props.items.partType  }}
                                </p>
                            </v-col>

                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">任务流水号:  </span>
                                    {{ props.items.taskNo }}
                                </p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">数量:  </span>
                                    {{ props.items.taskQty }}
                                </p>
                            </v-col>
                        </v-row>

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col>

                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">提报时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.requireTime }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12" class="text-right">
                                <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">不合格处理</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './search.vue' 
    import ScanBarComponents from '@/packages/ScanBar.vue'

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        SearchPage,
        TableComponents,
        ScanBarComponents
    },
    data: () => ({
        _taskNo:"",   // 检验任务流水 
        pageSearchConfig:{},  // 查询信息 
  
    }),

    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 查看工时
        async detailClick(props){
            const {items}=props
            
            
            this.$router.push({
                path:'/qualityMaterialDisqualification/detail', 
                query:{ ttQmDefectId:items.ttQmDefectId  }
            }) 

        },
        // 头部 查询 111
        async barSearchClick(value=''){
            this._taskNo=value.trim()

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 重置
        resetFunc(){
            this._taskNo=""
            this.$refs.ScanBar && this.$refs.ScanBar.reset() 

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}
            

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
            
        },   


    },
  }
</script>