<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>


        <v-sheet elevation="2" rounded class="custem-card">
            <!-- <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">保养设备信息</span>
                </v-col>
                <v-col cols="6">
                    <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验产品:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.partNo }}-{{ bufferRow.partName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">配送单号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.receiptNo  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">批次号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.batchNo  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">供应商信息:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.supperName  }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ FormatDictionary('test_type',bufferRow.taskType)['lable']   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <!-- <v-col cols="4">
                    <p class="font-weight-medium text"></p>
                </v-col> -->
                <v-col cols="6">
                    <p class="text-truncate font-weight-light">
                        <span class="font-weight-medium text">检验数量: </span>
                        {{ bufferRow.taskQty }}
                    </p>
                </v-col>
                <v-col cols="6" class="text-right">
                    <p class="text-truncate font-weight-light" style="color:#00E5FF;">
                        状态: 
                        <span >{{ FormatDictionary('qm_defect_status',bufferRow.defectStatus)['lable'] }}</span>
                    </p>
                </v-col>
            </v-row>
            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text"></p>
                </v-col>

            </v-row> -->

        </v-sheet>

        <v-sheet class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="tableList"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="10">
                                <!-- <p class="text-truncate font-weight-medium">类别: {{ props.items.inspectDetailName }}</p> -->
                            </v-col>
                            <v-col cols="1" class="text-right">
        
                                <!-- <v-btn @click="deleteHandle(props)" color="red mt-1" density="compact" :rounded="0" variant="plain">删除</v-btn> -->
                            
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium" style="color:#00E5FF;">类别: {{ props.items.inspectDetailName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验标准:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.parameterRange   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">测量结果:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.resultValue }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">判定结果:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.inspectResult   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4" style="padding-left:2px">
                                <p class="font-weight-medium text input-lable" style="margin-top:15px;">不合格描述:</p>
                            </v-col>
                            <v-col cols="8">
                                <van-field  v-model="props.items.reasonDesc" :disabled="readonlyPage" style="padding-left:0px;" class="custem-input-index1" autocomplete="off" placeholder="请输入描述" />
                            </v-col>
                        </v-row>



                    </v-card>
                </template>
            </TableComponents>
        </v-sheet>
        <div style="height: 16px;"></div>

        <v-sheet v-if="showLi1" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-file-edit-outline" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">质量工程师意见</span>
                </v-col>
                <v-col v-show="readonlyPage || readonlyPage11" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>


                <SelectComponents 
                    v-model="result1"
                    ref="select11"
                    label="处理结果"
                    required
                    :disabled="readonlyPage || readonlyPage11"
                    :option="result1SelectOption"
                />

                <!-- <SelectComponents 
                    v-model="type"
                    ref="select111"
                    label="不良类别"
                    :disabled="readonlyPage || readonlyPage11"
                    :option="typeSelectOption"
                /> -->


                <van-field v-model="opinion1" :disabled="readonlyPage || readonlyPage11" autocomplete="off" label="处理意见" placeholder="请输入描述" />

                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px;">
                        <p class="font-weight-medium text">处理人:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.qualityEngineerBy  }}</p>
                    </v-col>
                </v-row>

                <v-row no-gutters class="text" style="margin-bottom:14px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">处理时间:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.qualityEngineerTime  }}</p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">下发到技术:</p>
                    </v-col>
                    <v-col cols="4" style="text-align:right;">
                        <v-switch
                            v-model="_switch11"
                            :label="_switch11?'是':'否'"
                            color="primary"
                            density="comfortable"
                            :disabled="readonlyPage || readonlyPage11"
                            style="top:-12px;left:0px;position:relative;height:40px;display:block;height:48px;width:104px;"
                            ></v-switch>
                    </v-col>
                </v-row>

                <div style="position: relative;top:-16px">
                    <SelectComponents 
                        v-if="_switch11"
                        v-model="conductor7"
                        ref="select777"
                        label="技术处理人"
                        showSearch
                        required
                        :disabled="readonlyPage || readonlyPage11"
                        :option="conductorSelectOption7"
                        @onSearchChange="conductorSearchChange7"
                    />
                </div>


                <v-row no-gutters class="text">
                    <v-col cols="12" style="text-align:right;">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:qualityEngineerForm')"
                            color="warning"
                            :disabled="readonlyPage || readonlyPage11"
                            @click="submitQuality"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi2" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-file-edit-outline" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">技术人员意见</span>
                </v-col>
                <v-col v-show="readonlyPage || readonlyPage22" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>

                <SelectComponents 
                    v-model="result2"
                    ref="select66"
                    label="处理结果"
                    required
                    :disabled="readonlyPage || readonlyPage22"
                    :option="result2SelectOption"
                />

                <van-field v-model="opinion2" :disabled="readonlyPage || readonlyPage22" autocomplete="off" label="处理意见" placeholder="请输入描述" />



                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">处理人:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.technologyBy  }}</p>
                    </v-col>
                </v-row>

                <v-row no-gutters class="text" style="margin-bottom: 14px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">处理时间:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.technologyTime  }}</p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text">
                    <v-col cols="5" style="padding-left:5px">
                        <p class="font-weight-medium text">下发到采购:</p>
                    </v-col>
                    <v-col cols="6" style="text-align:right;">
                        <v-switch
                            v-model="_switch22"
                            :label="_switch22?'是':'否'"
                            color="primary"
                            density="comfortable"
                            :disabled="readonlyPage || readonlyPage22"
                            style="top:-12px;left:0px;position:relative;height:40px;display:block;height:48px;width:104px;"
                            ></v-switch>
                    </v-col>
                </v-row>

                <div style="position: relative;top:-16px">
                    <SelectComponents 
                        v-if="_switch22"
                        v-model="conductor8"
                        ref="select888"
                        label="采购处理人"
                        showSearch
                        required
                        :disabled="readonlyPage || readonlyPage22"

                        :option="conductorSelectOption8"
                        @onSearchChange="conductorSearchChange8"
                    />
                </div>

                <v-row no-gutters class="text">
                    <v-col cols="12" style="text-align:right;">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:technologyForm')"
                            color="warning"
                            :disabled="readonlyPage || readonlyPage22"
                            @click="submitTechnology"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi3" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-cart-minus" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">采购部门处理意见</span>
                </v-col>
                <v-col v-show="readonlyPage || readonlyPage33" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>

                <SelectComponents 
                    v-model="result7"
                    ref="select99"
                    label="处理结果"
                    required
                    :disabled="readonlyPage || readonlyPage33"
                    :option="result2SelectOption"
                />

                <van-field v-model="opinion7" :disabled="readonlyPage || readonlyPage33" autocomplete="off" label="处理意见" placeholder="请输入描述" />



                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">处理人:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.purchaseBy  }}</p>
                    </v-col>
                </v-row>

                <v-row no-gutters class="text" style="margin-bottom: 14px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">处理时间:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.purchaseTime  }}</p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text">
                    <v-col cols="5" style="padding-left:5px">
                        <p class="font-weight-medium text">下发给部长:</p>
                    </v-col>
                    <v-col cols="6" style="text-align:right;">
                        <v-switch
                            v-model="_switch77"
                            :label="_switch77?'是':'否'"
                            color="primary"
                            density="comfortable"
                            :disabled="readonlyPage || readonlyPage33"
                            style="top:-12px;left:0px;position:relative;height:40px;display:block;height:48px;width:104px;"
                            ></v-switch>
                    </v-col>
                </v-row>


                <div style="position: relative;top:-16px">
                    <SelectComponents 
                        v-if="_switch77"
                        v-model="conductor9"
                        ref="select999"
                        label="质量部长"
                        showSearch
                        required
                        :disabled="readonlyPage || readonlyPage33"

                        :option="conductorSelectOption9"
                        @onSearchChange="conductorSearchChange9"
                    />
                </div>


                <v-row no-gutters class="text">
                    <v-col cols="12" style="text-align:right;">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:purchaseCommit')"
                            color="warning"
                            :disabled="readonlyPage || readonlyPage33"
                            @click="submitPurchase"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <v-sheet v-if="showLi4" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-file-edit-outline" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">部长意见</span>
                </v-col>
                <v-col v-show="readonlyPage" cols="6" class="text-right">
                    <v-icon
                        large
                        color="error"
                        >
                        mdi-alert
                        </v-icon>
                    <span class="font-weight-medium" style="color:#B71C1C;">不可编辑</span>
                </v-col>
            </v-row>


                <SelectComponents 
                    v-model="result3"
                    ref="select77"
                    label="处理结果"
                    required
                    :disabled="readonlyPage"
                    :option="result3SelectOption"
                />

                <van-field v-model="opinion3" :disabled="readonlyPage" autocomplete="off" label="处理意见" placeholder="请输入描述" />


                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">处理人:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.qualityMinisterBy  }}</p>
                    </v-col>
                </v-row>

                <v-row no-gutters class="text" style="margin-bottom: 10px;">
                    <v-col cols="4" style="padding-left:5px">
                        <p class="font-weight-medium text">处理时间:</p>
                    </v-col>
                    <v-col cols="8">
                        <p class="text-truncate font-weight-light">{{ bufferRow.qualityMinisterTime  }}</p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text" style="text-align:right;">
                    <v-col cols="12">
                        <v-btn
                            v-show="ControlBtnPermission('iiot:*:qualityMinisterForm')"
                            color="warning"
                            :disabled="readonlyPage"
                            @click="submitMinister"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </v-sheet>

        <div style="height: 60px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import SelectComponents from '@/packages/Select.vue'

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast } from 'vant'
    import { showDialog  } from 'vant'

  export default {
    components:{
        AppBarPage,
        SelectComponents,
        TableComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据


        _switch11:false,  // check 1
        _switch22:false,  // check 2


        conductor7:"",   // 技术处理人
        conductorSelectOption7:[],    // 技术处理人 数据

        conductor8:"",   // 采购处理人
        conductorSelectOption8:[],    // 采购处理人 数据

        conductor9:"",   // 质量部长
        conductorSelectOption9:[],    // 质量部长 数据



        tableList:[],  // table数据

        result1:"",   //  处理结果   1
        result1SelectOption:[],   // 处理结果 数据  1
        opinion1:"",   // 处理意见   1

        result2:"",   //  处理结果   2
        result2SelectOption:[],   // 处理结果 数据  2
        opinion2:"",   // 处理意见   2


        result3:"",   //  处理结果   3
        result3SelectOption:[],   // 处理结果 数据  3
        opinion3:"",   // 处理意见  3

        result7:"",   // 处理结果   采购
        opinion7:"",   // 处理意见   采购
        _switch77:false,  // 采购

        type:"",   // 不良类别
        typeSelectOption:[],   // 不良类别 数据  


        showLi1:false,   // 显示 质量工程师意见
        showLi2:false,   // 显示 技术人员意见
        showLi3:false,   // 显示 采购
        showLi4:false,   // 显示 部长意见
        readonlyPage:true,   // 只读

        readonlyPage11:false,   // 只读 质量工程师意见
        readonlyPage22:false,   // 只读 技术人员意见
        readonlyPage33:false,   // 只读 采购


    }),
    created(){
        this.initFunc()

        this.typeHTTP()


        this.initRepairman7()  // 技术处理人
        this.initRepairman8()  // 采购处理人
        this.initRepairman9()  // 质量部长

    },
    watch: {
        '_switch77': { 
            handler(value){
                if(!value){
                    this.conductor9=''
                }
            },
        },
        '_switch22': { 
            handler(value){
                if(!value){
                    this.conductor8=''
                }
            },
        },
        '_switch11': { 
            handler(value){
                if(!value){
                    this.conductor7=''
                }
            },
        },
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 按钮权限
        ControlBtnPermission(key=""){
            const _page="/qualityMaterialDisqualification/index"
            const _bufferGlobalBtnPermissionlocalStorage=JSON.parse(localStorage.getItem("bufferGlobalBtnPermission")||{})
            const _result=(_bufferGlobalBtnPermissionlocalStorage[_page]||[]).filter(o=>o.perms==key).length?true:false

            // return _result
            return true
        },
        // 初始化
        async initFunc(){
            const {ttQmDefectId}=this.$route.query

            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")


            const _resuilt=_bufferDictionaries["defect_process_type"]||[]    // 处理结果

            this.result1SelectOption=_resuilt.map(o=>Object.assign({text:o.lable,value:o.value}))   // 状态数据
            this.result2SelectOption=_resuilt.map(o=>Object.assign({text:o.lable,value:o.value}))   // 状态数据
            this.result3SelectOption=_resuilt.map(o=>Object.assign({text:o.lable,value:o.value}))   // 状态数据

            
            // 详情 基础数据
            const {code,data={}}= await httpHandle({
               url:`/iiot/qmDefect/${ttQmDefectId}`,
               method: "get",
            })
           
            if(code==200){
                this.bufferRow=data

                // 控制页面
                // data.defectStatus="90"
                switch ( data.defectStatus ) {
                    case '11':   // 质量工程师
                        this.showLi1=true
                        this.showLi2=false
                        this.showLi3=false
                        this.showLi4=false
                        this.readonlyPage=false

                        break;
                    case '21':  // 技术
                        this.showLi1=true
                        this.showLi2=true
                        this.showLi3=false
                        this.showLi4=false
                        this.readonlyPage=false

                        this.readonlyPage11=true  // 只读 质量工程师意见

                        break;
                    case '31':   // 采购
                        this.showLi1=true
                        this.showLi2=true
                        this.showLi3=true
                        this.showLi4=false
                        this.readonlyPage=false

                        this.readonlyPage11=true  // 只读 质量工程师意见
                        this.readonlyPage22=true  // 只读 技术


                        break;
                    case '41':  // 部长
                        this.showLi1=true
                        this.showLi2=true
                        this.showLi3=true
                        this.showLi4=true
                        this.readonlyPage=false

                        this.readonlyPage11=true  // 只读 质量工程师意见
                        this.readonlyPage22=true  // 只读 技术
                        this.readonlyPage33=true  // 只读 采购


                        break;
                    case '90':   // 只读
                        this.showLi1=true
                        this.showLi2=true
                        this.showLi3=true
                        this.showLi4=true
                        this.readonlyPage=true
                        break;
                    default:
                        break;
                }
                

                // 初始化  质量工程师
                this.result1= data.qualityEngineerType // 处理结果
                this._switch11= data.issueTechnology=='1'?true:false // 下发到技术
                this.conductor7=data.unTechnologyBy    // 技术处理人

                this.type= data.tmBasReasonId  // 不良类别
                this.opinion1 = data.qualityEngineerD||''  //处理意见

                // 初始化 技术人员意见
                this.result2= data.technologyType // 处理结果
                this._switch22= data.issuePurchase=='1'?true:false // 下发到采购
                this.opinion2= data.technologyD||'' //处理意见 //处理意见
                this.conductor8= data.unPurchaseBy    // 采购处理人

                

                // 初始化  采购
                this.result7=data.purchaseType   // 处理结果
                this._switch77= data.issueQualityMinister=='1'?true:false  // 下发到质量部长 
                this.opinion7=data.purchaseD||''   //处理意见 //处理意见
                this.conductor9= data.upgradeProcessBy    // 质量部长

          
                // 初始化 部长意见
                this.result3= data.qualityMinisterType // 处理结果
                this.opinion3= data.qualityMinisterD||''   //处理意见    


                setTimeout(()=>{
                    this.$refs.select777 && this.$refs.select777.setValue( data.unTechnologyBy ) // 技术处理人
                    this.$refs.select888 && this.$refs.select888.setValue( data.unPurchaseBy ) // 采购处理人
                    this.$refs.select999 && this.$refs.select999.setValue( data.upgradeProcessBy ) // 质量部长

                    

                    this.$refs.select11 && this.$refs.select11.setValue( data.qualityEngineerType ) // 质量工程师  处理结果 111
                    this.$refs.select66 && this.$refs.select66.setValue( data.technologyType )  // 技术人员意见 处理结果 222
                    this.$refs.select99 && this.$refs.select99.setValue( data.purchaseType )  // 采购 处理结果 222
                    this.$refs.select77 && this.$refs.select77.setValue( data.qualityMinisterType )  // 部长意见 处理结果 333
                },1000)
     
            }
            

            // 详情 列表数据
            const dataResult= await httpHandle({
               url:`/iiot/qmDefectDetail/list`,
               method: "get",
               url_params:{
                ttQmDefectId:ttQmDefectId
               }
            })
           
            if(dataResult.code==200){
                this.tableList=dataResult.data||[]
                this.$nextTick(()=>{
                    this.$refs.table1 && this.$refs.table1.initFunc()
                })
            }
                
        
        },
        // 技术处理人 777
        async initRepairman7(key=''){
            const {code,data=[]}= await httpHandle({
                url:'/system/user/list',
                method:"get",
                url_params:{
                    userKey:key
                }
            }) 

            if(code==200){
                this.conductorSelectOption7=data.map(o=>Object.assign({
                    text:`${o.userName}-${o.nickName}`,
                    value:o.userName
                }))
            }
        },
        // 技术处理人 模糊查询
        conductorSearchChange7(text){
            this.initRepairman7(text)
        },
        // 采购处理人 888
        async initRepairman8(key=''){
            const {code,data=[]}= await httpHandle({
                url:'/system/user/list',
                method:"get",
                url_params:{
                    userKey:key
                }
            }) 

            if(code==200){
                this.conductorSelectOption8=data.map(o=>Object.assign({
                    text:`${o.userName}-${o.nickName}`,
                    value:o.userName
                }))
            }
        },
        // 采购处理人 模糊查询
        conductorSearchChange8(text){
            this.initRepairman8(text)
        },
        // 质量部长 999
        async initRepairman9(key=''){
            const {code,data=[]}= await httpHandle({
                url:'/system/user/list',
                method:"get",
                url_params:{
                    userKey:key
                }
            }) 

            if(code==200){
                this.conductorSelectOption9=data.map(o=>Object.assign({
                    text:`${o.userName}-${o.nickName}`,
                    value:o.userName
                }))
            }
        },
        // 质量部长 模糊查询
        conductorSearchChange9(text){
            this.initRepairman9(text)
        },
        // 不良类别
        async typeHTTP(){
            
            const {code,data=[]}= await httpHandle({
                url:`/iiot/reason/list`,
                method: "post",
                payload:{
                    // pageNum:1,
                    // pageSize:10,          
                    reasonNo:"",
                    params:{
                        reasonTypeList:['MS','F']
                    }
                }
            })
           
            if(code==200){
                this.typeSelectOption=data.map(o=>Object.assign({text:o.reasonNo+'-'+o.reasonName,value:o.tmBasReasonId}))   // 不良类别
            
                setTimeout(()=>{
                    this.$refs.select111 && this.$refs.select111.setValue( this.bufferRow.tmBasReasonId  )  // 质量工程师 不良类别 111
                },1000)
            }
        },
        // 质量工程师提交
        async submitQuality(){
            const {bufferRow}=this


            if( this._switch11 && !this.conductor7){
                showFailToast("技术处理人必填！")
                return
            }


            const _json={
                unTechnologyBy:this.conductor7,   // 技术处理人
                qualityEngineerType: this.result1, // 处理结果
                issueTechnology: this._switch11?'1':'0', // 下发到技术
                tmBasReasonId: this.type,  // 不良类别
                qualityEngineerD: this.opinion1,  //处理意见
                dataList: this.tableList,  // 明细列表reasonDesc

                ttQmDefectId: bufferRow.ttQmDefectId
            }


            if(!this.result1){
                showFailToast('处理结果必选！')
                return
            }


            const {code,data={}}= await httpHandle({
               url:'/iiot/qmDefect/qualityEngineerDefect',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/qualityMaterial/index', 
                    query:{  }
                }) 
            }
        },
        // 技术提交
        async submitTechnology(){
            const {bufferRow}=this

            if( this._switch22 && !this.conductor8){
                showFailToast("采购处理人必填！")
                return
            }

            const _json={
                unPurchaseBy: this.conductor8,  // 采购处理人
                technologyType: this.result2, // 处理结果
                issuePurchase: this._switch22?'1':'0', // 下发到采购
                technologyD: this.opinion2,  //处理意见 //处理意见
                ttQmDefectId: bufferRow.ttQmDefectId

            }

            if(!this.result2){
                showFailToast('处理结果必选！')
                return
            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmDefect/technologyDefect',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/qualityMaterial/index', 
                    query:{  }
                }) 
            }
        },
        // 采购提交
        async submitPurchase(){
            const {bufferRow}=this


            if( this._switch77 && !this.conductor9){
                showFailToast("质量部长必填！")
                return
            }

            const _json={
                upgradeProcessBy: this.conductor9,   // 质量部长
                purchaseType: this.result7, // 处理结果
                issueQualityMinister: this._switch77?'1':'0', // 下发到采购
                purchaseD: this.opinion7,  //处理意见 //处理意见

                ttQmDefectId: bufferRow.ttQmDefectId

            }



            if(!this.result7){
                showFailToast('处理结果必选！')
                return
            }



            const {code,data={}}= await httpHandle({
               url:'/iiot/qmDefect/purchaseCommit',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/qualityMaterial/index', 
                    query:{  }
                }) 
            }


        },
        // 部长提交
        async submitMinister(){
            const {bufferRow}=this


            const _json={
                qualityMinisterType: this.result3, // 处理结果
                qualityMinisterD: this.opinion3,   //处理意见
                ttQmDefectId: bufferRow.ttQmDefectId

            }

            if(!this.result3){
                showFailToast('处理结果必选！')
                return
            }


            const {code,data={}}= await httpHandle({
               url:'/iiot/qmDefect/qualityMinisterDefect',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/qualityMaterial/index', 
                    query:{  }
                }) 
            }

        },
        


    },
  }
</script>