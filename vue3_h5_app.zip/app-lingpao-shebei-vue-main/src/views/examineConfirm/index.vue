<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                url="/iiot/checkTask/list"
                :params="{taskState:'W'}"
                method="post"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="5">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <p class="text-truncate font-weight-medium text">维修设备</p>
                            </v-col>
                            <v-col cols="1" class="text-right">
                                <!-- <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>

                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <!-- <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col> -->
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">所属工厂: </span>
                                    {{ props.items.nodeLevelName   }}</p>
                            </v-col>

                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属车间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.partType  }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属产线:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.taskQty   }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">班次: {{ props.items.shiftNo }}</p>
                            </v-col>
                        </v-row> -->

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">批次号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.checkBatchNo }}</p>
                            </v-col>
                        </v-row> -->

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col>

                        </v-row> -->
                        <v-row no-gutters class="text">
                            <!-- <v-col cols="2">
                                <p class="font-weight-medium text">点检类型:</p>
                            </v-col> -->
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">点检类型:  </span>
                                    {{  FormatDictionary('CHECK_TYPE',props.items.taskType)['lable']  }}</p>
                            </v-col>
                            <!-- <v-col cols="2">
                                <p class="font-weight-medium text"></p>
                            </v-col> -->
                            <!-- <v-col cols="6">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">班次:   </span>
                                    {{ props.items.shiftNo }}
                                </p>
                            </v-col> -->
                        </v-row>
                        <v-row no-gutters class="text">
                            <!-- <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col> -->
                            <v-col cols="6">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">点检人:   </span>
                                    {{ props.items.checkBy }}
                                </p>
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <p class="text-truncate font-weight-light font-weight-medium" style="color:#00E5FF;">状态: {{  FormatDictionary('CHECK_STATE',props.items.taskState)['lable']  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">点检时间:   </span>
                                    {{ props.items.checkStartTime }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="5" class="text-left">
                                <v-btn @click="detailClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">查看点检信息</v-btn>
                            </v-col>
                            <v-col cols="1" class="text-left">

                            </v-col>
                            <v-col cols="3" class="text-right">
                                <v-btn @click="statusClick(props.items,true)" color="primary mt-1" density="compact" :rounded="0" variant="plain">正常</v-btn>
                            </v-col>
                            <v-col cols="3" class="text-right">
                                <v-btn @click="showDialogFunc(props.items)" color="error mt-1" density="compact" :rounded="0" variant="plain">异常</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>

        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round 
            closeable
        >
            <div>
                <p style="font-size: 18px;padding: 8px 0px 8px 6px;">是否报修</p>


                <div style="height:12px;"></div>
                <v-row no-gutters>

                    <v-col cols="5" class="text-center">
                        <v-btn @click="errorFunc(true)" color="primary" block>
                            是
                        </v-btn>
                    </v-col>
                    <v-col cols="2"></v-col>
                    <v-col cols="5" class="text-center">
                        <v-btn @click="errorFunc(false)" color="warning" block>
                            否
                        </v-btn>
                    </v-col>
                </v-row>
                <div style="height:18px;"></div>

            </div>
        </van-popup>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备点检  点检确认
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast, showDialog } from 'vant';


  export default {
    components:{
        AppBarPage,
        TableComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据
        showPicker: false
    }),

    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 查看点检信息
        async detailClick(props){
            const {items}=props


            this.$router.push({
                path:'/examineConfirm/detail',
                query:{ ttCheckTaskId:items.ttCheckTaskId  }
            })

        },
        // 正常 | 异常
        async statusClick(items,active){

            const _json={
                ttCheckTaskId: items.ttCheckTaskId,
                confirmResult: active?"O":"N"
            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/checkTaskRecord/commitCheckTaskRecord',
               method: "post",
               payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.showPicker=false

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc()
                })
            }
        },
        showDialogFunc(items={}){
            this.bufferRow=items  // 行数据
            this.showPicker=true
        },
        // 是否报修
        errorFunc(active){
            const {bufferRow}=this

            if(active){
                //  跳转设备报修
                this.$router.push({
                    path: '/equipment/repairs',
                    query: {
                        tmBasEquipmentId: bufferRow.tmBasEquipmentId,
                        equipmentNo: bufferRow.equipmentNo,
                        equipmentName: bufferRow.equipmentName,
                    }
                })
            }else{
                this.statusClick(bufferRow,false)
            }

        }


    },
  }
</script>
