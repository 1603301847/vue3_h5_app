<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <div>
            <div style="height: 12px;"></div>

            <h3 class="text-center">湖南星邦智能装备股份有限公司</h3>
            <h4 class="text-center">订单配置表</h4>
            <div style="height: 22px;"></div>

            <table class="order-page-table-index1" cellspacing="0">
                <tr>
                    <td class="lable">生产订单号</td>
                    <td>{{ bufferRow?.aufnr }} </td>
                    <td class="lable">序列号</td>
                    <td>{{ bufferRow.sernr }} </td>
                </tr>
                <tr>
                    <td class="lable">物料号</td>
                    <td>{{ bufferRow.matnr }}</td>
                    <td class="lable">物料描述</td>
                    <td>{{ bufferRow.makt }}</td>
                </tr>
                <tr>
                    <td class="lable">使用国别</td>
                    <td colspan="3"> {{ bufferRow.zgb }}</td>
                </tr>
                <tr>
                    <td colspan="4">基本配置要求</td>
                </tr>

                <tr>
                    <td class="lable">特征值</td>
                    <td>特征值描述</td>
                    <td class="lable">特性</td>
                    <td>特性值描述</td>
                </tr>
                
                <tr v-for="(o,i) in list" :key="i">
                    <td class="lable">{{ o.atnam }}</td>
                    <td>{{ o.atbez }}</td>
                    <td class="lable">{{ o.atwrt }}</td>
                    <td>{{ o.atwtb }}</td>

                </tr>

                
            </table>


            <div style="height: 62px;"></div>
        </div>






    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';




  export default {
    components:{
        AppBarPage,

    },
    data: () => ({
        bufferRow:{},
        list:[]

    }),
    created(){
        this.initFunc()
        this.initFunc2()

    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {sn='',orderNo=''}=this.$route.query

            const {code,data={}}= await httpHandle({
                url:`/iiot/orderConfig/getOrderConfigData`,
                method:'get',
                url_params:{
                    aufnr:orderNo,
                    sernr:sn,
                    // aufnr:'10000018865',
                    // sernr:'0103814083',
                }
            })

            if(code==200){
                this.bufferRow=data
            }
        },
        // 初始化2
        async initFunc2(){
            const {sn='',orderNo=''}=this.$route.query

            const {code,data=[]}= await httpHandle({
                url:`/iiot/orderConfig/getOrderConfigList`,
                method:'get',
                url_params:{
                    aufnr:orderNo,
                    sernr:sn,
                    // aufnr:'10000018865',
                    // sernr:'0103814083',
                }
            })

            if(code==200){
                this.list=data
            }
        },



    },
  }
</script>
<style lang="scss">

.order-page-table-index1{
    width: 100%;

    tr td:nth-child(1){
        border-left: 0.8px solid #BDBDBD;
    }
    td {
        border-right: 0.8px solid #BDBDBD;
        // border-bottom: 0.8px solid #BDBDBD;
        border-top: 0.8px solid #BDBDBD;
        padding: 2px 2px;
        text-align: center;
    }

    .lable{
        color: #212121;
        width: 60px;
    }

    border-bottom: 0.8px solid #BDBDBD;

}
</style>