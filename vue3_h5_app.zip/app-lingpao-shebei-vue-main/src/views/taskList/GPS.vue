<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <!-- <ScanBarComponents 
            ref="ScanBar"
            placeholder="请扫描或输入 GPS编码"
            @searchClick="barSearchClick"
        />

        <ScanBarComponents 
            ref="ScanBar2"
            placeholder="请扫描或输入 产品序列号"
            @searchClick="barSearchClick2"
        /> -->

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">基础信息</span>
                </v-col>
                <v-col cols="5">
                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p> -->
                </v-col>
            </v-row>
            <div style="height: 6px;"></div>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">GPS编码:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.gpsn }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品序列号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.sernr }}</p>
                </v-col>
            </v-row>





        </v-sheet>

        <!-- <v-row no-gutters>
            <v-col cols="12" class="text-center">
                <v-btn @click="submit" color="primary" block>绑定</v-btn>
            </v-col>
        </v-row> -->

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'

    import ScanBarComponents from '@/packages/ScanBar.vue'
    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';



  export default {
    components:{
        AppBarPage,
        ScanBarComponents,

    },
    data: () => ({
        bufferRow: {}

    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {sn=''}=this.$route.query

            const {code,data={}}= await httpHandle({
                url:`/iiot/momSapSnGps/getBindingGpsBySn`,
                method:'get',
                url_params:{
                    sernr:sn
                    // sernr:'0506800692'

                }
            })

            if(code==200){
                this.bufferRow=data
            }
        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            const {code,data=[]}= await httpHandle({
                url:'/iiot/qmTask/listQmTaskSnForSelect',
                method: "get",
                url_params:{
                    sn: _value
                }
            })

            if(code==200){

                if(!data.length){
                    showFailToast("SN号不存在！")
                    return
                }    

                // this.ttPpOrderSnId=data[0]?.ttPpOrderSnId
                showSuccessToast("扫描成功！")


            }
        },
        // 扫码  参评序列号
        barSearchClick2(value=''){

        },
        // 绑定
        async submit(){
            
        }



    },
  }
</script>
