<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <v-btn v-if="showBtn" style="width: 62px;height: 62px;position:fixed;top:170px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="secondary" @click="passFunc">通过</v-btn>
        <v-btn v-if="showBtn" style="width: 62px;height: 62px;position:fixed;top:248px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="error" @click="noPassFunc">不通过</v-btn>


        <div class="v-window-item-table">
            <!-- <ScanBarComponents 
                placeholder="请扫描或输入 序列号"
                @searchClick="barSearchClick"
            /> -->
            <TableComponents
                ref="table1"
                url="/iiot/qmDefect/findDefectDate"
                :showSearchBtn="!true"
                :auto="false"
                :params="{
                    ttPpOrderSnId:ttPpOrderSnId,
                    qmType:'IPQC'
    
                }"
                @searchClick="searchClick"

            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">

                            <v-col cols="1" >
                                <van-checkbox v-model="props.items._checkbox" checked-color="#4CAF50"  shape="square" style="width:23px;height:23px;margin-left:6px;">设备</van-checkbox>
                                <!-- <p @click="GlobalTooltipFunc(props.items.partName)" class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                            </v-col>
                            <v-col cols="1">
                                <v-badge style="position: relative;top: -2px;" :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="10" class="text-right">
                                <!-- <p   class="font-weight-medium text-right text-right text-teal-lighten-1" color="primary">{{ FormatDictionary('qm_defect_status',props.items.defectStatus)['lable']   }}</p> -->
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text" style="color:#00E5FF">{{ props.items.partName }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">供应商:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.supperName   }}</p>
                            </v-col>
                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验项目:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.inspectName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验明细:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.inspectDetailName   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验工位:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.nodeLevelName   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">不良描述:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.remark   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">不良类别:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.reasonName   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">整改结果:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.repairResultName   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理措施:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.repairMeasures   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">放行说明:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.releaseMeasures   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">放行人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.releaseBy   }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">整改状态:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ FormatDictionary('ipqc_defect_status',props.items.defectStatus)['lable']   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">是否通过:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ FormatDictionary('OK_NG',props.items.isOkNg)['lable']   }}</p>
                            </v-col>
                        </v-row>

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="12" class="text-right">
                                <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">不合格处理</v-btn>
                            </v-col>
                        </v-row> -->
                    </v-card>
                </template>
            </TableComponents>
        </div>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px',height:'240px',width:'80%'}"
            round 
            closeable
        >
            <div>
                <h3>确认不通过！</h3>

                <div style="margin-top: 32px;">
                    <van-field v-model="value22" type="textarea" required autocomplete="off" placeholder="请输入" label="退回原因" />

                </div>

                            
                    <v-row no-gutters style="margin-top: 22px;">

                        <v-col cols="12" class="text-center">
                            <v-btn @click="submitHandle" color="error" block>
                                确认
                            </v-btn>
                        </v-col>
                    </v-row>
            </div>
        </van-popup>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './searchResult.vue' 
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import {httpHandle} from '@/http/http'  // api


    import { showSuccessToast,showFailToast,showToast,showDialog } from 'vant';


  export default {
    components:{
        AppBarPage,
        SearchPage,
        TableComponents,
        ScanBarComponents
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息 
        showPicker:false,
        value22:"",
        ttPpOrderSnId:"",


        showBtn:false,

        selectList:[]
    }),
    created(){
        this.initHandle()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        async initHandle(){
            const {ttPpOrderSnId}=this.$route.query

            this.ttPpOrderSnId=ttPpOrderSnId

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })


            const {code,data={}}= await httpHandle({
                url:'/iiot/qmTask/getQmTaskDataBySnId/'+ttPpOrderSnId,
                method:"get",
            })

            if(code==200){
                this.showBtn= ( (data.processState=='C') )?true:false
            }
        },
        // 查看工时
        async detailClick(props){
            const {items}=props
            
            
            this.$router.push({
                path:'/processDisqualification/detail', 
                query:{ ttQmDefectId:items.ttQmDefectId  }
            }) 

        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}
            

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
            
        },   

        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            // this.$refs.table1.initFunc(1,{
            //         ttPpOrderSnId: (data[0]||{}).ttPpOrderSnId
            //     })
        },
        // 通过
        async passFunc(){
            const _list=this.$refs.table1.resultData().filter(o=>o._checkbox)

            if(!_list.length){
                showFailToast("未选择数据！")
                return
            }

            showDialog({
                title: '通过',
                message: `已经选择${_list.length}条数据,确认通过！`,
                theme: 'round-button',
                confirmButtonColor:"#4CAF50",
                closeOnClickOverlay:true,
            }).then(async () => {

                const _ids=_list.map(o=>o.ttQmDefectId)    

                const {code}= await httpHandle({
                    url:"/iiot/qmDefect/commitDefectOkOrNg",
                    method:'post',
                    payload:{
                        isOkNg:"OK",
                        idList:_ids
                    }
                })

                if(code==200){
                    this.initHandle()
                }
            });

        },
        // 不通过
        async noPassFunc(){



            const _list=this.$refs.table1.resultData().filter(o=>o._checkbox)

            if(!_list.length){
                showFailToast("未选择数据！")
                return
            }

            this.selectList=_list
            this.value22=""
            this.showPicker=true


            // showDialog({
            //     title: '不通过',
            //     message: `已经选择${_list.length}条数据,确认不通过！`,
            //     theme: 'round-button',
            //     confirmButtonColor:"error",
            //     closeOnClickOverlay:true,
            // }).then(async () => {
                


            // });
        },
        async submitHandle(){

            if( !this.value22 ){
                showFailToast('退回原因！')
                return
            }

            const _ids= this.selectList.map(o=>o.ttQmDefectId)    


            const _json={
                backReason: this.value22,
                isOkNg:"NG",
                idList:_ids
            }


            const {code}= await httpHandle({
                url:"/iiot/qmDefect/commitDefectOkOrNg",
                method:'post',
                payload:_json
            })

            if(code==200){
                this.initHandle()
                this.showPicker=false
            }
        }
    },
  }
</script>