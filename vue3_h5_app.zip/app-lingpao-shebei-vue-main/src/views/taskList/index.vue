<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">基础信息</span>
                </v-col>
                <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p>
                </v-col>
            </v-row>
            <div style="height: 6px;"></div>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品序列号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light">{{ bufferRow.sn }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品物料名称:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{bufferRow.partName}}</p>
                </v-col>
            </v-row>



        </v-sheet>

        <div>
            <v-row no-gutters>



                <v-col cols="12" class="text-center" style="margin-bottom:12px;margin-top: 12px;">
                    <v-btn @click="orderHandle" color="#26C6DA" style="color:#fff;" block>订单配置</v-btn>
                </v-col>

                <v-col cols="12" class="text-center" style="margin-bottom:12px;">
                    <v-btn @click="GPSHandle" color="#00796B" style="color:#fff;" block>GPS绑定</v-btn>
                </v-col>

                <v-col cols="12" class="text-center" style="margin-bottom:12px;">
                    <v-btn @click="putStorageHandle" color="#FF9100" style="color:#fff;" block>异常转序</v-btn>
                </v-col>

                <v-col cols="12" class="text-center" style="margin-bottom:12px;">
                    <v-btn @click="resultHandle" color="#9E9D24" style="color:#fff;" block>整改任务</v-btn>
                </v-col>

                <v-col cols="12" class="text-center" style="margin-bottom:12px;">
                    <v-btn @click="putInStorageHandle" color="#7B1FA2" style="color:#fff;" block>入库检</v-btn>
                </v-col>
            </v-row>
        </div>


        <div style="height:6px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 异常处理 详情
    import {httpHandle} from '@/http/http'  // api


    import { showSuccessToast,showFailToast } from 'vant'


  export default {
    components:{
        AppBarPage,
    },
    data: () => ({
        bufferRow:{},  // 行数据


    }),
    created(){
        this.initFunc()

    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmTaskId}=this.$route.query

            // 基础数据
            const {code,data={}}= await httpHandle({
                url:`/iiot/qmTask/getQmTaskData/${ttQmTaskId}`,
                method:'get'
            })

            if(code==200){
                this.bufferRow=data.qmTaskData||{}
            }

            // const {code,data={}}= await httpHandle({
            //     // url:'/iiot/abnormal',
            //     url:'/iiot/abnormal/getInfoByShow',
            //     method:"get",
            //     url_RESTful:`/${ttQmAbnormalId}`   
            // })

            // if(code==200){
            //     this.bufferRow=data

            //     // 图片预览 11
            //     if(data.initiatePath){
            //         this.bufferFileListPreviewInitiatePath=data.initiatePath.split(',').map(o=>Object.assign({url:o}))
            //     }

            //     // 图片预览 22
            //     if(data.managePath){
            //         this.bufferFileListPreviewManagePath=data.managePath.split(',').map(o=>Object.assign({url:o}))
            //     }

            // }


        },
        // 异常转序
        putStorageHandle(){
            const {bufferRow}=this
            
            this.$router.push({
                path:'/anomalyInitiateSection/search', 
                query:{ _sn: bufferRow.sn }
            }) 
        },
        // 订单配置
        orderHandle(){
            const {bufferRow}=this

            this.$router.push({
                path:'/taskList/order', 
                query:{orderNo:bufferRow.orderNo,sn:bufferRow.sn}
            }) 
        },
        // GpS 绑定
        GPSHandle(){
            const {bufferRow}=this
            this.$router.push({
                path:'/taskList/GPS', 
                query:{sn: bufferRow.sn }
            }) 
        },
        // 整改任务
        resultHandle(){
            const {bufferRow}=this

            this.$router.push({
                path:'/taskList/result', 
                query:{ ttPpOrderSnId: bufferRow.ttPpOrderSnId }
            }) 
        },
        // 入库检
        putInStorageHandle(){
            const {qcType,_pageActive,ttQmTaskId,_pageIndex}=this.$route.query

            this.$router.push({
                path:'/process/detail4', 
                query:{  qcType:'IPQCC', _pageActive: _pageActive, ttQmTaskId: ttQmTaskId, _pageIndex:4 }
            })  
        }

    },
  }
</script>