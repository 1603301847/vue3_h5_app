<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>当前保养任务</v-tab>
                    <v-tab value="2" hide-slider>我的保养任务</v-tab>
                </v-tabs>
            </template>
        </AppBarPage>
        <div style="height: 50px;"></div>

        <v-btn style="position:fixed;top:220px;right:16px;z-index: 11;color: #fff !important;width:60px;height:60px;" icon="mdi-plus" color="secondary" @click="AllHandle">批量<br/>指派</v-btn>


        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <ScanBarComponents
                    ref="scanBar1"
                    placeholder="扫描或输入 设备编码"
                    @searchClick="barSearchClick"
                />

                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    url="/iiot/mainTask/list"
                    :showSearchBtn="true"
                    :params="{
                        wbMais:'WI',params:{typeList:['A','B','C','D']},
                        tmBasEquipments:tmBasEquipments,
                        ...pageSearchConfig1
                    }"
                    method="post"
                    @searchClick="searchClick1"
                    refreshFunc
                    @refresh="refreshTable"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="8">
                                    <van-checkbox v-if="!props.items.implementBy" v-model="props.items._checked" checked-color="#4CAF50" shape="square" style="position:relative;top:4px;display:inline-block;margin-right:12px;"></van-checkbox>
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                    <span class="font-weight-medium">保养设备</span>

                                </v-col>
                                <!-- <v-col cols="4">
                                    <span class="font-weight-medium">保养设备</span>
                                </v-col> -->
                                <!-- <v-col cols="7">
                                    <p @click="GlobalTooltipFunc(props.items.equipmentName)" class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col> -->
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">设备类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  props.items.equipmentType  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">任务类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  FormatDictionary('WB_TT',props.items.wbTt)['lable']  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">是否超期:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  FormatDictionary('sys_yes_no',props.items.isExpire)['lable']  }}  </p>
                                </v-col>
                            </v-row>

                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">保养部位:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.faultStationCn)">{{ props.items.faultStationCn  }}</p>
                                </v-col>
                            </v-row> -->
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">保养方法:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.manitainContent)">{{ props.items.manitainContent  }}</p>
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">周期:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  FormatDictionary('WB_ST',props.items.wbSt)['lable']  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">计划保养人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.planImplementBy  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text" v-if="props.items.implementBy">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">指派人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.implementBy  }}</p>
                                </v-col>
                            </v-row>



                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">责任人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.zrPerson  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light text-left">
                                        到期时间:
                                        {{ props.items.expireTime}}
                                    </p>
                                </v-col>
                                <!-- <v-col cols="2">
                                    <p class="font-weight-medium text text-right">
                                        <span :class=" props.items.expireStatus=='0'?'text-cyan-lighten-1':'text-red-darken-4' ">{{ props.items.expireStatus=='0'?'未到期':'已到期' }}</span>

                                    </p>
                                </v-col> -->
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4" class="text-center">

                                </v-col>
                                <v-col cols="4" class="text-center">

                                </v-col>
                                <v-col cols="4" class="text-right">
                                    <v-btn @click="()=> this.experienceEditShow('singgle',props) " color="orange mt-1" density="compact" :rounded="0" variant="plain">指派</v-btn>
                                </v-col>
                            </v-row> -->
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <v-window-item value="2" class="v-window-item-table">
                <ScanBarComponents
                    ref="scanBar1"
                    placeholder="扫描或输入 区域码"
                    @searchClick="barSearchClick2"
                />
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    method="post"
                    :showSearchBtn="true"
                    url="/iiot/mainTask/listForApp"
                    :params="{
                        wbMais:'IO',params:{typeList:['A','B','C','D']},
                        tmBasEquipments:tmBasEquipments,
                        ...pageSearchConfig2
                    }"
                    @searchClick="searchClick2"
                    refreshFunc
                    @refresh="refreshTable"

                >
                <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="4">
                                    <span class="font-weight-medium">保养设备</span>
                                </v-col>
                                <v-col cols="7">
                                    <!-- <p @click="GlobalTooltipFunc(props.items.equipmentName)" class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">任务类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  FormatDictionary('WB_TT',props.items.wbTt)['lable']  }}  </p>
                                </v-col>
                            </v-row>


                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">是否超期:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  FormatDictionary('sys_yes_no',props.items.isExpire)['lable']  }}  </p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">设备类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  props.items.equipmentType  }}</p>
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">保养部位:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.faultStationCn)">{{ props.items.faultStationCn  }}</p>
                                </v-col>
                            </v-row> -->
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">保养方法:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.manitainContent)">{{ props.items.manitainContent  }}</p>
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">周期:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{  FormatDictionary('WB_ST',props.items.wbSt)['lable']  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">计划保养人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.planImplementBy  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">

                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light text-left">
                                        到期时间:
                                        {{ props.items.expireTime}}
                                    </p>
                                </v-col>
                                <!-- <v-col cols="2">
                                    <p class="font-weight-medium text text-right">
                                        <span :class=" props.items.expireStatus=='0'?'text-cyan-lighten-1':'text-red-darken-4' ">{{ props.items.expireStatus=='0'?'未到期':'已到期' }}</span>

                                    </p>
                                </v-col> -->
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4" class="text-center">

                                </v-col>
                                <v-col cols="4" class="text-center">
                                    <v-btn @click="cancelHandle(props)" color="red mt-1" density="compact" :rounded="0" variant="plain">取消保养</v-btn>
                                </v-col>
                                <v-col cols="4" class="text-right">
                                    <v-btn @click="reportHandle(props)" color="orange mt-1" density="compact" :rounded="0" variant="plain">实施保养</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>
        </v-window>


        <SearchPage1
            ref="searchPage1"
            :hideStatus="false"
            page="1"
            @resetHandle="resetHandle1"
            @searchHandle="searchHandle1"
        />

        <SearchPage2
            ref="searchPage2"
            :hideStatus="false"
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        />

        <span class="hide-select-equipment-input">
            <SelectComponents
                v-if="showSelect"
                ref="selectContent"
                label="设备"
                placeholderSearch="请输入设备编号"
                :forbidShow="true"
                required
                multiple
                showSearch
                :option="equipmentSelectOption"
                @onSearchChange="equipmentSearchChange"
                @onChange="equipmentConfirm"
            />
        </span>


        <van-popup
            v-model:show="showPicker"
            closeable
            position="right"
            :style="{padding:'12px',width:'90%',height:'100%' }"
        >

            <div>
                <p style="font-size: 18px;padding: 8px 0px 8px 6px;">指派维修员</p>
                <!-- <div style="height:12px"></div> -->
                <SelectComponents
                    v-model="user"
                    label="实施人"
                    ref="select777"
                    showSearch
                    filterSearch
                    required
                    :option="userSelectOption"
                />

                <div style="height:12px;"></div>
                <v-row no-gutters style="padding: 0px 6px;">
                    <v-col cols="12" class="text-center">
                        <v-btn
                            color="primary"
                            block
                            @click="()=> this.experienceEdit() "
                        >
                            确认
                        </v-btn>
                    </v-col>
                </v-row>

                <div style="height: 22px;"></div>
            </div>
        </van-popup>


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage1 from './search.vue'
    import  SearchPage2 from './search.vue'
    import {httpHandle} from '@/http/http'  // api
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import SelectComponents from '@/packages/Select.vue'


    import { showSuccessToast,showFailToast,showToast } from 'vant'
    import { showDialog  } from 'vant'
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api



  export default {
    components:{
        AppBarPage,
        SearchPage1,
        ScanBarComponents,
        SelectComponents,
        SearchPage2,
        TableComponents
    },
    data: () => ({
        tab: '1',
        showSelect:true,

        showPicker: false,
        bufferRocode:{},  // 行数据
        bufferTree:[],   // 工厂数据

        _teWbMainTaskIds:[],  // 批量指派

        user:"",              // 点检人
        userSelectOption:[],  // 点检人 数据


        pageSearchConfig1:{},  // 查询信息   11
        pageSearchConfig2:{},  // 查询信息   22

        tmBasNodeLevelId:"",   // 设备ID
        equipment:"",  // 设备
        tmBasEquipments:[],   // 设备ID 数组
        equipmentSelectOption:[],   // 设备 数据
        equipmentSelectOptionData:[],  // 设备 原始 数据
    }),
    created(){
        this.initFunc()
        this.factoryTreeHTTP()
        this.initUserHTTP()

        // 刷新页面
        const { $emitter } = this.$root;
        $emitter.on("update_maintain_page",()=>{
            this.initFunc()
            this.factoryTreeHTTP()
            this.refreshTable()
        });
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        initFunc(){
            const {tabs}=this.$route.query

            if(tabs){
                this.tab=tabs
            }
        },
        // 点检人
        async initUserHTTP(){
            const {data=[]}=await RepairmanHTTP()
            this.userSelectOption=data.map(o=> Object.assign({text:`${o.userName}-${o.nickName}`,value:o.userName}))
        },
        // table 刷新
        refreshTable(){

            this.$refs["scanBar1"] && this.$refs["scanBar1"].reset()
            this.$refs["scanBar2"] && this.$refs["scanBar2"].reset()
            this.tmBasEquipments=[]

            this.$nextTick(()=>{
                if(this.tab=="1"){
                    this.$refs.table1.initFunc(1,{})
                }

                if(this.tab=="2"){
                    this.$refs.table2.initFunc(1,{})
                }
            })

        },
        // 设备查询
        async equipmentSearchChange(key=""){
            this.equipmentHTTP(key)
        },
        // 初始化 设备
        async equipmentHTTP(keyNo=""){
            const {tmBasNodeLevelId}=this
            // 展示  equipmentNo +  equipmentName  值  tmBasEquipmentId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipment/list',
                method:"get",
                url_params:{
                    tmBasNodeLevelId: tmBasNodeLevelId,
                    equipmentNo:keyNo
                }

            })

            if(code==200){
                this.equipmentSelectOptionData=data
                this.equipmentSelectOption=data.map(o=>Object.assign({
                    text:`${o.equipmentNo}-${o.equipmentName}`,
                    value:o.tmBasEquipmentId
                })).splice(0,100)
            }
        },
        // 设备 选中
        equipmentConfirm(value=''){
            // const _obj=this.equipmentSelectOptionData.filter(o=>o.tmBasEquipmentId==value)[0]||{}

            this.tmBasEquipments=(value?value.split(","):[])


            this.$nextTick(()=>{
                if(this.tab=="1"){
                    this.$refs.table1.initFunc(1,{})
                }

                if(this.tab=="2"){
                    this.$refs.table2.initFunc(1,{})
                }
            })

        },
        // 工厂数据
        async factoryTreeHTTP(){
            const {data=[]} = await FactoryTreeHTTP()
            this.bufferTree=data

        },
        // 指派 弹框
        experienceEditShow(active,props={}){
            const {items}=props

            this.user=""
            this._teWbMainTaskIds=[]
            this.$refs.select777 && this.$refs.select777.reset()


            // 单个
            if(active=='singgle'){
                this.bufferRocode=items
                this.showPicker=true
            }

            // 多个
            if(active=='all'){

                const _select=this.$refs.table1.resultData().filter(o=>o._checked)

                if(!_select.length){
                    showFailToast('未选择数据！')
                    return
                }

                if( _select.filter(o=>o.implementBy).length ){
                    showFailToast('已指派数据，不能再指派！')
                    return
                }

                this.showPicker=true
                this._teWbMainTaskIds=_select.map(o=>o.teWbMainTaskId)
            }

        },
        // 批量指派
        AllHandle(){
            this.experienceEditShow("all")
        },
        // 指派
        async experienceEdit(){
            const {bufferRocode}=this

            // 实施人
            if( !this.user ){
                showFailToast('实施人必选！')
                return
            }


            let _json={}

            // 多个 单个
            if(this._teWbMainTaskIds.length){
                _json={
                    implementBy: this.user,   // 指派人
                    teWbMainTaskIds: this._teWbMainTaskIds,    // 批量指派
                    teWbMainTaskId: bufferRocode.teWbMainTaskId,  // 当前数据的teWbMainTaskId字段  维保任务id,
                    // wbMais: bufferRocode.wbMais,  // 当前数据的wbMais字段  实施状态  IO（实施中）
                    wbMais: "IO",  // 当前数据的wbMais字段  实施状态  IO（实施中）
                }
            }else(
                _json={
                    implementBy: this.user,   // 指派人
                    teWbMainTaskId: bufferRocode.teWbMainTaskId,  // 当前数据的teWbMainTaskId字段  维保任务id,
                    // wbMais: bufferRocode.wbMais,  // 当前数据的wbMais字段  实施状态  IO（实施中）
                    wbMais: "IO",  // 当前数据的wbMais字段  实施状态  IO（实施中）
                }
            )


            const {code}= await httpHandle({
                url:"/iiot/mainTask/responseTask",
                method:'PUT',
                payload: _json
            })


            if(code==200){
                this.showPicker=false

                showSuccessToast('提交成功！')
                this.$refs.table1.initFunc()
            }


        },
        // 取消保养
        async cancelHandle(props){
            const {items}=props

            showDialog({
                title: '取消确认',
                message: '取消后数据不可恢复，确认取消！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {


                const {code}= await httpHandle({
                    url:"/iiot/mainTask/cancelwbImp",
                    method:'post',
                    payload:{
                        teWbMainTaskId: items.teWbMainTaskId,  // 当前数据的teWbMainTaskId字段  维保任务id,
                    }
                })


                if(code==200){
                    showSuccessToast('提交成功！')
                    this.$refs.table2.initFunc()
                }


            });




        },
        // 实施报工
        async reportHandle(props){
            const {items}=props

            this.$router.push({
                path:'/maintain/detail',
                // query:{ row: JSON.stringify(items)  }
                query:{ teWbMainTaskId: items.teWbMainTaskId  }
            })
        },
        // 头部 查询 11
        async barSearchClick(value=''){
            const _value=value.trim()
            // const _newList=this.bufferTree.filter(o=>o.nodeLevelNo==_value)[0]||{}
            // if(!_newList.tmBasNodeLevelId){
            //     showFailToast("无工厂节点！")
            //     return
            // }

            this.showSelect=false
            // this.tmBasNodeLevelId=_newList.tmBasNodeLevelId
            this.$nextTick(async()=>{

                this.showSelect=true
                await this.equipmentHTTP(_value)


                this.$nextTick(()=>{
                    this.$refs.selectContent.showModle()
                })
            })


        },
        // 头部 查询 22
        async barSearchClick2(value=''){
            const _value=value.trim()

            const _newList=this.bufferTree.filter(o=>o.nodeLevelNo==_value)[0]||{}
            if(!_newList.tmBasNodeLevelId){
                showFailToast("无工厂节点！")
                return
            }

            this.showSelect=false
            this.tmBasNodeLevelId=_newList.tmBasNodeLevelId
            this.$nextTick(async()=>{

                this.showSelect=true
                await this.equipmentHTTP("")

                this.$nextTick(()=>{
                    this.$refs.selectContent.showModle()
                })
            })

        },
        // 查询 11
        searchClick1(){
            this.$refs.searchPage1.showDrawer()
        },
        // 查询结果 11
        searchHandle1(option){
            this.pageSearchConfig1=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置 11
        resetHandle1(opiton){
            this.pageSearchConfig1={}
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

        },
        // 查询 22
        searchClick2(){
            this.$refs.searchPage2.showDrawer()
        },
        // 查询结果 22
        searchHandle2(option){
            this.pageSearchConfig2=option
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置 22
        resetHandle2(opiton){
            this.pageSearchConfig2={}


            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })

        },
    },
  }
</script>
<style lang="scss">
.hide-select-equipment-input{
    >span >div.van-cell {
        visibility: hidden;
    }
}
</style>
