<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <ScanBarComponents 
            v-if="!isDetail"
            ref="scanBar"
            placeholder="扫描或输入原材料信息"
            @searchClick="barSearchClick"
        />

        <!-- <van-field v-model="code" placeholder="请输入" autocomplete="off" label="编码" /> -->

        <!-- <v-btn
            block
            @click="addHandle"
        >
            扫码添加
        </v-btn> -->

        <v-sheet elevation="2" rounded class="custem-card">
            <!-- <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">保养设备信息</span>
                </v-col>
                <v-col cols="6">
                    <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验产品:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.partNo}}-{{bufferRow.partName}}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">配送单号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.receiptNo  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">供应商信息:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.supplierName  }}</p>
                </v-col>
            </v-row>
            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">任务流水号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.taskNo  }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验数量:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.taskQty  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">状态:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light" style="color:#00E5FF;">{{ FormatDictionary("qm_task_status",bufferRow.taskStatus)["lable"]  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">任务流水号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.taskNo  }}</p>
                </v-col>
            </v-row>
        </v-sheet>

        <v-sheet class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="tableList"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="7">
                                <!-- <v-icon icon="mdi-pencil-outline" size="16" color="primary"></v-icon> -->
                                <p class="text-truncate font-weight-medium">批次号: {{ props.items.batchNo }}</p>
                            </v-col>
                            <v-col cols="2" class="text-right">
                                <p style="color: #4caf50;">{{ props.items.inspectBy?"完成":"" }}</p>
                            </v-col>
                            <v-col cols="2" class="text-right">
        
                                <v-btn   
                                    v-if="!isDetail"
                                    @click="deleteHandle(props)" style="position:relative;top:-4px" color="red" density="compact" :rounded="0" variant="plain">删除</v-btn>
                            
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">出厂日期: </p>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light">{{ props.items.remark01   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">检验类型: </p>
                            </v-col>
                            <v-col cols="5">
                                <p class="text-truncate font-weight-light">{{  FormatDictionary("QM_BY_TYPE",props.items.batchType)["lable"] }}</p>
                            </v-col>
                            <v-col cols="4" class="text-right">
                                <p class="text-truncate font-weight-light" :style="props.items.inspectResult=='10'?'color:#4CAF50':'color:#FF5722'">状态: {{ props.items.inspectResult=='10'?'合格':'不合格'   }}</p>
                            </v-col>
                        </v-row>

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text"></p>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light" :style="props.items.inspectResult=='10'?'color:#4CAF50':'color:#FF5722'">状态: {{ props.items.inspectResult=='10'?'合格':'不合格'   }}</p>
                            </v-col>
                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">报检时间:</p>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light">{{ props.items.createDate   }}</p>
                            </v-col>
                        </v-row>

                        <v-row style="margin-top: 0px;">
                            <v-col cols="12">
                                <p class="font-weight-medium text">
                                    检验人:
                                    <span>{{ props.items.inspectBy }}</span>
                                </p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text input-lable" style="margin-top:14px;">检验数量: </p>
                            </v-col>
                            <v-col cols="3" style="padding-left:4px;">
                                <van-field 
                                    class="custem-input-index1"
                                    v-model="props.items.batchQty" 
                                    style="padding-left:0px;"
                                    type="number" 
                                    size="large"
                                    autocomplete="off"
                                    :disabled="(props.items.ttQmTaskBatchId || !isDetail)?true:false"
                                    placeholder="输入检验数量"
                                />
                            </v-col>
                            <v-col cols="3">
                                <v-btn
                                    v-if="(!props.items.ttQmTaskBatchId || !isDetail)?true:false"
                                    depressed
                                    color="primary"
                                    style="margin-top:8px;"
                                    @click="onSubmit(props)"
                                >
                                    提交
                                </v-btn>
                            </v-col>
                          
                            <v-col cols="3">
                                <v-btn
                                    v-if="!isDetail"
                                    depressed
                                    color="warning"
                                    style="margin-top:8px"
                                    @click="onCheckout(props)"
                                >
                                    检验
                                </v-btn>
                            </v-col>
                        </v-row>



                    </v-card>
                </template>
            </TableComponents>
        </v-sheet>

        <div style="height: 60px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast } from 'vant'
    import { showDialog  } from 'vant'

  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        TableComponents
    },
    data: () => ({
        isDetail:false,
        ttQmTaskId:'',  // ttQmTaskId  
        bufferRow:{},  // 行数据

        code:"",
        tableList:[],  // table数据
    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmTaskId,row="{}",_pageActive}=this.$route.query
            
            this.isDetail=((_pageActive=="detail")?true:false)

            this.ttQmTaskId=ttQmTaskId
            this.bufferRow=JSON.parse(row)
            // console.log( ttQmTaskId )

            this.$nextTick(async()=>{

                const {code,data=[]}= await httpHandle({
                    url:`/iiot/qmTaskBatch/list?pageNum=1&pageSize=100&ttQmTaskId=${ttQmTaskId}`,
                    method:'get'
                })

                if(code==200){
                    this.tableList=data
                    this.$nextTick(()=>{
                        this.$refs.table1.initFunc()
                    })
                }
            })
            // this.bufferRow=_row
            // this.wbWorkhours=_row.wbWorkhours

            // this.$nextTick(()=>{
            //     this.$refs.table1.initFunc()
            // })
            // console.log(this.bufferRow)
            // const a=  this.bufferRow.ttWbWorkhoursid

            // const {code}= await httpHandle({
            //     url:"/iiot/workhours/"+a,
            //     method:'get'
            // })



        },
        // 删除
        async deleteHandle(props){
            const {items}=props

            showDialog({
                title: '删除',
                message: '删除后数据不可恢复，确认删除！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {

                if(!items.ttQmTaskBatchId){
        
                    this.tableList=this.tableList.filter(o=>o._repetition!=items._repetition)
                    this.$nextTick(()=>{
                        this.$refs.table1.initFunc()
                    })

                    return
                }


                const {code,data={}}= await httpHandle({
                    url:`/iiot/qmTaskBatch/${items.ttQmTaskBatchId}`,
                    method:'DELETE'
                })


                if(code==200){
                    showSuccessToast('删除成功！')
                    this.tableList=this.tableList.filter(o=>o.ttQmTaskBatchId!=items.ttQmTaskBatchId)
                    this.$nextTick(()=>{
                        this.$refs.table1.initFunc()
                    })
                }
            });
        },
        // 提交
        async onSubmit(props){
            const {bufferRow}=this
            const {items}=props

            const _json={
                "ttQmTaskId": bufferRow.ttQmTaskId, /*主任务id*/
                "batchType": items.batchType,/*检验类型，固定02*/
                "batchNo": items.batchNo,/*返回的扫码后sn信息*/
                "batchQty": Number(items.batchQty),/*输入的数量*/
                "lotNo": "" /*工装号，可为空*/
            }


            const {code,data={}}= await httpHandle({
                url:'/iiot/qmTaskBatch',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                // ttQmTaskBatchId

                this.tableList.map(o=> o._repetition==items._repetition?Object.assign(o,{ttQmTaskBatchId:data.ttQmTaskBatchId}) :o )
                this.$nextTick(()=>{
                    this.$refs.table1.initFunc()
                })

            }

            
        },
        // 检验
        async onCheckout(props){
            const {bufferRow}=this
            const {items}=props

            // 未提交  不能检验
            if( !items.ttQmTaskBatchId ){
                showFailToast("未提交,不能检验！")
                return
            }

            // 可检验数量
            if( Number(bufferRow.taskQty)<=0 ){
                showFailToast("可检验数量，必须大于0！")
                return
            }


            // 检验数量
            if( Number(items.batchQty)<=0 ){
                showFailToast("检验数量，必须大于0！")
                return
            }


            const {code,data={}}= await httpHandle({
                url:`/iiot/qmTaskBatch/listCheckResultListPda/${items.ttQmTaskBatchId}`,
                method:'get'
            })

            if(code==200){
                this.$router.push({
                    path:'/qualityMaterial/checkout', 
                    query:{ 
                        ttQmTaskBatchId:items.ttQmTaskBatchId,
                        _taskQty:bufferRow.taskQty  
                    }
                }) 
            }

        },
        // 扫码结果
        barSearchClick(text){
            this.addHandle(text)
        },
        // 添加扫描值
        async addHandle(_code=""){
            const {bufferRow}=this
            const _batchNoList=this.tableList.map(o=>o.batchNo)

            // console.log(_batchNoList)


            const {code,data={}}= await httpHandle({
                url:`/iiot/nodeLevel/analysisCode?code=${_code}`,
                // url:`/iiot/nodeLevel/analysisCode?code=101049000001C;1000858;20230308002;20230308`,
                method:'get'
            })

           
            // batchNo 批次号          新 sn
            // remark01  出厂日期          新  pdNo
            // batchType              新 02 写死
            // createDate  报检时间    新  不显示
            // batchQty   检验数量     新 0

            if(code==200){
                
                // 一样才能加
                if( bufferRow.partNo!=data.partNo ){
                    showFailToast("与当前产品不一致！")
                    return
                }


                // 防止重复  partNo +sn 
                const _repetition=(data.partNo+data.sn)
                if( this.tableList.filter(o=>o._repetition==_repetition).length ){
                    showFailToast("重复添加！")
                    return
                }

                // 重复添加
                if( _batchNoList.includes(data.sn) ){
                    showFailToast("重复添加！")
                    return
                }

                showSuccessToast('扫描成功！')

                this.tableList=this.tableList.concat([{
                    ...data,
                    batchNo:data.sn,
                    remark01: data.pdNo,
                    batchType:"02",
                    createDate:"",
                    batchQty:0,
                    _repetition:_repetition
                }])

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc()
                })
            }
        }
    },
  }
</script>