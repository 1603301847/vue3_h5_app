<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>待检验</v-tab>
                    <v-tab value="2" hide-slider>检验完成</v-tab>
                </v-tabs>
            </template>
        </AppBarPage>
        <div style="height: 50px;"></div>

        <v-btn v-if="tab=='1'" style="position:fixed;top:220px;right:16px;z-index: 11;" icon="mdi-plus" color="secondary" @click="addHandle"></v-btn>


        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <ScanBarComponents 
                    placeholder="扫描或输入 入库单号"
                    @searchClick="barSearchClick"
                />
                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    url="/iiot/qmTask/list"
                    method="post"
                    :auto="false"
                    :params='{ 
                        "taskType":"IQC",
                        "params":{
                            "statusList": [
                                "N",
                                "R"
                            ]
                        },
                        // partModel:partModel

                    }' 
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <!-- <v-col cols="7">
                                <p class="text-truncate font-weight-light">{{ props.items.partNo }}-{{ props.items.partName }}</p>
                            </v-col> -->
                            <v-col cols="11">
                                <p class="text-truncate text-right font-weight-medium text-right text-teal-lighten-1" color="primary">{{ FormatDictionary("qm_task_status",props.items.taskStatus)["lable"] }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.partNo }}-{{ props.items.partName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">任务流水号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.taskNo   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">配送单号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.receiptNo  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">收货状态:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" style="color:#00E5FF;">{{ props.items.isReceipt=='1'?'已收货':'未收货'   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">供应商信息:</p>
                            </v-col>
                            <v-col cols="8">
                                <p @click="GlobalTooltipFunc(`${props.items.supplierCode||''}-${ props.items.supplierName||''}`)" class="text-truncate font-weight-light">{{ props.items.supplierCode}}-{{ props.items.supplierName}}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">报检时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.requestTime }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">入库单编号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.receiptNo }}</p>
                            </v-col>
                        </v-row>
                        <v-row v-if="props.items.taskStatus=='R'" no-gutters class="text">
                            <!-- <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col> -->
                            <v-col cols="6">
                                <p class="text-truncate font-weight-light" style="margin-top: 6px;">
                                    <span class="font-weight-medium text">检验数量:</span>
                                    {{ props.items.taskQty  }}
                                </p>
                            </v-col>
                            <v-col cols="6" class="text-left">
                                <van-field v-model="props.items._taskQty" style="padding: 0px;" class="custem-input-index1" placeholder="合格数量" autocomplete="off" />
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="6" class="text-left">
                                <v-btn v-if="props.items.taskStatus=='R'" @click="accomplishClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">检验完成</v-btn>
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">检验</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
                </TableComponents>
            </v-window-item>

            <v-window-item value="2" class="v-window-item-table">
                <ScanBarComponents 
                    placeholder="扫描或输入 入库单号"
                    @searchClick="barSearchClick2"
                />
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    url="/iiot/qmTask/list"
                    method="post"
                    :auto="false"
                    :params='{ 
                        "taskType":"IQC",
                        "params":{
                            "statusList": ["F"]
                        },
                        // partModel:partModel

                    }' 
                >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <!-- <v-col cols="7">
                                <p class="text-truncate font-weight-light">{{ props.items.partNo }}-{{ props.items.partName }}</p>
                            </v-col> -->
                            <v-col cols="11">
                                <p class="text-truncate text-right font-weight-medium text-right text-teal-lighten-1" color="primary">{{ FormatDictionary("qm_task_status",props.items.taskStatus)["lable"] }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.partNo }}-{{ props.items.partName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">任务流水号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.taskNo   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">配送单号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.receiptNo  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">收货状态:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" style="color:#00E5FF;">{{ props.items.isReceipt=='1'?'已收货':'未收货'   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">供应商信息:</p>
                            </v-col>
                            <v-col cols="8">
                                <p @click="GlobalTooltipFunc(`${props.items.supplierCode||''}-${ props.items.supplierName||''}`)" class="text-truncate font-weight-light">{{ props.items.supplierCode}}-{{ props.items.supplierName}}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">报检时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.requestTime }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">入库单编号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.receiptNo }}</p>
                            </v-col>
                        </v-row>
                        <v-row v-if="props.items.taskStatus=='R'" no-gutters class="text">
                            <!-- <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col> -->
                            <v-col cols="6">
                                <p class="text-truncate font-weight-light" style="margin-top: 6px;">
                                    <span class="font-weight-medium text">检验数量:</span>
                                    {{ props.items.taskQty  }}
                                </p>
                            </v-col>
                            <v-col cols="6" class="text-left">
                                <van-field v-model="props.items._taskQty" style="padding: 0px;" class="custem-input-index1" placeholder="合格数量" autocomplete="off" />
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="6" class="text-left">
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <!-- <v-btn @click="detailHandle(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn> -->
                                <v-btn @click="detailClick(props,'detail')" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>
                            
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
                </TableComponents>
            </v-window-item>
        </v-window>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api
    import ScanBarComponents from '@/packages/ScanBar.vue'

    import AddPage from './add.vue'


    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        AddPage,
        ScanBarComponents,
        TableComponents
    },
    data: () => ({
        tab: '1',

        partModel:""
    }),
    watch: {
        tab(val){
            this.initHandle()
        },
    },
    created(){
        this.initHandle()

        // 刷新页面
        this.$root.$emitter.on("update_qualityMaterial_page1",(tabs='1')=>{
            this.tab=tabs
        })
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        initHandle(){
            const {tabs}=this.$route.query

            if(tabs){
                this.tab=tabs
            }
            
            this.partModel=localStorage.getItem("_qualityMaterialPartModel")


            this.$nextTick(()=>{
                if(this.tab=="1"){
                    this.$refs.table1.initFunc(1,{})
                }
                if(this.tab=="2"){
                    this.$refs.table2.initFunc(1,{})
                }
            })

        },
        // 头部 查询  111
        async barSearchClick(value=''){
            const _value=value.trim()

            this.$refs.table1.initFunc(1,{
                receiptNo: _value
            })

        },
        // 头部 查询  222
        async barSearchClick2(value=''){
            const _value=value.trim()

            this.$refs.table2.initFunc(1,{
                receiptNo: _value
            })

        },
        // 检验
        async detailClick(props,active=""){
            const {items}=props
            
            this.$router.push({
                path:'/qualityMaterial/detail', 
                query:{ 
                    _pageActive:active,
                    ttQmTaskId: items.ttQmTaskId, 
                    row:JSON.stringify(items) 
                }
            }) 

        },
        // 检验完成
        async accomplishClick(props){
            const {items}=props

            const _number=Number( items._taskQty||"" )

            if(!_number){
                showFailToast("合格数量必填！")
                return
            }

            if(_number>Number(items.taskQty)){
                showFailToast("合格数量不能大于检验数量！")
                return
            }


            const _json={
                "ttQmTaskId": items.ttQmTaskId,
                "taskQty":  items.taskQty,
                "qualifiedQty":  items.taskQty,
                "version":  items.version,
                "acceptQty":  _number,   // 合格数
            }

            const {code,data={}}= await httpHandle({
                url:'/iiot/qmTask/finishQmTask',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc(1)
                })

            }


        },
        // 添加
        addHandle(){
            
            this.$router.push({
                path:'/qualityMaterial/add', 
                query:{ }
            }) 
        },   
        // 详情
        detailHandle(props){
            const {items}=props

            // this.$router.push({
            //     path:'/process/checkDetail', 
            //     query:{ ttQmTaskId: items.ttQmTaskId,_page:"qualityMaterial" }
            // }) 
            
        },  

    },
  }
</script>