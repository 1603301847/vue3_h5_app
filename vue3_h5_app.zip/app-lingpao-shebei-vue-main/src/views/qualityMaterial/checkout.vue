<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>
        <v-btn style="position:fixed;top:80px;right:16px;z-index: 11;" icon="mdi-plus" color="secondary" @click="()=> show=true"></v-btn>

        <v-sheet elevation="2" rounded class="custem-card">
            <!-- <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">信息</span>
                </v-col>
                <v-col cols="6">
                    <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="3">
                    <p class="font-weight-medium text">检验产品:</p>
                </v-col>
                <v-col cols="9">
                    <p class="text-truncate font-weight-light text-left">{{ bufferRow.partNo}}-{{bufferRow.partName}}</p>
                </v-col>
            </v-row>


            <v-row no-gutters class="text">
                <v-col cols="2">
                    <p class="font-weight-medium text">批次号:</p>
                </v-col>
                <v-col cols="4">
                    <p class="text-truncate font-weight-light">{{ bufferRow.batchNo  }}</p>
                </v-col>
                <v-col cols="3">
                    <p class="font-weight-medium text">检验数量:</p>
                </v-col>
                <v-col cols="3">
                    <p class="text-truncate font-weight-light">{{ bufferRow.taskQty  }}</p>
                </v-col>
            </v-row>

            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">状态:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ FormatDictionary("qm_task_status",bufferRow.taskStatus)["lable"]  }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="3">
                    <p class="font-weight-medium text">检验类型:</p>
                </v-col>
                <v-col cols="3">
                    <p class="text-truncate font-weight-light">{{  FormatDictionary("QM_BY_TYPE",bufferRow.batchType)["lable"] }}</p>
                </v-col>
                <v-col cols="3">
                    <p class="font-weight-medium text">配送单号:</p>
                </v-col>
                <v-col cols="3">
                    <p class="text-truncate font-weight-light">{{ bufferRow.receiptNo  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">供应商信息:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.supplierName  }}</p>
                </v-col>
            </v-row>
        </v-sheet>

        <v-sheet class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="tableList"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        
                        <v-row no-gutters class="table-title">
                            <v-col cols="12">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>

                                <!-- <v-icon icon="mdi-pencil-outline" size="16" color="primary"></v-icon> -->
                                <span class="font-weight-medium">{{ props.items.inspectDetailName }}</span>
                                <span style="padding-left:12px;color:#00E5FF;"> {{  `< ${FormatDictionary("checkout_param_type",props.items.parameterType)["lable"]}类型 >`   }} </span>
                            </v-col>
                        </v-row>
                        <div style="height:6px;"></div>
                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">检验项目:</p>
                            </v-col>
                            <v-col cols="9">
                                <p @click="GlobalTooltipFunc(`${props.items.inspectDetailName||''}`)" class="text-truncate font-weight-light">{{ props.items.inspectDetailName   }}</p>
                            </v-col>

                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">检验方法:</p>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light">{{ props.items.methodDesc }}</p>
                            </v-col>
                        </v-row>

                        <div style="height:3px;"></div>


                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text input-lable">检验备注:</p>
                            </v-col>
                            <v-col cols="5">
                                <van-field 
                                    v-model="props.items._remark" 
                                    style="padding:0px;"
                                    size="large"
                                    placeholder="请输入备注"
                                    autocomplete="off"
                                    class="custem-input-index1"
                                    :style="'padding-top:0px;'"
                                    @focus="$root.$utils.VanFieldFocusToTop"

                                />
                            </v-col>
                            <v-col cols="4" style="text-align:right;">
                                <v-switch
                                    v-model="props.items._switch"
                                    :label="props.items._switch?'合格':'不合格'"
                                    color="primary"
                                    density="comfortable"
                                    style="top:-8px;left:18px;position:relative;height:40px;display:block;height:48px;width:104px;"
                                    ></v-switch>
                            </v-col>
                        </v-row>
                        <v-row no-gutters style="margin-top:0px;" class="text" v-if="props.items.parameterType=='DT'?true:false">
                            <v-col cols="3">
                                <p class="font-weight-medium text input-lable">检验数量:</p>
                            </v-col>
                            <v-col cols="5">
                                <van-field 
                                    
                                    v-model="props.items._number" 
                                    style="padding:0px;"
                                    size="large"
                                    placeholder="请输入数量"
                                    autocomplete="off"
                                    type="number"
                                    class="custem-input-index1"
                                    @focus="$root.$utils.VanFieldFocusToTop"

                                />
                            </v-col>

                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="5">
                                <p class="font-weight-medium text">供应商自检结果:</p>
                            </v-col>
                            <v-col cols="7">
                                <p class="font-weight-light">{{  FormatBatchNumber(props)    }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters>
                            <v-col cols="12">
                                <UploaderImageComponents 
                                    v-model="props.items._bufferFileList"
                                />
                            </v-col>

                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </v-sheet>
        
        <v-row no-gutters>
            <v-col cols="12" style="margin-bottom:18px;padding-left:6px;">
                <p>
                    <span>结果: </span>
                    <span :style="FormatBottomResultColor()">{{ FormatBottomResult() }}</span>
                </p>
            </v-col>
        </v-row>

        <v-row class="global-botom-btn-box" no-gutters>
            <v-col cols="5" class="text-center">
                <v-btn
                    color="warning"
                    @click="disqualificationApplyHandle"
                >
                    不合格处理申请
                </v-btn>
            </v-col>
            <v-col cols="4" class="text-center">
                <v-btn
                    color="error"
                    @click="standardHandle(false)"
                >
                    不合格
                </v-btn>
            </v-col>
            <v-col cols="3" class="text-center">
                <v-btn
                    color="primary"
                    @click="standardHandle(true)"
                >
                    合格
                </v-btn>
            </v-col>
        </v-row>


        <van-popup 
            v-model:show="show" 
            closeable
            position="right"
            :style="{padding:'12px',width:'90%',height:'100%' }"
        >
            <p style="font-size: 16px;">检验完成</p>

            <div>
                <div style="height:16px;"></div>
                <SelectComponents 
                    v-model="project"
                    ref="select1"
                    label="检验项目"
                    showSearch
                    :option="projectSelectOption"
                    @onChange="projectChange"
                    @onSearchChange="projectSearchChange"

                    required
                />

                <SelectComponents 
                    v-model="standard"
                    ref="select3"
                    label="检验明细"
                    :forbidShow="true"
                    showSearch
                    :option="standardSelectOption"
                    @onFieldClick="standardClick"
                    @onChange="standarChange"
                    @onSearchChange="standarSearchChange"

                    required
                />

                <van-field 
                    v-if="showNumberValue"
                    v-model="testValue" label="检验值" type="number" 
                    placeholder="请输入大于0的整数" 
                    autocomplete="off"
                />

                <span style="position:relative;top:-39px;margin-left:16px;">结果: </span>
                <v-switch
                    v-model="switchQualified"
                    :label="switchQualified?'合格':'不合格'"
                    color="primary"
                    density="comfortable"
                    style="height:48px;display:inline-block;height:48px;width:104px;margin-left:14px;"
                    ></v-switch>

                <van-field 
                    v-model="description" 
                    type="textarea" 
                    label="描述" 
                    placeholder="请输入描述" 
                    autocomplete="off"
                />

            </div>

            <div style="height: 20px;"></div>
            <v-row no-gutters>
                    <v-col cols="6" class="text-center">
                        <v-btn variant="plain" block @click="()=> show=false ">
                            取消
                        </v-btn>
                    </v-col>
                    <v-col cols="6" class="text-center">
                        <v-btn
                            variant="plain"
                            color="primary"
                            block
                           @click="affirmCheckout"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
        </van-popup>

        <div style="height: 60px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import SelectComponents from '@/packages/Select.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant'
    import { showDialog  } from 'vant'

  export default {
    components:{
        AppBarPage,
        SelectComponents,
        UploaderImageComponents,
        TableComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据
        qmTaskBatch:{},  // 缓存数据

        fileList:[
            // { url: 'https://fastly.jsdelivr.net/npm/@vant/assets/leaf.jpeg' },
        ],  // 图片
        bufferFileList:[],  // 缓存图片

        show:false,  // show 弹框
        showNumberValue:false,  // 显示检测值

        tableList:[],  // table数据
        supplDetail:[],  // 批次号 数组


        project:"",  // 项目检测
        projectSelectOption:[],   // 项目检测 数据

        standard:"",     // 检验标准
        standardSelectOption:[],   // 检验标准 数据
        bufferStandardSelectOption:[],   // 检验标准 数据 缓存

        testValue:"",   // 检验值
        switchQualified:true,   // 是否合格
        description:"",      // 描述

    }),
    created(){
        this.initFunc()

        this.projectHTTP()

    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 格式化 批次号
        FormatBatchNumber(props){
            const {items}=props
            const {supplDetail=[]}=this

            const _text=supplDetail.map(o=>Object.assign({no:o,text:items[o]}))
                .filter(k=>k.text)
                .map(o=>`批次号:${o.no} ${o.text}`).join(";")

            return _text||"无"
        },
        // 格式化 底部合格
        FormatBottomResult(){
            const {bufferRow={}}=this
            if(!bufferRow.inspectResult) return

            const _text=this.FormatDictionary("IQC_RESULT",bufferRow.inspectResult)["lable"]

            return _text
        },
        // 格式化 底部合格 颜色
        FormatBottomResultColor(){
            const {bufferRow={}}=this


            let _tetx=""
            switch (bufferRow.inspectResult) {
                case '10':
                    _tetx="color:#4CAF50"
                    break;
                case '20':
                    _tetx="color:#FF9800"
                    break;    
                case '30':
                    _tetx="color:#FF5722"
                    break;          
                default:
                    break;
            }

            return _tetx
        },
        // 初始化
        async initFunc(){
            const {ttQmTaskBatchId,_taskQty}=this.$route.query

            
            const {code,data={}}= await httpHandle({
                url:`/iiot/qmTaskBatch/listCheckResultListPda/${ttQmTaskBatchId}`,
                method:'get'
            })

            if(code==200){
                this.bufferRow= Object.assign( (data.qmTaskBatch||{}),{taskQty:_taskQty} )
                this.qmTaskBatch=data.qmTaskBatch||{}

                this.tableList=(data.dataList||[]).map(k=> Object.assign(k,{
                    _switch: k.inspectResult ? (k.inspectResult=="10"?true:false):true,
                    _remark: k.remark,
                    _number: k.resultValue,
                    _bufferFileList: k.taskResultPath ? k.taskResultPath.split(",").map(o=>Object.assign({url:o})) :[]
                }))
                this.supplDetail=data.supplDetail||[]

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc()

                })
            }

  

            
        },
        // 检验项目 数据
        async projectHTTP(key=''){

            const {code,data=[]}= await httpHandle({
                url:`/iiot/inspect/listInspectForSelect`,
                method:'get',
                url_params:{
                    inspectNo:key
                }
            }) 

            if(code==200){
                this.projectSelectOption=data.map(o=>Object.assign({text:`${o.inspectNo||''}-${o.inspectName||''}`,value:o.tmQmInspectId})).splice(0,50)  
            }
        },
         // 检验项目 查询
        projectSearchChange(key){
            this.projectHTTP(key)
        },
        // 切换检验项目
        projectChange(){
            this.$refs.select3.reset()
        },
        // 切换标准明细
        standarChange(value){

            if(value){
                const _option=this.bufferStandardSelectOption.filter(o=>o.tmQmInspectDetailId==value)[0]
                this.showNumberValue=(_option.parameterType=="DT")?true:false
            }
        },
        // 标准点击
        standardClick(){
           this.standardHTTP()
        },
        // 标准  查询
        standarSearchChange(key){
            this.standardHTTP(key)
        },
        // 检验标准 数据
        async standardHTTP(key=""){
            const {project}=this

            // console.log(project)
            if(!project){
                showSuccessToast('检验项目必选！')
                return
            }

            const {code,data=[]}= await httpHandle({
                url:`/iiot/inspectDetail/listInspectDetailForSelect`,
                url_params:{
                    inspectDetailNo:key,
                    tmQmInspectId: project
                },
                method:'get'
            }) 

            if(code==200){
                this.standardSelectOption=data.map(o=>Object.assign({text:`${o.inspectDetailNo||''}-${o.inspectDetailName||''}`,value:o.tmQmInspectDetailId})).splice(0,50)  
                this.bufferStandardSelectOption=data
                this.$refs.select3.showModle()
            }
        },
        // 检验添加 
        affirmCheckout(){
            const {project,standard,bufferStandardSelectOption=[]}=this

            if(!project){
                showFailToast('检验项目必选！')
                return
            }

            if(!standard){
                showFailToast('检验明细必选！')
                return
            }

            const _option=bufferStandardSelectOption.filter(o=>o.tmQmInspectDetailId==standard)[0]

            
            if( this.tableList.filter(o=>o.inspectDetailNo==_option.inspectDetailNo).length ){
                showFailToast('已存在！')
                return
            }


            const _json={
                parameterType: _option.parameterType,
                inspectDetailName: _option.inspectDetailName,
                inspectDetailNo: _option.inspectDetailNo,   // 判断去重
                parameterRange: _option.parameterRange,
                methodDesc: _option.methodName,
                remark: this.description,  // 描述
                resultValue: this.switchQualified,  // 结果
                inspectResult: this.testValue,  // 检测值
                tmQmInspectId: project,  // 项目检测 ID
                tmQmInspectDetailId: _option.tmQmInspectDetailId,
                isNewAdded:'1',

                _switch:this.switchQualified,  // 结果缓存  绑定外面
                _remark:this.description,  // 描述   绑定外面
                _number:this.testValue,  // 检测值   绑定外面
            }



            this.tableList=this.tableList.concat([_json])
            this.$nextTick(()=>{
                this.$refs.table1.initFunc()
                this.show=false
            })

        },
        // 不合格处理申请
        async disqualificationApplyHandle(){
            const _result=this.tableList.filter(o=>o.ttQmTaskResultId).length
            
            if( !_result==this.tableList.length ){
                showFailToast('新增项未保存！')
                return
            }


            // 不合格 备注必填
            if( this.tableList.filter(o=>{
                return (!o._switch)&&!((o._remark||"").trim())  
            }).length ){
                showFailToast('不合格时，备注必填')
                return
            }
            

            const {qmTaskBatch}=this

            const _json={
                dataList:  JSON.parse( JSON.stringify(this.tableList) ).map(o=> Object.assign(o,{
                    resultValue: o._number,
                    remark: o._remark,
                    inspectResult: o._switch?"10":"30",
                    taskResultPath: (o._bufferFileList||[]).map(o=>o.url).join()
                })), 
                qmTaskBatch: Object.assign(qmTaskBatch) 
            }
            

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmTaskBatch/applyUnQualityManage',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/qualityMaterialDisqualification/detail', 
                    query:{ ttQmDefectId: data.ttQmDefectId  }
                }) 
            }
        },
        // 合格  不合格 
        async standardHandle(active){
            const {qmTaskBatch,tableList }=this

            // 不合格 备注必填
            if( this.tableList.filter(o=>{
                return (!o._switch)&&!((o._remark||"").trim())  
            }).length ){
                showFailToast('不合格时，备注必填')
                return
            }

            const _json={
                dataList:  JSON.parse( JSON.stringify(this.tableList) ).map(o=> Object.assign(o,{
                    resultValue: o._number,
                    remark: o._remark,
                    inspectResult: o._switch?"10":"30",
                    taskResultPath: (o._bufferFileList||[]).map(o=>o.url).join()
                })), 
                qmTaskBatch: Object.assign(qmTaskBatch,{inspectResult:active?"10":'30' }) 
            }
            

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmTaskBatch/listCheckResultSave',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')
                this.initFunc()
                // this.$router.go(-1)
            }
        }

    },
  }
</script>