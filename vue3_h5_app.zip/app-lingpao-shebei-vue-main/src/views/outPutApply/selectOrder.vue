<template>
    <span>
        <van-popup 
            v-model:show="drawer" 
            closeable
            position="right"
            :style="{padding:'12px',width:'92%',height:'100%' }"
        >

            <div style="margin-top: 22px;">
                <van-field v-model="code" placeholder="请输入" autocomplete="off" label="业务编码" />

                <SelectComponents 
                    v-model="sign"
                    ref="select3"
                    label="业务类型"
                    :option="signSelectOption"

                />
            </div>

            <v-row no-gutters class="text">
                <v-col cols="4">
                
                </v-col>

                <v-col cols="8" class="text-right">
                    <v-btn @click="rest" color="warning mt-1" density="compact" :rounded="0" variant="plain">重置</v-btn>

                    <v-btn @click="search" color="primary mt-1" density="compact" :rounded="0" variant="plain">查询</v-btn>
                </v-col>
            </v-row>
            <div class="v-window-item-table">
                <TableComponents
                    ref="table1"
                    url="/iiot/sparePartBills/list"
                    method="get"
                    :params="{ 
                        // mtart: 'ZS01',
                        // matnr:code,
                        businessCode: code,
                        businessType: sign,
                        ...pageSearchConfig
                    }"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="4">
                                    <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                    <!-- <span class="font-weight-medium">保养设备</span> -->
                                </v-col>
                                <v-col cols="7">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">业务编码:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.businessCode}}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">业务名称:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.businessName  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">业务类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ FormatDictionary('ccgl_bpbj_business_type',props.items.businessType)['lable']    }}</p>
                                </v-col>
                            </v-row>
    
 
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                
                                </v-col>
                                <v-col cols="4">
                            

                                </v-col>
                                <v-col cols="4" class="text-right">
                                    <v-btn @click="select(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">选择</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </div>

        </van-popup>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import SelectComponents from '@/packages/Select.vue'



    import {httpHandle} from '@/http/http'  // api

    import { showSuccessToast,showFailToast,showToast } from 'vant';
import { windowWidth } from 'vant/lib/utils';

  export default {
    components:{
        AppBarPage,
        SelectComponents,
        TableComponents
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息

        drawer: false,


        code:'',  // 业务编码
        sign:"",   // 业务类型 
        signSelectOption:[],   // 业务类型  数据
    }),
    emits: ["select"],
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        }, 
        showDrawer(){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            
 
            const _selectAttribute2=_bufferDictionaries["ccgl_bpbj_business_type"]||[]    // 业务类型
            this.signSelectOption=_selectAttribute2.map(o=>Object.assign({text:o.lable,value:o.value}))   // 业务类型



            this.drawer=true
        },
        // 查询
        search(){
            this.$refs.table1.initFunc(1)
        },
        // 重置
        rest(){
            this.code=''
            this.sign=''
            this.$refs.select3 && this.$refs.select3.reset()

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 选择
        select(props){
            this.drawer=false
            this.$nextTick(()=>{
                this.$emit("select",props.items)
            })
        }
    },
  }
</script>