<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">{{useInfoTypeText}}申请</span>
                </v-col>
                <v-col cols="5" class="text-right">
                    <span :style="`color:${!isEdit?'#4CAF50':'#00E5FF'}`">{{ isEdit?'修改':'新增' }}</span>
                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p> -->
                </v-col>
            </v-row>
            

            
            <v-row v-if="isEdit" style="margin-top: 12px;" no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出入库类型:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{  useInfoTypeText  }}</p>
                </v-col>
            </v-row>

            <v-row v-if="isEdit" style="margin-top: 12px;" no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出入库编码:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{  bufferRow.sparePartUseCode  }}</p>
                </v-col>
            </v-row>

            <van-field v-model="name22" autocomplete="off" placeholder="请输入" label="出入库名称" />



            <SelectComponents 
                v-model="property"
                ref="select1"
                label="业务类型"
                :option="propertySelectOption"
                required
            />

            <v-row v-if="!showName" style="margin-top: 12px;" no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text"><span style="color: #ee0a24;">*</span>单据编码:</p>
                </v-col>
                <v-col cols="5">
                    <p class="font-weight-light text-left" style="color:#00E5FF;">{{ orderOption }}</p>
                </v-col>
                <v-col cols="3">
                    <v-btn @click="selectOrderCode" density="compact" color="primary">
                        选择
                    </v-btn>
                </v-col>
            </v-row>

            <van-field v-if="showName" v-model="orderOption" required autocomplete="off" placeholder="请输入" label="单据编码" />
            <van-field v-if="showName" v-model="name" autocomplete="off" placeholder="请输入" label="单据名称" />


            <v-row style="margin-top: 12px;" no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text"><span style="color: #ee0a24;">*</span>物资编码:</p>
                </v-col>
                <v-col cols="5">
                    <p class="font-weight-light text-left" style="color:#00E5FF;">{{ codeOption }}</p>
                </v-col>
                <v-col cols="3">
                    <v-btn @click="selectCode" density="compact" color="primary">
                        选择
                    </v-btn>
                </v-col>
            </v-row>

            
            
            <van-field v-model="number" placeholder="请输入" autocomplete="off" label="申请数量" required type="number"  />
            
            <van-field v-model="explain" autocomplete="off" placeholder="请输入" label="出入库说明" />



            <van-field v-if="show33" v-model="supplierCode" autocomplete="off" placeholder="请输入" label="供应商编码" />
            <van-field v-if="show33" v-model="supplierName" autocomplete="off" placeholder="请输入" label="供应商名称" />
            <van-field v-if="show33" v-model="supplierUser" autocomplete="off" placeholder="请输入" label="联系人" />
            <van-field v-if="show33" v-model="supplierTel" autocomplete="off" placeholder="请输入" label="联系电话" />



            <v-row >
   
                <v-col cols="12" class="text-left">
                    <v-btn @click="submit" block color="primary">
                        {{ isEdit?'修改':'提交' }}
                    </v-btn>
                </v-col>
                </v-row>
        </v-sheet>


        <SelectCodeComponents 
            ref="selectCode" 
            :typeAction="useInfoType"
            @select="selectCodeChange"
        />

        <SelectOrderComponents 
            ref="selectOrder" 
            @select="selectOrderChange"
        />
        


        <div style="height:6px;"></div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 异常处理 详情
    import {httpHandle} from '@/http/http'  // api
    import SelectComponents from '@/packages/Select.vue'
    import SelectCodeComponents from './selectCode.vue'
    import SelectOrderComponents from './selectOrder.vue'

    

    import { showSuccessToast,showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage,
        SelectComponents,
        SelectCodeComponents,
        SelectOrderComponents
    },
    data: () => ({
        show33:false,  
        showName:false,
        bufferRow:{},  // 行数据

        isEdit:false,
        useInfoType:"",  // 1 入库  2出库
        useInfoTypeText:"",
        name22:"",   // 出入库名称

        name:"",      // 单据名称
        number:"",   // 申请数量
        explain:"",   // 出入库说明

        orderOption:"",   // 单据编码
        codeOption:"",  // 物资编码

        orderOptionObj:{}, // 单据编码 对象
        codeOptionObj:{},   // 物资编码 对象


        supplierCode:"",  // 供应商编码
        supplierName:"",  // 供应商名称
        supplierUser:"",  // 联系人
        supplierTel:"",  //  联系电话

        

        property:"",   // 业务类型 
        propertySelectOption:[],   // 业务类型  数据
    }),
    watch: {
        property: { 
            handler(value){
      
                this.showName=false
                this.show33=false

                this.name=''
                this.orderOption=''

                this.codeOptionObj={}
                this.orderOptionObj={}


                this.supplierCode=""  // 供应商编码
                this.supplierName=""  // 供应商名称
                this.supplierUser="" // 联系人
                this.supplierTel=""  //  联系电话

                if(value=='1'){
                    this.show33=true
                    this.showName=true
                }
            },
            deep: true, 
            immediate: true, 
        },
    },
    created(){
        this.initFunc()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {useInfoType,sparePartUseId,isEdit=false}=this.$route.query
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            const _selectAttribute=_bufferDictionaries["ccgl_bpbj_business_type"]||[]    // 业务类型
            this.propertySelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 业务类型

            this.useInfoType=useInfoType
            this.useInfoTypeText= (useInfoType=='1') ?'入库':'出库'
            this.isEdit=isEdit

            if(!sparePartUseId) return
            const {code,data={}}= await httpHandle({
                url:'/iiot/sparePartUse',
                method:"get",
                url_RESTful:`/${sparePartUseId}`   
            })

            if(code==200){
                this.bufferRow=data

                this.name22=data.sparePartUseName  // 出入库名称

                this.property=data.businessType    // 业务类型
                this.$refs.select1 && this.$refs.select1.setValue( data.businessType )   // 业务类型

                this.explain=data.sparePartUseExplain         // 出入库说明
                this.number=data.goodsMaterialsNums          // 申请数量 

                this.$nextTick(()=>{
                    this.orderOption=data.businessCode
                    this.name=data.businessName

                    // 单据
                    this.orderOptionObj={
                        businessId: data.businessId,
                        businessCode: data.businessCode,
                        businessName: data.businessName,
                    }

                    // 物资编码
                    this.codeOption=data.goodsMaterialsCode
                    this.codeOptionObj={
                        tmBasPartId:data.goodsMaterialsId,
                        matnr:data.goodsMaterialsCode,
                        maktxC:data.goodsMaterialsName
                    }


                    setTimeout(()=>{
                        
                        this.supplierCode=data.supplierCode  // 供应商编码
                        this.supplierName=data.supplierName  // 供应商名称
                        this.supplierUser=data.supplierUser // 联系人
                        this.supplierTel=data.supplierTel    //  联系电话
                    },500)
                })



     
            }


        },
        // 选择 物质编码
        selectCode(){
            this.$refs.selectCode.showDrawer()
        },
        selectOrderCode(){
            this.$refs.selectOrder.showDrawer()
        },
        // 选中 物质编码
        selectCodeChange(items){
            this.codeOption=items.matnr
            this.codeOptionObj=items
        },
        // 选中 单据编码
        selectOrderChange(items){
            this.orderOption=items.businessCode
            this.orderOptionObj=items
        },
        // 提交
        async submit(){
            const {useInfoType,isEdit=false}=this.$route.query
            const _bufferUserInfo=JSON.parse( localStorage.getItem("bufferUserInfo")||"{}" )
            const {bufferRow}=this
            
            if( !this.property ){
                showFailToast('业务类型必填！')
                return
            }

            if( !this.orderOption ){
                this.showName? showFailToast('单据编码必填！'):showFailToast('单据编码必选！')
                return
            }

            if( !this.codeOption ){
                showFailToast('物资编码必选！')
                return
            }

      
            if( !this.number || ( Number(this.number)<=0 ) ){
                showFailToast('申请数量必填大于0！')
                return
            }


            // 新增
            const _json={
                sparePartUseId:null,  
                sparePartUseCode: null,
                sparePartUseName: null,
                outNums:null,
                outUserCode:null,
                outUserName:null,
                outDatetime:null, 
                sort: null,
                createBy: null,
                createTime: null,
                updateBy: null,
                updateTime: null,

                businessType: this.property,    // 业务类型
                sparePartUseExplain: this.explain,         // 出入库说明
                goodsMaterialsNums: Number(this.number),          // 申请数量 

                businessId:  this.orderOptionObj.businessId,    //单据编码 businessType为采购时(可为空).其他选型时,从选择器中获取ID
                businessCode: this.property=='1' ? this.orderOption : this.orderOptionObj.businessCode,  //单据编码 businessType为采购时(手动填写).其他选型时,从选择器中获取code
                businessName:  this.property=='1' ? this.name : this.orderOptionObj.businessName,  //单据编码 businessType为采购时(手动填写).其他选型时,从选择器中获取name

                goodsMaterialsId: this.codeOptionObj.tmBasPartId,   // 物资编码
                goodsMaterialsCode: this.codeOptionObj.matnr,       // 物资编码
                goodsMaterialsName: this.codeOptionObj.maktxC,      // 物资编码

                operUserName: _bufferUserInfo.userName,     // 用户信息 userName
                operUserCode: _bufferUserInfo.userId,        // 用户信息 userId



                supplierCode:this.supplierCode,  // 供应商编码
                supplierName:this.supplierName,  // 供应商名称
                supplierUser:this.supplierUser, // 联系人
                supplierTel:this.supplierTel,    //  联系电话
           

                useInfoType:  useInfoType,  // 入库1  出库2
                operType:"N", 
                finishState: "N",
                dataState: "N",
                delFlag: "Y",
                version: 0
            }


            // 编辑
            const _jsonEdit={
                sparePartUseId:bufferRow.sparePartUseId,  
                sparePartUseCode: bufferRow.sparePartUseCode,
                sparePartUseName: bufferRow.sparePartUseName,
                outNums:bufferRow.outNums,
                outUserCode:bufferRow.outUserCode,
                outUserName:bufferRow.outUserName,
                outDatetime:bufferRow.outDatetime, 
                sort: bufferRow.sort,
                createBy: bufferRow.createBy,
                createTime: bufferRow.createTime,

                updateBy: bufferRow.updateBy,
                updateTime: bufferRow.updateTime,

                sparePartUseName: this.name22,  // 出入库名称
                businessType: this.property,    // 业务类型
                sparePartUseExplain: this.explain,         // 出入库说明
                goodsMaterialsNums: Number(this.number),          // 申请数量 

                businessId:  this.orderOptionObj.businessId,    //单据编码 businessType为采购时(可为空).其他选型时,从选择器中获取ID
                businessCode: this.property=='1' ? this.orderOption : this.orderOptionObj.businessCode,  //单据编码 businessType为采购时(手动填写).其他选型时,从选择器中获取code
                businessName:  this.property=='1' ? this.name : this.orderOptionObj.businessName,  //单据编码 businessType为采购时(手动填写).其他选型时,从选择器中获取name

                goodsMaterialsId: this.codeOptionObj.tmBasPartId,   // 物资编码
                goodsMaterialsCode: this.codeOptionObj.matnr,       // 物资编码
                goodsMaterialsName: this.codeOptionObj.maktxC,      // 物资编码

                operUserName: _bufferUserInfo.userName,     // 用户信息 userName
                operUserCode: _bufferUserInfo.userId,        // 用户信息 userId
           

                supplierCode:this.supplierCode,  // 供应商编码
                supplierName:this.supplierName,  // 供应商名称
                supplierUser:this.supplierUser, // 联系人
                supplierTel:this.supplierTel,    //  联系电话

                useInfoType:  useInfoType,  // 入库1  出库2
                operType:"N", 
                finishState: "N",
                dataState: "N",
                delFlag: "Y",
                version: 0
            }
            // console.log(_jsonEdit)
            // return
            const {code,data={}}= await httpHandle({
                url:'/iiot/sparePartUse',
                method:  isEdit?'put':"post",
                payload: isEdit?_jsonEdit: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.go(-1)
            }
        }
    },
  }
</script>