<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <!-- <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">详情</span>
                </v-col>
                <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出入库名称:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.sparePartUseName   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">业务类型:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{  FormatDictionary('ccgl_bpbj_business_type',bufferRow.businessType)['lable']    }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">单据编码:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.businessCode   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">物资编码:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.goodsMaterialsCode   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出入库说明:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.sparePartUseExplain   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">申请数量:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.goodsMaterialsNums    }}</p>
                </v-col>
            </v-row>

            <van-field v-model="number" placeholder="请输入" autocomplete="off" label="归还数量" required type="number"  />

        </v-sheet>



        <div style="height:6px;"></div>
        <v-btn @click="submit" block color="primary">
                    提交
                </v-btn>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 异常处理 详情
    import {httpHandle} from '@/http/http'  // api

    import { showSuccessToast,showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage,

    },
    data: () => ({
        bufferRow:{},  // 行数据

        number:"",  // 归还数量
    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {row={}}=this.$route.query

            this.bufferRow=JSON.parse(row)

            this.$nextTick(()=>{
                this.number=this.bufferRow.goodsMaterialsNums
            })
        },
        async submit(){
            const {bufferRow}=this
            const _bufferUserInfo=JSON.parse( localStorage.getItem("bufferUserInfo")||"{}" )

            if( !this.number || ( Number(this.number)<=0 ) ){
                showFailToast('归还数量必填大于0！')
                return
            }

            if( Number(this.number) >  Number(bufferRow.goodsMaterialsNums) ){
                showFailToast('归还数量不能大于申请数量！')
                return
            }

            const _json={
                // ...bufferRow,

                businessId: bufferRow.sparePartUseId,
                businessCode: bufferRow.sparePartUseCode,
                businessName: bufferRow.sparePartUseName,
                // sparePartUseCode:"GH-" + bufferRow.goodsMaterialsCode + "-" + this.blackNum,
                sparePartUseCode:"GH-" + bufferRow.goodsMaterialsCode,

                sparePartUseName: bufferRow.sparePartUseName + "归还物料",
                sparePartUseExplain: bufferRow.sparePartUseCode + "-" + bufferRow.sparePartUseName + "归还物料",
                useInfoType:'1',
                businessType: bufferRow.businessType,
                operType:'Y',
                goodsMaterialsId: bufferRow.goodsMaterialsId,
                goodsMaterialsCode: bufferRow.goodsMaterialsCode,
                goodsMaterialsName: bufferRow.goodsMaterialsName,
                goodsMaterialsNums: bufferRow.outNums,
                operUserName: _bufferUserInfo.userName,     // 用户信息 userName
                operUserCode: _bufferUserInfo.userId,        // 用户信息 userId
                finishState:'N',


                goodsMaterialsNums:Number(this.number)   // 归还数量
            }
            
            // console.log(_json)
            // return
            const {code,data={}}= await httpHandle({
                url:'/iiot/sparePartUse',
                method:  "post",
                payload: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.go(-1)
            }

        }

    },
  }
</script>