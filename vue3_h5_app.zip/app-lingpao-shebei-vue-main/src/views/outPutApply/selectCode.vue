<template>
    <span>
        <van-popup 
            v-model:show="drawer" 
            closeable
            position="right"
            :style="{padding:'12px',width:'92%',height:'100%' }"
        >

            <div style="margin-top: 22px;">
                <van-field v-model="code" placeholder="请输入" autocomplete="off" label="物料编号" />

            </div>

            <v-row no-gutters class="text">
                <v-col cols="4">
                
                </v-col>

                <v-col cols="8" class="text-right">
                    <v-btn @click="rest" color="warning mt-1" density="compact" :rounded="0" variant="plain">重置</v-btn>

                    <v-btn @click="search" color="primary mt-1" density="compact" :rounded="0" variant="plain">查询</v-btn>
                </v-col>
            </v-row>
            <div class="v-window-item-table">
                <TableComponents
                    ref="table1"
                    :url="baseURL"
                    :auto="false"
                    :params="{ 
                        // mtart: 'ZS01',
                        // matnr:code,
                        ...pageSearchConfig
                    }"

                >
                    <template v-slot:tableBody="props">
                        <v-card v-if="typeAction=='1'">
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="4">
                                    <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                    <!-- <span class="font-weight-medium">保养设备</span> -->
                                </v-col>
                                <v-col cols="7">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料编号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.matnr  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料描述:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.maktxC  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ FormatDictionary('matnr_type',props.items.mtart)['lable']    }}</p>
                                </v-col>
                            </v-row>
    
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料大类:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ FormatDictionary('matnr_broad',props.items.broad)['lable']    }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">长文本:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.ltext  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">大小/量纲:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.groes  }}</p>
                                </v-col>
                            </v-row>
                            

                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">毛重:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.brgew  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">净重:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.ntgew  }}</p>
                                </v-col>
                            </v-row>


                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">重量单位:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ FormatDictionary('matnr_gewei',props.items.gewei)['lable']    }}</p>
                                </v-col>
                            </v-row> -->

                            
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                            
                            </v-col>
                            <v-col cols="4">
                         

                            </v-col>
                            <v-col cols="4" class="text-right">
                                <v-btn @click="select(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">选择</v-btn>
                            </v-col>
                        </v-row>
                        </v-card>

                        <v-card v-if="typeAction=='2'">
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="4">
                                    <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                    <!-- <span class="font-weight-medium">保养设备</span> -->
                                </v-col>
                                <v-col cols="7">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物资编码:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.goodsMaterialsCode  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物资名称:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.goodsMaterialsName  }}</p>
                                </v-col>
                            </v-row>
    
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">规格型号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{  props.items.partModel   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">数量:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.goodsMaterialsNums  }}</p>
                                </v-col>
                            </v-row>
  
                            
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                            
                            </v-col>
                            <v-col cols="4">
                         

                            </v-col>
                            <v-col cols="4" class="text-right">
                                <v-btn @click="select(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">选择</v-btn>
                            </v-col>
                        </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </div>

        </van-popup>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'


    import {httpHandle} from '@/http/http'  // api

    import { showSuccessToast,showFailToast,showToast } from 'vant';
import { windowWidth } from 'vant/lib/utils';

  export default {
    components:{
        AppBarPage,
        TableComponents
    },
    data: () => ({
        baseURL:"",
        pageSearchConfig:{},  // 查询信息

        drawer: false,


        code:'',  // 物料编号
    }),
    emits: ["select"],
    created(){
        this.initHandle()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        }, 
        initHandle(){
            const {typeAction}=this

            this.$nextTick(()=>{

                if(typeAction=='1'){
                   this.baseURL='/iiot/sparePart/listAll' 
                }

                if(typeAction=='2'){
                   this.baseURL='/iiot/sparePartUse/getGoodsMaterialsList' 
                }

            })
        },
        showDrawer(){
            this.drawer=true

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1,{})
            })
        },
        // 查询
        search(){
            this.$refs.table1.initFunc(1)
        },
        // 重置
        rest(){
            this.code=''
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 选择
        select(props){
            this.drawer=false
            const {typeAction}=this

            // 出库
            const _json={
                tmBasPartId: props.items.goodsMaterialsId,
                matnr: props.items.goodsMaterialsCode,
                maktxC: props.items.goodsMaterialsName,
            }

            this.$nextTick(()=>{
                this.$emit("select", typeAction=='1'? props.items:_json)
            })
        }
    },
    props:{
        typeAction:{
            type: String,
            default: ()=> ""
        }, 
    }
  }
</script>