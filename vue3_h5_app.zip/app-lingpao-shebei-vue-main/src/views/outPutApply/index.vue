<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <v-row >    
            <v-btn @click="aplayClick('1')" color="primary" variant="outlined" style="margin-right: 12px;">入库申请</v-btn>
            <v-btn @click="aplayClick('2')" color="warning" variant="outlined">出库申请</v-btn>
        </v-row>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                :showSearchBtn="true"
                :auto="false"
                url="/iiot/sparePartUse/ghList"
                :params="{ 
                    operUserCode:_operUserCode,
                    dataState:'N',
                    ...pageSearchConfig
                 }"
                @searchClick="searchClick"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="4">
                                <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                <!-- <span class="font-weight-medium">保养设备</span> -->
                            </v-col>
                            <v-col cols="7">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出入库编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.sparePartUseCode  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出入库名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.sparePartUseName  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出入库类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ FormatDictionary('ccgl_oper_type',props.items.useInfoType)['lable']  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">业务类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ FormatDictionary('ccgl_bpbj_business_type',props.items.businessType)['lable']  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">单据编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.businessCode  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">单据名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.businessName  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">物资编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.goodsMaterialsCode  }}</p>
                            </v-col>
                        </v-row>

                        
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">物资名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.goodsMaterialsName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">申请数量:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.goodsMaterialsNums  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">申请人名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.operUserName  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出库数量:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.outNums  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出库人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.outUserCode  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出库人名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.outUserName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出库时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.outDatetime  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">完成标记:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" :style="`${props.items.finishState=='Y'?'color:#4CAF50;':'color:#F44336;'}`">{{ FormatDictionary('sys_yes_no',props.items.finishState)['lable']   }}</p>
                            </v-col>
                        </v-row>
  
                        <v-row no-gutters class="text">
                            <v-col cols="6">
                                <v-btn v-if="props.items.finishState=='N'" @click="edit(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">修改</v-btn>
                                <v-btn v-if="props.items.finishState=='Y' &&  props.items.ghState==0" @click="giveBack(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">归还</v-btn>
                            </v-col>

                            <v-col cols="6" class="text-right">
                                <v-btn v-if="props.items.finishState=='N'" @click="remove(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">报废</v-btn>
                                <v-btn v-if="props.items.finishState=='Y'" @click="pigeonhole(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">归档</v-btn>
                                
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './search.vue' 

    import {httpHandle} from '@/http/http'  // api

    import { showSuccessToast,showFailToast,showToast } from 'vant';
    import { showDialog  } from 'vant'


  export default {
    components:{
        AppBarPage,
        SearchPage,
        TableComponents
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息

        _operUserCode:""
    }),
    created(){
        this.initHanlde()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        }, 
        initHanlde(){
            const _bufferUserInfo=JSON.parse( localStorage.getItem("bufferUserInfo")||"{}" )

            this._operUserCode=_bufferUserInfo.userId       // 用户信息 userId

            this.$nextTick(()=>{
                this.$refs.table1.initFunc()
            })
        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option={}){

            this.pageSearchConfig=option

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

            // console.log(option)
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })


        },
        // 入库申请 出库申请
        async aplayClick(active){
            this.$router.push({
                path:'/outPutApply/put',
                query:{useInfoType: active }
            })
        }, 
        // 修改
        edit(props){
            const {items}=props
            // console.log(items)
            // useInfoType

            this.$router.push({
                path:'/outPutApply/put',
                query:{
                    isEdit:true,
                    useInfoType: items.useInfoType, 
                    sparePartUseId: items.sparePartUseId 
                }
            })
        },
        // 报废
        async remove(props){
            const {items}=props

            showDialog({
                title: '报废',
                message: `是否确认删除仓储物流-备品备件出入库编号为[${items.sparePartUseId}]的数据项？`,
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {

                const {code,data={}}= await httpHandle({
                    url:`/iiot/sparePartUse/${items.sparePartUseId}`,
                    method:'DELETE'
                })

                if(code==200){
                    showSuccessToast('提交成功！')
                    this.$refs.table1.initFunc()
                }
            });
        },
        // 归还
        giveBack(props){
            const {items}=props
            
            this.$router.push({
                path:'/outPutApply/giveBack',
                query:{ row: JSON.stringify(items) }
            })
        },
        // 归档
        async pigeonhole(props){
            const {items}=props


            const {code,data={}}= await httpHandle({
                url: `/iiot/sparePartUse/updateState/${items.sparePartUseId}`,
                method: "get",
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.$refs.table1.initFunc(1)
            }

        }
    },
  }
</script>