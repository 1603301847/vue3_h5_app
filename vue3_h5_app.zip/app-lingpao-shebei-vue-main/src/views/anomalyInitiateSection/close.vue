<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">例外转序信息</span>
                </v-col>
                <v-col cols="5" class="text-right">
                    <!-- <span :style="`color:${!isEdit?'#4CAF50':'#00E5FF'}`">{{ isEdit?'修改':'新增' }}</span> -->
                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p> -->
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">序列号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left text-teal-lighten-1">{{ bufferRow.sn }}</p>
                </v-col>
            </v-row>
            
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起工序:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light">{{ bufferRow.initiateProcess }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">拦截工序:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light">{{ bufferRow.interceptProcess }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">例外转序原因:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light">{{ bufferRow.conversionDesc }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">整机物料:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light">{{ bufferRow.partName }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light" >{{ bufferRow.initiateByName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light" >{{ bufferRow.createDate }}</p>
                </v-col>
            </v-row>

  
            <UploaderImageComponents 
                :initPath="bufferRow.initiatePath"
                preview
            />


            <van-field v-model="value1"  type="textarea" required autocomplete="off" placeholder="请输入" label="关闭原因" />

        

            <v-row >
   
                <v-col cols="12" class="text-left">
                    <v-btn @click="submit" block color="primary">
                        关闭
                    </v-btn>
                </v-col>
                </v-row>
        </v-sheet>



        


        <div style="height:56px;"></div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 异常处理 详情
    import {httpHandle} from '@/http/http'  // api
    import SelectComponents from '@/packages/Select.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'


    

    import { showSuccessToast,showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        SelectComponents,
        UploaderImageComponents,
    },
    data: () => ({

        bufferRow:{},  // 行数据

        bufferFileList:[],  // 缓存图片

        value1:"",   // 关闭原因

    }),
    watch: {

    },
    created(){
        this.initFunc()

    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmAbnormalConversionId}=this.$route.query


            const {code,data={}}= await httpHandle({
                url:`/iiot/abnormalConversion/${ttQmAbnormalConversionId}`,
                method: "get",
            })

            if(code==200){
                this.bufferRow=data
            } 

        },
        // 提交
        async submit(){
            const {ttQmAbnormalConversionId}=this.$route.query
            const {bufferRow}=this



            if( !this.value1.trim() ){
                showFailToast('关闭原因必填！')
                return
            }



            const _json={
                ttQmAbnormalConversionId:ttQmAbnormalConversionId,  // 例外转序ID
                closeExplain: this.value1  // 关闭原因
            }


            const {code,data={}}= await httpHandle({
                url:'/iiot/abnormalConversion/closeAbnormalConversion',
                method: "post",
                payload: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                
                setTimeout(()=>{
                    this.$router.go(-1)
                },600)
            }
        }
    },
  }
</script>