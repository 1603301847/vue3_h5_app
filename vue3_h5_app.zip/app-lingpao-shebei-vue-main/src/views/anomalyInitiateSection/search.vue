<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <ScanBarComponents 
            ref="ScanBar"
            placeholder="请扫描或输入 整机序列号"
            @searchClick="barSearchClick"
        />


        <SelectComponents 
            v-model="measures"
            ref="select11"
            label="工序查询"
            showSearch
            :option="measuresSelectOption"
            @onSearchChange="measuresSelectSearchChange"

        />

        <v-btn style="position:fixed;top:170px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="secondary" @click="searchFunc">查询</v-btn>
        <!-- <v-btn style="position:fixed;top:236px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="addFunc">发起</v-btn> -->
        <v-btn style="position:fixed;top:228px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="resetFunc">重置</v-btn>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                url="/iiot/abnormalConversion/list"
                :showSearchBtn="false"
                :params="{  
                    ttPpOrderSnId:ttPpOrderSnId,
                    tmBasNodeLevelId: measures
                }"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>

                            <v-col cols="8">
                                <p class="text-truncate font-weight-medium text-left text-teal-lighten-1" color="primary">{{ FormatDictionary('conversion_status',props.items.conversionState)['lable'] }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-light text-teal-lighten-1">{{ props.items.conversionNo }}</p>
                            </v-col>
                        </v-row>
      
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">序列号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.sn }}</p>
                            </v-col>
                        </v-row>
                        
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">发起工序:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.initiateProcess }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">拦截工序:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.interceptProcess }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">例外转序原因:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.conversionDesc }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">整机物料:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.partName }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">发起人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.initiateByName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">发起时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" >{{ props.items.createDate }}</p>
                            </v-col>
                        </v-row>

  
                        <UploaderImageComponents 
                            :initPath="props.items.initiatePath"
                            preview
                        />


                        <!-- <v-row no-gutters class="text">
                            <v-col cols="6" class="text-left">
                                <v-btn v-if="props.items.conversionState=='10'" @click="dischargedClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">放行</v-btn>
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn v-if="props.items.conversionState!='30'" @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">关闭</v-btn>
                            </v-col>
                        </v-row> -->
                    </v-card>
                </template>
            </TableComponents>
        </div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';
    import SelectComponents from '@/packages/Select.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'


  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        SelectComponents,
        UploaderImageComponents,
        TableComponents
    },
    data: () => ({

        ttPpOrderSnId:"",   // 序列号 ID 


        measures:"",            // 发起工序
        measuresSelectOption:[],    // 发起工序 数据
    }),
    created(){
        this.measuresHTTP()
        this.initHandle()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        initHandle(){
            const {_sn}=this.$route.query

            if(_sn){
                setTimeout(()=>{
                    this.$refs.ScanBar && this.$refs.ScanBar.setInputText(_sn)
                    this.barSearchClick(_sn)
                },1000)
            }
        },
        // 发起工序
        async measuresHTTP(key=""){
            const {bufferRow}=this


            const {code,data=[]}= await httpHandle({
                url:'/iiot/nodeLevel/listNodeLevelForSelect',
                method:"get",
                url_params:{
                    noOrName:key,
                    templateLevelNodeNo:'uloc',
                    // tmBasNodeLevelId:this.tmBasNodeLevelId,
                    status:"1"
                }

            }) 

            if(code==200){
                this.measuresSelectOption=data.map(o=>Object.assign({
                    text:o.nodeLevelNo +o.nodeLevelName,
                    value:o.tmBasNodeLevelId 
                }))
            } 
        },
        // 发起工序  模糊查询
        measuresSelectSearchChange(text){
            this.measuresHTTP(text) 
        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            const {code,data=[]}= await httpHandle({
                url:'/iiot/qmTask/listQmTaskSnForSelect',
                method: "get",
                url_params:{
                    sn: _value
                }
            })

            if(code==200){

                if(!data.length){
                    showFailToast("SN号不存在！")
                    return
                }    

                this.ttPpOrderSnId=data[0]?.ttPpOrderSnId
                showSuccessToast("扫描成功！")

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc(1)
                })
            }
        },
        // 重置
        resetFunc(){
            this.ttPpOrderSnId=''
            this.$refs.ScanBar && this.$refs.ScanBar.setInputText('')
            this.$refs.select11 && this.$refs.select11.reset(  )  // 发起工序

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询
        searchFunc(){
            this.$refs.table1.initFunc(1)
        },
        // 发起
        addFunc(){
            
            // this.$router.push({
            //     path:'/anomalyInitiateSection/add', 
            //     query:{ }
            // }) 
        },
        // 关闭
        async detailClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiateSection/close', 
                query:{ ttQmAbnormalConversionId: items.ttQmAbnormalConversionId  }
            }) 

        },
        // 放行
        dischargedClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiateSection/discharged', 
                query:{ ttQmAbnormalConversionId: items.ttQmAbnormalConversionId  }
            }) 
        }


    },
  }
</script>
