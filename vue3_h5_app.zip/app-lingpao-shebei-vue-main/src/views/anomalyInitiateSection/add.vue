<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">例外转序信息</span>
                </v-col>
                <v-col cols="5" class="text-right">
                    <span :style="`color:${!isEdit?'#4CAF50':'#00E5FF'}`">{{ isEdit?'变更':'发起' }}</span>
                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p> -->
                </v-col>
            </v-row>
            
            <div style="margin-top: 12px;padding: 0px 8px;">
                <ScanBarComponents 
                    ref="ScanBar"
                    placeholder="请扫描或输入 整机序列号"
                    @searchClick="barSearchClick"
                />
                <p :style="`color:#4CAF50`">{{ ttPpOrderSnId }}</p>
            </div>



            <SelectComponents 
                v-model="measures"
                ref="select11"
                label="发起工位"
                
                required
                :option="measuresSelectOption"
                @onSearchChange="measuresSelectSearchChange"
                @onChange="measuresSelectChange"
            />

            <SelectComponents 
                v-model="measures22"
                ref="select22"
                label="拦截工位"
                
                :option="measuresSelectOption22"
                @onSearchChange="measuresSelectSearchChange22"
            />


            <van-field v-model="value1"  type="textarea" required autocomplete="off" placeholder="请输入" label="例外转序原因" />
            
            <UploaderImageComponents 
                v-model="bufferFileList"
            />
            <van-field v-model="value2"  type="textarea"  autocomplete="off" placeholder="请输入" label="备注" />



            
 

            <v-row >
   
                <v-col cols="12" class="text-left">
                    <v-btn @click="submit" block color="warning">
                       {{ isEdit?'变更':'发起' }} 
                    </v-btn>
                </v-col>
                </v-row>
        </v-sheet>



        


        <div style="height:56px;"></div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 异常处理 详情
    import {httpHandle} from '@/http/http'  // api
    import SelectComponents from '@/packages/Select.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'


    

    import { showSuccessToast,showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        SelectComponents,
        UploaderImageComponents,
    },
    data: () => ({
        showName:false,
        bufferRow:{},  // 行数据

        isEdit:false,

        ttPpOrderSnId:"",   // 序列号 ID 
        bufferFileList:[],  // 缓存图片


        value1:"",   // 例外转序原因
        value2:"",   // 备注


        measures:"",            // 发起工序
        measuresSelectOption:[],    // 发起工序 数据

        measures22:"",            // 拦截工序
        measuresSelectOption22:[],    // 拦截工序 数据
    }),
    watch: {

    },
    created(){
        this.initFunc()
        // this.measuresHTTP()
        // this.measuresHTTP22()


    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmAbnormalConversionId,ttPpOrderSnId,sn}=this.$route.query

            this.isEdit=ttQmAbnormalConversionId?true:false

            if(ttPpOrderSnId){
                this.ttPpOrderSnId=ttPpOrderSnId

                this.$nextTick(()=>{
                    this.$refs.ScanBar && this.$refs.ScanBar.setInputText(sn)
                })

            }

            // 检验过来
            if(!ttQmAbnormalConversionId && ttPpOrderSnId){
                // this.initStation()

                this.$nextTick(()=>{
                    this.measuresHTTP()
                    this.measuresHTTP22()
                })

            }

            // 变更
            if(ttQmAbnormalConversionId) {
                const {code,data={}}= await httpHandle({
                    url:`/iiot/abnormalConversion/${ttQmAbnormalConversionId}`,
                    method: "get",
                })

                if(code==200){
                    this.bufferRow=data

                    this.ttPpOrderSnId=data.ttPpOrderSnId

                    this.$nextTick(async()=>{
                        await this.measuresHTTP()
                        await this.measuresHTTP22()

                        this.measures=data.tmBasNodeLevelId   // 发起工序
                        this.measures22=data.interceptProcessId   // 拦截工序

                        this.$refs.select11 && this.$refs.select11.setfieldValue( data.initiateProcess )  // 发起工序
                        this.$refs.select22 && this.$refs.select22.setfieldValue( data.interceptProcess )  // 拦截工序

                        setTimeout(()=>{
                            this.$refs.select11 && this.$refs.select11.setValue( data.tmBasNodeLevelId )  // 发起工序
                            this.$refs.select22 && this.$refs.select22.setValue( data.interceptProcessId )  // 拦截工序
                        },1000)
                    })



                    



                    this.value1=data.conversionDesc       // 例外转序原因

                    this.value2=data.remark                // 发起备注


                    if(data.initiatePath){
                        this.bufferFileList=data.initiatePath.split(',').map(o=>Object.assign({url:o}))    // 发起图片
                    }


                } 
            }
            //
        },
        // 默认 发起工位
        async initStation(){
            // const {ttPpOrderSnId=''}=this.$route.query
            // const {code,data={}}= await httpHandle({
            //     url:'/iiot/userUloc/getUserUlocByUser',
            //     method: "get",
            // })

            // if(code==200){

            //     this.interceptDefult(data.tmBasNodeLevelId,ttPpOrderSnId)
            //     this.measures=data.tmBasNodeLevelId   // 发起工序
                
            //     setTimeout(()=>{
            //         this.$refs.select11 && this.$refs.select11.setValue( data.tmBasNodeLevelId  )  // 发起工序
            //     },1000)
            // }
        },
        // 默认拦截工位
        async interceptDefult(tmBasNodeLevelId,ttPpOrderSnId){
   
            // const {code,data}= await httpHandle({
            //     url:'/iiot/qmTask/getInterceptProcessIdById',
            //     method: "get",
            //     url_params:{
            //         ttPpOrderSnId: ttPpOrderSnId,
            //         tmBasNodeLevelId: tmBasNodeLevelId
            //     }
            // })

            // if(code==200 && data){
            //     this.measures22=data   // 拦截工序

            //     setTimeout(()=>{
            //         this.$refs.select22 && this.$refs.select22.setValue( data )  // 拦截工序
            //     },1000)
            // }
        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            const {code,data=[]}= await httpHandle({
                url:'/iiot/qmTask/listQmTaskSnForSelect',
                method: "get",
                url_params:{
                    sn: _value
                }
            })

            if(code==200){

                if(!data.length){
                    showFailToast("SN号不存在！")
                    return
                }    

                this.ttPpOrderSnId=data[0]?.ttPpOrderSnId
                showSuccessToast("扫描成功！")

                if(this.measures){
                    this.interceptDefult(this.measures,data[0]?.ttPpOrderSnId)
                }


                this.$nextTick(()=>{
                    this.measuresHTTP()
                    this.measuresHTTP22()
                })
            }
        },
        // 发起工序
        async measuresHTTP(key=""){
            const {bufferRow}=this
            const _ttPpOrderSnId=this.ttPpOrderSnId


            // const {code,data=[]}= await httpHandle({
            //     url:'/iiot/nodeLevel/listNodeLevelForSelect',
            //     method:"get",
            //     url_params:{
            //         noOrName:key,
            //         templateLevelNodeNo:'uloc',
            //         // tmBasNodeLevelId:this.tmBasNodeLevelId,
            //         status:"1"
            //     }

            // }) 

            const {code,data=[]}= await httpHandle({
                url:'/iiot/qmTask/getInspectNodeLevelList',
                method:"get",
                url_params:{
                    ttPpOrderSnId:_ttPpOrderSnId
                }
            }) 


            if(code==200){
                this.measuresSelectOption=data.map(o=>Object.assign({
                    text:o.nodeLevelNo +o.nodeLevelName,
                    value:o.tmBasNodeLevelId 
                }))
            } 
        },
        // 拦截工序
        async measuresHTTP22(key=""){
            const {bufferRow}=this
            const _ttPpOrderSnId=this.ttPpOrderSnId


            // const {code,data=[]}= await httpHandle({
            //     url:'/iiot/nodeLevel/listNodeLevelForSelect',
            //     method:"get",
            //     url_params:{
            //         noOrName:key,
            //         templateLevelNodeNo:'uloc',
            //         // tmBasNodeLevelId:this.tmBasNodeLevelId,
            //         status:"1"
            //     }

            // }) 
            const {code,data=[]}= await httpHandle({
                url:'/iiot/qmTask/getInspectNodeLevelList',
                method:"get",
                url_params:{
                    ttPpOrderSnId:_ttPpOrderSnId
                }
            }) 

            if(code==200){
                this.measuresSelectOption22=data.map(o=>Object.assign({
                    text:o.nodeLevelNo +o.nodeLevelName,
                    value:o.tmBasNodeLevelId 
                }))
            } 
        },
        // 发起工序 模糊查询
        measuresSelectSearchChange(text){
            this.measuresHTTP(text) 
        },
        // 发起工位  change
        measuresSelectChange(text){
            // if(this.ttPpOrderSnId){
            //     this.interceptDefult(text,this.ttPpOrderSnId)
            // }

            this.$nextTick(()=>{
                const _measuresSelectOption22=this.measuresSelectOption22
                if(_measuresSelectOption22.length){
                    const _obj=_measuresSelectOption22[_measuresSelectOption22.length-1]
                    
                    this.measures22=_obj.value
                    console.log(_obj.value)
                    this.$refs.select22 && this.$refs.select22.setValue( _obj.value )  // 拦截工序
                }
            })
        },
        // 拦截工序 模糊查询
        measuresSelectSearchChange22(text){
            this.measuresHTTP22(text) 
        },
        // 提交
        async submit(){
            const {ttQmAbnormalConversionId}=this.$route.query



            if( !this.ttPpOrderSnId ){
                showFailToast('整机序列号 未扫描！')
                return
            }

            if( !this.measures ){
                showFailToast('发起工序必选！')
                return
            }

            if( !this.value1.trim() ){
                showFailToast('例外转序原因必填！')
                return
            }


            // 新增
            const _json={
                ttPpOrderSnId: this.ttPpOrderSnId,      // 产品序列号
                tmBasNodeLevelId: this.measures,    // 发起工序
                interceptProcessId: this.measures22,   // 拦截工序
                conversionDesc: this.value1,       // 例外转序原因
                initiatePath: this.bufferFileList.map(o=>o.url).join(),         // 发起图片
                remark: this.value2,                 // 发起备注

            }

            const {code,data={}}= await httpHandle({
                url: '/iiot/abnormalConversion',
                method:ttQmAbnormalConversionId? 'put': "post",
                payload: ttQmAbnormalConversionId?{
                    ttQmAbnormalConversionId:ttQmAbnormalConversionId, 
                    ..._json
                }: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.go(-1)
            }
        }
    },
  }
</script>