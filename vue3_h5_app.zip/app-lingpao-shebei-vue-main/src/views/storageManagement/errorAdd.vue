<template>
    <span>
        <AppBarPage>
        </AppBarPage>

        <v-row no-gutters style="margin-bottom:8px;">
            <v-col cols="8">
                <v-icon icon="mdi-bullhorn" size="16" color="error"></v-icon>
                <span style="padding-left:6px;">{{ `${abnormalId?'修改异常':'添加异常'}` }}</span>
            </v-col>
            <v-col cols="4" class="text-right" style="padding-right:6px">
                <!-- <span class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</span> -->
            </v-col>
        </v-row>



        <v-sheet elevation="2" rounded class="custem-card">



            <SelectComponents 
                v-model="user"
                ref="select11"
                label="物料编码"
                :option="repairmanSelectOption"
            />

            <van-field v-model="reqQty" type="number" placeholder="请输入" label="数量" autocomplete="off" />


            <SelectComponents 
                v-model="type"
                ref="select22"
                label="异常类型"
                :option="typeSelectOption"
            />

            <SelectComponents 
                v-model="type2"
                ref="select33"
                label="处理类型"
                :option="type2SelectOption"
            />


            <van-field v-model="abnormalExplain" placeholder="请输入" label="异常说明" autocomplete="off" />
            <van-field v-if="isDispose" v-model="disposeExplain" placeholder="请输入" label="处理说明" autocomplete="off" />
   

            <SelectComponents 
                v-if="isDispose"
                v-model="dataStatus"
                ref="select55"
                label="数据状态"
                :option="dataStatusSelectOption"
            />

        </v-sheet>

        <v-row no-gutters>
            <v-col cols="12">
                <v-btn
                    block
                    color="primary"
                    @click="onSubmit"
                >
                    提交
                </v-btn>
            </v-col>

        </v-row>
        <div style="height: 80px;"></div>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import SelectComponents from '@/packages/Select.vue'


    import { showSuccessToast,showFailToast } from 'vant'
    import {httpHandle} from '@/http/http'  // api




  export default {
    components:{
        AppBarPage,
        SelectComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据
        abnormalId:'',

        editData:{},
        isDispose:false,  // 处理

        user:"",     // 物料编码    
        repairmanSelectOption:[],   // 物料编码 数据

        reqQty:"",  // 数量

        
        type:"",     // 异常类型    
        typeSelectOption:[],   // 异常类型 数据

        type2:"",     // 处理异常类型    
        type2SelectOption:[],   // 处理异常类型 数据

        abnormalExplain:"",  // 异常说明
        disposeExplain:"",  // 处理说明

        dataStatus:"",   // 数据状态 
        dataStatusSelectOption:[],   // 数据状态 
    }),
    created(){
        this.initFunc()
        this.initRepairman()  
    },
    methods: {
        // 初始化
        async initFunc(){
            const {abnormalId,isDispose}=this.$route.query

            this.abnormalId=abnormalId
            this.isDispose=isDispose
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            // 异常类型
            const _selectAttribute=_bufferDictionaries["ccgl_abnormal_type"]||[]    // 属性
            this.typeSelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

            // 处理类型
            const _selectAttribute2=_bufferDictionaries["ccgl_abnomal_dispose"]||[]    // 属性
            this.type2SelectOption=_selectAttribute2.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

            // 数据
            const _selectAttribute3=_bufferDictionaries["ccgl_abnomal_state"]||[]    //  数据状态类型
            this.dataStatusSelectOption=_selectAttribute3.map(o=>Object.assign({text:o.lable,value:o.value}))   // 数据状态 数据

            
            // 修改
            const {code,data={}}= await httpHandle({
                url: '/iiot/deliverySlipAbnormal/' + abnormalId,
                method:"get",
            }) 

            if(code==200){
                // console.log(data)
                this.editData=data

                this.user=data.partNo,     // 物料编码   
                this.reqQty=data.reqQty  // 数量
                this.type=data.abnormalType     // 异常类型    
                this.type2=data.disposeType    // 处理异常类型    
                this.abnormalExplain=data.abnormalExplain  // 异常说明
                // this.disposeExplain=data.disposeExplain // 处理说明


                this.$nextTick(()=>{
                    this.$refs.select11 && this.$refs.select11.setValue(data.partNo)
                    this.$refs.select22 && this.$refs.select22.setValue(data.abnormalType)
                    this.$refs.select33 && this.$refs.select33.setValue(data.disposeType)
                })
            }
        },
        // 物料编码
        async initRepairman(){
            
            const {deliverySlipId}=this.$route.query

            const _data= await httpHandle({
                url:`/iiot/deliverySlipPart/dict/${deliverySlipId}`,
                method:"get",
            }) 

            this.repairmanSelectOption=(_data||[]).map(o=>Object.assign({
                text:`${o.dictValue||''}-${o.dictLabel||''}`,
                value:o.dictValue,
                dictLabel:o.dictLabel
            }))

        },
        // 确认维修
        async onSubmit(){
            const {deliverySlipId,deliverySlipType,poNo,srmNo,abnormalId}=this.$route.query


            const json={
                abnormalId: null,
                deliverySlipId: deliverySlipId,
                deliverySlipType: deliverySlipType,
                poNo: poNo,
                srmNo: srmNo,
                abnormalType: null,
                abnormalExplain: null,
                partNo: null,
                reqQty: null,
                partName: null,
                submitDatetime: null,
                submitUser: null,
                disposeType: null,
                disposeExplain: null,
                disposeUser: null,
                disposeDatetime: null,
                dataState: 2,
                createBy: null,
                createTime: null,
                updateBy: null,
                updateTime: null,
                delFlag: null,
                version: null
            }
            
            const _json2= abnormalId ? this.editData :json

            const _json={
                ..._json2,
                partNo:this.user,     // 物料编码   
                partName: this.repairmanSelectOption.filter(o=>o.value==this.user)[0]?.dictLabel,
                reqQty:this.reqQty,  // 数量
                abnormalType:this.type,     // 异常类型    
                disposeType:this.type2,     // 处理异常类型    
                abnormalExplain:this.abnormalExplain,  // 异常说明
                disposeExplain:this.disposeExplain,  // 处理说明
                dataState: this.dataStatus   // 数据状态
            }


            const {code,data={}}= await httpHandle({
                url:'/iiot/deliverySlipAbnormal',
                method: abnormalId?'put':'post',
                payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$router.go(-1) 
            }
            
        },


    },
  }
</script>