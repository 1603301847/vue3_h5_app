<template>
    <span>
        <AppBarPage>
        </AppBarPage>

        <v-row no-gutters style="margin-bottom:8px;">
            <v-col cols="8">
                <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                <span style="padding-left:6px;">入库</span>
            </v-col>
            <v-col cols="4" class="text-right" style="padding-right:6px">
                <!-- <span class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</span> -->
            </v-col>
        </v-row>



        <v-sheet elevation="2" rounded class="custem-card">

            <ScanBarComponents 
                ref="scanBar1"
                placeholder="扫描或输入 工装编号"
                @searchClick="barSearchClick"
            />
            <p style="padding-left:4px;padding-bottom:4px;color:#00E5FF;">{{ boxSn }}</p>

            <ScanBarComponents 
                ref="scanBar2"
                placeholder="扫描或输入 地码编号"
                @searchClick="barSearchClick2"
            />
            <p style="padding-left:4px;padding-bottom:4px;color:#00E5FF;">{{ storageCode }}</p>

            <ScanBarComponents 
                ref="scanBar3"
                placeholder="扫描物料码"
                @searchClick="barSearchClick3"
            />
            <p style="padding-left:4px;padding-bottom:4px;color:#00E5FF;">{{ text1 }}</p>

            

            <v-row no-gutters>
                <v-col cols="4">
                    <p style="padding-left:16px;margin-top:14px;">
                        <span style="color:red">*</span>
                        AGV调度</p>
                </v-col>
                <v-col cols="8" style="height: 42px;">
                    <v-switch
                    v-model="switchUrgency"
                    :label="switchUrgency?'是':'否'"
                    required
                    color="primary"
                    density="comfortable"
                    style="height:48px;display:inline-block;height:48px;width:104px;margin-left:14px;"
                    ></v-switch>
                </v-col>
            </v-row>

            <SelectComponents 
                v-model="user"
                ref="select11"
                label="物料编码"
                required
                :option="repairmanSelectOption"
            />

            <!-- <van-field v-model="reqQty" type="number" placeholder="请输入" label="数量" autocomplete="off" /> -->


            <!-- <SelectComponents 
                v-model="type"
                ref="select22"
                label="异常类型"
                :option="typeSelectOption"
            /> -->

            <!-- <SelectComponents 
                v-model="type2"
                ref="select33"
                label="处理类型"
                :option="type2SelectOption"
            /> -->


            <!-- <van-field v-model="abnormalExplain" placeholder="请输入" label="异常说明" autocomplete="off" />
            <van-field v-model="disposeExplain" placeholder="请输入" label="处理说明" autocomplete="off" />
            -->

            <van-field v-model="value11" type="number" required placeholder="请输入" label="数量" autocomplete="off" />
            <van-field v-model="value22" placeholder="请输入" label="队列序号" autocomplete="off" />
            <van-field v-model="value33" placeholder="请输入" label="追溯码" autocomplete="off" />
            <van-field v-model="value44" placeholder="请输入" label="批次编码" autocomplete="off" />
            <van-field v-model="value55" placeholder="请输入" label="包装号" autocomplete="off" />
            <van-field v-model="value66" placeholder="请输入" label="产品号" autocomplete="off" />

            <DatePickerComponents 
                v-model="dateStart"
                label="生产日期" 
                ref="dateTimeStart"
                :columns-type="['year','month','day']"
            />

            <DatePickerComponents 
                v-model="dateOver"
                label="有效日期" 
                ref="dateTimeOver"
                :columns-type="['year','month','day']"
            />

        </v-sheet>
        <div style="height: 16px;"></div>

        <v-row no-gutters>
            <v-col cols="12">
                <v-btn
                    block
                    color="secondary"
                    @click="onSubmit"
                >
                    添加
                </v-btn>
            </v-col>
        </v-row>
        <div style="height: 16px;"></div>

        <v-sheet>
            <v-row no-gutters style="margin-bottom:8px;">
                <v-col cols="8">
                    <v-icon icon="mdi-format-list-bulleted-square" size="16" color="primary"></v-icon>
                    <span style="padding-left:6px;">部件信息列表 [{{ children.length }}]</span>
                </v-col>
                <v-col cols="4" class="text-right" style="padding-right:6px">
                    <!-- <span class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</span> -->
                </v-col>
            </v-row>

            <div class="v-window-item-table">
                <TableComponents
                    ref="table1"
                    :showSearchBtn="false"
                    :pagingShow="false"
                    :children="children"
                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="5">
                                    <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                    <!-- <p class="text-truncate font-weight-medium font-weight-light">点检设备</p> -->
                                </v-col>
                                <v-col cols="1" class="text-right">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料编码:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.partNo }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料名称:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.partName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">入库数量:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.goodsMaterialsNums }}</p>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </div>


        </v-sheet>
        <div style="height: 12px;"></div>

        <v-row no-gutters>
            <v-col cols="12">
                <v-btn
                    block
                    color="primary"
                    @click="onSubmit22"
                >
                    提交
                </v-btn>
            </v-col>
        </v-row>

        <div style="height: 80px;"></div>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import SelectComponents from '@/packages/Select.vue'
    import DatePickerComponents from '@/packages/DatePicker.vue'
    import TableComponents from '@/packages/Table.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import moment from "moment"


    import { showSuccessToast,showFailToast } from 'vant'
    import {httpHandle} from '@/http/http'  // api




  export default {
    components:{
        AppBarPage,
        SelectComponents,
        DatePickerComponents,
        TableComponents,
        ScanBarComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据

        children:[],    // 部件列表

        text1:"",

        switchUrgency:true,   // 是
        user:"",     // 物料编码    
        repairmanSelectOption:[],   // 物料编码 数据

        value11:"",
        value22:"",
        value33:"",
        value44:"",
        value55:"",
        value66:"",

        dateStart:"",  // 生产日期
        dateOver:"",    // 有效日期

        boxSn:"",  // 工装编号
        storageCode:"",  // 地码编号


        reqQty:"",  // 数量

        
        type:"",     // 异常类型    
        typeSelectOption:[],   // 异常类型 数据

        type2:"",     // 处理异常类型    
        type2SelectOption:[],   // 处理异常类型 数据

        abnormalExplain:"",  // 异常说明
        disposeExplain:"",  // 处理说明
    }),
    created(){
        this.initFunc()
        this.initRepairman()  
    },
    methods: {
        // 初始化
        initFunc(){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            // 异常类型
            const _selectAttribute=_bufferDictionaries["ccgl_abnormal_type"]||[]    // 属性
            this.typeSelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

            // 处理类型
            const _selectAttribute2=_bufferDictionaries["ccgl_abnomal_dispose"]||[]    // 属性
            this.type2SelectOption=_selectAttribute2.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

            
            
            
        },
        // 物料编码
        async initRepairman(){
            
            const {deliverySlipId}=this.$route.query

            const {code,data=[]}= await httpHandle({
                url: '/iiot/deliverySlip/selectPutInStorageList/' + deliverySlipId,
                method:"get",
            }) 

            if(code==200){
                this.repairmanSelectOption=data.map(o=>Object.assign({
                    text:`${o.partNo||''}-${o.partName||''}`,
                    value:o.partNo,
                    partNo: o.partNo,
                    partName: o.partName,
                }))
            }


        },
        // 添加
        async onSubmit(){
            const {deliverySlipId,deliverySlipType,poNo,srmNo}=this.$route.query


            if(!this.user){
                showFailToast("物料编码未选！")
                return
            }

            if(!this.value11){
                showFailToast("数量必填！")
                return
            }

            if(Number(this.value11)<=0){
                showFailToast("数量必填大于0！")
                return
            }

            const _json={
                partNo: this.user,   // 物料编码
                partName:  this.repairmanSelectOption.filter(o=>o.partNo==this.user)[0]?.partName,   // 物料名称
                goodsMaterialsNums: Number(this.value11),   // 数量
                warehouseSn: this.value22,   // 队列序号
                traceSn: this.value33,   // 追溯码
                bnsSn: this.value44,   // 批次编码
                packSn: this.value55,   // 包装号
                productSn: this.value66,   // 产品号
                dateOfManufacture: this.dateStart,   // 生产日期
                effectiveDate: this.dateOver   // 有效日期
            }

            
            
            this.children= this.children.concat([_json]) 

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
                this.resetHandle()


                this.$refs.scanBar1.reset()
                this.$refs.scanBar2.reset()
                this.$refs.scanBar3.reset()

                this.boxSn=""
                this.storageCode=""
                this.text1=""


            })
            
        },
        // 重置
        resetHandle(){
            this.user,   // 物料编码


                this.value11='',   // 数量
                this.value22=''   // 队列序号
                this.value33=''   // 追溯码
                this.value44=''   // 批次编码
                this.value55=''   // 包装号
                this.value66=''   // 产品号

                this.user=''   // 物料编码
                this.$refs.select11.reset()


                this.$refs.dateTimeStart.reset()
                this.$refs.dateTimeOver.reset()
        },
        barSearchClick(value){
            const _val=value.trim()
            this.boxSn=_val
        },
        barSearchClick2(value){
            const _val=value.trim()
            this.storageCode=_val   
        },
        // 提交
        async onSubmit22(){
            const {deliverySlipId}=this.$route.query

            if(!this.children.length){
                showFailToast("未添加部件信息！")
                return
            }

            const _json={
                storageCode: this.storageCode,   // 地码编号
                agv: this.switchUrgency?"Y":"N",  // agv
                boxSn: this.boxSn,    // 工装编号
                deliverySlipId: deliverySlipId,  
                partList:this.children   // 列表
            }

            const {code,data=[]}= await httpHandle({
                url: '/iiot/putin/receiveProcurementData',
                method:"post",
                payload: _json
            }) 

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.go(-1)
            }

        },
        // 物料码
        barSearchClick3(text){
            const {repairmanSelectOption}=this
            const _text=String(text)
            const _obj=_text.split(';')

            if(_obj.length!=3){
                showFailToast("物料码格式错误！")
                return
            }

            const _code=repairmanSelectOption.filter(o=>o.partNo==_obj[0])

            // 物料编码
            if( _code.length ){
                this.user=_code[0].partNo
                this.$refs.select11 && this.$refs.select11.setValue( _code[0].partNo )  // 处理部门
                
                this.value33=_obj[2]
                this.value44= moment(new Date()).format('YYYY.MM.DD')
                this.text1=text
            }else{
                showFailToast("物料编码不存在！")
            }

        }
    },
  }
</script>