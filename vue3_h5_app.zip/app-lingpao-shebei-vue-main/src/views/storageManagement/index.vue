<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <div class="v-window-item-table">

            <ScanBarComponents 
                ref="scanBar1"
                placeholder="扫描或输入 送货单号"
                @searchClick="barSearchClick"
            />

            <TableComponents
                ref="table1"
                :showSearchBtn="true"
                url="/iiot/deliverySlip/receiving/abnormalList"
                :params="{ 
                    ...pageSearchConfig
                 }"
                @searchClick="searchClick"

            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="5">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <!-- <p class="text-truncate font-weight-medium font-weight-light">点检设备</p> -->
                            </v-col>
                            <v-col cols="1" class="text-right">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">送货单类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  FormatDictionary('ccgl_delivery_slip_type',props.items.deliverySlipType)['lable']  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">送货单号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.poNo  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">srm单号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.srmNo  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">供应商名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.supplierName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">发货人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.sendUser  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">联系电话:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.sendUserTel  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">发货日期:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.sendDatetime  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">仓库名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.storageName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">收货人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.signForUserName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">收货时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.signForDatetime  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">单据状态:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  FormatDictionary('ccgl_delivery_slip_state',props.items.deliverySlipState)['lable']  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">是否上报:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  FormatDictionary('sys_yes_no',props.items.sendState)['lable']  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">异常数:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.allNum  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">未处理数:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" :style="`color:${Number(props.items.abnormalNum)>0?'red':''} `">{{  props.items.abnormalNum  }}</p>
                            </v-col>
                        </v-row>


                        <v-row no-gutters class="text">
                            <v-col cols="3" class="text-left">
                                <!-- <v-btn @click="takeClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">收货</v-btn> -->
                            </v-col>
                            <v-col cols="6" class="text-left"></v-col>
  
                            <v-col cols="3" class="text-center">
                                <v-btn @click="detailClick(props)" style="font-size:18px;" color="secondary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>

                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="3" class="text-center">
                                <v-btn @click="putinHandle(props)" style="font-size:18px;" color="secondary mt-1" density="compact" :rounded="0" variant="plain">入库</v-btn>
                            </v-col>
                            <v-col cols="3" class="text-center">
                                <v-btn @click="errorHandle(props)" style="font-size:18px;" color="error mt-1" density="compact" :rounded="0" variant="plain">异常</v-btn>

                            </v-col>
                            <v-col cols="3" class="text-center">
                                <v-btn @click="appearClick(props)" v-if="props.items.sendState === 'N'" style="font-size:18px;" color="primary mt-1" density="compact" :rounded="0" variant="plain">上报</v-btn>
                            </v-col>
                            <v-col cols="3" class="text-center">
                                <v-btn @click="takeClick(props)" style="font-size:18px;" color="error mt-1" density="compact" :rounded="0" variant="plain">归档</v-btn>
                            </v-col>

                        </v-row>

                    </v-card>
                </template>
            </TableComponents>
        </div>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备点检  历史查询
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api
    import  SearchPage from './search.vue' 
    import ScanBarComponents from '@/packages/ScanBar.vue'

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showDialog } from 'vant';


  export default {
    components:{
        AppBarPage,
        TableComponents,
        ScanBarComponents,
        SearchPage
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息
    }),

    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 查看点检单
        async detailClick(props){
            const {items}=props
            
            this.$router.push({
                path:'/storage/detail', 
                query:{ 
                    deliverySlipId:items.deliverySlipId,
                }
            }) 

        },
        // 归档
        async takeClick(props){
            const {items}=props
            

            if(items.abnormalNum < 1) {


                showDialog({
                    title: '归档',
                    message: '确认归档！',
                    theme: 'round-button',
                    closeOnClickOverlay:true,
                }).then(async () => {

                    const {code}= await httpHandle({
                        url:`/iiot/deliverySlip/receiving/archive/${items.deliverySlipId}`,
                        method:'get'
                    })

                    if(code==200){
                        showSuccessToast('归档成功！')
                        this.$refs.table1.initFunc(1)
                    }else{
                        showFailToast("归档失败!")
                    }

                });




            }else{
                showFailToast("异常未处理完不能归档!")
            }
        },
        // 上报
        async appearClick(props){
            const {items}=props


            showDialog({
                title: '上报',
                message: '确认上报！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {

                const {code}= await httpHandle({
                    url:`/iiot/deliverySlip/sendSap/${items.deliverySlipId}`,
                    method:'get'
                })

                if(code==200){
                    showSuccessToast('上报成功！')
                    this.$refs.table1.initFunc(1)
                }

            });




        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option={}){

            this.pageSearchConfig=option

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

            // console.log(option)
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 扫码
        barSearchClick(value){
            const _val=value.trim()
            
            this.$refs.table1.initFunc(1,{
                deliverySlipId:_val
            })
        },
        // 异常
        errorHandle(props){
            const {items}=props

            this.$router.push({
                path:'/storageManagement/error', 
                query:{ 
                    deliverySlipId: items.deliverySlipId,
                    deliverySlipType: items.deliverySlipType,
                    poNo: items.poNo,
                    srmNo: items.srmNo,
                }
            }) 
        },
        // 入库
        putinHandle(props){
            const {items}=props

            this.$router.push({
                path:'/storageManagement/putin', 
                query:{ 
                    deliverySlipId: items.deliverySlipId,
                    // deliverySlipType: items.deliverySlipType,
                    // poNo: items.poNo,
                    // srmNo: items.srmNo,
                }
            }) 
            

        }


    },
  }
</script>