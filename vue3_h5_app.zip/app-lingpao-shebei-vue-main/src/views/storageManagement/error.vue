<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <v-btn style="position:fixed;top:170px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="secondary" @click="errorHandle"></v-btn>


        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                :showSearchBtn="true"
                :auto="false"
                url="/iiot/deliverySlipAbnormal/list"
                :params="{ 
                    ...initParams,
                    ...pageSearchConfig
                 }"
                @searchClick="searchClick"

            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="5">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <!-- <p class="text-truncate font-weight-medium font-weight-light">点检设备</p> -->
                            </v-col>
                            <v-col cols="1" class="text-right">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">物料编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.partNo  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">物料名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.partName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">数量:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.reqQty  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">异常类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  FormatDictionary('ccgl_abnormal_type',props.items.abnormalType)['lable']  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">异常说明:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.abnormalExplain  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">提报时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.submitDatetime  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">提报人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.submitUser  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.disposeType  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理说明:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.disposeExplain  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.disposeUser  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.disposeDatetime  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">数据状态:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  FormatDictionary('ccgl_abnomal_state',props.items.dataState)['lable']  }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">是否上报:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  FormatDictionary('sys_yes_no',props.items.sendState)['lable']  }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">异常数:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.allNum  }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">未处理数:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{  props.items.abnormalNum  }}</p>
                            </v-col>
                        </v-row> -->



                        <v-row no-gutters class="text">
                            <v-col cols="3" class="text-center">
                                <v-btn @click="editClick(props)" style="font-size:18px;" color="primary mt-1" density="compact" :rounded="0" variant="plain">修改</v-btn>
                            </v-col>
                            <v-col cols="3" class="text-center">
                                <v-btn @click="disposeClick(props)" style="font-size:18px;" color="warning mt-1" density="compact" :rounded="0" variant="plain">处理</v-btn>

                            </v-col>
                            <v-col cols="3" class="text-center">
                                <v-btn @click="deleteClick(props)" style="font-size:18px;" color="error mt-1" density="compact" :rounded="0" variant="plain">删除</v-btn>
                            </v-col>
                            <v-col cols="3" class="text-center">
                                <!-- <v-btn @click="takeClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">归档</v-btn> -->
                            </v-col>

                        </v-row>

                    </v-card>
                </template>
            </TableComponents>
        </div>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备点检  历史查询
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api
    import  SearchPage from './search2.vue' 

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showDialog } from 'vant';


  export default {
    components:{
        AppBarPage,
        TableComponents,
        SearchPage
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息

        initParams:{},  
    }),
    created(){
        this.initHandle()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        initHandle(){
            const {deliverySlipId='',deliverySlipType='',poNo='',srmNo=''}=this.$route.query


            this.initParams={
                deliverySlipId: deliverySlipId,
                deliverySlipType: deliverySlipType,
                poNo: poNo,
                srmNo: srmNo,
            }

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },


        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option={}){

            this.pageSearchConfig=option

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

            // console.log(option)
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 异常 添加
        errorHandle(){
            const {deliverySlipId='',deliverySlipType='',poNo='',srmNo=''}=this.$route.query
            
            this.$router.push({
                path:'/storageManagement/errorAdd', 
                query:{ 
                    deliverySlipId:deliverySlipId,
                    deliverySlipType:deliverySlipType,
                    poNo:poNo,
                    srmNo:srmNo
                }
            })
        },
        // 修改
        editClick(props){
            const {abnormalId}=props.items
            const {deliverySlipId='',deliverySlipType='',poNo='',srmNo=''}=this.$route.query
            
            this.$router.push({
                path:'/storageManagement/errorAdd', 
                query:{ 
                    deliverySlipId:deliverySlipId,
                    deliverySlipType:deliverySlipType,
                    poNo:poNo,
                    srmNo:srmNo,
                    abnormalId:abnormalId
                }
            })
        },
        // 处理
        disposeClick(props){
            const {abnormalId}=props.items
            const {deliverySlipId='',deliverySlipType='',poNo='',srmNo=''}=this.$route.query
            
            this.$router.push({
                path:'/storageManagement/errorAdd', 
                query:{ 
                    deliverySlipId:deliverySlipId,
                    deliverySlipType:deliverySlipType,
                    poNo:poNo,
                    srmNo:srmNo,
                    abnormalId:abnormalId,
                    isDispose:true
                }
            })
        },
        // 删除
        deleteClick(props){
            const {abnormalId}=props.items

            showDialog({
                title: '删除',
                message: '删除后数据不可恢复，确认删除！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {

                const {code,data={}}= await httpHandle({
                    url:'/iiot/deliverySlipAbnormal/' + abnormalId,
                    method:'DELETE'
                })


                if(code==200){
                    showSuccessToast('删除成功！')
                    this.$nextTick(()=>{
                        this.$refs.table1.initFunc(1)
                    })
                }
            });
        }


    },
  }
</script>