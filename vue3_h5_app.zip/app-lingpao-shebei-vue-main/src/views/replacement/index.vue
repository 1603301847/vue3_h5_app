<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <div>
            <!-- <SelectComponents 
                v-model="material"
                ref="select33"
                label="物料信息"
                :option="materialSelectOption"
            /> -->

            <v-text-field
                    v-model="searchInputValue"
                    density="compact"
                    variant="solo"
                    elevation="0"
              
                    single-line
                    hide-details
                    placeholder="请输入 备件编码"
                    autocomplete="off"              
                >
                    <!-- <template v-slot:prepend-inner>
                        <v-icon @click="prependIcon($event)"  color="primary" icon="mdi-line-scan"></v-icon>
                    </template> -->
                    <template v-slot:append-inner>
                        <v-icon @click="appendIcon" color="primary" icon="mdi-magnify"></v-icon>
                    </template>

            </v-text-field>
            <div style="height: 8px;"></div>
            <v-text-field
                    v-model="searchInputNameValue"
                    density="compact"
                    variant="solo"
                    elevation="0"
              
                    single-line
                    hide-details
                    placeholder="请输入 名称"
                    autocomplete="off"              
                >
                    <!-- <template v-slot:prepend-inner>
                        <v-icon @click="prependIcon($event)"  color="primary" icon="mdi-line-scan"></v-icon>
                    </template> -->
                    <template v-slot:append-inner>
                        <v-icon @click="appendNameIcon" color="primary" icon="mdi-magnify"></v-icon>
                    </template>

            </v-text-field>

        </div>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                url="/iiot/sparePartUse/getGoodsMaterialsList"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="3">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <p class="text-truncate font-weight-light">领用物料</p>
                            </v-col>
                            <v-col cols="8" class="text-right">
                                <p class="text-truncate  font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.goodsMaterialsCode }}-{{ props.items.goodsMaterialsName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <!-- <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col> -->
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">当前库存量: {{ props.items.goodsMaterialsNums    }}</p>
                            </v-col>
                            <!-- <v-col cols="4">
                                <p class="text-truncate font-weight-light">单位: {{ props.items.processingMethod  }}</p>
                            </v-col> -->
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">规格型号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.partModel  }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">单位:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.processingMethod  }}</p>
                            </v-col>
                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="text-truncate font-weight-light" style="position:relative;top:4px">领用数量</p>
                            </v-col>
                            <v-col cols="6" class="text-left">
                                <van-field v-model="props.items._number" style="padding:0px;color:16px;" placeholder="请输入领用数量"  autocomplete="off" type="number" />
                            </v-col>
                            <v-col cols="3" class="text-right">
                                <v-btn @click="submitClick(props)" color="primary mt-1" density="compact">提交</v-btn>
                            </v-col>
                        </v-row>


                    </v-card>
                </template>
            </TableComponents>
        </div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 备件领用
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api
    import SelectComponents from '@/packages/Select.vue'


    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        SelectComponents,
        TableComponents
    },
    data: () => ({
        bufferRow:{},// 行数据
        searchInputValue:"",   // 物料信息 查询
        searchInputNameValue:"",   // 名称查询 查询


        tableChildren:[],  // table 数据

        material:"",   // 物料信息
        materialSelectOption:[],   // 物料信息 数据  
    }),
    created(){
        this.initFunc()
        // this.materialHTTP()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {row="{}"}=this.$route.query

            this.bufferRow=JSON.parse(row)

            // const {code,data=[]}= await httpHandle({
            //     url:'/iiot/checkTask/checkTask',
            //     method: "post",
            //     payload:{
            //         ttCheckTaskId: ttCheckTaskId
            //     }
            // })

            // if(code==200){
            //     this.tableChildren=data

            //     this.$nextTick(()=>{
            //         this.$refs.table1.initFunc()
            //     })
            // }

        },
        // 物料信息查询
        async appendIcon(){

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1,{
                    goodsMaterialsCode: this.searchInputValue.trim()
                })
            })
        },
        // 名称查询
        async appendNameIcon(){
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1,{
                    goodsMaterialsName: this.searchInputNameValue.trim()
                })
            })
        },
        // 物料信息
        async materialHTTP(key){

            // 展示  abnormalNo + abnormalName   
            // 取值  tmBasAbnormalTypeId
            // const {code,data=[]}= await httpHandle({
            //     url:'/iiot/abnormalType/listAbnormalTypeForSelect',
            //     method:"get",
            //     url_params:{
            //         abnormalNo: '',
            //         abnormalAttribute: ''
            //     }

            // }) 

            // if(code==200){
            //     this.materialSelectOption=data.map(o=>Object.assign({
            //         text:`${o.abnormalNo}${o.abnormalName}`,
            //         value:o.tmBasAbnormalTypeId
            //     }))  
            // }

        },
        // 提交
        async submitClick(props){

            const {activeType=""}=this.$route.query
            const {items}=props
            const {bufferRow}=this
            const _number=Number( items._number||0 )
            const _bufferUserInfo=JSON.parse( localStorage.getItem("bufferUserInfo")||"{}" )


            // console.log(bufferRow)
            if(_number<=0){
                showFailToast("领用数量必须大于0")
                return
            }

            if(_number>items.goodsMaterialsNums){
                showFailToast("领用数量不能大于当前库存量！")
                return
            }


            let _json={}

            // 设备
            if( activeType=="equipment" ){
                _json={
                    // operUserCode: bufferRow.reportBy,   // 取当前设备维修报修人
                    // operUserName: bufferRow.reportBy,   // 取当前设备维修报修人

                    operUserName: _bufferUserInfo.userName,     // 用户信息 userName
                    operUserCode: _bufferUserInfo.userId,        // 用户信息 userId


                    finishState: 'N',  // 
                    //sparePartUseCode:"eq"+ bufferRow.tmBasEquipmentId,  // eq+设备id
                    sparePartUseName: bufferRow.equipmentName,   // 设备名称
                    sparePartUseExplain:"设备报修备件领用",   // 设备报修备件领用
                    useInfoType: 2,
                    businessType: 2,
                    businessId: bufferRow.teAdRepairId,  // 当前设备维修id
                    businessCode: bufferRow.teAdRepairId,  // 当前设备维修id
                    businessName: "设备维修",   // 设备维修
                    goodsMaterialsId: items.goodsMaterialsId,   // goodsMaterialsId
                    goodsMaterialsCode:items.goodsMaterialsCode,  // goodsMaterialsCode
                    goodsMaterialsName:items.goodsMaterialsName,  // goodsMaterialsName
                    goodsMaterialsNums: Number( items._number ),  // 输入框填写
                }
            }



            // 保养
            if( activeType=="maintain" ){
                _json={
                    // operUserCode: bufferRow.implementBy,   // 取当前设备保养保养人
                    // operUserName: bufferRow.implementBy,   // 取当前设备保养保养人

                    operUserName: _bufferUserInfo.userName,     // 用户信息 userName
                    operUserCode: _bufferUserInfo.userId,        // 用户信息 userId

                    finishState: 'N', 
                    //sparePartUseCode:"wb"+ bufferRow.tmBasEquipmentId,   // wb+设备id tmBasEquipmentId
                    sparePartUseName: bufferRow.equipmentName,   // 设备名称
                    sparePartUseExplain:"设备保养备件领用",   // 设备保养备件领用
                    useInfoType: 2,
                    businessType: 3,
                    businessId: bufferRow.teWbMainTaskId,   // 当前设备保养id
                    businessCode: bufferRow.teWbMainTaskId,   // 当前设备保养id
                    businessName:"设备保养",  // 设备保养
                    goodsMaterialsId: items.goodsMaterialsId,   // goodsMaterialsId
                    goodsMaterialsCode:items.goodsMaterialsCode,  // goodsMaterialsCode
                    goodsMaterialsName:items.goodsMaterialsName,  // goodsMaterialsName
                    goodsMaterialsNums: Number( items._number ),  // 输入框填写
                }
            }

            // 点检
            if(activeType=="check"){
                _json={
                    // operUserCode:bufferRow.checkBy,  // 取当前设备点检人
                    // operUserName:bufferRow.checkBy,    // 取当前设备点检人

                    operUserName: _bufferUserInfo.userName,     // 用户信息 userName
                    operUserCode: _bufferUserInfo.userId,        // 用户信息 userId

                    finishState:'N', 
                    //sparePartUseCode: "dj"+bufferRow.tmBasEquipmentId, // dj+设备id
                    sparePartUseName: bufferRow.equipmentName, //设备名称
                    sparePartUseExplain:"设备点检备件领用", // 设备点检备件领用
                    useInfoType: 2,
                    businessType: 4,
                    businessId: bufferRow.ttCheckTaskId,   // 当前设备点检id
                    businessCode: bufferRow.ttCheckTaskId, // 当前设备点检id
                    businessName : "设备点检",  // 设备点检

                    goodsMaterialsId: items.goodsMaterialsId,   // goodsMaterialsId
                    goodsMaterialsCode:items.goodsMaterialsCode,  // goodsMaterialsCode
                    goodsMaterialsName:items.goodsMaterialsName,  // goodsMaterialsName
                    goodsMaterialsNums: Number( items._number ),  // 输入框填写
                }
            }

            // 点检创建
            if(activeType=="checkCreate"){
                _json={
                    // operUserCode:bufferRow.ctCheckBy,  // 取当前设备点检人
                    // operUserName:bufferRow.ctCheckBy,    // 取当前设备点检人

                    operUserName: _bufferUserInfo.userName,     // 用户信息 userName
                    operUserCode: _bufferUserInfo.userId,        // 用户信息 userId

                    finishState:'N', 
                    //sparePartUseCode: "dj"+bufferRow.tmBasEquipmentId, // dj+设备id
                    sparePartUseName: bufferRow.eEquipmentName, //设备名称
                    sparePartUseExplain:"设备点检备件领用", // 设备点检备件领用
                    useInfoType: 2,
                    businessType: 4,
                    businessId: bufferRow.ttCheckTaskId,   // 当前设备点检id
                    businessCode: bufferRow.ttCheckTaskId, // 当前设备点检id
                    businessName : "设备点检",  // 设备点检

                    goodsMaterialsId: items.goodsMaterialsId,   // goodsMaterialsId
                    goodsMaterialsCode:items.goodsMaterialsCode,  // goodsMaterialsCode
                    goodsMaterialsName:items.goodsMaterialsName,  // goodsMaterialsName
                    goodsMaterialsNums: Number( items._number ),  // 输入框填写
                }
            }

            // console.log(_json)
            // return
            const {code,data={}}= await httpHandle({
                url:'/iiot/sparePartUse',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.go(-1)


                // this.$router.push({
                //     path:'/anomalyInitiate/index', 
                //     query:{ }
                // }) 
            } 
            

        }

    },
  }
</script>