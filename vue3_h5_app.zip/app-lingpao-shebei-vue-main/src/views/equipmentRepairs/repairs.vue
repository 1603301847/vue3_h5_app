<template>
    <span>
        <AppBarPage>
        </AppBarPage>

        <v-row no-gutters style="margin-bottom:2px;">
            <v-col cols="11">
                <v-icon icon="mdi-tools" size="16" color="#3F51B5"></v-icon>
                <span style="padding-left:6px;">当前报修设备</span>
            </v-col>
            <v-col cols="1" class="text-right" style="padding-right:6px">
                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{equipmentName }}</p> -->
            </v-col>
        </v-row>

        <v-row no-gutters>
            <v-col cols="12" style="margin-bottom:4px;padding-left: 2px;">
                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{equipmentName }}</p>
            </v-col>
        </v-row>

        <v-sheet elevation="2" rounded class="pa-1">
            <div class="text-h7 card-title-index1">
                <v-icon size="x-small" color="#26C6DA" icon="mdi-file-document-edit"></v-icon>
                <span>故障确认</span>
            </div>
            <div style="height:8px;"></div>
            <SelectComponents
                v-model="formData.typeSelectValue"
                label="故障类型"
                required
                :option="typeOption"
            />
            <SelectComponents
                v-model="formData.locationSelectValue"
                label="故障位置"
                required
                :option="locationOption"
            />

            <van-field
                v-model="formData.description"
                rows="2"
                autosize
                label="故障详细描述"
                type="textarea"
                autocomplete="off"
                placeholder="请输入"
                maxlength="200"
                required
                show-word-limit
            />

            <UploaderImageComponents
                v-model="bufferFileList"
            />


        </v-sheet>

        <div style="height:12px;"></div>
        <v-sheet elevation="2" rounded class="pa-1">
            <div class="text-h7 card-title-index1">
                <v-icon size="x-small" color="#3F51B5" icon="mdi-account-wrench"></v-icon>
                <span>报修确认</span>
            </div>
            <div style="height:8px;"></div>
            <SelectComponents
                v-model="formData.maintainTypeSelectValue"
                label="维修类型"
                required
                :option="maintainTypeSelectOption"
            />

            <!-- <van-field
                v-model="formData.user"
                label="报修人"
                placeholder="请输入"
            /> -->
            <!-- <SelectComponents
                v-model="formData.user"
                label="报修人"
                required
                :option="repairmanSelectOption"
            /> -->
            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">报修人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">q'q'qqqq</p>
                </v-col>
            </v-row> -->
            <van-field v-model="repairsPersonnel" placeholder="请输入" autocomplete="off" label="报修人" readonly  />


            <!-- <van-field
                v-model="formData.date"
                label="报修时间"
                readonly
            /> -->
        </v-sheet>

        <div class="mt-3 mb-4 ">
            <v-btn block color="primary" @click="submit">
                确定
            </v-btn>
        </div>
        <div style="height: 52px;"></div>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import SelectComponents from '@/packages/Select.vue'
    import DatePickerComponents from '@/packages/DatePicker.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import {httpHandle} from '@/http/http'  // api

    import {FaultTypeHTTP,FaultPositionHTTP,MaintainTypeHTTP,RepairmanHTTP,SubmitHTTP} from '@/http/equipment/repairs'   // api


    import { showSuccessToast,showFailToast } from 'vant'
    import { OBJECTMEMBER_TYPES } from '@babel/types'

  export default {
    components:{
        AppBarPage,
        SelectComponents,
        UploaderImageComponents,
        DatePickerComponents
    },
    data: () => ({
        repairsPersonnel:"",   // 报修人

        equipmentName:"",   // 设备
        bufferFileList:[],  // 缓存图片


        // 表单数据
        formData:{
            typeSelectValue:"",  //  故障类型
            locationSelectValue:"",   // 故障位置
            description:"",   // 描述

            maintainTypeSelectValue:"",   // 维修类型
            user:"",                    // 报修人
            date:"",  // 报修时间
        },


        // 故障类型 数据
        typeOption:[
            // { text: '动力系统故障', value: '1' },
            // { text: '电气系统故障', value: '2' },
            // { text: '工具道具故障', value: '3' },
            // { text: '网路故障', value: '4' },
        ],

        // 故障位置 数据
        locationOption:[
            // { text: '动力系统', value: '1' },
            // { text: '电气系统', value: '2' },
            // { text: '工具道具', value: '3' },
            // { text: '网路', value: '4' },
        ],



        // 维修类型 数据
        maintainTypeSelectOption:[
            // { text: '动力系统7', value: '1' },
            // { text: '电气系统7', value: '2' },
            // { text: '工具道具7', value: '3' },
            // { text: '网路7', value: '4' },
        ],

        // 报修人 数据
        repairmanSelectOption:[

        ],

    }),
    created(){
        this.initType()
        this.initPosition()
        this.initMaintainType()
        this.initRepairman()

        this.initTime()
    },
    methods: {
        // 初始化
        async initTime(){
            const {equipmentNo='',equipmentName='',tmBasEquipmentId}=this.$route.query



            this.formData.date="2023-2-23 15:33"

            const _json2=JSON.parse( localStorage.getItem("bufferUserInfo")||"{}" )
            this.repairsPersonnel=`${_json2["userName"]}-${_json2["nickName"]}`

            const {code,data={}}= await httpHandle({
                // url:'/iiot/abnormal',
                url:`/iiot/equipment/getEquipment/${tmBasEquipmentId}`,
                method:"get",
            })

            if(code==200){
                this.equipmentName=data.equipmentName
            }

        },
        // 故障类型 下拉数据
        async initType(){
            const {data=[]}=await FaultTypeHTTP()
            this.typeOption=data.map(o=> Object.assign({text:`${o.faultTypeNo}-${o.faultTypeName}`,value:o.tmBasFaultTypeId}))
        },
        // 故障位置
        async initPosition(){
            const {data=[]}=await FaultPositionHTTP()
            this.locationOption=data.map(o=> Object.assign({text:`${o.faultNo}-${o.faultName}`,value:o.tmBasFaultId}))
        },
        // 维修类型
        async initMaintainType(){
            const {data=[]}=await MaintainTypeHTTP()
            this.maintainTypeSelectOption=data.map(o=> Object.assign({text:`${o.dictLabel}`,value:o.dictValue}))
        },
        // 报修人
        async initRepairman(){
            const {data=[]}=await RepairmanHTTP()
            this.repairmanSelectOption=data.map(o=> Object.assign({text:`${o.userName}-${o.nickName}`,value:String(o.userName)}))
        },

        // 提交
        async submit(){
            const {typeSelectValue,locationSelectValue,description,maintainTypeSelectValue,user}=this.formData
            const {tmBasEquipmentId}=this.$route.query

            // console.log( )

            if(!typeSelectValue){
                showFailToast("故障类型必填！")
                return
            }

            if(!locationSelectValue){
                showFailToast("故障位置必填！")
                return
            }

            if(!description.trim()){
                showFailToast("故障详细描述必填！")
                return
            }


            if(!maintainTypeSelectValue){
                showFailToast("维修类型必填！")
                return
            }

            // if(!user){
            //     showFailToast("报修人必填！")
            //     return
            // }


            console.log(JSON.stringify(this.bufferFileList))

            const {code}=await SubmitHTTP({
                payload:{
                    tmBasFaultTypeId: typeSelectValue, //  故障类型 o.tmBasFaultTypeId
                    tmBasFaultId: locationSelectValue, //  故障位置  o.tmBasFaultId
                    problemCause: description,  //  详细描述

                    reportType: maintainTypeSelectValue,  // 报修类型  o.dictValue
                    // reportBy: user, //   报修人   o.userName

                    tmBasEquipmentId: tmBasEquipmentId, //  设备  o.tmBasEquipmentId


                    filePath :JSON.stringify(this.bufferFileList) // 文件上传
                }
            })


            if(code==200){
                showSuccessToast("提交成功！")
                // this.$router.push({
                //     path:'/equipment',
                //     query:{ }
                // })
                this.$router.go(-1)

            }
        },

    },
  }
</script>
