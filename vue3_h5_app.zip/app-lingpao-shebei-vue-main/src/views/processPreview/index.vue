<template>
    <span>
        <AppBarPage>
            <!-- <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                >
                    <v-tab value="1">待检验</v-tab>
                    <v-tab value="2">检验完成</v-tab>
                </v-tabs>
            </template> -->
        </AppBarPage>
        <!-- <div style="height: 50px;"></div> -->

        <!-- <v-btn v-if="tab==1" style="position:fixed;top:220px;right:16px;z-index: 11;" icon="mdi-plus" color="secondary" @click="addHandle"></v-btn> -->

        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <ScanBarComponents 
                    placeholder="请扫描或输入 产品编码或名称"
                    @searchClick="barSearchClick"
                />
                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    url="/iiot/partInspect/list"
                    :showSearchBtn="!true"
                    :params='{ 
                        testType:"IPQC",

                        // "taskType":"IPQC",
                        // "params": {
                        //     "statusList": [
                        //     "N",
                        //     "R"
                        //     ],
                        // },
                        ...pageSearchConfig
                    }' 
                    :formatData="(data)=> data.map(o=> Object.assign(o,{_taskQty:'1'}) )  "
                    @searchClick="searchClick"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="1">
                                    <!-- <p class="font-weight-medium text-left text-teal-lighten-1">{{ FormatDictionary("process_state",props.items.processState)["lable"] }}</p> -->
                                </v-col>
                                <v-col cols="10">
                                    <!-- <p class="font-weight-medium text-right text-teal-lighten-1">{{ FormatDictionary("process_state",props.items.processState)["lable"] }}</p> -->
                                    <!-- <p class="text-truncate text-right font-weight-medium text-right text-teal-lighten-1" color="primary">{{ FormatDictionary("qm_task_status",props.items.taskStatus)["lable"] }}</p> -->
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="12" color="primary">
                                    <p class="text-left font-weight-medium" style="color:#00E5FF;">
                                        {{ props.items.partNo }}-{{ props.items.partName }}
                                    </p>
                                </v-col>   
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">产品编码:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-medium font-weight-light">{{ props.items.partNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">产品名称:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-medium font-weight-light">{{ props.items.partName  }}</p>
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">任务流水号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.taskNo   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">订单号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.orderNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text">
                                        <span>产品SN号: </span>
                                        <span>{{props.items.sn}}</span>
                                    </p>
                                </v-col>

                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">工作中心:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.nodeLevelName}}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">报检时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.requestTime }}</p>
                                </v-col>
                            </v-row>
                            <v-row v-if="props.items.taskStatus=='R'" no-gutters class="text">
              
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light" style="margin-top: 6px;">
                                        <span class="font-weight-medium text">检验数量:</span>
                                        {{ props.items.taskQty  }}
                                    </p>
                                </v-col>
                                <v-col cols="4" class="text-left">
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">合格数量:</p>
                                </v-col>
                                <v-col cols="8">
                                    <van-field v-model="props.items._taskQty" style="position:relative;padding:0px;top:-4px;" class="custem-input-index1" placeholder="合格数量" autocomplete="off" />
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="6" class="text-left">
                                    <!-- <v-btn v-if="(props.items.taskStatus=='R') && props.items.processState=='D'" @click="accomplishClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">检验确认</v-btn> -->
                                </v-col>
                                <v-col cols="6" class="text-right">
                                    <v-btn @click="detailClick(props)" style="font-size:20px;" color="error mt-1" density="compact" :rounded="0" variant="plain">预览</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <!-- <v-window-item value="2" class="v-window-item-table">
                <ScanBarComponents 
                    placeholder="请扫描或输入 SN号"
                    @searchClick="barSearchClick2"
                />
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    url="/iiot/qmTask/list"
                    method="post"
                    :showSearchBtn="true"
                    :params='{ 
                        "taskType":"IPQC",
                        "params": {
                            "statusList": ["F"],
                        },
                        ...pageSearchConfig2
                    }' 
                    @searchClick="searchClick2"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="1">
                                </v-col>
                                <v-col cols="10">
                                    <p class="font-weight-medium text-right text-teal-lighten-1">{{ FormatDictionary("process_state",props.items.processState)["lable"] }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12" color="primary">
                                    <p class="text-left font-weight-medium" style="color:#00E5FF;">
                                        {{ props.items.partNo }}-{{ props.items.partName }}
                                    </p>
                                </v-col>   
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">任务流水号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.taskNo   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">订单号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.orderNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text">
                                        <span>产品SN号: </span>
                                        <span>{{props.items.sn}}</span>
                                    </p>
                                </v-col>

                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">工作中心:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.nodeLevelName}}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">报检时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.requestTime }}</p>
                                </v-col>
                            </v-row>
                            <v-row v-if="props.items.taskStatus=='R'" no-gutters class="text">
                 
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-light" style="margin-top: 6px;">
                                        <span class="font-weight-medium text">检验数量:</span>
                                        {{ props.items.taskQty  }}
                                    </p>
                                </v-col>
                                <v-col cols="6" class="text-left">
                                    <van-field v-model="props.items._taskQty" style="padding: 0px;" class="custem-input-index1" placeholder="合格数量" autocomplete="off" />
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="6" class="text-left">
                                </v-col>
                                <v-col cols="6" class="text-right">
                                    <v-btn @click="detailClick(props,'detail')" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>
                                    
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item> -->
        </v-window>


        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px',height:'260px',width:'80%'}"
            round 
            closeable
        >
            <h3>检验选择</h3>

            <div>
                <div style="height: 6px;"></div>
                <p class="font-weight-medium text text-teal-lighten-1">{{ menuTopTitle  }}</p>
                <div style="height: 20px;"></div>
                
                <v-btn v-if="showBtn1" block color="primary" @click="routerPush('2')">
                    工序检验
                </v-btn>
                <div style="height: 16px;"></div>
                <v-btn v-if="showBtn2" block color="indigo" @click="routerPush('3')">
                    调试检验
                </v-btn>
                <div style="height: 16px;"></div>

                <v-btn v-if="showBtn3" block color="purple" @click="routerPush('4')">
                    入库检验
                </v-btn>
            </div>
        </van-popup>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

        <SearchPage2 
            ref="searchPage2" 
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import  SearchPage from './search.vue' 
    import  SearchPage2 from './search.vue' 


    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        SearchPage,
        SearchPage2,
        TableComponents
    },
    data: () => ({
        tab: '1',
        pageActive:'',  

        showBtn1:false,   // 显示 工序按钮
        showBtn2:false,   // 显示 装调按钮
        showBtn3:false,   // 显示 入库按钮


        pageSearchConfig:{},  // 查询信息 11
        pageSearchConfig2:{},  // 查询信息 22


        menuTopTitle:"",   // 菜单头部显示值
        bufferData:{},  // 缓存数据
        showPicker:false
    }),
    created(){
        this.initHandle()



        // 刷新页面
        this.$root.$emitter.on("update_process_page1",(tabs='1')=>{
            this.tab=tabs
        })
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        initHandle(){
            const {tabs}=this.$route.query

            if(tabs){
                this.tab=tabs
            }
        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            this.$refs.table1.initFunc(1,{
                partNo: _value
            })

            // const {code,data=[]}= await httpHandle({
            //     url:'/iiot/orderSn/listOrderSnForSelect',
            //     method: "get",
            //     url_params:{
            //         sernr: _value
            //     }
            // })

            // if(code==200){

            //     if(!data.length){
            //         showFailToast("SN号不存在！")
            //         return
            //     }    
            //     this.$refs.table1.initFunc(1,{
            //         ttPpOrderSnId: (data[0]||{}).ttPpOrderSnId
            //     })
            // }
        },
        // 头部 查询 222
        async barSearchClick2(value=''){
            const _value=value.trim()

            const {code,data=[]}= await httpHandle({
                url:'/iiot/orderSn/listOrderSnForSelect',
                method: "get",
                url_params:{
                    sernr: _value
                }
            })

            if(code==200){

                if(!data.length){
                    showFailToast("SN号不存在！")
                    return
                }    
                this.$refs.table2.initFunc(1,{
                    ttPpOrderSnId: (data[0]||{}).ttPpOrderSnId
                })
            }
        },
        // 预览
        async detailClick(props,active=''){
            const {items}=props

            this.pageActive=active
            this.bufferData=items
            this.menuTopTitle=""
            

            this.showPicker=true
            this.menuTopTitle=this.FormatDictionary('process_state',items.processState)['lable']


            this.showBtn1=true   // 显示 工序按钮
            this.showBtn2=true   // 显示 装调按钮
            this.showBtn3=true   // 显示 入库按钮

            // const {code,data={}}= await httpHandle({
            //    url:`/iiot/part/${items.tmBasPartId}`,
            //    method: "get"
            // })
           
            // if(code==200){
            //     //  其它  ||  自制件 
            //     if( ['ZF01','ZF02','ZF03','ZF04'].includes(data.mtart) ){
            //         this.showPicker=true
            //         this.menuTopTitle=this.FormatDictionary('process_state',items.processState)['lable']

            //         // 状态 == A
            //         // items.processState=""
            //         if( (items.processState=="A") || !items.processState ){
            //             this.showBtn1=true   // 显示 工序按钮
            //             this.showBtn2=false   // 显示 装调按钮
            //             this.showBtn3=false   // 显示 入库按钮
            //         }

            //         // 状态 == B
            //         if( items.processState=="B" ){
            //             this.showBtn1=true   // 显示 工序按钮
            //             this.showBtn2=true   // 显示 装调按钮
            //             this.showBtn3=false   // 显示 入库按钮
            //         }

            //         // 状态 ==  C
            //         if( (items.processState=="C") || (items.processState=="D") ){
            //             this.showBtn1=true   // 显示 工序按钮
            //             this.showBtn2=true   // 显示 装调按钮
            //             this.showBtn3=true   // 显示 入库按钮
            //         }

            //     }else{
            //         this.$nextTick(()=>{
            //             this.$router.push({
            //                 path:'/process/detail', 
            //                 query:{ 
            //                     _pageActive: this.pageActive,
            //                     ttQmTaskId: items.ttQmTaskId,
            //                     _pageIndex:1 
            //                 }
            //             }) 
            //         })

            //     }
            // }
        },
        // 查询
        searchClick(){
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
            
        },
        // 查询 222
        searchClick2(){
            this.$refs.searchPage2.showDrawer()
        },
        // 查询结果 222
        searchHandle2(option){
            this.pageSearchConfig2=option
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置 222
        resetHandle2(opiton){
            this.pageSearchConfig2={}
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 详情跳转
        routerPush(active){
            const {bufferData}=this


            switch (active) {
                case "2":   // 工序检验
                    this.$router.push({
                        path:'/processPreview/detail', 
                        query:{titleText:'工序检验',testType:bufferData.tmBasPartId, tmBasPartId:bufferData.tmBasPartId, qcType:'IPQCA', _pageActive: this.pageActive, ttQmTaskId: bufferData.ttQmTaskId,_pageIndex:2 }
                    })  
                    break;
                case "3":   // 调试检验
                    this.$router.push({
                        path:'/processPreview/detail', 
                        query:{titleText:'调试检验',testType:bufferData.tmBasPartId, tmBasPartId:bufferData.tmBasPartId, qcType:'IPQCB', _pageActive: this.pageActive, ttQmTaskId: bufferData.ttQmTaskId, _pageIndex:3 }
                    })  
                    break;
                case "4":   // 入库检验
                    this.$router.push({
                        path:'/processPreview/detail', 
                        query:{ titleText:'入库检验',testType:bufferData.tmBasPartId, tmBasPartId:bufferData.tmBasPartId, qcType:'IPQCC', _pageActive: this.pageActive, ttQmTaskId: bufferData.ttQmTaskId, _pageIndex:4 }
                    })  
                
                    // this.$router.push({
                    //     path:'/process/detail4', 
                    //     query:{  qcType:'IPQCC', _pageActive: this.pageActive, ttQmTaskId: bufferData.ttQmTaskId, _pageIndex:4 }
                    // })  
                    break;            
                default:
                    break;
            }

 
        },   
        // 检验完成
        async accomplishClick(props){
            const {items}=props

            const _number=Number( items._taskQty||"" )
            
            if(!_number){
                showFailToast("合格数量必填！")
                return
            }

            if(_number>Number(items.taskQty)){
                showFailToast("合格数量不能大于检验数量！")
                return
            }


            const _json={
                "ttQmTaskId": items.ttQmTaskId,
                "taskQty":  items.taskQty,
                "qualifiedQty":  items.taskQty,
                "version":  items.version,
                "acceptQty":  _number,   // 合格数
            }

            const {code,data={}}= await httpHandle({
                url:'/iiot/qmTask/finishQmTask',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc(1)
                    // this.tab='2'
                })

            }


        },
        // 添加
        addHandle(){
            this.$router.push({
                path:'/process/add', 
                query:{ }
            }) 
        },
        // 详情
        detailHandle(props){
            const {items}=props

            // this.$router.push({
            //     path:'/process/checkDetail', 
            //     query:{ ttQmTaskId: items.ttQmTaskId,_page:"process" }
            // }) 
            
        },     

    },
  }
</script>