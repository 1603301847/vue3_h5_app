<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <!-- <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">详情</span>
                </v-col>
                <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">任务流水号:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.taskNo   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">订单号:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.orderNo   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">产品SN号:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.sn   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">工作中心:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.nodeLevelName   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">报检时间:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.requestTime   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">检验人:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.inspectByName   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">检验时间:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.inspectTime   }}</p>
                </v-col>
            </v-row>


        </v-sheet>



        <div style="height:6px;"></div>
        <v-btn @click="backHandle" block color="primary">
                    返回
        </v-btn>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 异常处理 详情
    import {httpHandle} from '@/http/http'  // api

    import { showSuccessToast,showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage,

    },
    data: () => ({
        bufferRow:{},  // 行数据

    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmTaskId}=this.$route.query


            const {code,data={}}= await httpHandle({
                url:`/iiot/qmTask/${ttQmTaskId}`,
                method: "get",
            })

            if(code==200){
                this.bufferRow=data
            }



        },
        async backHandle(){
            const {_page}=this.$route.query

            // 过程检验
            if(_page=="process"){
                this.$router.push({
                    path:'/processQualifiedProductionLine/index', 
                    query:{  }
                }) 
                setTimeout(()=>{
                    this.$root.$emitter.emit("update_process_page1","2")
                },300)
            }

            // 来料检
            if(_page=="qualityMaterial"){
                this.$router.push({
                    path:'/qualityMaterial/index', 
                    query:{  }
                }) 
                setTimeout(()=>{
                    this.$root.$emitter.emit("update_qualityMaterial_page1","2")
                },300)
            }

            
        }

    },
  }
</script>