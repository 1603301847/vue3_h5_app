<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>合格</v-tab>
                    <v-tab value="2" hide-slider>不合格</v-tab>
                </v-tabs>
            </template>

        </AppBarPage>
        <div style="height: 50px;"></div>

        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    :showSearchBtn="true"
                    url="/iiot/checkTaskRecord/list"
                    :params="{ 
                        taskState: 'F',
                        confirmResult:'O',
                        ...pageSearchConfig
                    }"
                    @searchClick="searchClick"

                >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="5">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <p class="text-truncate font-weight-medium font-weight-light">点检设备</p>
                            </v-col>
                            <v-col cols="1" class="text-right">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属工厂:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.tmBasNodeLevelId   }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属车间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.partType  }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属产线:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.taskQty   }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">班次:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.shiftNo }}</p>
                            </v-col>
                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">点检类型: </span>
                                    {{  FormatDictionary('CHECK_TYPE',props.items.taskType)['lable']  }}</p>
                            </v-col>
                            <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">设备类型: </span>
                                        {{ props.items.equipmentType   }}
                                    </p>
                                </v-col>

                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">周期: </span>
                                        {{ FormatDictionary('WB_ST',props.items.checkWeek)['lable']   }}
                                    </p>
                                </v-col>

                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12" class="text-left">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">点检结果:  </span>
                                    <span class="font-weight-medium" :style="props.items.confirmResult=='O'?'color:#4CAF50':'color:#FF5722'">{{ props.items.confirmResult=='O'?'合格':'异常' }}</span>
                                </p>
                            </v-col>
                        </v-row>

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col>

                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">点检人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.checkBy }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">点检时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.checkStartTime }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">确认人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.confirmBy }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">确认时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.confirmTime }}</p>
                            </v-col>
                        </v-row> -->

                        <v-row no-gutters class="text">
                            <v-col cols="8" class="text-left">
                            </v-col>

  
                            <v-col cols="4" class="text-right">
                                <v-btn @click="detailClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">查看点检单</v-btn>

                            </v-col>
                        </v-row>
                    </v-card>
                </template>
                </TableComponents>
            </v-window-item>
            <v-window-item value="2" class="v-window-item-table">
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    :showSearchBtn="true"
                    url="/iiot/checkTaskRecord/list"
                    :params="{ 
                        taskState: 'F',
                        confirmResult:'N',
                        ...pageSearchConfig2
                    }"
                    @searchClick="searchClick2"

                >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="5">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <p class="text-truncate font-weight-medium font-weight-light">点检设备</p>
                            </v-col>
                            <v-col cols="1" class="text-right">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属工厂:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.tmBasNodeLevelId   }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属车间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.partType  }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属产线:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.taskQty   }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">班次:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.shiftNo }}</p>
                            </v-col>
                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">点检类型: </span>
                                    {{  FormatDictionary('CHECK_TYPE',props.items.taskType)['lable']  }}</p>
                            </v-col>
                            <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">设备类型: </span>
                                        {{ props.items.equipmentType   }}
                                    </p>
                                </v-col>

                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">周期: </span>
                                        {{ FormatDictionary('WB_ST',props.items.checkWeek)['lable']   }}
                                    </p>
                                </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12" class="text-left">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">点检结果:  </span>
                                    <span class="font-weight-medium" :style="props.items.confirmResult=='O'?'color:#4CAF50':'color:#FF5722'">{{ props.items.confirmResult=='O'?'合格':'异常' }}</span>
                                </p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col>

                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">点检人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.checkBy }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">点检时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.checkStartTime }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">确认人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.confirmBy }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">确认时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.confirmTime }}</p>
                            </v-col>
                        </v-row> -->

                        <v-row no-gutters class="text">
                            <v-col cols="8" class="text-left">
                            </v-col>

  
                            <v-col cols="4" class="text-right">
                                <v-btn @click="detailClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">查看点检单</v-btn>

                            </v-col>
                        </v-row>
                    </v-card>
                </template>
                </TableComponents>
            </v-window-item>
        </v-window>



        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

        <SearchPage 
            ref="searchPage2" 
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        />


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备点检  历史查询
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api
    import  SearchPage from './search.vue' 
    import  SearchPage2 from './search.vue' 

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        TableComponents,
        SearchPage,
        SearchPage2
    },
    data: () => ({
        tab: '1',

        pageSearchConfig:{},  // 查询信息
        pageSearchConfig2:{},  // 查询信息

    }),

    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 查看点检单
        async detailClick(props){
            const {items}=props
            
            
            this.$router.push({
                path:'/examineSearch/detail', 
                query:{ 
                    ttCheckTaskId:items.ttCheckTaskId,
                    row: JSON.stringify(items)
                }
            }) 

        },
        // 查询 111
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果 111
        searchHandle(option={}){

            this.pageSearchConfig=option

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置  111
        resetHandle(opiton){
            this.pageSearchConfig={}

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 222
        searchClick2(){
            this.$refs.searchPage2.showDrawer()
        },
        // 查询结果 222
        searchHandle2(option={}){

            this.pageSearchConfig2=option

            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置  222
        resetHandle2(opiton){
            this.pageSearchConfig2={}

            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },

    },
  }
</script>