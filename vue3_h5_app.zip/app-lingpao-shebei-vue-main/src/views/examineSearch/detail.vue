<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <v-row no-gutters class="text"  style="margin: 8px 4px;">
            <v-col cols="12">
                <p class="font-weight-medium text">
                    <v-icon icon="mdi-message-text font-weight-medium" size="16" color="primary"></v-icon>
                    点检设备信息:</p>
            </v-col>
            <v-col cols="12" class="text-left">
                <p class="font-weight-medium font-weight-light" style="color:#00E5FF;">{{ bufferRow.equipmentName   }}</p>
            </v-col>
        </v-row>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="tableChildren"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="8">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <p class="text-truncate font-weight-medium  font-weight-light">点检项目</p>
                            </v-col>
                            <v-col cols="1" class="text-right">
                                <!-- <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.checkNo }}-{{ props.items.checkName }}</p> -->
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="text-left font-weight-medium text-teal-lighten-1" color="primary">{{ props.items.checkNo }}-{{ props.items.checkName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">维护方法:</p>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light">{{ props.items.judgmentMethod   }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">处理方式:</p>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light">{{ props.items.processingMethod  }}</p>
                            </v-col>
                        </v-row> -->

<!--                        <v-row no-gutters class="text">-->
<!--                            <v-col cols="4">-->
<!--                                <p class="font-weight-medium text">周期:</p>-->
<!--                            </v-col>-->
<!--                            <v-col cols="8">-->
<!--                                <p class="font-weight-light">{{ FormatDictionary('WB_ST',props.items.week)['lable']   }}</p>-->
<!--                            </v-col>-->
<!--                        </v-row>-->

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">判断标准:</p>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.standardJudgment )">{{ props.items.standardJudgment   }}</p>
                            </v-col>
                        </v-row> -->

                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text">
                                    维护标准:
                                    {{  props.items.standardJudgment }}
                                </p>
                            </v-col>
                            <!-- <v-col cols="8">
                                <p class="font-weight-light" @click="GlobalTooltipFunc( props.items.standardJudgment)">{{  props.items.standardJudgment }}</p>
                            </v-col> -->
                        </v-row>


                        <!-- <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text">目的:</p>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light">{{ props.items.objective }}</p>
                            </v-col>
                        </v-row> -->


                        <v-row v-if="props.items.checkResult=='N'" no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text">
                                    不合格描述:
                                    <span>{{ props.items.checkResultContent }}</span>
                                </p>
                            </v-col>
                        </v-row>



                        <v-row no-gutters class="text">
                            <v-col cols="6" class="text-right">

                            </v-col>

                            <v-col cols="6" class="text-right">
                                <p class="text-truncate font-weight-light">
                                    结果:
                                    <span :style="props.items.checkResult=='N'?'color:#FF5722':'color:#4CAF50'"> {{  props.items.checkResult=='N'?'不合格':'合格'  }}</span>

                                </p>
                            </v-col>
                        </v-row>



                    </v-card>
                </template>
            </TableComponents>
        </div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备点检  点检单
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        TableComponents
    },
    data: () => ({
        bufferRow:{},   // 行数据
        tableChildren:[],  // table 数据
    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttCheckTaskId,row="{}"}=this.$route.query



            const {code,data=[]}= await httpHandle({
                url:'/iiot/checkTask/checkTask',
                method: "post",
                payload:{
                    ttCheckTaskId: ttCheckTaskId
                }
            })

            if(code==200){
                this.tableChildren=data
                this.bufferRow=JSON.parse(row)

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc()
                })
            }

        },



    },
  }
</script>
