<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <div class="v-window-item-table">
            <!-- :params="{ warinState:'MA' }" -->
            <TableComponents
                ref="table1"
                url="/iiot/assay/list"
                :showSearchBtn="true"
                :params="{  
                    ...pageSearchConfig
                }"
                @searchClick="searchClick"

            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                            <v-col cols="3">
                                <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                <!-- <span class="font-weight-medium">维修设备</span> -->
                            </v-col>
                            <v-col cols="8">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.nodeLevelName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <!-- <span class="font-weight-medium text"></span> -->
                                <span class="font-weight-medium text">设备:{{ props.items.equipmentName }}</span>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">故障描述:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.problemDesc)">{{ props.items.problemDesc }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">状态:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ FormatDictionary('assay_state',props.items.assayState)['lable']   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">根本问题:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.rootWarin)">{{ props.items.rootWarin }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">解决措施:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.solvingMeasures)">{{ props.items.solvingMeasures }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">维修用时:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.repairTime }} 分钟</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">影响时长:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.productAffectTime }} 分钟</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">提报人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.reportAssayBy }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">提报时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.reportAssayDate }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">故障分析原因:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.assayReason)">{{ props.items.assayReason }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="5">
                                <p class="font-weight-medium text">故障分析单路径:</p>
                            </v-col>
                            <v-col cols="7">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.assayPath)">{{ props.items.assayPath }}</p>
                            </v-col>
                        </v-row>


                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.processBy }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.processDate }}</p>
                            </v-col>
                        </v-row>



                        <!-- <v-row no-gutters class="text">
                            <v-col cols="12" class="text-right">
                                <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">确认维修结束</v-btn>
                            </v-col>
                        </v-row> -->
                    </v-card>
                </template>
            </TableComponents>
        </div>

        <SearchPage
            ref="searchPage"
            :hideStatus="false"
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './search.vue'

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        SearchPage,
        TableComponents
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息   

    }),

    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 确认维修  结束
        async detailClick(props){
            const {items}=props


            const {code}=await OverHTTP({
                payload:{
                    productAffectTime: Number(items.productAffectTime||0),   // 影响时长

                    teAdRepairId: items.teAdRepairId,  // 当前数据的teAdRepairId字段
                    tmBasEquipmentId: items.tmBasEquipmentId,  // 当前数据的tmBasEquipmentId字段值
                    productRepairBy: items.productRepairBy  // 当前数据的productRepairBy字段值


                }
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$refs.table1.initFunc()
            }
        },
        // 查询 
        searchClick(){
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果 
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置 
        resetHandle(opiton){
            this.pageSearchConfig={}
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

        },

    },
  }
</script>
