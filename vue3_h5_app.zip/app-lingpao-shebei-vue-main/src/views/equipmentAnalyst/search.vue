<template>
    <span>

        <van-popup 
            v-model:show="drawer" 
            closeable
            position="right"
            :style="{padding:'12px',width:'90%',height:'100%' }"
        >

            <div style="height: 36px;"></div>

            <van-field
                v-model="fieldValue"
                is-link
                readonly
                label="工厂节点"
                placeholder="请选择工厂节点"
                type="textarea"
                autocomplete="off"
                @click="show = true"
            />
            <van-popup v-model:show="show" round position="bottom">
                <v-btn
                    block
                    color="cyan"
                    elevation="0"
                    style="border-radius: 0px;"
                    @click="()=> show=false"
                >
                    确定
                </v-btn>
                <van-cascader
                    v-if="hideFactory"
                    title="请选择工厂节点"
                    :options="options"
                    active-color="#4CAF50"
                    :field-names="{text:'nodeLevelName',value:'tmBasNodeLevelId',children:'children'}"
                    @close="show = false"
                    @change="onFinish"
                />
            </van-popup>

            <!-- <SelectComponents 
                v-model="type"
                ref="select1"
                label="异常类型"
                showSearch
                :option="typeSelectOption"
                @onSearchChange="getTypeHttp"

            /> -->
            <!-- <SelectComponents 
                v-model="property"
                ref="select2"
                label="属性"
                :option="propertySelectOption"

            /> -->

            <!-- <SelectComponents 
                v-if="hideStatus"
                v-model="status"
                ref="select3"
                label="状态"
                :option="statusSelectOption"

            /> -->

            <div style="margin-top:32px;">
                <v-row no-gutters>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="()=> drawer=false " density="compact"  variant="plain">关闭</v-btn>
                    </v-col>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="resetClick" density="compact" color="warning" variant="plain">重置</v-btn>
                    </v-col>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="searchClick" density="compact" color="primary" variant="plain">查询</v-btn>
                    </v-col>
                </v-row>
            </div>


        </van-popup>


    </span>
</template>
<script>
    import SelectComponents from '@/packages/Select.vue'
    import {httpHandle} from '@/http/http'  // api


    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import {FormatTree} from '@/utils/data'   // utils
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api

  export default {
    components:{
        SelectComponents
    },
    emits: ["searchHandle","resetHandle"],
    data: () => ({
        hideFactory:true,
        drawer: false,

        show:false,   // 工厂 show
        fieldValue:"",  // 工厂显示值
        options:[],    // 工厂 数据

        factoryID:"",   // 工厂选中ID

        type:"",   // 异常类型
        typeSelectOption:[],   // 异常类型数据

        property:"",   // 属性 
        propertySelectOption:[],   // 属性数据

        status:"",  // 状态
        statusSelectOption:[],   // 状态数据
    }),
    created(){
        this.initFunc()

        // this.getTypeHttp()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 重置
        resetClick(){
            this.fieldValue="" // 工厂显示值
            this.factoryID=""  // 工厂选中ID
            // this.type=""   // 异常类型
            // this.property=""  // 属性 
            // this.status="" // 状态


            // this.$refs.select1.reset()
            // this.$refs.select2.reset()
            // this.$refs.select3.reset()

            this.hideFactory=false
            this.$nextTick(()=>{
                this.hideFactory=true
            })

            
            this.$emit("resetHandle",{})


        },
        // 初始化 下拉框
        async initFunc(){
            // 数据字典
            // 属性   abnormal_type
            // 状态     abnormal_state
            // 紧急程度   urgent_degree

            // const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")


            // const _selectAttribute=_bufferDictionaries["abnormal_type"]||[]    // 属性
            // const _selectStatus=_bufferDictionaries["abnormal_state"]||[]     // 状态
            // // const _selectUrgentDegree=_bufferDictionaries["urgent_degree"]||[]     // 紧急程度

            // this.propertySelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据
            // this.statusSelectOption=_selectStatus.map(o=>Object.assign({text:o.lable,value:o.value}))   // 状态数据
      


            // 工厂节点数据
            const {data=[]} = await FactoryTreeHTTP()
            const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")
            this.options=_tree
        },
        // 异常类型
        async getTypeHttp(key=""){
            
            // 展示  abnormalNo + abnormalName   
            // 取值  tmBasAbnormalTypeId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/abnormalType/listAbnormalTypeForSelect',
                method:"get",
                url_params:{
                    // ttQmAbnormalId:ttQmAbnormalId
                    abnormalNo:key
                }
    
            }) 

            if(code==200){
                this.typeSelectOption=data.map(o=>Object.assign({
                    text:`${o.abnormalNo}${o.abnormalName}`,
                    value:o.tmBasAbnormalTypeId
                }))  
            }
        },    
        // 工厂 完成
        onFinish ({ selectedOptions }){


            if(!selectedOptions.length) return

            // tmBasNodeLevelId:“465621691089092608
            let _tmBasNodeLevelId= (selectedOptions[ selectedOptions.length-1 ]||{})["tmBasNodeLevelId"]
            
            this.factoryID=_tmBasNodeLevelId
            this.fieldValue = selectedOptions.map((o) => o.nodeLevelName).join('/')
        },
        // 查询
        searchClick(){
            const {factoryID,type,property,status}=this;


            const _json={
                tmBasNodeLevelId:factoryID,  // 工厂
                // tmBasAbnormalTypeId:type,       // 异常类型
                // abnormalType:property,    // 属性
                // abnormalState:status,     // 状态

            }

            // console.log(_json)
            this.$emit("searchHandle",_json)
            this.drawer=false

        },
        showDrawer(){
            this.drawer=true
        }
    },
    props: {
        // 隐藏 状态
        hideStatus:{
            type: Boolean,
            default: ()=> true      
        },
    }
  }
</script>