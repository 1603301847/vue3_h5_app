<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <v-row no-gutters class="text"  style="margin: 8px 4px;">
            <v-col cols="12">
                <p class="font-weight-medium text">
                    <v-icon icon="mdi-message-text" size="16" color="primary"></v-icon>
                    点检设备信息:</p>
            </v-col>
            <v-col cols="12" class="text-left">
                <p class="font-weight-medium font-weight-light" style="color:#00E5FF;">{{ bufferRow.equipmentName   }}</p>
            </v-col>
        </v-row>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="tableData"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="8">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <p class="text-truncate font-weight-light">点检项目</p>
                            </v-col>

                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.checkName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">维护方法:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.judgmentMethod    }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属车间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.partType  }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所属产线:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.taskQty   }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理方式:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.processingMethod }}</p>
                            </v-col>
                        </v-row> -->

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ FormatDictionary('check_plan',props.items.week)['lable']   }}</p>
                            </v-col>
                        </v-row>



                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text">
                                    维护标准:
                                    {{  props.items.standardJudgment }}
                                </p>
                            </v-col>
                            <!-- <v-col cols="8">
                                <p class="font-weight-light" @click="GlobalTooltipFunc( props.items.standardJudgment)">{{  props.items.standardJudgment }}</p>
                            </v-col> -->
                        </v-row>
                      <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">是否拍照:</p>
                            </v-col>
                            <v-col cols="8">
                                {{ FormatDictionary('is_picture',props.items.isPicture)['lable']   }}
                                <UploaderImageComponents
                                  v-model="props.items.bufferFileList"
                                />
                            </v-col>
                        </v-row>


                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">批次号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.checkBatchNo }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">目的:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.objective }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">不合格描述:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.checkResultContent }}</p>
                            </v-col>
                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p class="font-weight-medium text" style="position: relative;top:7px">结果:</p>
                            </v-col>
                            <v-col cols="9" style="text-align:right;">
                                <v-switch
                                    v-model="props.items._switch"
                                    :label="props.items._switch?'合格':'不合格'"
                                    color="primary"
                                    density="comfortable"
                                    style="top:-8px;left:18px;position:relative;height:40px;display:block;height:48px;width:104px;"
                                    ></v-switch>
                            </v-col>
                        </v-row>
                        <van-field v-model="props.items.checkResultContent" v-if="!props.items._switch" placeholder="请输入" autocomplete="off" label="不合格描述" />

                    </v-card>
                </template>
            </TableComponents>
        </div>

        <v-row no-gutters class="text" style="padding: 0px 4px;">
            <v-col cols="4">
                <v-btn
                    color="#00E5FF"
                    @click="onReceiveFunc"
                >
                    备件领用
                </v-btn>
            </v-col>
            <v-col cols="4">
                <v-btn
                        color="warning"
                        @click="onRepairs"
                    >
                        设备报修
                    </v-btn>
            </v-col>
            <v-col cols="4">
                <v-btn @click="submitClick" color="primary" >提交</v-btn>
            </v-col>
        </v-row>

        <div style="height: 52px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备点检  点检
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents,
        TableComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据
        tableData:[],   //table数据
    }),
    created(){
        // this.initFunc()


        // 刷新页面
        this.$root.$emitter.on("update_examineHistory_page_index",()=>{
            this.initFunc()
        });

    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttCheckTaskId,row="{}"}=this.$route.query

            this.bufferRow=JSON.parse(row)

            const {code,data=[]}= await httpHandle({
                url:'/iiot/checkTask/checkTask',
                method: "post",
                payload:{
                    ttCheckTaskId:ttCheckTaskId
                }
            })

            if(code==200){
                this.tableData=data.map(o=> Object.assign(o,{
                    _switch: o.checkResult=='O'?true:false
                }))

                this.$nextTick(()=>{
                    setTimeout(()=>{
                        this.$refs.table1.initFunc()
                    },300)
                })
            }
        },
        // 提交
        async submitClick(props){
            // const {items}=props
          //检查必须传图片的检测项

          let msg = ''
          this.tableData.forEach(o=>{
            if(o.isPicture == '是' && (!o.bufferFileList || o.bufferFileList == null || o.bufferFileList == '')){
              msg = '检测项:' + o.checkName + ' 必须上传照片,请确认'
            }
          })

          if(msg){
            this.GlobalTooltipFunc(msg)
            return
          }

            const _list= this.tableData.map(o=> Object.assign(o,{
                checkResult: o._switch ? 'O':'N'
            }))

            // console.log( _list )
            // this.$router.push({
            //     path:'/examineConfirm/detail',
            //     query:{ ttCheckTaskId:items.ttCheckTaskId  }
            // })

            const {code,data={}}= await httpHandle({
                url:'/iiot/checkTaskRecord/submitCheckTaskRecord',
                method: "post",
                payload:{
                    checkTaskRecords:   _list.map(o=> Object.assign({
                        checkResult: o.checkResult,
                        inspectValue: o.inspectValue,
                        judgmentResult: o.judgmentResult,
                        ttCheckTaskId: o.ttCheckTaskId,
                        ttCheckTaskRecordId: o.ttCheckTaskRecordId,
                        checkResultContent: o.checkResultContent,
                        bufferFileList: JSON.stringify(o.bufferFileList),
                    }) )
                }
            })

            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/examineHistory/index',
                    query:{  }
                })
                // this.$router.go(-1)

                setTimeout(()=>{
                    this.$root.$emitter.emit("update_examineHistory_page")
                },1500)

            }

        },
        // 备件领用
        onReceiveFunc(){
            const {bufferRow}=this

            this.$router.push({
                path: '/replacement/index',
                query: {
                    activeType:"check",  // 点检
                    row: JSON.stringify(bufferRow)
                    // tmBasEquipmentId: bufferRow.tmBasEquipmentId,
                    // equipmentNo: bufferRow.equipmentNo,
                    // equipmentName: bufferRow.equipmentName,
                }
            })
        },
        // 到设备报修
        onRepairs(){
            const {bufferRow}=this
            // console.log(bufferRow)

            // console.log(bufferRow)
            // return
            this.$router.push({
                path: '/equipment/repairs',
                query: {
                    tmBasEquipmentId: bufferRow.tmBasEquipmentId,
                    equipmentNo: bufferRow.equipmentNo,
                    equipmentName: bufferRow.equipmentName,
                }
            })

        },


    },
  }
</script>
