<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                :showSearchBtn="true"
                url="/iiot/sparePartUse/list"
                :params="{ 
                    finishState: 'N',
                    ...pageSearchConfig
                 }"
                @searchClick="searchClick"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="4">
                                <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                <!-- <span class="font-weight-medium">保养设备</span> -->
                            </v-col>
                            <v-col cols="7">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出入库编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.sparePartUseCode  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出入库名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.sparePartUseName  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出入库类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ FormatDictionary('ccgl_oper_type',props.items.useInfoType)['lable']  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">业务类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ FormatDictionary('ccgl_bpbj_business_type',props.items.businessType)['lable']  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">单据编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.businessCode  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">单据名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.businessName  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">物资编码:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" style="color:#00E5FF;">{{ props.items.goodsMaterialsCode  }}</p>
                            </v-col>
                        </v-row>

                        
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">物资名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.goodsMaterialsName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">申请数量:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.goodsMaterialsNums  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">申请人名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.operUserName  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出库数量:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.outNums  }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出库人名称:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.outUserName  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">出库时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.outDatetime  }}</p>
                            </v-col>
                        </v-row> -->

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">完成标记:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light" :style="`${props.items.finishState=='Y'?'color:#4CAF50;':'color:#F44336;'}`">{{ FormatDictionary('sys_yes_no',props.items.finishState)['lable']   }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">申请时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="font-weight-light">{{ props.items.createTime  }}</p>
                            </v-col>
                        </v-row>
                        
  
                        <v-row no-gutters class="text">
                            <v-col cols="4">

                            </v-col>
                            <v-col cols="4">
                                <v-btn @click="removeClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">删除</v-btn>
                                
                            </v-col>
                            <v-col cols="4" class="text-right">
                                <v-btn @click="detailClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">
                                    {{ props.items.useInfoType=='1'?'入库':'出库' }} 
                                </v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './search.vue' 

    import {httpHandle} from '@/http/http'  // api

    import { showSuccessToast,showFailToast,showToast } from 'vant';
    import { showDialog  } from 'vant'


  export default {
    components:{
        AppBarPage,
        SearchPage,
        TableComponents
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息
    }),

    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 出库
        async detailClick(props){
            const {items}=props
            
            this.$router.push({
                path:'/outPutManage/detail',
                query:{sparePartUseId: items.sparePartUseId }
            })
        },   
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option={}){

            this.pageSearchConfig=option

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

            // console.log(option)
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })


        },
        // 删除
        async removeClick(props){
            const {items}=props

            showDialog({
                title: '删除',
                message: '删除后数据不可恢复，确认删除！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {

                const {code,data={}}= await httpHandle({
                    url:`/iiot/sparePartUse/${items.sparePartUseId}`,
                    method:'DELETE'
                })


                if(code==200){
                    showSuccessToast('提交成功！')
                    this.$refs.table1.initFunc(1)
                }
            });
        }

    },
  }
</script>