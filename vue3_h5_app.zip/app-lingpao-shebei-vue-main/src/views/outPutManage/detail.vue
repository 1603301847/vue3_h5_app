<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">详情</span>
                </v-col>
                <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出入库类型:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ FormatDictionary('ccgl_oper_type',bufferRow.useInfoType)['lable']   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出入库编码:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light" style="color:#00E5FF;">{{ bufferRow.sparePartUseCode   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出入库名称:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.sparePartUseName   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">业务类型:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ FormatDictionary('ccgl_bpbj_business_type',bufferRow.businessType)['lable']   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">单据编码:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light" style="color:#00E5FF;">{{ bufferRow.businessCode   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">单据名称:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.businessName   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">物资编码:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light" style="color:#00E5FF;">{{ bufferRow.goodsMaterialsCode   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">申请数量:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.goodsMaterialsNums   }}</p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出入库说明:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.sparePartUseExplain   }}</p>
                </v-col>
            </v-row>


            <!-- <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">完成标记:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light" :style="`${bufferRow.finishState=='Y'?'color:#4CAF50;':'color:#F44336;'}`">{{ FormatDictionary('sys_yes_no',bufferRow.finishState)['lable']   }}</p>
                </v-col>
            </v-row> -->


            <!-- <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">出库数量:</p>
                </v-col>
                <v-col cols="7">
                    <p class="font-weight-light">{{ bufferRow.outNums   }}</p>
                </v-col>
            </v-row> -->

            <van-field v-model="number" autocomplete="off" required placeholder="请输入" label="出库数量" />
            

            <v-switch
            v-model="switch22"
            :label="switch22?'选择货架号':'输入货架号'"
            color="primary"
            density="comfortable"
            style="top:-8px;left:18px;position:relative;height:40px;display:block;height:48px;width:304px;"
            ></v-switch>

            <SelectComponents 
                v-if="switch22"
                v-model="property"
                label="货架号"
                ref="select11"
                :option="selectPropertyOption"
            />

                
            <van-field v-if="!switch22" v-model="property" autocomplete="off" placeholder="请输入" label="货架号" />


            <v-row >
                <v-col cols="12" class="text-left">
                    <v-btn @click="submit" block color="primary">
                        提交
                    </v-btn>
                </v-col>
            </v-row>

        </v-sheet>
        <div style="height:6px;"></div>



    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 异常处理 详情
    import {httpHandle} from '@/http/http'  // api
    import SelectComponents from '@/packages/Select.vue'

    import { showSuccessToast,showFailToast } from 'vant'
    import moment from "moment"


  export default {
    components:{
        AppBarPage,
        SelectComponents

    },
    watch:{
        switch22(value){
            this.property=""
            
            this.$nextTick(()=>{
                this.$refs.select11 && this.$refs.select11.reset()
            })
            // console.log(value)
        }
    },
    data: () => ({
        switch22:true,
        bufferRow:{},  // 行数据

        number:'',   // 出库数量


        property:"",  // 货架号
        selectPropertyOption:[],  // 货架号 数据
    }),
    created(){
        this.initFunc()


    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {sparePartUseId}=this.$route.query

            const {code,data={}}= await httpHandle({
                url:'/iiot/sparePartUse',
                method:"get",
                url_RESTful:`/${sparePartUseId}`   
            })

            if(code==200){
                this.bufferRow=data

                this.shelfNumber(data)
            }


        },
        // 货架号
        async shelfNumber(option){
            console.log()


            const _list= await httpHandle({
                url:'/iiot/sparePartUse/getStorageDictByPartId/' + option.goodsMaterialsId,
                method:"get",
            })

            // console.log(_list)

            this.selectPropertyOption=(_list||[]).map(o=>Object.assign({text:o.dictLabel,value:o.dictCode}))   // 数据


            // if(code==200){
            //     // this.bufferRow=data

            //     // this.shelfNumber(data)
            // }

        },
        // 提交
        async submit(){
            const _bufferUserInfo=JSON.parse( localStorage.getItem("bufferUserInfo")||"{}" )


            if( !this.number || ( Number(this.number)<=0 ) ){
                showFailToast('出库数量必填大于0！')
                return
            }


            const _json=Object.assign(this.bufferRow,{
                finishState: "Y",
                outDatetime: moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),   // 时间 2023-05-12 14:07:58
                outNums: Number(this.number),               // 出库数量
                outUserName: _bufferUserInfo.userName,     // 用户信息 userName
                outUserCode: _bufferUserInfo.userId,        // 用户信息 userId
                storageCode: this.property,   // 货架号
            })

            // console.log(_json)
            // return
            const {code,data={}}= await httpHandle({
                url:'/iiot/sparePartUse',
                method: 'put',
                payload: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.go(-1)
            }
  

        }
    },
  }
</script>