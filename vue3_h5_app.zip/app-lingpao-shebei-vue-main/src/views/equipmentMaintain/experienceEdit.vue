<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">维修设备信息</span>
                </v-col>
                <!-- <v-col cols="6">
                    <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ 111 }}</p>
                </v-col> -->
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">故障类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.faultTypeCn }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">故障位置:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.faultStationCn }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">故障详情描述:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.problemDesc }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ FormatDictionary('equipment_repair_type',bufferRow.reportType)['lable']   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">报修人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.reportBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">报修时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.reportTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">响应人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.responseBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">响应时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.responseTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.productRepairBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">维修时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.productRepairTime }}</p>
                </v-col>
            </v-row>

        </v-sheet>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-pencil-outline" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">维修经验填写</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="uploadFunc" class="font-weight-medium text-right text-teal-lighten-1" color="primary">上传维修文件</p> -->
                </v-col>
            </v-row>

            <van-field v-model="value1" autocomplete="off" label="根本问题"  placeholder="请输入" required  />
            <van-field v-model="value2" autocomplete="off" label="解决措施"  placeholder="请输入" required  />
            <van-field v-model="value3" autocomplete="off" label="改进建议"  placeholder="请输入" required  />

            <van-field v-model="value4" autocomplete="off" label="维修用时" type="number"  placeholder="请输入"   />
            <van-field v-model="value5" autocomplete="off" label="维修内容"  placeholder="请输入"   />
            <van-field v-model="value6" autocomplete="off" label="工具"  placeholder="请输入"   />


        </v-sheet>

        <v-btn
            elevation="2"
            block
            @click="onSubmit"
        >
            确认
        </v-btn>

        <div style="height: 60px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api

    import {ExperienceDetailHTTP,SaveHistoryHTTP} from '@/http/equipment/maintain'   // api
    import { showSuccessToast,showFailToast } from 'vant';

  export default {
    components:{
        AppBarPage,
        TableComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据

        value1:"",  //根本问题
        value2:"",  //解决措施
        value3:"",  //改进建议

        value4:"",   // 维修用时
        value5:"",   //  维修内容
        value6:"",   // 工具

    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {teAdRepairId}=this.$route.query


            // const {data={}}=await ExperienceDetailHTTP({
            //     url_RESTful:`/${teAdRepairId}`
            //     // url_RESTful:"/462191250168418304"
            // })

            //

            const {code,data={}}= await httpHandle({
                url:`/iiot/equipmentRepair/${teAdRepairId}`,
                method: "get"
            })

            if(code==200){
                this.bufferRow=data

                this.value1=data.rootWarin //根本问题
                this.value2=data.solvingMeasures  //解决措施
                this.value3=data.suggestionsImprovement //改进建议

                this.value4=data.repairTime    // 维修用时
                this.value5=data.repairContent   // 维修内容
                this.value6=data.tool   // 工具


            }

        },
        // 提交
        async onSubmit(){
            const {value1,value2,value3,bufferRow}=this

            if(!value1.trim()){
                showFailToast("根本问题必填!")
                return
            }

            if(!value2.trim()){
                showFailToast("解决措施必填!")
                return
            }

            if(!value3.trim()){
                showFailToast("改进建议必填!")
                return
            }

            const _json={
                ...bufferRow,  // 行数据
                rootWarin: value1, // 根本问题
                solvingMeasures: value2,   // 解决措施
                suggestionsImprovement: value3, // 改进建议


                repairTime: this.value4,   // 维修用时
                repairContent : this.value5, // 维修内容
                tool: this.value6, // 工具
            }


            const {code,data={}}= await httpHandle({
                url:'/iiot/equipmentRepair/editTalk',
                method: "put",
                payload:_json
            })

            if(code==200){
                this.$router.push({
                    path:'/equipment/maintain',
                    query:{ tabs:2 }
                })
            }






        },
        // 上传维修文件
        uploadFunc(){
            showSuccessToast('正在建设中！')

        }
    },
  }
</script>
