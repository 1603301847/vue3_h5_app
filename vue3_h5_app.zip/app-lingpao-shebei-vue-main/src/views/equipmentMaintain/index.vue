<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>当前维修任务</v-tab>
                    <v-tab value="2" hide-slider>我的维修任务</v-tab>
                </v-tabs>
            </template>
        </AppBarPage>
        <div style="height: 50px;"></div>

        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    :showSearchBtn="true"
                    url="/iiot/equipmentRepair/list"
                    :params="{
                        warinState:'WM',
                        ...pageSearchConfig1
                    }"
                    @searchClick="searchClick1"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="5">
                                    <span class="font-weight-medium">维修设备</span>
                                </v-col>
                                <v-col cols="1">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.faultTypeCn }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障位置:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.faultStationCn }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障详细描述:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p @click="GlobalTooltipFunc(`${props.items.problemDesc}`)" class="text-truncate font-weight-light">{{ props.items.problemDesc }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <!-- <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col> -->
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-medium text">维修类型: {{ FormatDictionary('equipment_repair_type',props.items.reportType)['lable'] }}</p>
                                </v-col>

                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12" class="text-left">
                                    <p class="text-truncate font-weight-medium text">报修人: {{ props.items.reportBy }}</p>
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col>

                            </v-row> -->
                            <v-row no-gutters class="text">
                                <!-- <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col> -->
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-medium text">报修时间: {{ props.items.reportTime }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12" class="text-right">
                                    <v-btn @click="preemptClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">抢单响应</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <v-window-item value="2" class="v-window-item-table">
                <!-- <span>url="/iiot/equipmentRepair/listForApp"</span> -->
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    :showSearchBtn="true"
                    url="/iiot/equipmentRepair/listForApp"
                    :params="{
                        ...pageSearchConfig2
                    }"
                    @searchClick="searchClick2"
                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="5">
                                    <span class="font-weight-medium">维修设备</span>
                                </v-col>
                                <v-col cols="1">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.faultTypeCn }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障位置:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.faultStationCn }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">故障详细描述:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p @click="GlobalTooltipFunc(`${props.items.problemDesc}`)" class="text-truncate font-weight-light">{{ props.items.problemDesc }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <!-- <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col> -->
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-medium text">维修类型: {{ FormatDictionary('equipment_repair_type',props.items.reportType)['lable'] }}</p>
                                </v-col>

                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12" class="text-left">
                                    <p class="text-truncate font-weight-medium text">报修人: {{ props.items.reportBy }}</p>
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col>

                            </v-row> -->
                            <v-row no-gutters class="text">
                                <!-- <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col> -->
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-medium text">报修时间: {{ props.items.reportTime }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4" class="text-center">
                                    <v-btn @click="checkExperience(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">查看维修经验</v-btn>
                                </v-col>
                                <v-col cols="4" class="text-center">
                                    <v-btn @click="cancelMaintain(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">取消维修</v-btn>
                                </v-col>
                                <v-col cols="4" class="text-right">
                                    <v-btn @click="equipmentMaintain(props)" color="orange mt-1" density="compact" :rounded="0" variant="plain">设备维修</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>
        </v-window>


        <SearchPage1
            ref="searchPage1"
            :hideStatus="false"
            @resetHandle="resetHandle1"
            @searchHandle="searchHandle1"
        />

        <SearchPage2
            ref="searchPage2"
            :hideStatus="false"
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        />

        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px 12px 4px 12px',width:'90%'}"
            round 
        >   
            <h3>取消确认!</h3>

            <span style="color:#D84315;display: block;padding-left: 22px;margin-top: 12px;margin-bottom: 22px;">取消后数据不可恢复，确认取消！</span>
            <van-field v-model="reasonCancellation" required label="取消原因" placeholder="请输入" autocomplete="off"  />
            

            <v-btn style="margin-bottom:28px;margin-top: 18px;" @click="cancelReimbursement" block color="error" variant="outlined">
                取消报修
            </v-btn>
        </van-popup>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api
    import  SearchPage1 from './search.vue'
    import  SearchPage2 from './search.vue'



    import {PreemptHTTP} from '@/http/equipment/maintain'   // api
    import {CancelHTTP} from '@/http/equipment/maintain'   // api
    import { showDialog  } from 'vant'

    import { showSuccessToast,showFailToast,showToast } from 'vant';

  export default {
    components:{
        AppBarPage,
        SearchPage1,
        SearchPage2,
        TableComponents
    },
    data: () => ({
        showPicker:false,
        reasonCancellation:"",   // 取消原因
        rowData:{},   // 行数据


        tab: '1',
        repairsPersonnel:"",   // 报修人


        pageSearchConfig1:{},  // 查询信息   11
        pageSearchConfig2:{},  // 查询信息   22



    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        initFunc(){
            const {tabs}=this.$route.query

            this.repairsPersonnel=JSON.parse( localStorage.getItem("bufferUserInfo")||"{}" )["userName"]

            if(tabs){
                this.tab=tabs
            }
        },
        /**
         * 抢单响应
        */
        async preemptClick(props){
            const {items}=props

            const {code}=await PreemptHTTP({
                payload:{
                    tmBasEquipmentId: items.tmBasEquipmentId,   // 当前数据的tmBasEquipmentId字段
                  teAdRepairId: items.teAdRepairId   // 当前数据的teAdRepairId字段
                }
            })

            if(code==200){
                showSuccessToast('提交成功！')
                this.$refs["table1"].initFunc()
            }

        },
        // 查看维修经验
        async checkExperience(props){
            const {items}=props

            this.$router.push({
                path:'/equipment/maintain/experience',
                query:{
                    state:"1",
                  teAdRepairId:items.teAdRepairId,
                  tmBasEquipmentId:items.tmBasEquipmentId
                }
            })

        },
        // 取消维修
        async cancelMaintain(props){
            const {items}=props


            showDialog({
                title: '取消确认！',
                message: '取消后，数据会回到当前维修任务！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {

                const {code,data={}}= await httpHandle({
                    url:'/iiot/equipmentRepair/cancelRepair',
                    method: "post",
                    payload: {
                        tmBasEquipmentId: items.tmBasEquipmentId,   // 当前数据的tmBasEquipmentId字段
                        teAdRepairId: items.teAdRepairId   // 当前数据的teAdRepairId字段
                    }
                })

                if(code==200){
                    showSuccessToast('提交成功！')
                    this.$refs.table2.initFunc()
                }

            });




            // this.showPicker=true
            // this.reasonCancellation=""
            // this.rowData=items

            // return
            // showDialog({
            //     title: '取消',
            //     message: '取消后数据不可恢复，确认取消！',
            //     theme: 'round-button',
            //     closeOnClickOverlay:true,
            // }).then(async () => {



            // });




        },
        // 取消报修
        async cancelReimbursement(){
            const {rowData}=this
            const _reasonCancellation=this.reasonCancellation.trim()

            if( !_reasonCancellation  ){
                showFailToast("取消原因必填！")
                return
            }

            const _json={
                cancelReason: _reasonCancellation,   // 取消原因
                tmBasEquipmentId: rowData.tmBasEquipmentId,   // 当前数据的tmBasEquipmentId字段
                teAdRepairId: rowData.teAdRepairId   // 当前数据的teAdRepairId字段

            }


            const {code,data={}}= await httpHandle({
                url:'/iiot/equipmentRepair/cancelRepairWbForceForApp',
                method: "post",
                payload: _json
            })

            if(code==200){
                showSuccessToast('提交成功！')

                this.showPicker=false
                this.$refs.table2.initFunc()
            }
        },
        // 设备维修
        async equipmentMaintain(props){
            const {items}=props
            // console.log(items)
            this.$router.push({
                path:'/equipment/maintain/detail',
                // query:{row: JSON.stringify(items) }
                query:{ 
                    teAdRepairId:items.teAdRepairId,
                    filePath: items.filePath 
                }

            })

            setTimeout(()=>{
                this.$root.$emitter.emit("update_maintain_page_index")
            },1500)
        },
        // 查询 11
        searchClick1(){
            this.$refs.searchPage1.showDrawer()
        },
        // 查询结果 11
        searchHandle1(option){
            this.pageSearchConfig1=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置 11
        resetHandle1(opiton){
            this.pageSearchConfig1={}
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

        },
        // 查询 22
        searchClick2(){
            this.$refs.searchPage2.showDrawer()
        },
        // 查询结果 22
        searchHandle2(option){
            this.pageSearchConfig2=option
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置 22
        resetHandle2(opiton){
            this.pageSearchConfig2={}


            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })

        },
    },
  }
</script>
