<template>
    <span>



        <van-popup 
            v-model:show="drawer" 
            closeable
            position="right"
            :style="{padding:'12px',width:'90%',height:'100%' }"
        >


            <div style="height: 52px;"></div>

            <van-field v-model="value1" autocomplete="off" placeholder="请输入" label="出入库编码" />
            <van-field v-model="value2" autocomplete="off" placeholder="请输入" label="单据编码" />
            <van-field v-model="value3" autocomplete="off" placeholder="请输入" label="物资编码" />
            <van-field v-model="value4" autocomplete="off" placeholder="请输入" label="申请人名称" />


            <SelectComponents 
                v-model="property"
                ref="select1"
                label="出入库类型"
                :option="propertySelectOption"

            />

            <SelectComponents 
                v-model="property22"
                ref="select2"
                label="业务类型"
                :option="propertySelectOption22"

            />


            <div style="margin-top:32px;">
                <v-row no-gutters>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="()=> drawer=false " density="compact"  variant="plain">关闭</v-btn>
                    </v-col>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="resetClick" density="compact" color="warning" variant="plain">重置</v-btn>
                    </v-col>
                    <v-col cols="4" class="text-center">
                        <v-btn @click="searchClick" density="compact" color="primary" variant="plain">查询</v-btn>
                    </v-col>
                </v-row>
            </div>


        </van-popup>


    </span>
</template>
<script>
    import SelectComponents from '@/packages/Select.vue'
    import {httpHandle} from '@/http/http'  // api
    import DatePickerComponents from '@/packages/DatePicker.vue'
    import { showSuccessToast,showFailToast } from 'vant';


    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import {FormatTree} from '@/utils/data'   // utils
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api

  export default {
    components:{
        SelectComponents,
        DatePickerComponents
    },
    emits: ["searchHandle","resetHandle"],
    data: () => ({

        drawer: false,

        value1:"",
        value2:"",
        value3:"",
        value4:"",

 
        property:"",   // 出入库类型 
        propertySelectOption:[],   // 出入库类型  数据

        property22:"",   // 业务类型 
        propertySelectOption22:[],   // 业务类型  数据
    }),
    created(){
        this.initFunc()


    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 重置
        resetClick(){

            this.value1=''   // 出入库编码
            this.value2=''   // 单据编码
            this.value3=''   // 物资编码
            this.value4=''   // 申请人名称



            this.property=''   // 出入库类型
            this.property22=''   // 业务类型
            this.$refs.select1 && this.$refs.select1.reset()
            this.$refs.select2 && this.$refs.select2.reset()


        
            this.$emit("resetHandle",{})


        },
        // 初始化 下拉框
        async initFunc(){
 
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")


            const _selectAttribute=_bufferDictionaries["ccgl_oper_type"]||[]    // 任务类型
            this.propertySelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 任务类型


            const _selectAttribute2=_bufferDictionaries["ccgl_bpbj_business_type"]||[]    // 业务类型
            this.propertySelectOption22=_selectAttribute2.map(o=>Object.assign({text:o.lable,value:o.value}))   // 业务类型


            

        },
        // 查询
        searchClick(){

            
  
            const _json={
                sparePartUseCode: this.value1,   // 出入库编码
                businessCode: this.value2,   // 单据编码
                goodsMaterialsCode:  this.value3,   // 物资编码
                operUserName:  this.value4,   // 申请人名称

                useInfoType: this.property,   // 出入库类型
                businessType: this.property22,   // 业务类型
            }

            // console.log(_json)
            // return
            this.$emit("searchHandle",_json)
            this.drawer=false

        },
        showDrawer(){
            this.drawer=true
        }
    },
  }
</script>