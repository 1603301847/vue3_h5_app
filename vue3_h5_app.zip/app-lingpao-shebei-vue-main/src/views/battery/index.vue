<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <!-- <ScanBarComponents 
            ref="ScanBar"
            placeholder="请扫描或输入 GPS编码"
            @searchClick="barSearchClick"
        />

        <ScanBarComponents 
            ref="ScanBar2"
            placeholder="请扫描或输入 产品序列号"
            @searchClick="barSearchClick2"
        /> -->

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">基础信息</span>
                </v-col>
                <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ isDetail?'详情':'编辑' }}</p>
                </v-col>
            </v-row>
            <div style="height: 6px;"></div>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验产品:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.partName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">订单号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.orderNo }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">工作中心:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.nodeLevelName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品SN号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.sn }}</p>
                </v-col>
            </v-row>
            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验数量:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.taskQty }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">状态:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ FormatDictionary("qm_task_status",bufferRow.taskStatus)["lable"]  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ FormatDictionary('test_type',bufferRow.taskType)['lable']  }}</p>
                </v-col>
            </v-row>

        </v-sheet>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-file-edit-outline" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">采集信息</span>
                </v-col>
                <v-col cols="5">
                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p> -->
                </v-col>
            </v-row>
            <div style="height: 6px;"></div>

            <div style="position:relative;top:5px">
                <SelectComponents 
                    v-model="supplier"
                    ref="select11"
                    label="供应商代码"
                    filterSearch
                    showSearch
                    :disabled="isDetail"
                    :option="supplierSelectOption"
                    @onChange="supplierSelectChange"

                />
            </div>

            <div style="padding-left:4px">
                <v-row no-gutters class="text">
                    <v-col cols="12">
                        <p class="font-weight-medium text">
                            电池品牌:
                            {{ bufferRow4.battery }}
                        </p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text">
                    <v-col cols="12">
                        <p class="font-weight-medium text">
                            SAP物料号:
                            {{ bufferRow2.matnr }}
                        </p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text">
                    <v-col cols="12">
                        <p class="font-weight-medium text">
                            电池规格型号:
                            <span style="color:#00E5FF;">{{ bufferRow2.batterySpecs }}</span>
                        </p>
                    </v-col>
                </v-row>
            </div>
            <div style="height:12px"></div>

            <v-divider></v-divider>

            <div style="position:relative;top:5px">
                <SelectComponents 
                    v-model="supplier2"
                    ref="select22"
                    label="供应商代码"
                    :disabled="isDetail"
                    filterSearch
                    showSearch
                    :option="supplierSelectOption2"
                    @onChange="supplierSelectChange"
                />
            </div>

            <div style="padding-left:4px">
                <v-row no-gutters class="text">
                    <v-col cols="12">
                        <p class="font-weight-medium text">
                            充电器品牌:
                            <span>{{ bufferRow4.charger }}</span>
                        </p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text">
                    <v-col cols="12">
                        <p class="font-weight-medium text">
                            SAP物料号:
                            {{ bufferRow3.chargerMatnr }}
                        </p>
                    </v-col>
                </v-row>
                <v-row no-gutters class="text">
                    <v-col cols="12">
                        <p class="font-weight-medium text">
                            充电器规格型号:
                            <span style="color:#00E5FF;">{{ bufferRow3.chargerSpecs }}</span>
                        </p>
                    </v-col>
                </v-row>
                <div style="height:12px"></div>

                <v-divider></v-divider>
                <div style="height:12px" v-if="!isDetail"></div>

                    <van-field v-if="showBtn=='0'" v-model="value111" :disabled="isDetail" label-width="7.5em" placeholder="请输入" autocomplete="off" label="充电曲线数值:" required />
                    <van-field v-if="showBtn=='1'" v-model="value222" :disabled="isDetail" label-width="7.5em" placeholder="请输入" autocomplete="off" label="36预报警数值:" required />
                    <van-field v-if="showBtn=='1'" v-model="value333" :disabled="isDetail" label-width="7.5em" placeholder="请输入" autocomplete="off" label="68预报警数值:" required />

                </div>

                <div style="height:12px" v-if="isDetail">
                    <van-field v-model="value111" :disabled="isDetail" label-width="7.5em" placeholder="请输入" autocomplete="off" label="充电曲线数值:" required />
                    <van-field v-model="value222" :disabled="isDetail" label-width="7.5em" placeholder="请输入" autocomplete="off" label="36预报警数值:" required />
                    <van-field v-model="value333" :disabled="isDetail" label-width="7.5em" placeholder="请输入" autocomplete="off" label="68预报警数值:" required />

                </div>
            <div style="height:12px"></div>
            <UploaderImageComponents 
                v-model="bufferFileList"
                :preview="isDetail"
            />

        </v-sheet>

        
        <div style="height:6px"></div>

        <v-row no-gutters v-if="!isDetail">
            <v-col cols="12" class="text-center">
                <v-btn @click="submit" color="primary" block>提交</v-btn>
            </v-col>
        </v-row>
        <div style="height:82px"></div>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import SelectComponents from '@/packages/Select.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import ScanBarComponents from '@/packages/ScanBar.vue'
    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';



  export default {
    components:{
        AppBarPage,
        SelectComponents,
        ScanBarComponents,
        UploaderImageComponents

    },
    data: () => ({
        isDetail:false,  // 详情
        bufferFileList:[],  // 缓存图片


        bufferRow: {},

        bufferRow2:{},   
        bufferRow3:{},   
        bufferRow4:{},   
        
        showBtn:"",  // '0' 充电曲线   '1' 预报警

        value111:"",
        value222:"",
        value333:"",

        supplier:"",   // 供应商代码
        supplierSelectOption:[],   // 供应商代码 数据

        supplier2:"",   // 供应商代码
        supplierSelectOption2:[],   // 供应商代码 数据

    }),
    created(){
        this.initFunc()
        this.supplierHTTP()   // 供应商代码
        this.supplierHTTP2()   // 供应商代码2

    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {row,_pageActive,batteryCheckType=''}=this.$route.query

            this.showBtn=batteryCheckType

            const _row=JSON.parse(row)
            this.bufferRow=_row

            // console.log(_row)

            // 详情
            this.isDetail= ((_pageActive=='detail')?true:false)
            // if(_pageActive=='detail'){
            //     const {code,data=[]}= await httpHandle({
            //         url:`/iiot/batteryResult/list`,
            //         method:'get',
            //         url_params:{
            //             orderNo: _row.orderNo,
            //             partNo: _row.partNo,
            //         }
            //     })

            //     if(code==200){
            //         console.log(data)
            //     }
            //     return
            // }


            // console.log( JSON.parse(row)  )
            const {code,data={}}= await httpHandle({
                url:`/iiot/batteryCurve/getBatteryInfoByOrderNo/${_row.sn}`,
                method:'get'
            })

            if(code==200){

                this.bufferRow2=data   
                this.bufferRow3=data
                this.bufferRow4=data    // 电池品牌  充电器品牌



                // 图片
                if(data.filePath){
                    this.bufferFileList=data.filePath.split(',').map(o=>Object.assign({url:o}))
                }

                

                // if(_pageActive=='detail'){
                //     this.value111=data.curve
                //     this.value222=data.reportFin
                //     this.value333=data.reportOne  
                // }
                this.value111=data.curve||""
                this.value222=data.reportOne||""
                this.value333=data.reportFin||""


                this.supplier=data.supplierCode    /*电池供应商编码*/
                this.supplier2=data.chargerSupplierCode   /*充电器供应商编码*/

                this.$nextTick(()=>{


                    setTimeout(()=>{
                        this.$refs.select11 && this.$refs.select11.setValue( data.supplierCode )  /*电池供应商编码*/
                        this.$refs.select22 && this.$refs.select22.setValue( data.chargerSupplierCode )    /*充电器供应商编码*/
                        
                        this.supplierSelectChange()
                    },600)
                })


                
   
                // // 电池供应商
                // this.supplier= data.supplierCode
                // // 充电器供应商
                // this.supplier2= data.chargerSupplierCode

                // setTimeout(()=>{
                //     this.$refs.select11 && this.$refs.select11.setValue( data.supplierCode )                  // 电池供应商
                //     this.$refs.select22 && this.$refs.select22.setValue( data.chargerSupplierCode )         // 充电器供应商  
                // },600)

                // this.$nextTick(()=>{
                //     this.getDetailFunc()
                // })
            }
        },
        // 详情
        async getDetailFunc(){
            // const {row,_pageActive}=this.$route.query

            // const _row=JSON.parse(row)
            // const {code,data=[]}= await httpHandle({
            //     url:`/iiot/batteryResult/list`,
            //     method:'get',
            //     url_params:{
            //         orderNo: _row.orderNo,
            //         partNo: _row.partNo,
            //     }
            // })

            // if(code==200){
            //     if(data && data.length){
            //         const _obj=data[0]

            //         // 图片
            //         if(_obj.filePath){
            //             this.bufferFileList=_obj.filePath.split(',').map(o=>Object.assign({url:o}))
            //         }

                 

            //         if(_pageActive=='detail'){
            //             this.value111=_obj.curve
            //             this.value222=_obj.reportFin
            //             this.value333=_obj.reportOne  
            //         }


            //         this.$nextTick(()=>{
            //             this.supplier=_obj.supplierCode    /*电池供应商编码*/
            //             this.supplier2=_obj.chargerSupplierCode   /*充电器供应商编码*/

            //             setTimeout(()=>{
            //                 this.$refs.select11 && this.$refs.select11.setValue( _obj.supplierCode )  /*电池供应商编码*/
            //                 this.$refs.select22 && this.$refs.select22.setValue( _obj.chargerSupplierCode )    /*充电器供应商编码*/
            //                 // this.supplierSelectChange()
            //             },600)
            //         })
            //     }
            //     // console.log(data)
            // }
        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            const {code,data=[]}= await httpHandle({
                url:'/iiot/qmTask/listQmTaskSnForSelect',
                method: "get",
                url_params:{
                    sn: _value
                }
            })

            if(code==200){

                if(!data.length){
                    showFailToast("SN号不存在！")
                    return
                }    

                // this.ttPpOrderSnId=data[0]?.ttPpOrderSnId
                showSuccessToast("扫描成功！")


            }
        },
        // 扫码  参评序列号
        barSearchClick2(value=''){

        },
        // 提交
        async submit(){
            const {bufferRow4,bufferRow}=this
            const _value1=this.value111.trim()    // 充电
            const _value2=this.value222.trim()  // 36
            const _value3=this.value333.trim()   // 68

            let _json7={}

            // 
            if(this.showBtn=='0'){
                _json7={
                    curve: bufferRow4.curve,  // 充电曲线
                }
            }

            if(this.showBtn=='1'){
                _json7={
                    reportFin: bufferRow4.reportFin,   // 68 报警
                    reportOne: bufferRow4.reportOne,   // 36 报警
                }
            }

   
            if(this.showBtn=='0'){
                if( (bufferRow4.curve !=_value1) ){
                    showFailToast("充电曲线数值不匹配!")
                    return
                }
            }
            
     
            if(this.showBtn=='1'){

                if( (bufferRow4.reportOne !=_value2) ){
                    showFailToast("36预报警数值不匹配!")
                    return
                }

                if( (bufferRow4.reportFin !=_value3) ){
                    showFailToast("68预报警数值不匹配!")
                    return
                }
            }
      




            const _json={
                ...this.bufferRow2,
                sn: bufferRow.sn,
                ttQmTaskId:bufferRow.ttQmTaskId,
                orderNo: bufferRow.orderNo,
                partNo: bufferRow.partNo,
                partName: bufferRow.partName,

                tmBasNodeLevelId: bufferRow.tmBasNodeLevelId,

                supplierCode: this.supplier,    /*电池供应商编码*/
                chargerSupplierCode: this.supplier2,   /*充电器供应商编码*/

   
                ..._json7,

                partModel: bufferRow4.partModel, 

                battery: bufferRow4.battery,
                charger: bufferRow4.charger,

                filePath: this.bufferFileList.map(o=>o.url).join()  // 图片


            }

            const {code,data={}}= await httpHandle({
                url:`/iiot/batteryResult`,
                method:'post',
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.go(-1)
            }

        },
        // 供应商代码 数据
        async supplierHTTP(){
  
            const {code,data=[]}= await httpHandle({
                url:'/iiot/supplier/list',
                method:"get",
                url_params:{
                    delFlag:'Y',
                    searchType:'10'
                }
            }) 

            if(code==200){
                this.supplierSelectOption=data.map(o=>Object.assign({
                    text:`${o.supplierCode}-${o.supplierName}`,
                    value:o.supplierCode
                }))
            }
        }, 
        // 供应商代码 数据
        async supplierHTTP2(){
  
            const {code,data=[]}= await httpHandle({
                url:'/iiot/supplier/list',
                method:"get",
                url_params:{
                    delFlag:'Y',
                    searchType:'10'
                }
            }) 

            if(code==200){
                this.supplierSelectOption2=data.map(o=>Object.assign({
                    text:`${o.supplierCode}-${o.supplierName}`,
                    value:o.supplierCode
                }))
            }
        }, 
        // 供应商切换
        async supplierSelectChange(){
            const {row}=this.$route.query
            const _row=JSON.parse(row)
            const _partNo=_row.partNo.slice(0,6)


            if( !this.supplier || !this.supplier2 ){
                return
            }

            const {bufferRow2}=this
            const {code,data=[]}= await httpHandle({
                url:'/iiot/batteryCurve/list',
                method:"get",
                url_params:{
                    partModel:_partNo,   // no 的前六位 
                    supplierCode: this.supplier,    /*电池供应商编码*/
                    chargerSupplierCode: this.supplier2,   /*充电器供应商编码*/
                    matnr:bufferRow2.matnr,   // 电池 物料号
                    chargerMatnr:bufferRow2.chargerMatnr,   // 充电器 物料号
                }
            }) 

            if(code==200){
                this.bufferRow4=data[0]||{}
                // console.log(data)
            }


        }

    },
  }
</script>
