<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="tableChildren"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="8">
                                <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                <p class="text-truncate font-weight-light">点检项目</p>
                            </v-col>

                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.checkNo }}-{{ props.items.checkName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">点检方法:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.judgmentMethod   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">处理方法:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.processingMethod  }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">判断标准:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.standardJudgment)">{{ props.items.standardJudgment   }}</p>
                            </v-col>
                        </v-row> -->
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text">
                                    判断标准:
                                    {{  props.items.standardJudgment }}
                                </p>
                            </v-col>
                            <!-- <v-col cols="8">
                                <p class="font-weight-light" @click="GlobalTooltipFunc( props.items.standardJudgment)">{{  props.items.standardJudgment }}</p>
                            </v-col> -->
                        </v-row>


                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">目的:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.objective }}</p>
                            </v-col>
                        </v-row>




                        <v-row no-gutters class="text">
                            <v-col cols="6" class="text-right">

                            </v-col>
                            <v-col cols="2" class="text-right">
                                <p class="font-weight-medium text">结果:</p>
                            </v-col>
                            <v-col cols="3">
                                <p class="text-truncate font-weight-light" :style="props.items.checkResult=='N'?'color:#FF5722':'color:#4CAF50'">{{  props.items.checkResult=='N'?'不合格':'合格'  }}</p>
                            </v-col>
                        </v-row>



                    </v-card>
                </template>
            </TableComponents>
        </div>

        <v-row no-gutters class="text">
            <v-col cols="5" class="text-left">
            
                <v-btn
                    color="#00E5FF"
                    @click="onReceiveFunc"
                >
                    备件领用
                </v-btn>
            </v-col>
            <v-col cols="1" class="text-left">

            </v-col>
            <v-col cols="3" class="text-right">
                <v-btn @click="statusClick(true)" color="primary mt-1" >正常</v-btn>
            </v-col>
            <v-col cols="3" class="text-right">
                <v-btn @click="statusClick(false)" color="error mt-1">异常</v-btn>
            </v-col>
        </v-row>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备点检  点检单
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        TableComponents
    },
    data: () => ({
        tableChildren:[],  // table 数据
    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttCheckTaskId}=this.$route.query

            

            const {code,data=[]}= await httpHandle({
                url:'/iiot/checkTask/checkTask',
                method: "post",
                payload:{
                    ttCheckTaskId: ttCheckTaskId
                }
            })

            if(code==200){
                this.tableChildren=data

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc()
                })
            }

        },
        // 备件领用
        onReceiveFunc(){
            const {bufferRow,tableChildren=[]}=this

            if(!tableChildren.length){
                showFailToast("无数据！")
                return
            }
            
            this.$router.push({
                path: '/replacement/index', 
                query: {
                    activeType:"checkCreate",  // 点检创建
                    row: JSON.stringify( tableChildren[0] )
                    // tmBasEquipmentId: bufferRow.tmBasEquipmentId,
                    // equipmentNo: bufferRow.equipmentNo,
                    // equipmentName: bufferRow.equipmentName,
                }
            })
        },
        // 正常 | 异常
        async statusClick(active){
            const {ttCheckTaskId}=this.$route.query

            const _json={
                ttCheckTaskId: ttCheckTaskId,
                confirmResult: active?"O":"N"
            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/checkTaskRecord/commitCheckTaskRecord',
               method: "post",
               payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')

                this.$router.push({
                    path:'/examineConfirm/index', 
                    query:{  }
                }) 
            }

        }   


    },
  }
</script>