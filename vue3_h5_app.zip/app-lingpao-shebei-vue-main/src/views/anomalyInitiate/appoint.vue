<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">异常发起信息流水</span>
                </v-col>
                <v-col cols="5">
                    <p class="font-weight-medium text-truncate text-center text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">异常类型属性:</p>
                </v-col>
                <v-col cols="7">
                    <p class="text-truncate font-weight-light">{{ bufferRow.abnormalTypeName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">紧急程度:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light" style="color:#00E5FF;">{{ bufferRow.urgentDegreeName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常类型:</span>
                    <span class="font-weight-light">{{ bufferRow.abnormalName }}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常内容:</span>
                    <span class="font-weight-light">{{ bufferRow.contentName }}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常描述:</span>
                    <span class="font-weight-light">{{ bufferRow.abnormalDesc }}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品序列号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.ttPpOrderSnId }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品名称:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.partName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">异常地点:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.abnormalPlace }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">设备型号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ (bufferRow.equipmentNo||'') + '-' + (bufferRow.equipmentName||'') }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiateBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiateTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">发起联系方式:</p>
                </v-col>
                <v-col cols="7">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiatePhone }}</p>
                </v-col>
            </v-row>

            <UploaderImageComponents 
                v-model="bufferFileListPreview"
                preview
            />


        </v-sheet>
        <div style="height:6px;"></div>
        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-share" size="16" color="indigo"></v-icon>
                    <span class="font-weight-medium">异常转发信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p class="font-weight-medium text-truncate text-center text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo  }}</p> -->
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light text">
                        <span class="font-weight-medium">转发说明:</span>
                        <span style="color:#00E5FF;">{{ bufferRow.retransmissionDesc }}</span>
                    </p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">转发到:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.retransmissionBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">转发时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.retransmissionTime }}</p>
                </v-col>
            </v-row>
        </v-sheet>
        <div style="height:6px;"></div>


        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-share" size="16" color="indigo"></v-icon>
                    <span class="font-weight-medium">异常转发信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>


            <van-field v-model="explain" placeholder="请输入" label="指派说明" autocomplete="off" required />

            <SelectComponents 
                v-model="user"
                label="指派到"
                required
                showSearch
                :option="selectOption"
                @onSearchChange="userSearchChange"

            />
   
            <van-field v-model="remark" placeholder="请输入" autocomplete="off" label="备注"  />

        </v-sheet>
        <v-sheet elevation="2" rounded class="custem-card">
            <van-field v-model="rejectReason" placeholder="请输入" label="退回原因" autocomplete="off" required />
        </v-sheet>

        <div style="height:6px;"></div>
        <v-row no-gutters>
            <v-col cols="6" class="text-center">
                <v-btn @click="rejectHandle" color="error" >
                    退回
                </v-btn>
            </v-col>

            <v-col cols="6" class="text-center">
                <v-btn @click="forwardHandle" color="primary" >
                    确认指派
                </v-btn>
            </v-col>
        </v-row>
        <div style="height:36px;"></div>


    </span>
</template>
<script>

    import AppBarPage from '@/components/AppBar.vue'  // 异常处理 异常指派
    import {httpHandle} from '@/http/http'  // api
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import SelectComponents from '@/packages/Select.vue'

    import { showSuccessToast,showFailToast,showToast } from 'vant'

    import moment from "moment"

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents,
        SelectComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据

        bufferFileListPreview:[],  // 图片预览

        explain:"",         // 转发说明
        user:"",            // 转发到
        selectOption:[],    // 转发到 数据

        remark:"",   // 备注

        rejectReason:"",   // 退回原因
    }),
    created(){
        this.initFunc()

    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmAbnormalId}=this.$route.query

            // 

            const {code,data={}}= await httpHandle({
                url:'/iiot/abnormal',
                method:"get",
                url_RESTful:`/${ttQmAbnormalId}`   
            })

            if(code==200){
                this.bufferRow=data

                // 图片预览 11
                if(data.initiatePath){
                    this.bufferFileListPreview=data.initiatePath.split(',').map(o=>Object.assign({url:o}))
                }


                this.$nextTick(()=>{
                    this.initRepairman()
                })

            }


        },
        // 转发到
        async initRepairman(key=''){
            // const {data=[]}=await RepairmanHTTP()
            // this.selectOption=data.map(o=> Object.assign({text:`${o.userName}-${o.nickName}`,value:o.userName}))
            

            const {bufferRow}=this
            const {code,data=[]}= await httpHandle({
                // url:'/iiot/abnormalPrincipal/listAbnormalPrincipalForSelect',
                url:'/system/user/list',
                method:"get",
                url_params:{
                    // pageNum:1,
                    // pageSize:10,          
                    // noOrName:key
                    userKey:key,  //  模糊查询
                    // tmBasAbnormalTypeId: bufferRow.tmBasAbnormalTypeId  // 异常类型  主表信息里面取出来
                }

            }) 

            if(code==200){
                this.selectOption=data.map(o=>Object.assign({
                    text:`${o.userName}-${o.nickName}`,
                    value:o.userName
                })).splice(0,100)
            }
        
        
        },
        // 转发到  查询
        userSearchChange(key){
            this.initRepairman(key)
        },
        // 确认 指派
        async forwardHandle(){
            const {bufferRow}=this
            const {pageAction}=this.$route.query



            if(!this.explain.trim()){
                showFailToast("指派说明必填！")
                return
            }

            if(!this.user){
                showFailToast("指派到必填！")
                return
            }

            const _json={
                ...bufferRow,  // 行数据
                appointDesc: this.explain, /** 指派说明*/
                appointRemark: this.remark,/**备注*/
                appointBy: this.user   /** 指派到*/
            }

            const {code,data={}}= await httpHandle({
                url:'/iiot/abnormal/appoint',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")

                if( pageAction==2 ){
                    this.$router.push({
                        path:'/anomalyInitiate/index/appointIndex', 
                        query:{ }
                    }) 
                }else{
                    this.$router.push({
                        path:'/anomalyInitiate/index', 
                        query:{ }
                    }) 
                }

            }
        },
        // 驳回
        async rejectHandle(){
            const {bufferRow}=this
            const {pageAction}=this.$route.query



            if(!this.rejectReason.trim()){
                showFailToast("驳回原因必填！")
                return
            }

            const _json={
                ...bufferRow,   /** 所有 详情数据  */
                rejectReason: this.rejectReason   /** 退回原因 */
            }

            const {code,data={}}= await httpHandle({
                url: '/iiot/abnormal/reject',
                method: "post",
                payload: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")

                if( pageAction==2 ){
                    this.$router.push({
                        path:'/anomalyInitiate/index/appointIndex', 
                        query:{ }
                    }) 
                }else{
                    this.$router.push({
                        path:'/anomalyInitiate/index', 
                        query:{ }
                    }) 
                }
            }
        },
    },
  }
</script>