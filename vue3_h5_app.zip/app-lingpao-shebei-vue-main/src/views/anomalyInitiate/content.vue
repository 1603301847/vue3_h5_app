<template>
    <span>
        <AppBarPage>
        </AppBarPage>





        <!-- <div style="height:12px;"></div> -->


        <div class="eror-content-steps-container">
            <van-steps direction="vertical" :active="active" active-color="#07c160">
                <van-step v-for="(o,i) in steapList" :key="i">
                    <p class="title text">{{ o.title }}</p>
                    <p class="user text">{{ o.user }}</p>
                    <p class="time text">{{ o.time }}</p>
                    <p class="remark text">{{ o.remark }}</p>

                    <UploaderImageComponents 
                        v-if="o._bufferFileList.length"
                        v-model="o._bufferFileList"
                        preview
                    />
                </van-step>
            </van-steps>
        </div>

        <div style="height:52px;"></div>

    </span>
</template>
<script>

    import AppBarPage from '@/components/AppBar.vue'  // 异常处理 异常关闭
    import {httpHandle} from '@/http/http'  // api
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import { showSuccessToast,showFailToast } from 'vant'

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents
    },
    data: () => ({

        active:0,
        steapList:[]

    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmAbnormalId}=this.$route.query


            const {code,data=[]}= await httpHandle({
                url:'/iiot/abnormalDetail/list',
                method:"get",
                url_params:{
                    ttQmAbnormalId: ttQmAbnormalId
                }
            })

            if(code==200 && data.length){

                this.steapList=data.map(o=>{

                    var _textNew=""
                    var _operatePath=o.operatePath||''

                    // _operatePath=""
                    if( o.operateType=='1' || o.operateType=='5' ){
                        _textNew=o.abnormalDesc||''
                    }

                    if( o.operateType=='2' ){
                        _textNew=o.retransmissionDesc||''
                    }

                    if( o.operateType=='3' ){
                        _textNew=o.appointDesc||''
                    }

                    if( o.operateType=='4' ){
                        _textNew=o.manageDesc||''
                    }

                    if( o.operateType=='6' || o.operateType=='8' ){
                        _textNew=o.rejectReason||''
                    }

                    if( o.operateType=='7' ){
                        _textNew=o.closeAppraise||''
                    }


                    var _newJson=Object.assign({
                        title: o.operateTypeName,   // 标题
                        user: o.operateBy,    // 操作人
                        time: o.operateTime,    // 时间
                        remark: `${o.operateTypeName}描述: ${_textNew}`,  // 说明
                        _bufferFileList: _operatePath?_operatePath.split(',').map(o=>Object.assign({url:o})):[],   // 图片
                        // aaa: o.abnormalDesc
                    })

                    return _newJson
                })

                this.active=(data.length-1)
            }


        },

    },
  }
</script>

<style lang="scss">
    .eror-content-steps-container{
        padding: 12px 12px;
        .van-badge__wrapper.van-icon.van-icon-checked{
            font-size: 26px;
            margin-top: 12px;
        }
        p.text.title{
            color: rgba(0,0,0,0.92);
            font-size: 16px;
            font-weight: bold;
            padding-left: 2px !important;
            margin-bottom: 6px;
        }

        p.text{
            margin-top: 4px;
            padding-left: 12px;
            color: rgba(0,0,0,0.87);
            font-size: 14px;

            word-wrap: break-word;
        }
    }
</style>