<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">异常发起信息流水</span>
                </v-col>
                <v-col cols="5">
                    <p class="font-weight-medium text-truncate text-center text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">异常类型属性:</p>
                </v-col>
                <v-col cols="7">
                    <p class="text-truncate font-weight-light">{{ bufferRow.abnormalTypeName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">紧急程度:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light" style="color:#00E5FF;">{{ bufferRow.urgentDegreeName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常类型:</span>
                    <span class="font-weight-light">{{ bufferRow.abnormalName }}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常内容:</span>
                    <span class="font-weight-light">{{ bufferRow.contentName }}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常描述:</span>
                    <span class="font-weight-light">{{ bufferRow.abnormalDesc }}</span>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品序列号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.ttPpOrderSnId }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品名称:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.partName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">异常地点:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.abnormalPlace }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">设备型号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ (bufferRow.equipmentNo||'') + '-' + (bufferRow.equipmentName||'') }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiateBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiateTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">发起联系方式:</p>
                </v-col>
                <v-col cols="7">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiatePhone }}</p>
                </v-col>
            </v-row>


            <UploaderImageComponents 
                v-model="bufferFileListPreview"
                preview
            />


        </v-sheet>
        <div style="height:6px;"></div>
        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-share" size="16" color="indigo"></v-icon>
                    <span class="font-weight-medium">异常转发信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p class="font-weight-medium text-truncate text-center text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo  }}</p> -->
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light text">
                        <span class="font-weight-medium">转发说明:</span>
                        <span style="color:#00E5FF;">{{ bufferRow.retransmissionDesc }}</span>
                    </p>
                </v-col>
            </v-row>


            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">转发到:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.retransmissionBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">转发时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.retransmissionTime }}</p>
                </v-col>
            </v-row>
        </v-sheet>
        <div style="height:6px;"></div>
        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-send" size="16" color="warning"></v-icon>
                    <span class="font-weight-medium">异常指派信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p class="font-weight-medium text-truncate text-center text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo  }}</p> -->
                </v-col>
            </v-row>


            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light text">
                        <span class="font-weight-medium">指派说明:</span>
                        <span style="color:#00E5FF;">{{ bufferRow.appointDesc }}</span>
                    </p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">指派到:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.appointBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">指派时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.appointTime }}</p>
                </v-col>
            </v-row>
        </v-sheet>
        <div style="height:6px;"></div>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-alert-circle" size="16" color="error"></v-icon>
                    <span class="font-weight-medium">异常处理信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>

            <SelectComponents 
                v-model="reason"
                label="异常原因"
                required
                showSearch
                :option="reasonSelectOption"
                @onChange="reasonSelectChange"
                @onSearchChange="reasonSelectSearchChange"

            />

            <SelectComponents 
                v-model="measures"
                ref="select33"
                showSearch
                label="处理措施"
                required
                :option="measuresSelectOption"
                @onSearchChange="measuresSelectSearchChange"

            />



   
            <van-field v-model="remark" placeholder="请输入" autocomplete="off" label="处理描述" required=""  />

            <v-row no-gutters>
                <v-col cols="8">
                    <van-field v-model="time" placeholder="请输入" autocomplete="off" label="影响时长" type="number" required />

                </v-col>
                <v-col cols="4">
                    <p style="margin-top:9px;">分钟</p>
                </v-col>
            </v-row>

            <UploaderImageComponents 
                v-model="bufferFileList"
            />


        </v-sheet>

        <v-sheet elevation="2" rounded class="custem-card">
            <van-field v-model="rejectReason" placeholder="请输入" label="退回原因" autocomplete="off" required />
        </v-sheet>

        <div style="height:6px;"></div>
        <v-row no-gutters>
            <v-col cols="6" class="text-center">
                <v-btn @click="rejectHandle" color="error" >
                    退回
                </v-btn>
            </v-col>
            <v-col cols="6" class="text-center">
                <v-btn @click="forwardHandle"  color="primary">
                    确认处理
                </v-btn>
            </v-col>
        </v-row>
        <div style="height:36px;"></div>



        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round 
            closeable
        >
            <div>
                <p style="font-size: 18px;padding: 8px 0px 8px 6px;">是否直接关闭异常?</p>
                <!-- <div style="height:12px"></div> -->
                <van-field v-model="value111" required readonly placeholder="请输入" autocomplete="off" label="影响时长:" />
                <van-field v-model="value222" type="number" required placeholder="请输入" autocomplete="off" label="影响台套:" />


                <div style="height:12px;"></div>
                <v-row no-gutters style="padding: 0px 6px;">
                    <v-col cols="5" class="text-center">
                        <v-btn @click="close2(1)">
                            取消
                        </v-btn>
                    </v-col>
                    <v-col cols="2" class="text-center"></v-col>
                    <v-col cols="5" class="text-center">
                        <v-btn
                            color="primary"
                            @click="close2(2)"
                        >
                            确认
                        </v-btn>
                    </v-col>
                </v-row>

                <div style="height: 22px;"></div>
            </div>
        </van-popup>

    </span>
</template>
<script>

    import AppBarPage from '@/components/AppBar.vue'  // 异常处理 异常处理
    import {httpHandle} from '@/http/http'  // api
    import {RepairmanHTTP} from '@/http/equipment/repairs'   // api
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import SelectComponents from '@/packages/Select.vue'

    import { showSuccessToast,showFailToast,showConfirmDialog } from 'vant'

    import moment from "moment"

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents,
        SelectComponents
    },
    data: () => ({
        showPicker:false,
        value111:"",
        value222:"1",
        closeObject:{},  // 直接关闭对象

        bufferRow:{},  // 行数据

        fileList:[
            // { url: 'https://fastly.jsdelivr.net/npm/@vant/assets/leaf.jpeg' },
        ],  // 图片
        bufferFileListPreview:[],   // 图片预览
        bufferFileList:[],  // 缓存图片

        reason:"",            // 异常原因
        reasonSelectOption:[],    // 异常原因 数据

        measures:"",            // 处理措施
        measuresSelectOption:[],    // 处理措施 数据

        remark:"",   // 描述
        time:"",         // 影响时长

        rejectReason:"",   // 退回原因

    }),
    created(){
        this.initFunc()


        
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmAbnormalId}=this.$route.query

            // 

            const {code,data={}}= await httpHandle({
                url:'/iiot/abnormal',
                method:"get",
                url_RESTful:`/${ttQmAbnormalId}`   
            })

            if(code==200){
                this.bufferRow=data

                this.time=data.manageDuration||"0" // 影响时长

                // 图片预览
                if(data.initiatePath){
                    this.bufferFileListPreview=data.initiatePath.split(',').map(o=>Object.assign({url:o}))
                }

                this.$nextTick(()=>{
                    this.reasonHTTP()   // 异常原因
                    this.measuresHTTP()  // 处理措施
                })

            }


        },
        // 异常原因
        async reasonHTTP(text=""){
            const {bufferRow}=this


            const {code,data=[]}= await httpHandle({
                url:'/iiot/abnormalReason/listAbnormalReasonForSelect',
                // url:'/iiot/abnormalMeasures/list',
                // url:'/iiot/abnormalReason/list',
                method:"get",
                url_params:{
                    reasonKey:text,
                    tmBasAbnormalTypeId: bufferRow.tmBasAbnormalTypeId,

                }

            }) 

            if(code==200){
                this.reasonSelectOption=data.map(o=>Object.assign({
                    text:o.reasonNo+o.reasonName,
                    value:o.tmBasReasonId
                }))
            }  
        },
        // 异常原因模糊查询
        reasonSelectSearchChange(text){
            this.reasonHTTP(text)
        },
        // 异常原因 切换
        reasonSelectChange(value){
            // // console.log(value)

            // this.measures=""
            // this.$refs.select33 && this.$refs.select33.reset()

            // this.$nextTick(()=>{
            //     this.measuresHTTP("")  // 处理措施
            // })

        },
        // 处理措施
        async measuresHTTP(text=""){
            const {bufferRow}=this

            // 展示  measuresNo + measuresName   值  tmBasAbnormalMeasuresId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/abnormalMeasures/list',
                method:"get",
                url_params:{
                    enabled: "1",
                    tmBasAbnormalTypeId: bufferRow.tmBasAbnormalTypeId,

                    // pageNum:1,
                    // pageSize:10,          
                    // measuresNo:""
                    measuresKey:text
                }

            }) 

            if(code==200){
                this.measuresSelectOption=data.map(o=>Object.assign({
                    text:o.measuresNo +o.measuresName,
                    value:o.tmBasAbnormalMeasuresId
                }))
            } 
        },
        // 处理措施  模糊查询
        measuresSelectSearchChange(text){
            this.measuresHTTP(text)  // 处理措施

        },
        // 确认 处理
        async forwardHandle(){
            const {bufferRow}=this
            const {pageAction}=this.$route.query


            if(!this.reason){
                showFailToast("异常原因必填！")
                return
            }
            if(!this.measures){
                showFailToast("处理措施必填！")
                return
            }

            if(!this.remark.trim()){
                showFailToast("处理描述必填！")
                return
            }

            if(this.time==""){
                showFailToast("影响时长必填！")
                return
            }


            const _json={
                ...bufferRow,  // 行数据
                manageCause: this.reason, /** 异常原因*/
                tmBasAbnormalMeasuresId: this.measures,/**处理措施*/
                manageDesc: this.remark,   /** 处理描述*/
                manageDuration: Number(this.time),   // 异常影响时长
                managePath: this.bufferFileList.map(o=>o.url).join()  // 图片

            }

            this.value111=this.time
            this.showPicker=true
            this.closeObject=_json

            // showConfirmDialog({
            //     title: '系统提示!',
            //     message:'是否直接关闭异常?',
            // })
            // .then(async()=>{
            //     // 直接关闭
            //     const {code,data={}}= await httpHandle({
            //         url:'/iiot/abnormal/manage',
            //         method: "post",
            //         payload: Object.assign(_json,{
            //             isClose:'Y'
            //         }) 
            //     })

            //     if(code==200){
            //         showSuccessToast("提交成功！")

            //         if( pageAction==2 ){
            //             this.$router.push({
            //                 path:'/anomalyInitiate/index/disposeIndex', 
            //                 query:{ }
            //             }) 
            //         }else{
            //             this.$router.push({
            //                 path:'/anomalyInitiate/index', 
            //                 query:{ }
            //             }) 
            //         }


            //     }
            // })
            // .catch(async() => {
            //     // 不 直接关闭
            //     const {code,data={}}= await httpHandle({
            //         url:'/iiot/abnormal/manage',
            //         method: "post",
            //         payload:_json
            //     })

            //     if(code==200){
            //         showSuccessToast("提交成功！")

            //         if( pageAction==2 ){
            //             this.$router.push({
            //                 path:'/anomalyInitiate/index/disposeIndex', 
            //                 query:{ }
            //             }) 
            //         }else{
            //             this.$router.push({
            //                 path:'/anomalyInitiate/index', 
            //                 query:{ }
            //             }) 
            //         }


            //     }
            // });

  

        },
        // 是否直接关闭
        async close2(active){
            const {bufferRow}=this
            const {pageAction}=this.$route.query

            const _json={
                ...this.closeObject
            }

            // 取消 

    
            // 确定
            if(active==2){

                _json.isClose='Y'
                _json.close_sets=Number(this.value222)

                if(Number(this.value222)<1){
                    showFailToast("影响台套必须大于等于1！")
                    return
                }

            }

            // console.log(_json)
            // return
            const {code,data={}}= await httpHandle({
                url:'/iiot/abnormal/manage',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")

                if( pageAction==2 ){
                    this.$router.push({
                        path:'/anomalyInitiate/index/disposeIndex', 
                        query:{ }
                    }) 
                }else{
                    this.$router.push({
                        path:'/anomalyInitiate/index', 
                        query:{ }
                    }) 
                }
            }

        },
        // 驳回
        async rejectHandle(){
            const {bufferRow}=this
            const {pageAction}=this.$route.query


            if(!this.rejectReason.trim()){
                showFailToast("驳回原因必填！")
                return
            }

            const _json={
                ...bufferRow,   /** 所有 详情数据  */
                rejectReason: this.rejectReason   /** 退回原因 */
            }

            const {code,data={}}= await httpHandle({
                url: '/iiot/abnormal/reject',
                method: "post",
                payload: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")

                if( pageAction==2 ){
                    this.$router.push({
                        path:'/anomalyInitiate/index/disposeIndex', 
                        query:{ }
                    }) 
                }else{
                    this.$router.push({
                        path:'/anomalyInitiate/index', 
                        query:{ }
                    }) 
                }
            }
        },
    },
  }
</script>