<template>
    <span>
        <AppBarPage>
        </AppBarPage>



        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">异常发起信息流水</span>
                </v-col>
                <v-col cols="5">
                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">异常类型属性:</p>
                </v-col>
                <v-col cols="7">
                    <p class="text-truncate font-weight-light">{{ bufferRow.abnormalTypeName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">紧急程度:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light" style="color:#00E5FF;">{{ bufferRow.urgentDegreeName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">是否停线:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.isLineStopName   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常类型:</span>
                    <span class="font-weight-light">{{ bufferRow.abnormalName }}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常内容:</span>
                    <span class="font-weight-light">{{ bufferRow.contentName }}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">异常描述:</span>
                    <span class="font-weight-light">{{ bufferRow.abnormalDesc }}</span>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品序列号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.ttPpOrderSnId }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品名称:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.partName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">异常地点:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.abnormalPlace }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">设备型号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ (bufferRow.equipmentNo||'') + '-' + (bufferRow.equipmentName||'') }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiateBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发起时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiateTime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="5">
                    <p class="font-weight-medium text">发起联系方式:</p>
                </v-col>
                <v-col cols="7">
                    <p class="text-truncate font-weight-light">{{ bufferRow.initiatePhone }}</p>
                </v-col>
            </v-row>

            <UploaderImageComponents 
                v-model="bufferFileListPreviewInitiatePath"
                preview
            />

        </v-sheet>
        <div style="height:6px;"></div>
        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-share" size="16" color="indigo"></v-icon>
                    <span class="font-weight-medium">异常转发信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ "YC202302140001" }}</p> -->
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light text">
                        <span class="font-weight-medium">转发说明:</span>
                        <span style="color:#00E5FF;">{{ bufferRow.retransmissionDesc }}</span>
                    </p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">转发到:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.retransmissionBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">转发时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.retransmissionTime }}</p>
                </v-col>
            </v-row>
        </v-sheet>
        <div style="height:6px;"></div>
        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-send" size="16" color="warning"></v-icon>
                    <span class="font-weight-medium">异常指派信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ "YC202302140001" }}</p> -->
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light text">
                        <span class="font-weight-medium">指派说明:</span>
                        <span style="color:#00E5FF;">{{ bufferRow.appointDesc  }}</span>
                    </p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">指派到:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.appointBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">指派时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.appointTime }}</p>
                </v-col>
            </v-row>
        </v-sheet>
        <div style="height:6px;"></div>
        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-alert-circle" size="16" color="error"></v-icon>
                    <span class="font-weight-medium">异常处理信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ "YC202302140001" }}</p> -->
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light text">
                        <span class="font-weight-medium">处理描述:</span>
                        <span style="color:#00E5FF;">{{ bufferRow.manageDesc  }}</span>
                    </p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">处理措施:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.measuresName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">异常原因:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{bufferRow.reasonNO}}-{{bufferRow.reasonName}}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">异常影响时长:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.manageDuration }} 分钟</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">异常处理人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.manageBy }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">处理时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.manageTime }}</p>
                </v-col>
            </v-row>

            <UploaderImageComponents 
                v-model="bufferFileListPreviewManagePath"
                preview
            />

        </v-sheet>

        <div style="height:6px;"></div>
        <v-sheet v-if="['index','search'].includes(pageType)" elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-close-circle" size="16" color="error"></v-icon>
                    <span class="font-weight-medium">异常关闭信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ "YC202302140001" }}</p> -->
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light text">
                        <span class="font-weight-medium">关闭时影响时长:</span>
                        <span>{{ bufferRow.closeDuration  }} 分钟</span>
                        
                    </p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">影响台套:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.closeSets  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">关闭人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{bufferRow.closeBy}}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">关闭时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.closeTime  }} </p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <span class="font-weight-medium text">评价: </span>
                    <span>{{ bufferRow.closeAppraise }}</span>
                </v-col>
            </v-row>
        </v-sheet>

        <div style="height:6px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue' // 异常处理 详情
    import {httpHandle} from '@/http/http'  // api
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import { showSuccessToast,showFailToast } from 'vant'

    import moment from "moment"

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据
        pageType:"",

        bufferFileListPreviewInitiatePath:[],   // 图片预览 1
        bufferFileListPreviewManagePath:[],   // 图片预览 2

    }),
    created(){
        this.initFunc()

    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {ttQmAbnormalId,pageType=''}=this.$route.query

            this.pageType=pageType
            // 
            const {code,data={}}= await httpHandle({
                // url:'/iiot/abnormal',
                url:'/iiot/abnormal/getInfoByShow',
                method:"get",
                url_RESTful:`/${ttQmAbnormalId}`   
            })

            if(code==200){
                this.bufferRow=data

                // 图片预览 11
                if(data.initiatePath){
                    this.bufferFileListPreviewInitiatePath=data.initiatePath.split(',').map(o=>Object.assign({url:o}))
                }

                // 图片预览 22
                if(data.managePath){
                    this.bufferFileListPreviewManagePath=data.managePath.split(',').map(o=>Object.assign({url:o}))
                }

            }


        },

    },
  }
</script>