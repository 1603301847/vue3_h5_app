<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <!-- <v-btn @click="sponsorHandle" color="warning">
            发起异常
        </v-btn> -->

        <div class="v-window-item-table">
            <!--  url="/iiot/abnormal/list" -->
            <TableComponents
                ref="table1"
                url="/iiot/abnormal/list"
                :params="{
                    abnormalState: 20,
                    queryType:20,
                    ...pageSearchConfig
                }"
                :showSearchBtn="true"
                @searchClick="searchClick"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="5">
                                <span class="font-weight-medium">异常流水</span>
                            </v-col>

                            
                            <v-col cols="6">
                                <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ formatStatus(props.items)  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.abnormalNo  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-light">
                                    <span class="font-weight-medium text">异常类型:</span>
                                    <span>{{ props.items.abnormalName   }}</span>
                                </p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="5">
                                <p class="font-weight-medium text">异常类型属性:</p>
                            </v-col>
                            <v-col cols="7">
                                <p class="text-truncate font-weight-light">{{ props.items.abnormalTypeName   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">紧急程度:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" style="color:#00E5FF;">{{ props.items.urgentDegreeName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">是否停线:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.isLineStopName   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">异常内容:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.contentName   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">发起时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.initiateTime }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4" class="text-left">
                                <v-btn  v-if="props.items.abnormalState=='40'" @click="closeClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">异常关闭</v-btn>
                                <v-btn v-if="props.items.abnormalState=='30'" @click="disposeClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">异常处理</v-btn>
                                <v-btn v-if="props.items.abnormalState=='20'" @click="appointClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">异常指派</v-btn>
                                <v-btn v-if="props.items.abnormalState=='10'" @click="transpondClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">异常转发</v-btn>
                                
                            
                            </v-col>
     
                            <v-col cols="4" class="text-center">
                                <v-btn @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>
                            </v-col>

                            <v-col cols="4" class="text-right">
                                <v-btn @click="nodeDetail(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">节点详情</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>



        <SearchPage 
            ref="searchPage" 
            :hideStatus="false"
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'

    import  SearchPage from './search.vue' 




    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast } from 'vant';

  export default {
    components:{
        AppBarPage,
        TableComponents,
        SearchPage,

    },
    data: () => ({
        searchParamas:{},  // 查询参数
        pageSearchConfig:{},  // 查询信息 

    }),
    created(){
        // 判断 状态
    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 详情
        async detailClick(props){
            const {items}=props
            
            
            this.$router.push({
                path:'/anomalyInitiate/detail', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }
            }) 

        }, 
        // 处理 状态
        formatStatus(items){


            let _text=""

            switch (items.abnormalState) {
                case '10':  
                    _text="待转发"
                    break;
                case '20':  
                    _text="待指派"
                    break;   
                case '30':  
                    _text="待处理"
                    break;    
                case '40':  
                    _text="待关闭"
                    break;   
                case '90':  
                    _text="已关闭"
                    break; 
                case '60':  
                    _text="已驳回"
                    break;      
                default:
                    break;
            }

            return _text
     


        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}
            
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)    
            })
        },
        // 发起异常
        sponsorHandle(){
            
            this.$router.push({
                path:'/anomalyInitiate/sponsor', 
                query:{ }
            })    
        },
        // 异常转发
        transpondClick(props){
            const {items}=props
            
            // 待转发
            this.$router.push({
                path:'/anomalyInitiate/transpond', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }

            })       
        },
        // 异常指派
        appointClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/appoint', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId, pageAction:2 }

            }) 
        },
        // 异常处理
        disposeClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/dispose', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }

            }) 
        },
        // 异常关闭
        closeClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/close', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }

            }) 
        },
        // 节点详情
        nodeDetail(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/content', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }
            }) 
        },


    },
  }
</script>