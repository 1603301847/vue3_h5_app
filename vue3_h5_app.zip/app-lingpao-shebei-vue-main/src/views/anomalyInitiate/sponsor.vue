<template>
    <span>
        <AppBarPage>
        </AppBarPage>


        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-access-point" size="16" color="indigo"></v-icon>
                    <span class="font-weight-medium">通用信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>




            <SelectComponents 
                v-model="property"
                label="异常类型属性"
                required
                ref="select11"
                :option="selectPropertyOption"
                @onChange="selectPropertyChange"
            />

            <SelectComponents 
                v-model="type"
                ref="selectType"
                label="异常类型"
                showSearch
                :option="typeSelectOption"
                :forbidShow="true"
                @onFieldClick="typeFieldClick"
                @onChange="selectTypeChange"
                @onSearchChange="typeSearchChange"

                required
            />

            <SelectComponents 
                v-model="content"
                ref="selectContent"
                label="异常内容"
                :forbidShow="true"
                showSearch
                :option="contentSelectOption"
                @onFieldClick="contentFieldClick"
                @onSearchChange="contentSearchChange"
                required
            />
   

            <van-field
                v-model="fieldValue"
                is-link
                readonly
                label="工厂节点"
                placeholder="请选择工厂节点"
                type="textarea"
                required
                autocomplete="off"
                @click="show = true"
            />
            <van-popup v-model:show="show" round position="bottom">
                <v-btn
                    block
                    color="cyan"
                    elevation="0"
                    style="border-radius: 0px;"
                    @click="()=> show=false"
                >
                    确定
                </v-btn>
                <van-cascader
                    title="请选择工厂节点"
                    :options="options"
                    active-color="#4CAF50"
                    :field-names="{text:'nodeLevelName',value:'tmBasNodeLevelId',children:'children'}"
                    @close="show = false"
                    @change="onFinish"
                />
            </van-popup>

            <v-row no-gutters class="text">
                <v-col cols="4" style="padding-left:5px">
                    <p class="font-weight-medium text"><span style="color:#ee0a24">*</span>是否停线:</p>
                </v-col>
                <v-col cols="4" style="text-align:right;">
                    <van-radio-group v-model="_switch11" direction="horizontal">
                        <van-radio name="1" checked-color="#4CAF50" shape="square">是</van-radio>
                        <van-radio name="0" checked-color="#4CAF50" shape="square">否</van-radio>
                    </van-radio-group>
                </v-col>
        </v-row>




            <SelectComponents 
                v-model="urgency"
                ref="select4"
                label="紧急程度"
                :option="urgencySelectOption"
                required
            />

            <van-field v-model="place" autocomplete="off" placeholder="请输入" label="地点" />

            
            <div style="padding: 0px 12px;">
                <ScanBarComponents 
                    placeholder="扫描或输入产品序列号"
                    @searchClick="barSearchClick"
                />
                <p v-if="serialNumberLable">查询结果: {{ serialNumberLable }}</p>
            </div>


        </v-sheet>
        <div style="height:6px;"></div>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-dots-vertical" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">其他信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>

            <SelectComponents 
                v-model="equipment"
                ref="select7"
                label="设备信息"
                showSearch
                :option="equipmentSelectOption"
                @onSearchChange="equipmentSearchChange"
                
            />


            <SelectComponents 
                v-model="product"
                ref="select8"
                label="产品信息"
                showSearch
                required
                :option="productSelectOption"
                @onSearchChange="productSearchChange"
                
            />

        </v-sheet>
        <div style="height:6px;"></div>
        
        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-alert-circle" size="16" color="warning"></v-icon>
                    <span class="font-weight-medium">异常信息</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>
 
            <van-field v-model="abnormalDescription" placeholder="请输入" autocomplete="off" type="textarea" label="异常描述" required />
            <van-field v-model="remark" placeholder="请输入" autocomplete="off" type="textarea" label="备注" />


            <UploaderImageComponents 
                v-model="bufferFileList"
            />


        </v-sheet>



        <v-row no-gutters>

            <v-col cols="12" class="text-center">
                <v-btn @click="submitHandle" color="primary" block>
                    确认发起
                </v-btn>
            </v-col>
        </v-row>
        <div style="height:36px;"></div>


    </span>
</template>
<script>

    import AppBarPage from '@/components/AppBar.vue'  // 异常处理 异常发起
    import {httpHandle} from '@/http/http'  // api
    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import {FormatTree} from '@/utils/data'   // utils
    import SelectComponents from '@/packages/Select.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'


    import { showSuccessToast,showFailToast } from 'vant'
    import moment from "moment"


  export default {
    components:{
        AppBarPage,
        UploaderImageComponents,
        ScanBarComponents,
        SelectComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据

        _switch11:"",


        fileList:[
            // { url: 'https://fastly.jsdelivr.net/npm/@vant/assets/leaf.jpeg' },
        ],  // 图片
        bufferFileList:[],  // 缓存图片

        property:"",  // 异常类型属性
        selectPropertyOption:[],  // 异常类型属性 数据

        type:"",   // 异常类型
        typeSelectOption:[],   // 异常类型数据

        content:"",  // 异常内容
        contentSelectOption:[],   // 异常内容 数据


        show:false,   // 工厂 show
        fieldValue:"",  // 工厂显示值
        options:[],    // 工厂 数据
        factoryID:"",   // 工厂选中ID

        urgency:"",  // 紧急
        urgencySelectOption:[],   // 紧急 数据

        place:"",    // 地点


        serialNumber:"",   // 产品数列号 ID
        serialNumberLable:"",   // 产品数列号 显示值



        equipment:"",   // 设备信息
        equipmentSelectOption:[],   // 设备信息 数据


        product:"",   // 产品信息
        productSelectOption:[],   // 产品信息 数据

        abnormalDescription:"",   // 异常描述
        remark:"",    // 备注

    }),
    created(){
        this.initFunc()
        // this.getTypeHttp()  // 异常类型

        this.getContentHttp()  // 异常内容
        this.FactoryHTTP()   //  工厂数据
        this.getEquipmentHttp()  // 设备信息
        this.productHTTP()   // 产品信息

    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            // 异常类型属性
            const _selectAttribute=_bufferDictionaries["abnormal_type"]||[]    // 属性
            this.selectPropertyOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据


            // 紧急程度
            const _selectUrgent=_bufferDictionaries["urgent_degree"]||[]     
            this.urgencySelectOption=_selectUrgent.map(o=>Object.assign({text:o.lable,value:o.value}))  

            // 
            // console.log( _bufferDictionaries )
            // 工厂
            const _bufferPageDataAnomalyInitiateSponsorFactory=JSON.parse(localStorage.getItem("bufferPageDataAnomalyInitiateSponsorFactory")||"{}")
            if(_bufferPageDataAnomalyInitiateSponsorFactory.id){
                this.factoryID=_bufferPageDataAnomalyInitiateSponsorFactory.id
                this.fieldValue = _bufferPageDataAnomalyInitiateSponsorFactory.text
            }

            // 异常变更 跳转过来
            const {ttQmAbnormalId}=this.$route.query

            if(ttQmAbnormalId){
                this.editFunc(ttQmAbnormalId)
            }

        },
        // 编辑数据
        async editFunc(ttQmAbnormalId){
            const {code,data={}}= await httpHandle({
                url: `/iiot/abnormal/${ttQmAbnormalId}`,
                method: "get",
            })

            if(code==200){
                // console.log(data)


                this.property= data.abnormalType    // 异常类型属性
                this.type=data.tmBasAbnormalTypeId   // 异常类型
                this.content=data.tmBasAbnormalContentId  // 异常内容
                this.urgency= data.urgentDegree  // 紧急程度

                this._switch11=String(data.isLineStop||''),  // 是否停线


                this.place= data.abnormalPlace   // 地点
                this.serialNumber= data.ttPpOrderSnId  // 产品序列号 ID 

                this.equipment= data.tmBasAbnormalMeasuresId    // 设备信息
                this.product= data.tmBasPartId    // 产品信息

                this.abnormalDescription= data.abnormalDesc   // 异常描述
                this.remark=data.initiateRemark    // 备注

                // 图片预览 
                if(data.initiatePath){
                    this.bufferFileList=data.initiatePath.split(',').map(o=>Object.assign({url:o}))
                }
                
                // 工厂初始化
                this.factoryID=data.tmBasNodeLevelId  // 工厂节点
                this.factoryEdit(data.tmBasNodeLevelId)  // 


                this.$nextTick(()=>{
                    this.$refs.select11 && this.$refs.select11.setValue( data.abnormalType )  // 异常类型属性
                    this.$refs.select4 && this.$refs.select4.setValue( data.urgentDegree )   // 紧急程度

                })

                // 异常类型
                this.getTypeHttp({
                    abnormalAttribute: data.abnormalType
                },"",()=>{
                    this.$refs.selectType && this.$refs.selectType.setValue( data.tmBasAbnormalTypeId  ) // 异常类型
                })

                
                // 异常类容
                this.getContentHttp({
                    tmBasAbnormalTypeId:data.tmBasAbnormalTypeId  
                },"",()=>{
                    this.$refs.selectContent && this.$refs.selectContent.setValue( data.tmBasAbnormalContentId  ) // 异常内容
                })

                // 扫码序列号
                if(data.ttPpOrderSnId){
                    this.barSearchClick("",data.ttPpOrderSnId,(dataCode)=>{
                        this.serialNumberLable=dataCode['sernr']
                    })
                }


                // 设备信息
                this.getEquipmentHttp("",data.tmBasAbnormalMeasuresId,()=>{
                    this.$refs.select7 && this.$refs.select7.setValue( data.tmBasAbnormalMeasuresId  ) // 设备信息
                })

                // 产品信息
                this.productHTTP("",data.tmBasPartId,()=>{
                    this.$refs.select8 && this.$refs.select8.setValue( data.tmBasPartId ) // 产品信息
                })
            }
        },
        // 工厂编辑 初始化
        async factoryEdit(tmBasNodeLevelId){
            if(!tmBasNodeLevelId) return

            const {data=[]} = await FactoryTreeHTTP()
            const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")


            const searchParent = (map, key) => {
                let t = []
                for (let i = 0; i < map.length; i++) {
                    const e = map[i]
                    if (e.tmBasNodeLevelId === key) {
                        //若查询到对应的节点，则直接返回
                        t.push(e)
                        break
                    } else if (e.children && e.children.length !== 0) {
                        //判断是否还有子节点，若有对子节点进行循环调用
                        let p = searchParent(e.children, key)
                        //若p的长度不为0，则说明子节点在该节点的children内，记录此节点，并终止循环
                        if (p.length !== 0) {
                            p.unshift(e)
                            t = p
                            break
                        }
                    }
                }
                return t
            }  

            
            //调用函数方式
            // console.log( _tree )
            const _list= (searchParent(_tree,tmBasNodeLevelId)||[])
            this.fieldValue = _list.map((o) => o.nodeLevelName).join('/')
            
        },
        // 异常类型 过滤
        typeSearchChange(key){
            this.getTypeHttp({
                abnormalAttribute: this.property
            },key)
        },
        // 异常类型
        async getTypeHttp(option={},key='',callBack){

            // 展示  abnormalNo + abnormalName   
            // 取值  tmBasAbnormalTypeId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/abnormalType/listAbnormalTypeForSelect',
                method:"get",
                url_params:{
                    // ttQmAbnormalId:ttQmAbnormalId
                    abnormalNo:key,
                    ...option
                }

            }) 

            if(code==200){
                this.typeSelectOption=data.map(o=>Object.assign({
                    text:`${o.abnormalNo}${o.abnormalName}`,
                    value:o.tmBasAbnormalTypeId
                }))  

                this.$nextTick(()=>{
                    callBack && callBack()
                })
            }
        }, 
        // 异常类型属性切换
        selectPropertyChange(value){
       

            this.type=""  // 异常类型
            this.typeSelectOption=[]   // 异常类型数据
            this.$refs.selectType.reset()  // 重置
 
            this.content="" // 异常内容
            this.contentSelectOption=[]   // 异常内容 数据
            this.$refs.selectContent.reset()

        },
        // 异常切换
        selectTypeChange(){
            this.content="" // 异常内容
            this.contentSelectOption=[]   // 异常内容 数据
            this.$refs.selectContent.reset()
        },
        // 异常类型属性 点击
        typeFieldClick(){
            
            if(!this.property){
                showFailToast("异常类型属性未选！")
                return
            }

            this.getTypeHttp({
                abnormalAttribute: this.property
            })
            
            setTimeout(()=>{
                this.$refs.selectType.showModle()
            },600)
        },
        // 异常内容点击
        contentFieldClick(){
            if(!this.type){
                showFailToast("异常类型未选！")
                return
            }


            this.getContentHttp({
                tmBasAbnormalTypeId:this.type
            })

            setTimeout(()=>{
                this.$refs.selectContent.showModle()
            },600)
            
        },
        // 异常内容 数据
        async getContentHttp(option={},key="",callBack){

            // 展示  abnormalNo + abnormalName   
            // 取值  tmBasAbnormalTypeId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/abnormalContent/listAbnormalContentForSelect',
                method:"get",
                url_params:{
                    // ttQmAbnormalId:ttQmAbnormalId
                    contentNo: key,
                    ...option
                }

            }) 

            if(code==200){
                this.contentSelectOption=data.map(o=>Object.assign({
                    text: `${o.contentNo}${o.contentName}`,
                    value:o.tmBasAbnormalContentId
                }))  

                this.$nextTick(()=>{
                    callBack && callBack()
                })
            }
        }, 
        // 异常内容 查询
        contentSearchChange(key){
            this.getContentHttp({
                tmBasAbnormalTypeId:this.type
            },key)
        },
        async FactoryHTTP(){
            // 工厂节点数据
            const {data=[]} = await FactoryTreeHTTP()
            const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")
            this.options=_tree
        },
        // 工厂 完成
        onFinish ({ selectedOptions }){

            if(!selectedOptions.length) return

            // tmBasNodeLevelId:“465621691089092608
            let _tmBasNodeLevelId= (selectedOptions[ selectedOptions.length-1 ]||{})["tmBasNodeLevelId"]
            
            // console.log(_tmBasNodeLevelId)
            this.factoryID=_tmBasNodeLevelId
            this.fieldValue = selectedOptions.map((o) => o.nodeLevelName).join('/')


            localStorage.setItem("bufferPageDataAnomalyInitiateSponsorFactory",JSON.stringify({
                id: this.factoryID,
                text: this.fieldValue 
            }) )


        },
        // 设备信息 数据
        async getEquipmentHttp(key='',tmBasEquipmentId="",callBack){
            // 展示  equipmentNo +  equipmentName  值  tmBasEquipmentId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipment/llistEquipmentForSelect',
                method:"get",
                url_params:{
                    equipmentNo:key,
                    tmBasEquipmentId:tmBasEquipmentId
                }

            }) 

            if(code==200){
                this.equipmentSelectOption=data.map(o=>Object.assign({
                    text:`${o.equipmentNo}${o.equipmentName}`,
                    value:o.tmBasEquipmentId
                }))  

                this.$nextTick(()=>{
                    callBack && callBack()
                })
            }
        }, 
        // 设备信息 查询
        equipmentSearchChange(key){
            this.getEquipmentHttp(key)
        },
        // 产品信息 数据
        async productHTTP(key='',tmBasPartId='',callBack){
            // 展示  matnr + maktxC   值  tmBasPartId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/part/listPartForSelect',
                method:"get",
                url_params:{
                    // pageNum:1,
                    // pageSize:10,          
                    noOrName:key,
                    tmBasPartId:tmBasPartId
                }

            }) 

            if(code==200){
                this.productSelectOption=data.map(o=>Object.assign({
                    text:`${o.matnr}${o.maktxC}`,
                    value:o.tmBasPartId
                })).splice(0,100)

                this.$nextTick(()=>{
                    callBack && callBack()
                })
            }
        }, 
        // 产品信息 查询
        productSearchChange(key){
            this.productHTTP(key)
        },
        // 提交
        async submitHandle(){
            const {ttQmAbnormalId}=this.$route.query

            
            if( !this.property ){
                showFailToast('异常类型属性必填！')
                return
            }

            if( !this.type ){
                showFailToast('异常类型必填！')
                return
            }

            if( !this.content ){
                showFailToast('异常内容必填！')
                return
            }

            if( !this.factoryID ){
                showFailToast('工厂节点必填！')
                return
            }

            if( !String(this._switch11) ){
                showFailToast('是否停线必填！')
                return
            }
            

            if( !this.urgency ){
                showFailToast('紧急程度必填！')
                return
            }

            if( !this.product ){
                showFailToast('产品信息必填！')
                return
            }
            

            if( !this.abnormalDescription ){
                showFailToast('异常描述必填！')
                return
            }



            const _json={
                ttQmAbnormalId:ttQmAbnormalId||'',    // 主表ID

                abnormalType: this.property,    // 异常类型属性
                tmBasAbnormalTypeId: this.type,    // 异常类型
                tmBasAbnormalContentId: this.content,  // 异常内容
                tmBasNodeLevelId: this.factoryID,  // 工厂节点
                isLineStop: String(this._switch11),  // 是否停线

                urgentDegree: this.urgency,   // 紧急程度
                abnormalPlace: this.place,   // 地点
                ttPpOrderSnId: this.serialNumber,  // 产品序列号
                tmBasAbnormalMeasuresId: this.equipment,    // 设备信息
                tmBasPartId: this.product,   // 产品信息

                abnormalDesc: this.abnormalDescription,   // 异常描述

                initiateRemark: this.remark,    // 备注
                initiatePath: this.bufferFileList.map(o=>o.url).join()  // 图片
            }

            // console.log( _json )
            // 异常变更  | 新增
            const {code,data={}}= await httpHandle({
                url:'/iiot/abnormal',
                method: ttQmAbnormalId?"put":"post",
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.$router.push({
                    path:'/anomalyInitiate/index', 
                    query:{ }
                }) 
            }
            
        },
        // 扫码结果
        async barSearchClick(text='',ttPpOrderSnId='',callBack){

            this.serialNumber=""   // 产品数列号 ID
            this.serialNumberLable=""   // 产品数列号 显示值

            // 入参   let params = {};
            // params.sernr=key;
            // 展示  sernr   值  ttPpOrderSnId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/orderSn/listOrderSnForSelect',
                method:"get",
                url_params:{
                    sernr:text,
                    ttPpOrderSnId: ttPpOrderSnId
                }

            }) 

            if(code==200 && data.length){

                showSuccessToast("查询成功！")

                this.serialNumberLable=data[0].sernr
                this.serialNumber=data[0].ttPpOrderSnId

                this.$nextTick(()=>{
                    callBack && callBack(data[0]||{})
                })
            }else{
                showFailToast("未查询到结果！")
            }

        },
    },
  }
</script>