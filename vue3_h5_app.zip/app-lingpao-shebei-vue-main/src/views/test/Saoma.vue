<template>
    <span>
        <AppBarPage>

        </AppBarPage>

        <div>

          <button @click="aaa">11</button>

        </div>


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import { showSuccessToast,showFailToast } from 'vant';
    import { showImagePreview } from 'vant'

  export default {
    components:{
        AppBarPage
    },
    data: () => ({

    }),
    methods: {
      aaa(){
        showImagePreview([
          'https://fastly.jsdelivr.net/npm/@vant/assets/apple-1.jpeg',
          'https://fastly.jsdelivr.net/npm/@vant/assets/apple-2.jpeg',
        ]);
      }
    },
  }
</script>