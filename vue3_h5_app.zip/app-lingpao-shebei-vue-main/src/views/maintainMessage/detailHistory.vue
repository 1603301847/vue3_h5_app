<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">保养设备信息</span>
                </v-col>
                <v-col cols="6" class="text-right">
                    <v-btn @click="checksParePart" color="primary mt-1" density="compact" :rounded="0" variant="plain">备件信息</v-btn>

                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</p> -->
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">任务类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{  FormatDictionary('WB_TT',bufferRow.wbTt)['lable']  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">设备类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{  bufferRow.equipmentType  }}</p>
                </v-col>
            </v-row>


            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">保养部位:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.faultStationCn  }}</p>
                </v-col>
            </v-row> -->
            <!-- <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">保养方法:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(bufferRow.manitainContent)">{{ bufferRow.manitainContent  }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">周期:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{  FormatDictionary('WB_ST',bufferRow.wbSt)['lable']  }} </p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">计划人:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.planImplementBy  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">到期时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.expireTime  }}</p>
                </v-col>
            </v-row>

        </v-sheet>

        <!-- <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-clock-time-five" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">实施报工</span>
                </v-col>
                <v-col cols="6">
                    <p @click="addManHourFunc" class="font-weight-medium text-right text-teal-lighten-1" color="primary">添加工时</p>
                </v-col>
            </v-row>

            <van-field v-model="value1" label="实施内容" autocomplete="off" type="textarea" placeholder="请输入" required  />

        </v-sheet>    -->

        <!-- <v-sheet class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="wbWorkhours"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="6">
                                <v-icon icon="mdi-pencil-outline" size="16" color="primary"></v-icon>
                                <span class="font-weight-medium">工时 {{ props._index+1 }}</span>
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn @click="editHandle(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">编辑</v-btn>
                                <v-btn @click="deleteHandle(props)" color="red mt-1" density="compact" :rounded="0" variant="plain">删除</v-btn>

                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">维护人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.maintainBy   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">维护工时:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.actualDuration }}{{' 分钟'}}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">工作内容:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.workContent   }}</p>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </v-sheet> -->

        <p v-if="!teBasPlanMcList.length" class="font-weight-medium text">
            <v-icon
                large
                color="error"
                >
                mdi-alert
            </v-icon>
            <span style="font-size: 16px;position: relative;top: 2px;left: 4px;">无维护内容</span>
        </p>
        <v-sheet class="v-window-item-table">
            <TableComponents
                ref="table2"
                :children="teBasPlanMcList"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="5">
                                <span class="font-weight-medium">维护项目</span>
                            </v-col>
                            <v-col cols="1">
                                <!-- <p class="font-weight-medium text-truncate text-center text-teal-lighten-1" color="primary">{{ props.items.manitainItem  }}</p> -->
                            </v-col>

                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.manitainItem  }}</p>
                            </v-col>
                        </v-row>



                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">内容编号:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.manitainContentNo   }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">维护人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ bufferRow.implementBy   }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">维护项目:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.manitainItem   }}</p>
                            </v-col>
                        </v-row> -->

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">保养级别:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ FormatDictionary('WB_TT',props.items.wbTt)['lable']       }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">周期:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ FormatDictionary('WB_ST',props.items.weeks)['lable']  }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">保养部位:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.manitainSpace   }}</p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text">
                                    保养方法: {{ props.items.manitainContentName   }}
                                </p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium text">
                                    保养结果: {{ props.items.mcResult   }}
                                </p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所需辅料:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.manitainMaterial   }}</p>
                            </v-col>
                        </v-row> -->

                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">所需工具:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.manitainTool   }}</p>
                            </v-col>
                        </v-row> -->

                        <v-row no-gutters class="text">
                            <v-col cols="8">

                            </v-col>
                            <v-col cols="4" style="text-align:right;">
                                <v-switch
                                    v-model="props.items._switch"
                                    :label="props.items._switch?'合格':'不合格'"
                                    color="primary"
                                    disabled
                                    density="comfortable"
                                    style="top:-10px;left:8px;position:relative;height:40px;display:block;height:48px;width:104px;"
                                    ></v-switch>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <UploaderImageComponents 
                                    v-if="props.items.pictureFlag=='1'"
                                    v-model="props.items._bufferFileList"
                                    preview
                                />
                            </v-col>
                        </v-row>


                    </v-card>
                </template>
            </TableComponents>
        </v-sheet>

        <div style="height: 12px;"></div>

        <!-- <v-row no-gutters class="global-botom-btn-box text-center">
            <v-col cols="4">
                <v-btn
                    color="warning"
                    @click="onRepairs"
                >
                    设备报修
                </v-btn>
            </v-col>
            <v-col cols="4" class="text-center">
                <v-btn
                    color="#00E5FF"
                    @click="onReceiveFunc"
                >
                    备件领用
                </v-btn>
            </v-col>
            <v-col cols="4" class="text-center">
                <v-btn

                    color="primary"
                    @click="onSubmit"
                >
                    确认
                </v-btn>
            </v-col>
        </v-row> -->


        <!-- <div style="height: 60px;"></div> -->

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'


    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant'
    import { showDialog  } from 'vant'

  export default {
    components:{
        AppBarPage,
        UploaderImageComponents,
        TableComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据

        value1:"",  // 实施内容

        wbWorkhours:[],  // 工时
        teBasPlanMcList:[],   // 维护内容
    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {row="{}"}=this.$route.query
            const _row=JSON.parse(row)

            this.bufferRow=_row
            // this.wbWorkhours=_row.wbWorkhours

            // console.log(_row)
            this.teBasPlanMcList=(_row.teBasPlanMcList||[]).map((o,i)=> Object.assign(o,{
                _switch: o.manitainResult=='1'?true:false,
                _index:i+1,
                _bufferFileList: o.filePath ? o.filePath.split(',').map(o=>Object.assign({url:o})) :[]
            }) )

            this.$nextTick(()=>{
                this.$refs.table2.initFunc()
            })

            // console.log(this.bufferRow)
            // const a=  this.bufferRow.ttWbWorkhoursid

            // const {code}= await httpHandle({
            //     url:"/iiot/workhours/"+a,
            //     method:'get'
            // })
        },
        // 提交
        async onSubmit(){
            const {value1,bufferRow,teBasPlanMcList}=this

            // if(!value1.trim()){
            //     showFailToast("实施内容必填!")
            //     return
            // }
            
            // console.log( this.teBasPlanMcList )           
            // managePath: this.bufferFileList.map(o=>o.url).join()  // 图片

            const _newList=this.teBasPlanMcList.filter(o=>(o.pictureFlag=='1' && !o._bufferFileList.length))
            
            if(_newList.length){
                showFailToast(`序号: ${_newList.map(o=>o._index).slice()} 图片必传！`)
                return
            }


            const _json={
                equipmentName: bufferRow.equipmentName,  // 当前数据equipmentName字段
                expireTime: bufferRow.expireTime,  // 当前数据expireTime字段
                faultStationCn: bufferRow.faultStationCn,  // 当前数据faultStationCn字段
                manitainContent: bufferRow.manitainContent,  // 当前数据manitainContent字段
                implementContent: value1, // 输入框,/*实施内容*/
                planImplementBy: bufferRow.planImplementBy, // 当前数据planImplementBy字段
                wbSt: bufferRow.wbSt,  // 当前数据wbSt字段
                wbTt: bufferRow.wbTt,  // 当前数据wbTt字段
                tmBasEquipmentId: bufferRow.tmBasEquipmentId, // 当前数据tmBasEquipmentId 字段
                machineType: bufferRow.machineType, // 当前数据machineType字段
                teWbMainTaskId: bufferRow.teWbMainTaskId, // 当前数据teWbMainTaskId字段
                tmWbMainPlanId: bufferRow.tmWbMainPlanId, // 当前数据tmWbMainPlanId字段
                wbMais: bufferRow.wbMais,  // 当前数据wbMais 字段 IO

                teBasPlanMcList: this.teBasPlanMcList.map(o=>Object.assign(o,{
                    manitainResult:o._switch?'1':'0',
                    filePath: o._bufferFileList.map(o=>o.url).join()  
                })),   // 维护内容
            }

            // console.log(_json)
            // return  
            const {code,data={}}= await httpHandle({
                url:'/iiot/mainTask/wbJob',
                method: "post",
                payload:_json
            })


            if(code==200){
                showSuccessToast('提交成功！')
                this.$router.push({
                    path:'/maintain/index',
                    query:{ tabs:2 }
                })
            }

        },
        // 添加工时
        addManHourFunc(){
            const {bufferRow}=this

            // console.log(bufferRow)
            this.$router.push({
                path:'/maintain/add',
                query:{ row: JSON.stringify({
                    teWbMainTaskId:bufferRow.teWbMainTaskId
                }) }
            })
        },
        // 编辑
        async editHandle(props){
            const {items}=props

            const {code,data={}}= await httpHandle({
                url:`/iiot/workhours/${items.ttWbWorkhoursId}`,
                method:'get'
            })


            if(code==200){
                this.$router.push({
                    path:'/maintain/add',
                    query:{ row: JSON.stringify(data)  }
                })
            }
        },
        // 删除
        async deleteHandle(props){
            const {items}=props

            showDialog({
                title: '删除',
                message: '删除后数据不可恢复，确认删除！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {

                const {code,data={}}= await httpHandle({
                    url:`/iiot/workhours/${items.ttWbWorkhoursId}`,
                    method:'DELETE'
                })


                if(code==200){
                    showSuccessToast('提交成功！')
                    this.$router.push({
                        path:'/maintain/index',
                        query:{ tabs:2 }
                    })
                }
            });

        },
        // 到设备报修
        onRepairs(){
            const {bufferRow}=this
            // console.log(bufferRow)

            this.$router.push({
                path: '/equipment/repairs',
                query: {
                    tmBasEquipmentId: bufferRow.tmBasEquipmentId,
                    equipmentNo: bufferRow.equipmentNo,
                    equipmentName: bufferRow.equipmentName,
                }
            })

        },
        // 备件领用
        onReceiveFunc(){
            const {bufferRow}=this

            this.$router.push({
                path: '/replacement/index',
                query: {
                    activeType:"maintain",  // 保养
                    row: JSON.stringify(bufferRow)
                    // tmBasEquipmentId: bufferRow.tmBasEquipmentId,
                    // equipmentNo: bufferRow.equipmentNo,
                    // equipmentName: bufferRow.equipmentName,
                }
            })
        },
        // 查看 备件信息
        checksParePart(){
            this.$router.push({
                path:'/outPutHistory/detail',
                query:{ _page:"maintainMessageDetailHistory",partNo:this.bufferRow.partNo  }
            })
        }
    },
  }
</script>
