<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                :showSearchBtn="true"
                url="/iiot/maintain/list"
                :params="{ 
                    ...pageSearchConfig
                 }"
                @searchClick="searchClick"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="4">
                                <!-- <v-icon icon="mdi-dns" size="16" color="primary"></v-icon> -->
                                <span class="font-weight-medium">保养设备</span>
                            </v-col>
                            <v-col cols="7">
                                <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-medium" style="color:#00E5FF;">{{ props.items.equipmentName }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">任务类型:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{  FormatDictionary('WB_TT',props.items.wbTt)['lable']  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">周期:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ FormatDictionary('WB_ST',props.items.wbSt)['lable']  }}</p>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">保养部位:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.faultStationCn)">{{ props.items.faultStationCn   }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">保养方法:</p>
                            </v-col>
                            <v-col cols="8">
                                <p @click="GlobalTooltipFunc( props.items.manitainContent )" class="text-truncate font-weight-light">{{ props.items.manitainContent   }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">实施内容:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light" @click="GlobalTooltipFunc(props.items.implementContent)">{{ props.items.implementContent }}</p>
                            </v-col>
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
              
                            <v-col cols="8">
                                <p class="text-truncate font-weight-medium text">额定工时: {{ props.items.ratedDuration     }}</p>
                            </v-col>
               
                        </v-row> -->
                        <!-- <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text"></p>
                            </v-col>

                        </v-row> -->
                        
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">计划人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{  props.items.planImplementBy  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">实施人:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{  props.items.implementBy  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">实施时间:</p>
                            </v-col>
                            <v-col cols="8">
                                <p class="text-truncate font-weight-light">{{ props.items.implementTime  }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="6"></v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn @click="detailClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>
                            </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import  SearchPage from './search.vue' 

    import {httpHandle} from '@/http/http'  // api

    import { showSuccessToast,showFailToast,showToast } from 'vant';

  export default {
    components:{
        AppBarPage,
        SearchPage,
        TableComponents
    },
    data: () => ({
        pageSearchConfig:{},  // 查询信息
    }),

    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 详情
        async detailClick(props){
            const {items}=props
            
            const {code,data={}}= await httpHandle({
                url: `/iiot/maintain/${items.ttWbMaintainId}`,
                method:"get",
            })

            if(code==200){


            }
            

            this.$router.push({
                path:'/maintainMessage/detailHistory',
                query:{row: JSON.stringify(data) }
            })
        },   
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option={}){

            this.pageSearchConfig=option

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

            // console.log(option)
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })


        },

    },
  }
</script>