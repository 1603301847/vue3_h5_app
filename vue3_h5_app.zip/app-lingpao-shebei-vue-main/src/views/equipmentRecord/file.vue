<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <v-row no-gutters class="text"  style="margin: 8px 4px;">
            <v-col cols="12">
                <p class="font-weight-medium text">
                    <v-icon icon="mdi-message-text" size="16" color="primary"></v-icon>
                    文档信息:</p>
            </v-col>
            <v-col cols="12" class="text-left">
                <p class="font-weight-medium font-weight-light" style="color:#00E5FF;">{{ bufferRow.equipmentName   }}</p>
            </v-col>
        </v-row>

        <div class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="tableData"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-card>
                        <v-row no-gutters class="text">

                          <v-col cols="12">
                                <p class="font-weight-medium text">
                                  <a :href="props.items.fileAddr">
                                    文件编号:
                                    {{  props.items.fileNo }}
                                    </a>
                                </p>
                          </v-col>
                          <v-col cols="12">
                              <p class="font-weight-medium text">
                                <a :href="props.items.fileAddr">
                                  文件名称:
                                  {{  props.items.fileName }}
                                </a>
                              </p>
                          </v-col>
                        </v-row>
                    </v-card>
                </template>
            </TableComponents>
        </div>
        <div style="height: 52px;"></div>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备点检  点检
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api

    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        TableComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据
        tableData:[],   //table数据
    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 初始化
        async initFunc(){
            const {tmBasEquipmentId,row="{}"}=this.$route.query

            this.bufferRow=JSON.parse(row)

            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipmentFile/list?tmBasEquipmentId='+tmBasEquipmentId,
                method: "get",
            })

            if(code==200){
                this.tableData=data
            }
        },
    },
  }
</script>
