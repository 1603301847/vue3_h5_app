<template>
    <span>
        <AppBarPage>
            <!-- <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                >
                    <v-tab value="1">当前点检任务</v-tab>
                    <v-tab value="2">我的点检任务</v-tab>
                </v-tabs>
            </template> -->
        </AppBarPage>
        <!-- <div style="height: 50px;"></div> -->

        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <!-- <ScanBarComponents 
                    ref="scanBar1"
                    placeholder="扫描或输入 区域码"
                    @searchClick="barSearchClick"
                /> -->
                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    url="/iiot/equipment/listEquipmentApp"
                    :showSearchBtn="true"
                    :params="{
                        // params:{
                        //     typeList:['dj'],
                        //     beginTime:pageSearchConfig1.beginTime , // 开始日期
                        //     endTime:pageSearchConfig1.endTime,  // 结束日期
                        // },
                        // taskState:'',
                        // tmBasEquipments:tmBasEquipments,
                        ...pageSearchConfig1
                    }"
            
                    refreshFunc
                    @searchClick="searchClick1"
                    @refresh="refreshTable"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="5">
                                    <!-- <span class="font-weight-medium">点检设备</span> -->
                                </v-col>
                                <v-col cols="3">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row> -->

    
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">设备编号: </span>
                                        {{ props.items.equipmentNo }}
                                    </p>
                                </v-col>
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">设备名称: </span>
                                        {{ props.items.equipmentName }}
                                    </p>
                                </v-col>

                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">所属节点: </span>
                                        {{ props.items.node }}
                                    </p>
                                </v-col>

                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">设备类型: </span>
                                        {{ props.items.equipmentType2 }}
                                    </p>
                                </v-col>

                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">设备状态: </span>
                                      {{ FormatDictionary('iiot_devices_status',props.items.deviceStatus)['lable']   }}
                                    </p>
                                </v-col>

                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">所属电表: </span>
                                        {{ props.items.owningMeter }}
                                    </p>
                                </v-col>

                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">上级设备: </span>
                                        {{ props.items.parentEquipment }}
                                    </p>
                                </v-col>
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">位置: </span>
                                        {{ props.items.location }}
                                    </p>
                                </v-col>
                              <v-col cols="12">
                                <v-btn block color="cyan" elevation="0" style="border-radius: 0px;" @click="selectRecord(props)">
                                    文档查看
                                </v-btn>
                              </v-col>
                            </v-row>

                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <v-window-item value="2" class="v-window-item-table">
                <ScanBarComponents 
                    ref="scanBar2"
                    placeholder="扫描或输入 区域码"
                    @searchClick="barSearchClick2"
                />
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    url="/iiot/checkTask/listForApp"
                    :showSearchBtn="true"
                    :params="{
                      params:{typeList:['dj']},
                        taskState:'C',
                        tmBasEquipments:tmBasEquipments,
                        ...pageSearchConfig2
                    }"
                    method="post"
                    @searchClick="searchClick2"
                    refreshFunc
                    @refresh="refreshTable"

                >
                <template v-slot:tableBody="props">
                    <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="5">
                                    <span class="font-weight-medium">点检设备</span>
                                </v-col>
                                <v-col cols="1">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <!-- <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col> -->
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">点检类型:   </span>
                                        {{ FormatDictionary('CHECK_TYPE',props.items.taskType)['lable']   }}
                                    </p>
                                </v-col>
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">申请人:    </span>
                                        {{ props.items.createBy  }}
                                    </p>
                                </v-col>
                                <!-- <v-col cols="6">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">班次:   </span>
                                        {{ props.items.shiftNo }}
                                    </p>
                                </v-col> -->
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col>

                            </v-row> -->
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">所属车间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.manitainContent  }}</p>
                                </v-col>
                            </v-row> -->
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">所属产线:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light">{{ props.items.wbSt  }}</p>
                                </v-col>
                            </v-row> -->
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">申请人:    </span>
                                        {{ props.items.createBy  }}
                                    </p>
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <!-- <v-col cols="4">
                                    <p class="font-weight-medium text"></p>
                                </v-col> -->
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">申请时间:   </span>
                                        {{ props.items.createDate  }}
                                    </p>

                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4" class="text-center">

                                </v-col>
                                <v-col cols="4" class="text-center">
                                    <v-btn @click="cancelHandle(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">取消点检</v-btn>
                                </v-col>
                                <v-col cols="4" class="text-right">
                                    <v-btn @click="experienceEdit(props)" color="orange mt-1" density="compact" :rounded="0" variant="plain">点检</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>
        </v-window>


        <SearchPage1
            ref="searchPage1"
            :hideStatus="false"
            @resetHandle="resetHandle1"
            @searchHandle="searchHandle1"
        />

        <SearchPage2
            ref="searchPage2"
            :hideStatus="false"
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        />


        <span class="hide-select-equipment-input" v-if="showSelect">
            <SelectComponents 
                ref="selectContent"
                label="设备"
                placeholderSearch="请输入设备编号"
                :forbidShow="true"
                required
                showSearch
                multiple
                :option="equipmentSelectOption"
                @onSearchChange="equipmentSearchChange"
                @onChange="equipmentConfirm"
            />
        </span>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'  // 点检设备  点检记录
    import TableComponents from '@/packages/Table.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import SelectComponents from '@/packages/Select.vue'

    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api


    import {httpHandle} from '@/http/http'  // api
    import  SearchPage1 from './search.vue'
    import  SearchPage2 from './search.vue'

    import { showSuccessToast,showFailToast } from 'vant'
    import { showDialog  } from 'vant'



  export default {
    components:{
        AppBarPage,
        SearchPage1,
        SearchPage2,
        SelectComponents,
        ScanBarComponents,
        TableComponents
    },
    data: () => ({
        show: false,
        tab: '1',

        bufferTree:[],   // 工厂数据

        pageSearchConfig1:{},  // 查询信息   11
        pageSearchConfig2:{},  // 查询信息   22


        tmBasEquipments:[],   // 设备ID 数组
        showSelect:true,
        tmBasNodeLevelId:"",   // 设备ID
        equipment:"",  // 设备
        equipmentSelectOption:[],   // 设备 数据
        equipmentSelectOptionData:[],  // 设备 原始 数据
    }),
    created(){
        this.initFunc()

        this.factoryTreeHTTP()



        // 刷新页面
        const { $emitter } = this.$root;
        $emitter.on("update_examineHistory_page",()=>{

            this.initFunc()
            this.factoryTreeHTTP()

            this.refreshTable()
        });

    },
    methods: {
      selectRecord(props){
        const {items}=props
        console.log('tmBasEquipmentId', items.tmBasEquipmentId)
        this.$router.push({
          path:'/equipmentRecord/file',
          query:{tmBasEquipmentId: items.tmBasEquipmentId, row: JSON.stringify(items) }
        })
      },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        initFunc(){
            const {tabs}=this.$route.query

            if(tabs){
                this.tab=tabs
            }
        },
        // table 刷新
        refreshTable(){

            this.$refs["scanBar1"] && this.$refs["scanBar1"].reset()
            this.$refs["scanBar2"] && this.$refs["scanBar2"].reset()
            this.tmBasEquipments=[]

            this.$nextTick(()=>{
                if(this.tab=="1"){
                    this.$refs.table1.initFunc(1,{})
                }

                if(this.tab=="2"){
                    this.$refs.table2.initFunc(1,{})
                }
            })

        },
        // 设备查询
        async equipmentSearchChange(key=""){
            this.equipmentHTTP(key)
        },
        // 初始化 设备 
        async equipmentHTTP(keyNo=""){
            const {tmBasNodeLevelId}=this
            // 展示  equipmentNo +  equipmentName  值  tmBasEquipmentId
            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipment/list',
                method:"get",
                url_params:{
                    tmBasNodeLevelId: tmBasNodeLevelId,
                    equipmentNo:keyNo
                }

            }) 

            if(code==200){
                this.equipmentSelectOptionData=data
                this.equipmentSelectOption=data.map(o=>Object.assign({
                    text:`${o.equipmentNo}-${o.equipmentName}`,
                    value:o.tmBasEquipmentId
                })).splice(0,100)  
            }
        },
        // 设备 选中
        equipmentConfirm(value=''){
            // const _obj=this.equipmentSelectOptionData.filter(o=>o.tmBasEquipmentId==value)[0]||{}
            
            this.tmBasEquipments=(value?value.split(","):[])


            this.$nextTick(()=>{
                if(this.tab=="1"){
                    this.$refs.table1.initFunc(1,{})
                }

                if(this.tab=="2"){
                    this.$refs.table2.initFunc(1,{})
                }
            })
        },
        // 工厂数据
        async factoryTreeHTTP(){
            const {data=[]} = await FactoryTreeHTTP()
            this.bufferTree=data

        },
        // 点检 111
        async experienceEditTo(props){
            const {items}=props

            const {code}= await httpHandle({
                    url:"/iiot/checkTask/checkTask",
                    method:'post',
                    payload:{
                        ttCheckTaskId:items.ttCheckTaskId
                    }
                })


                if(code==200){
                    showSuccessToast('提交成功！')

                    this.tab='1'
                    this.$nextTick(()=>{
                        this.$refs.table1.initFunc()
                    })
                }
        },
        // 点检
        async experienceEdit(props){
            const {items}=props


            this.$router.push({
                path:'/examineHistory/detail',
                query:{ttCheckTaskId: items.ttCheckTaskId,row: JSON.stringify(items) }
            })

            setTimeout(() => {
                this.$root.$emitter.emit("update_examineHistory_page_index")
            }, 1000);

        },
        // 取消点检
        async cancelHandle(props){
            const {items}=props

            showDialog({
                title: '取消确认',
                message: '取消后数据不可恢复，确认取消！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {


                const {code}= await httpHandle({
                    url:"/iiot/checkTask",
                    method:'PUT',
                    payload:{
                        "ttCheckTaskId": items.ttCheckTaskId, // 当前数据ttCheckTaskId字段 点检任务id
                        "taskState": 'N'    // 前数据 taskState  点检状态 修改状态为'N'",
                    }
                })


                if(code==200){
                    showSuccessToast('提交成功！')

                    this.tab='1'
                    this.$nextTick(()=>{
                        this.$refs.table1.initFunc()
                    })
                }


            });




        },
        // 头部 查询 11
        async barSearchClick(value=''){
            const _value=value.trim()


            const _newList=this.bufferTree.filter(o=>o.nodeLevelNo==_value)[0]||{}
            if(!_newList.tmBasNodeLevelId){
                showFailToast("无工厂节点！")
                return
            }

            this.showSelect=false
            this.tmBasNodeLevelId=_newList.tmBasNodeLevelId
            this.$nextTick(async()=>{

                this.showSelect=true
                await this.equipmentHTTP("")

                
                this.$nextTick(()=>{
                    this.$refs.selectContent.showModle()
                })
            })

        },
        // 头部 查询 22
        async barSearchClick2(value=''){
            const _value=value.trim()

            const _newList=this.bufferTree.filter(o=>o.nodeLevelNo==_value)[0]||{}
            if(!_newList.tmBasNodeLevelId){
                showFailToast("无工厂节点！")
                return
            }

            this.showSelect=false
            this.tmBasNodeLevelId=_newList.tmBasNodeLevelId
            this.$nextTick(async()=>{

                this.showSelect=true
                await this.equipmentHTTP("")

                this.$nextTick(()=>{
                    this.$refs.selectContent.showModle()
                })
            })

        },
        // 查询 11
        searchClick1(){
            this.$refs.searchPage1.showDrawer()
        },
        // 查询结果 11
        searchHandle1(option){
            this.pageSearchConfig1=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置 11
        resetHandle1(opiton){
            this.pageSearchConfig1={}
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

        },
        // 查询 22
        searchClick2(){
            this.$refs.searchPage2.showDrawer()
        },
        // 查询结果 22
        searchHandle2(option){
            this.pageSearchConfig2=option
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置 22
        resetHandle2(opiton){
            this.pageSearchConfig2={}


            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })

        },
    },
  }
</script>
<style lang="scss">
.hide-select-equipment-input{
    >span >div.van-cell {
        visibility: hidden;
    }
}
</style>
