<template>
    <span>
        <AppBarPage>
      

        </AppBarPage>

        <v-btn v-if="_pageIndex=='3' &&  $root.$utils.PermissionButton('iiot:qmTask:rectify')" style="width:52px;height:52px;position:fixed;top:220px;right:16px;z-index: 11;color: #fff;" icon="mdi-plus" color="secondary" @click="abarbeitungHandle"><span style="color: #fff;">整改</span></v-btn>
        <v-btn v-if="_pageIndex=='4'" style="width:52px;height:52px;position:fixed;top:280px;right:16px;z-index: 11;color: #fff;" icon="mdi-plus" color="secondary" @click="abarbeitungAddHandle"><span style="color: #fff;">新增</span></v-btn>


        <v-btn v-if="(_pageIndex=='2' || _pageIndex=='3' )" style="width:52px;height:52px;position:fixed;top:310px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="primary" @click="toOrderHandle">配置</v-btn>

        

        <v-sheet elevation="2" rounded class="custem-card">
            <!-- <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-bullhorn" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">信息</span>
                </v-col>
                <v-col cols="6">
                    <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</p>
                </v-col>
            </v-row> -->
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验产品:</p>
                </v-col>
                <v-col cols="8">
                    <p @click="GlobalTooltipFunc(bufferRow.partName)" class="font-weight-light text-left">{{bufferRow.partName}}</p>
                </v-col>
            </v-row>


            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">订单号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.orderNo  }}</p>
                </v-col>

            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">工作中心:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ bufferRow.nodeLevelName  }}</p>
                </v-col>
            </v-row>


            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">产品SN号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{  bufferRow.sn }}</p>
                </v-col>

            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">检验类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="text-truncate font-weight-light">{{ FormatDictionary('test_type',bufferRow.taskType)['lable']   }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <!-- <v-col cols="3">
                    <p class="font-weight-medium text"></p>
                </v-col> -->
                <!-- <v-col cols="6">
                    <p class="text-truncate font-weight-light">
                        <span class="font-weight-medium text">检验数量: </span>
                        {{ bufferRow.taskQty }}
                    </p>
                </v-col> -->
                <v-col cols="6">
                    <p class="text-truncate font-weight-light">
                        状态: 
                        <span style="color:#00E5FF;">{{ FormatDictionary("qm_task_status",bufferRow.taskStatus)["lable"]  }}</span>
                    </p>
                </v-col>
            </v-row>

            <!-- <v-row no-gutters class="text">
                <v-col cols="3">
                    <p class="font-weight-medium text"></p>
                </v-col>

            </v-row> -->

            
        </v-sheet>

        <SelectComponents 
            v-if="( _pageIndex==2 || _pageIndex==3 )"
            v-model="process"
            label="工序"
            ref="select111"
            :disabled="_pageActive"
            :option="processSelectOption"
            @onChange="onChangeProcess"
        />

        <v-row v-if="tableList.filter(o=>o.isBatteryCheck=='1').length" style="margin-top:0px;margin-bottom:12px;">
            <v-col cols="12" style="padding: 0px;">
                <v-btn
                    block
                    color="warning"
                    @click="batteryHandle(tableList)"
                >
                    电池曲线调试
                </v-btn>
            </v-col>    
        </v-row>

        <v-sheet class="v-window-item-table">
            <TableComponents
                ref="table1"
                :children="tableList"
                :pagingShow="false"
            >
                <template v-slot:tableBody="props">
                    <v-sheet>
                        
                        <v-row no-gutters class="table-title">
                            <v-col cols="1">
                                <v-badge :content="props._index+1" color="primary" inline></v-badge>
                            </v-col>
                            <v-col cols="9">
                                <p class="text-truncate font-weight-light font-weight-medium text">
                                    <!-- <span class="font-weight-medium">{{ props.items.inspectName }}</span> -->
                                    <span style="padding-left:12px;color:#00E5FF;"> {{  `<${FormatDictionary("checkout_param_type",props.items.parameterType)["lable"]}类型>`   }} </span>
                                </p>
                            </v-col>
                            <v-col cols="2" class="text-right">
                                <p style="color: #4caf50;">{{ props.items.inspectBy?"完成":"" }}</p>
                            </v-col>

                        </v-row>
                        <div style="height:6px;"></div>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <p class="font-weight-light" style="color:#00E5FF;">
                                    {{ props.items.inspectName }}
                                </p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="4">
                                <p class="font-weight-medium text">检验项目:</p>
                            </v-col>
                            <v-col cols="8">
                                <p @click="GlobalTooltipFunc(props.items.inspectName)" class="text-truncate font-weight-light">{{ props.items.inspectName   }}</p>
                            </v-col>
                        </v-row>
                        <v-row no-gutters class="text">
                            <v-col cols="12">
                                <span class="font-weight-medium text">检验明细:</span>
                                <span @click="GlobalTooltipFunc(`${props.items.inspectDetailName||''}`)" class="font-weight-light" style="padding-left: 6px;">{{ props.items.inspectDetailName }}</span>
                            </v-col>
            
                        </v-row>
                        <v-row no-gutters class="text" v-if="props.items.parameterType=='DT'?true:false">
     
                            <v-col cols="4">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">标准值: </span>
                                    {{ props.items.parameterDefault }}
                                </p>
                            </v-col>

                            <v-col cols="4">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">最大值: </span>
                                    {{ props.items.upperDeviation }}
                                </p>
                            </v-col>
                            <v-col cols="4">
                                <p class="text-truncate font-weight-light">
                                    <span class="font-weight-medium text">最小值: </span>
                                    {{ props.items.lowerDeviation }}
                                </p>
                            </v-col>
                        </v-row>
                        <!-- <v-row>
                            <v-col cols="3">
                                <p class="font-weight-medium text">工序:</p>
                            </v-col>
                            <v-col cols="3">
                                <p class="text-truncate font-weight-light">{{ props.items.methodDesc }}</p>
                            </v-col>
                        </v-row> -->



                        <div style="height:3px;"></div>

                        <v-row no-gutters class="text">
                            <v-col cols="3">
                                <p style="margin-top: 8px;" class="font-weight-medium text input-lable">检验结果:</p>
                            </v-col> 
                            <v-col cols="9">
                                <van-field 
                                    v-model="props.items.resultValue" 
                                    style="padding:0px;"
                                    size="large"
                                    placeholder="请输入检验结果"
                                    autocomplete="off"
                                    class="custem-input-index1 custem-input-big"
                                    :style="'padding-top:0px;'"
                                    :type="`${FormatDictionary('checkout_param_type',props.items.parameterType).value=='DT'?'number':'text'}`"
                                    @focus="$root.$utils.VanFieldFocusToTop"
                                    @update:model-value="resultValueHandle(props)"

                                />
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">
                            <v-col cols="12" style="position: relative;left: -14px;">
                            
                                <SelectComponents 
                                    v-model="props.items.tmBasReasonId"
                                    label="不良类别"
                                    :option="typeSelectOption"
                                />

                            </v-col>
                            <v-col cols="12" style="position: relative;left: -14px;">
                                <van-field v-model="props.items.remark" autocomplete="off" placeholder="请输入" label="不良描述" />

                                <!-- <SelectComponents 
                                    v-model="props.items._urgency"
                                    ref="select4"
                                    label="问题描述"
                                    class="custem-select-big"
                                    showSearch
                                    :option="urgencySelectOption"
                                    @onSearchChange="productSearchChange"
                                    
                                /> -->
                            </v-col>
                        </v-row>

                        <v-row style="margin-top: 0px;">
                            <v-col cols="12">
                                <p class="font-weight-medium text">
                                    检验人:
                                    <span>{{ props.items.inspectBy }}</span>
                                </p>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="text">

                            <v-col cols="12" style="text-align:right;">
                                <v-switch
                                    v-model="props.items._switch"
                                    :label="props.items._switch?'合格':'不合格'"
                                    color="primary"
                                    density="comfortable"
                                    :disabled="_pageActive || FormatDictionary('checkout_param_type',props.items.parameterType).value=='DT'"
                                    style="top:-10px;left:8px;position:relative;height:40px;display:block;height:48px;width:104px;"
                                    ></v-switch>
                            </v-col>
                        </v-row>
                        <!-- <v-row no-gutters class="text" v-if="props.items.parameterType=='DT'?true:false">
                            <v-col cols="3">
                                <p style="margin-top: 3px;" class="font-weight-medium text input-lable">检验数量:</p>
                            </v-col>
                            <v-col cols="5">
                                <van-field 
                                    
                                    v-model="props.items._number" 
                                    style="padding:0px;"
                                    size="large"
                                    placeholder="请输入数量"
                                    autocomplete="off"
                                    type="number"
                                    :disabled="_pageActive"
                                    class="custem-input-index1"
                                />
                            </v-col>

                        </v-row> -->


                        <v-row no-gutters v-if="!props.items._switch">
                            <v-col cols="12">
                                <UploaderImageComponents 
                                    v-model="props.items._bufferFileList"
                                    :preview="_pageActive"
                                />
                            </v-col>

                        </v-row>

                        <v-row v-if="props.items.isRectiify=='1'" no-gutters style="padding:6px 8px;">
                            <v-col cols="12">
                                <v-btn
                                    block
                                    color="warning"
                                    @click="rectifyHandle(props.items)"
                                >
                                    整改
                                </v-btn>
                            </v-col>
                        </v-row>

                        <!-- <v-row v-if="_pageIndex==4 && !_pageActive" no-gutters style="padding: 0px 12px;">
                            <v-col cols="12">
                                <v-btn
                                    block
                                    color="warning"
                                    @click="applyDisposeHandle(props)"
                                >
                                    不合格处理申请
                                </v-btn>
                            </v-col>
                        </v-row> -->

                    </v-sheet>
                </template>
            </TableComponents>
        </v-sheet>

        <div style="height:80px;"></div>

        
        <v-row class="global-botom-btn-box" style="bottom: 122px;padding-top: 12px;background: #fff;" no-gutters>
            <v-col cols="12" style="margin-bottom:18px;padding-left:6px;">
                <p>
                    <span>结果: </span>
                    <span :style="FormatBottomResultColor()">{{ FormatBottomResult() }}</span>
                </p>
            </v-col>
        </v-row>

        <span v-if="!_pageActive">
            <v-row class="global-botom-btn-box" no-gutters v-if="_pageIndex==1">
                <!-- <v-col cols="5" class="text-center">
                    <v-btn
                        color="warning"
                        @click="disqualificationApplyHandle"
                    >
                        不合格处理申请
                    </v-btn>
                </v-col>
                <v-col cols="4" class="text-center">
                    <v-btn
                        color="error"
                        @click="standardHandle(false)"
                    >
                        不合格
                    </v-btn>
                </v-col>
                <v-col cols="3" class="text-center">
                    <v-btn
                        color="primary"
                        @click="standardHandle(true)"
                    >
                        合格
                    </v-btn>
                </v-col> -->
                <v-btn
                    color="cyan"
                    @click="submitHandle(undefined)"
                    block
                >
                    提交
                </v-btn>
            </v-row>

            <v-row style="bottom: 118px;" class="global-botom-btn-box" no-gutters v-if="(_pageIndex==2)||(_pageIndex==3)">

             
                <v-col cols="5" class="text-center">
                    <!-- <v-btn v-if="(_pageIndex==2)" :disabled="qmTaskData.processState != 'A'" @click="shiftToHandle('B')" color="purple" block>
                        转装调
                    </v-btn> -->
                    <v-btn v-if="(_pageIndex==3)" :disabled="qmTaskData.processState != 'B'" @click="shiftToHandle('C')" color="purple" block>
                        转入库检验  
                    </v-btn>
                </v-col>
                <v-col cols="2"></v-col>
                <v-col v-if="(_pageIndex==2)||(_pageIndex==3)" cols="5" class="text-center">
                    <v-btn
                        color="cyan"
                        @click="submitHandle(undefined)"
                        block
                    >
                        提交
                    </v-btn>
                </v-col>
            </v-row>

            <v-row style="bottom: 64px;" class="global-botom-btn-box" no-gutters v-if="(_pageIndex==2)||(_pageIndex==3)">
                <v-col cols="5" class="text-center">
                    <v-btn @click="anomalyInitiateSectionFunc(1)" color="primary" block>例外转序发起</v-btn>
                </v-col>
                <v-col cols="2"></v-col>
                <v-col cols="5" class="text-center">
                    <v-btn @click="anomalyInitiateSectionFunc(2)" color="error" block>例外转序关闭</v-btn>
                </v-col>
            </v-row>


            <v-row class="global-botom-btn-box" no-gutters v-if="_pageIndex==4">
                <v-col cols="12" class="text-center">
                    <v-btn
                        color="cyan"
                        @click="submitHandle(undefined)"
                        block
                    >
                        提交
                    </v-btn>
                </v-col>
                <!-- <v-col cols="6" class="text-center">
                    <v-btn
                        color="error"
                        @click="submitHandle(2)"
                    >
                        不合格
                    </v-btn>
                </v-col>
                <v-col cols="6" class="text-center">
                    <v-btn
                        color="primary"
                        @click="submitHandle(1)"
                    >
                        合格
                    </v-btn>
                </v-col> -->
            </v-row>
        </span>

        <div style="height: 60px;"></div>

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import SelectComponents from '@/packages/Select.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant'
    import { showDialog  } from 'vant'

  export default {
    components:{
        AppBarPage,
        SelectComponents,
        UploaderImageComponents,
        TableComponents
    },
    data: () => ({
        active663:true,  // 重复提交

        _pageIndex:0,   // 页面标识
        _pageActive:false,

        bufferRow:{},  // 行数据
        qmTaskData:{},  // 缓存数据

        tableList:[],  // table数据
        tableListBuffer:[],  // table数据 缓存

        typeSelectOption:[],   // 不良类别 数据  


        urgency:"",  // 备注
        urgencySelectOption:[],   // 备注数据

        process:"",            // 工序
        processSelectOption:[],    // 工序 数据

    }),
    created(){
        this.initFunc()
        this.remarkHTTP()

        this.typeHTTP()  // 不良类别 数据
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 格式化 底部合格
        FormatBottomResult(){
            const {bufferRow={}}=this
            if(!bufferRow.inspectResult) return

            const _text=this.FormatDictionary("IQC_RESULT",bufferRow.inspectResult)["lable"]

            return _text
        },
        // 格式化 底部合格 颜色
        FormatBottomResultColor(){
            const {bufferRow={}}=this


            let _tetx=""
            switch (bufferRow.inspectResult) {
                case '10':
                    _tetx="color:#4CAF50"
                    break;
                case '20':
                    _tetx="color:#FF9800"
                    break;    
                case '30':
                    _tetx="color:#FF5722"
                    break;          
                default:
                    break;
            }

            return _tetx
        },
        // 初始化
        async initFunc(){
            const {ttQmTaskId,_pageIndex=0,qcType='',_pageActive=''}=this.$route.query

            this._pageIndex=_pageIndex
            this._pageActive=(_pageActive=='detail')?true:false

            // 基础数据
            const {code,data={}}= await httpHandle({
                url:`/iiot/qmTask/getQmTaskData/${ttQmTaskId}`,
                method:'get'
            })

            if(code==200){
                this.bufferRow=data.qmTaskData||{}
                this.qmTaskData=data.qmTaskData||{}
            }



            // table
            const _result= await httpHandle({
                url:`/iiot/qmTaskResult/getCheckResultList`,
                method:'get',
                url_params:{
                    ttQmTaskId:ttQmTaskId,
                    qcType: qcType
                }
            })

            if(code==200){
                this.tableList=(_result?.data.dataList||[]).map(k=> Object.assign(k,{
                    _switch: k.inspectResult ? (k.inspectResult=="10"?true:false):true,
                    // _urgency: k.remark,
                    // _number: k.resultValue,
                    _bufferFileList: k.taskResultPath ? k.taskResultPath.split(",").map(o=>Object.assign({url:o})) :[]
                }))

                this.$nextTick(()=>{
                    this.tableListBuffer=this.tableList
                    this.$refs.table1.initFunc()
                })

                let _newList= new Set((_result?.data.dataList||[]).map(o=>o.nodeLevelName))
                this.processSelectOption= [..._newList].map((o,i)=>Object.assign({text:o,value:i}))    // 工序 数据


                this.$nextTick(()=>{
                    // 切换工序
                    const _bufferProcessDetailSelectProcess=JSON.parse( localStorage.getItem("bufferProcessDetailSelectProcess")||"{}" )
                    if( Object.keys( _bufferProcessDetailSelectProcess ).length ){
                        const _optionSelect=this.processSelectOption.filter(o=>o.text==_bufferProcessDetailSelectProcess.text)[0]||{}
                        
                        this.$refs.select111 && this.$refs.select111.setValue( _optionSelect.value )  // 工序
                        this.onChangeProcess("",_optionSelect)
                        // console.log( _optionSelect )
                    }

                })
                
            }

        },
        // 不良类别
        async typeHTTP(){
            const {code,data=[]}= await httpHandle({
                url: "/iiot/reason/list",
                method: "post",
                payload:{      
                    // reasonNo:"",
                    enabled:"1",
                    params:{
                        reasonTypeList:['MS','F']
                    }
                }
            })
           
            if(code==200){
                this.typeSelectOption=data.map(o=>Object.assign({text:o.reasonNo+'-'+o.reasonName,value:o.tmBasReasonId}))   // 不良类别
            }
        },
        // 备注数据
        async remarkHTTP(key=''){

            const {code,data=[]}= await httpHandle({
                url:'/iiot/defect/listDefectForSelect',
                method:"get",
                url_params:{
                    // pageNum:1,
                    // pageSize:10,          
                    defectNo:key,
                    enabled:"1"
                }

            }) 

            if(code==200){
                this.urgencySelectOption=data.map(o=>Object.assign({
                    text:`${o.defectTypeName}-${o.defectName}`,
                    value:o.tmQmDefectId
                })).splice(0,200)

            }
        },
        // 备注数据 查询
        productSearchChange(key){
            this.remarkHTTP(key)
        },
        // 工序切换
        onChangeProcess(value,option){
            // console.log(option)
            this.tableList= JSON.parse( JSON.stringify(this.tableListBuffer) ).filter(o=>o.nodeLevelName==option.text)

            this.$nextTick(()=>{
                this.$refs.table1.initFunc()
                localStorage.setItem("bufferProcessDetailSelectProcess", JSON.stringify(option) )
            })
        },
        // 检验结果 判断
        resultValueHandle(props){
            const {items,_index}=props

            // 最大 最小 不存在
            if( (items.lowerDeviation=="") || (items.lowerDeviation==null) || (items.lowerDeviation==undefined) || (items.lowerDeviation=="undefined") ){
                return
            }
            if( (items.upperDeviation=="") || (items.upperDeviation==null) || (items.upperDeviation==undefined) || (items.upperDeviation=="undefined") ){
                return
            }

            this.$nextTick(()=>{
                // 数值类型
                if( this.FormatDictionary('checkout_param_type',props.items.parameterType).value=='DT' ){
                    if(  (Number(items.resultValue)>=Number(items.lowerDeviation)) && (Number(items.resultValue)<=Number(items.upperDeviation))  ){
                        this.tableList[_index]['_switch']=true
                    }else{
                        this.tableList[_index]['_switch']=false
                    }
                }
            })

        },
        // 自制件  不合格处理申请
        async disqualificationApplyHandle(){
            const {qmTaskData}=this

            // 不合格 不良描述必选
            if( this.tableList.filter(o=>{
                return (!o._switch)&&!((o.tmBasReasonId||"").trim())  
            }).length ){
                showFailToast('不合格时，不良类别必选')
                return
            }


            // 不合格 不良描述必选
            if( this.tableList.filter(o=>{
                return (!o._switch)&&!((o.remark||"").trim())  
            }).length ){
                showFailToast('不合格时，不良描述必填')
                return
            }

            

            const _json={
                dataList:  JSON.parse( JSON.stringify(this.tableList) ).map(o=> Object.assign(o,{
                    // resultValue: o._number,
                    // remark: o._urgency,
                    inspectResult: o._switch?"10":"30",
                    taskResultPath: (o._bufferFileList||[]).map(o=>o.url).join()
                })), 
                qmTaskData: qmTaskData
            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmTaskResult/materialsApplyUnQualityManage',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')
                // this.initFunc()
                // 跳转 不合格处理   data.ttQmDefectId

                this.$router.push({
                    path:'/processDisqualification/detail', 
                    query:{ ttQmDefectId:data.ttQmDefectId  }
                }) 
            }

        },
        // 自制件 合格 不合格 
        async standardHandle(active){
            const {qmTaskData}=this
            const {_pageIndex=''}=this.$route.query

            // 不合格 不良描述必选
            if( this.tableList.filter(o=>{
                return (!o._switch)&&!((o.tmBasReasonId||"").trim())  
            }).length ){
                showFailToast('不合格时，不良类别必选')
                return
            }

            // 不合格 不良描述必选
            if( this.tableList.filter(o=>{
                return (!o._switch)&&!((o.remark||"").trim())  
            }).length ){
                showFailToast('不合格时，不良描述必填')
                return
            }

            const _json={
                dataList:  JSON.parse( JSON.stringify(this.tableList) ).map(o=> Object.assign(o,{
                    // resultValue: o._number,
                    // remark: o._urgency,
                    inspectResult: o._switch?"10":"30",
                    taskResultPath: (o._bufferFileList||[]).map(o=>o.url).join()
                })), 
                qmTaskData: Object.assign(qmTaskData,{inspectResult:active?"10":'30' }) 
            }
            
            // console.log(_json)
            const {code,data={}}= await httpHandle({
               url:'/iiot/qmTaskResult/materialsCheckResultSave',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')
                this.initFunc()



                // active==true   自制件
                if(_pageIndex=='1' && active){
      
                    setTimeout(()=>{
                        // this.$router.push({
                        //     path:'/process/index', 
                        //     query:{ }
                        // }) 

                        this.$router.go(-1)
                    },1500)
                }

            }
        },
        // 工序自检-提交   装调自检-提交   入库检验 合格 不合格 
        async submitHandle(active){
            const {qmTaskData}=this
            const {_pageIndex=''}=this.$route.query


            let _json2={}

            switch (active) {
                case 1:
                    _json2={inspectResult:'10'}
                    break;
                case 2:
                    _json2={inspectResult:'30'}
                    break;            
                default:
                    break;
            }

            // console.log(this.process==5)
            // return

            // 只要有一条不合格 30   其它10
            var _json6={
                inspectResult:""
            }
            if( this.tableList.filter(o=>!o._switch).length ){
                _json6.inspectResult='30'
            }else{
                _json6.inspectResult='10'
            }


            // 数值类型 检验结果必填
            const _isnumber=this.tableList.filter(o=> this.FormatDictionary('checkout_param_type',o.parameterType).value=='DT' && !o.resultValue )
            if(_isnumber.length){
                showFailToast('数值类型，检验结果必填！')
                return
            }

            
            // 不合格 不良描述必选
            if( this.tableList.filter(o=>{
                return (!o._switch)&&!((o.tmBasReasonId||"").trim())  
            }).length ){
                showFailToast('不合格时，不良类别必选')
                return
            }

            // 不合格 不良描述必选
            if( this.tableList.filter(o=>{
                return (!o._switch)&&!((o.remark||"").trim())  
            }).length ){
                showFailToast('不合格时，不良描述必填')
                return
            }

            const _json={
                dataList:  JSON.parse( JSON.stringify(this.tableList) ).map(o=> Object.assign(o,{
                    // resultValue: o._urgency,
                    // remark: o._urgency,
                    inspectResult: o._switch?"10":"30",
                    taskResultPath: (o._bufferFileList||[]).map(o=>o.url).join()
                })), 
                qmTaskData: Object.assign(qmTaskData,_json2,_json6) 
            }



            if( !this.active663 ){
                showFailToast('重复提交！')
                return
            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmTaskResult/materialsCheckResultSave',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')

                this.active663=false
                this.initFunc()




                // 工序
                if(_pageIndex=='2' && !active){
                    setTimeout(()=>{
                        // this.$router.push({
                        //     path:'/process/index', 
                        //     query:{ }
                        // }) 
                        this.$router.go(-1)
                    },1500)
                }


                // 装调
                if(_pageIndex=='3' && !active){
                    // 工位6
                    if( this.process != (this.processSelectOption.length-1) ){
                        setTimeout(()=>{
                            // this.$router.push({
                            //     path:'/process/index', 
                            //     query:{ }
                            // }) 
                            this.$router.go(-1)
                        },1500)
                    }
                }


                // 入库  点合格
                if(_pageIndex=='4' && active==1){
                    setTimeout(()=>{
                        // this.$router.push({
                        //     path:'/process/index', 
                        //     query:{ }
                        // }) 
                        this.$router.go(-1)
                    },1500)
                }

   
            }

        },
        // 入库检验 不合格处理申请
        async applyDisposeHandle(props){
            const {items}=props
            const {qmTaskData}=this

            // 不合格 备注必填
            if(  (!items._switch) && !((items.tmBasReasonId||"").trim()) ){
                showFailToast('不合格时，不良类别必选')
                return
            }

            const _json={
                dataList:[items],
                qmTaskData: qmTaskData
            }

            const {code,data={}}= await httpHandle({
               url:'/iiot/qmTaskResult/materialsApplyUnQualityManage',
               method: "post",
               payload:_json
            })
           
            if(code==200){
                showSuccessToast('提交成功！')
                
                this.$router.push({
                    path:'/processDisqualification/detail', 
                    query:{ ttQmDefectId:data.ttQmDefectId  }
                }) 
            }
        },
        //  转装调   转入库
        async shiftToHandle(active){
            const {qmTaskData}=this


            const _json={
                type:  active,   // type的话    工序自检  转装调的时候传  B    装调自检  转入库
                ttQmTaskId:qmTaskData.ttQmTaskId
            }

            const {code,data={}}= await httpHandle({
                url:'/iiot/qmTaskResult/turnAdjustmentStorage',
                method: "post",
                payload:{
                    qmTaskData:_json
                } 
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.initFunc()

                // this.$router.push({
                //     path:'/anomalyInitiate/index', 
                //     query:{ }
                // }) 

                setTimeout(()=>{
                    // this.$router.push({
                    //     path:'/process/index', 
                    //     query:{ }
                    // }) 
                    this.$router.go(-1)
                },1000)
            }
            
   
        },
        // 转序发起  关闭
        anomalyInitiateSectionFunc(active){
            const {qmTaskData}=this

            // 发起
            if(active==1){
                this.$router.push({
                    path:'/anomalyInitiateSection/add', 
                    query:{ sn:qmTaskData?.sn, ttPpOrderSnId:qmTaskData?.ttPpOrderSnId }
                }) 
            }
            // 关闭
            if(active==2){
                this.$router.push({
                    path:'/anomalyInitiateSection/dispose', 
                    query:{ sn:qmTaskData?.sn, ttPpOrderSnId:qmTaskData?.ttPpOrderSnId }
                }) 
            }
        },
        // 整改
        rectifyHandle(option){
            this.$router.push({
                path:'/processDisqualification/detail', 
                query:{ ttQmDefectId:option.ttQmDefectId  }
            }) 
        },
        // 电池曲线调试
        async batteryHandle(props=[]){
            const {_pageActive=''}=this.$route.query
            const {bufferRow}=this
            // console.log()
            // 详情
            if(_pageActive=='detail'){


                const {code,data=[]}= await httpHandle({
                    url:`/iiot/batteryResult/list`,
                    method:'get',
                    url_params:{
                        sn: bufferRow.sn,
                        orderNo: bufferRow.orderNo,
                        partNo: bufferRow.partNo,

                    }
                })

                if(code==200){
                    if(data && data.length){
                        this.$router.push({
                            path:'/battery/index', 
                            query:{_pageActive:_pageActive, row: JSON.stringify(this.bufferRow) }
                        }) 
                    }else{
                        showFailToast("没有维护电池曲线!")
                    }

                }

                return
            }


            // 创建
            const _result2= await httpHandle({
                url:`/iiot/batteryResult/batteryList`,
                method:'get',
                url_params:{
                    sn: bufferRow.sn,
                    orderNo: bufferRow.orderNo,
                    partNo: bufferRow.partNo,
                }
            })

            if(_result2.code==200){
                // 创建
                this.$router.push({
                    path:'/battery/index', 
                    query:{batteryCheckType:props[0]?.batteryCheckType,_pageActive:_pageActive, row: JSON.stringify(this.bufferRow) }
                }) 
            }




        },
        // 整改
        abarbeitungHandle(){
            const {qmTaskData={}}=this

            this.$router.push({
                path:'/process/index/abarbeitung', 
                query:{ 
                    ttPpOrderSnId: qmTaskData.ttPpOrderSnId,
                    ttQmTaskId: qmTaskData.ttQmTaskId
                }
            }) 
        },
        // 新增
        abarbeitungAddHandle(){
            const {qmTaskData={}}=this

            this.$router.push({
                path:'/process/addProjiect', 
                query:{ 
                    ttQmTaskId: qmTaskData.ttQmTaskId
                }
            }) 
        },
        // 订单配置页面
        toOrderHandle(){
            const {qmTaskData}=this

            this.$router.push({
                path:'/taskList/order', 
                query:{orderNo:qmTaskData.orderNo,sn:qmTaskData.sn}
            }) 
        }

    },
  }
</script>