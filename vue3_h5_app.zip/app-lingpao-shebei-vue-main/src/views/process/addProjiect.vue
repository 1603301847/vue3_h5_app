<template>
    <span>
        <AppBarPage>

        </AppBarPage>

        <div>
            <div style="height: 12px;"></div>

            <v-row no-gutters class="text">
                <v-col cols="11">
                    <SelectComponents 
                        v-model="project"
                        ref="select11"
                        label="检验项目"
                        showSearch
                        required
                        :option="projectSelectOption"
                        @onSearchChange="projectSelectChange"
                        @onChange="projectChange"
                    />
                </v-col>
                <v-col cols="1" class="text-right">
                    <v-icon
                        style="margin-top:8px;"
                        size="large"
                        color="green-darken-2"
                        icon="mdi-plus"
                        @click="addProject"
                        ></v-icon>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="11">
                    <SelectComponents 
                        v-model="projectDetail"
                        ref="select22"
                        label="检验明细"
                        showSearch
                        required
                        forbidShow
                        :option="projectDetailSelectOption"
                        @onSearchChange="projectDetailSelectChange"
                        @onFieldClick="projectDetailClick"
                    />
                </v-col>
                <v-col cols="1" class="text-right">
                    <v-icon
                        style="margin-top:8px;"
                        size="large"
                        color="green-darken-2"
                        icon="mdi-plus"
                        @click="addProjectDetail"
                        ></v-icon>
                </v-col>
            </v-row>


            <v-row no-gutters class="text">
                <v-col cols="11">
                    <SelectComponents 
                        v-model="standard"
                        ref="select33"
                        label="检验方法"
                        showSearch
                        required
                        :option="standardSelectOption"
                        @onSearchChange="standardSelectChange"
                    />
                </v-col>
                <v-col cols="1" class="text-right">
                    <v-icon
                        style="margin-top:8px;"
                        size="large"
                        color="green-darken-2"
                        icon="mdi-plus"
                        @click="addStandard"
                        ></v-icon>
                </v-col>
            </v-row>

            <div style="height: 30px;"></div>
            <v-row no-gutters style="padding: 0px 6px;">
             
                <v-col cols="12" class="text-center">
                    <v-btn
                        block   
                        color="primary"
                        @click="submit5"
                    >
                        提交
                    </v-btn>
                </v-col>
                </v-row>

        </div>


        <van-popup 
            v-model:show="showPicker1" 
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round 
            closeable
        >
            <div>
                <h3>添加-检验项目</h3>
                <div style="height:12px;"></div>

                <van-field v-model="value1" required  placeholder="请输入" autocomplete="off" label="文本:" />

                <div style="height:22px;"></div>
                <v-row no-gutters style="padding: 0px 6px;">
   
                    <v-col cols="12" class="text-center">
                        <v-btn
                            block   
                            color="primary"
                            @click="submit1"
                        >
                            确认
                        </v-btn>
                    </v-col>
                </v-row>

                <div style="height: 22px;"></div>
            </div>
        </van-popup>


        <van-popup 
            v-model:show="showPicker2" 
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round 
            closeable
        >
            <div>
                <h3>添加-检验明细</h3>
                <div style="height:12px;"></div>

                <van-field v-model="value2" required  placeholder="请输入" autocomplete="off" label="文本:" />

                <div style="height:22px;"></div>
                <v-row no-gutters style="padding: 0px 6px;">
   
                    <v-col cols="12" class="text-center">
                        <v-btn
                            block   
                            color="primary"
                            @click="submit2"
                        >
                            确认
                        </v-btn>
                    </v-col>
                </v-row>

                <div style="height: 22px;"></div>
            </div>
        </van-popup>

        <van-popup 
            v-model:show="showPicker3" 
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round 
            closeable
        >
            <div>
                <h3>添加-检验方法</h3>
                <div style="height:12px;"></div>

                <van-field v-model="value3" required  placeholder="请输入" autocomplete="off" label="文本:" />

                <div style="height:22px;"></div>
                <v-row no-gutters style="padding: 0px 6px;">
   
                    <v-col cols="12" class="text-center">
                        <v-btn
                            block   
                            color="primary"
                            @click="submit3"
                        >
                            确认
                        </v-btn>
                    </v-col>
                </v-row>

                <div style="height: 22px;"></div>
            </div>
        </van-popup>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import SelectComponents from '@/packages/Select.vue'

    import { showSuccessToast,showFailToast } from 'vant';
    import { showImagePreview } from 'vant'
    import {httpHandle} from '@/http/http'  // api

  export default {
    components:{
        AppBarPage,
        SelectComponents
    },
    data: () => ({
        project:"",   // 项目
        projectSelectOption:[],  // 项目数据


        projectDetail:"",  // 检验明细
        projectDetailSelectOption:[],   // 检验明细 数据

        standard:"",   // 方法
        standardSelectOption:[],  // 方法数据


        showPicker1:false,
        showPicker2:false,
        showPicker3:false,



        value1:"",
        value2:"",
        value3:"",


    }),
    created(){
        this.projectInit()   // 项目
        // this.projectDetailInit()   // 项目明细
        this.standardInit()   // 方法

    },
    methods: {
        // 初始化
         initFunc(){

        },
        // 检验项目
        async projectInit(key=""){

            const {code,data={}}= await httpHandle({
                url: "/iiot/inspect/listInspectForSelect",
                method: "get",
                url_params:{
                    inspectNo: key
                }
            })

            if(code==200){
                this.projectSelectOption=data.map(o=>Object.assign({
                    text: `${o.inspectName}`,
                    value:o.tmQmInspectId
                }))  
            }
        },
        // 检验项目 查询
        projectSelectChange(key=""){
            this.projectInit(key)
        },
        // 项目 change
        projectChange(value){
            this.projectDetail=""
            this.$refs.select22.reset()
        },
        // 检验项目 明细 点击
        projectDetailClick(){
            if(!this.project){
                showFailToast("未选择检验项目！")
                return
            }
            this.projectDetailInit()
        },
        // 检验项目 明细
        async projectDetailInit(key=""){
            const {project}=this

            const {code,data={}}= await httpHandle({
                url: "/iiot/inspectDetail/listInspectDetailForSelect",
                method: "get",
                url_params:{
                    // inspectDetailNo: key
                    tmQmInspectId: project,
                    inspectDetailNo:key
                }
            })

            if(code==200){
                this.projectDetailSelectOption=data.map(o=>Object.assign({
                    text: `${o.inspectDetailName}`,
                    value:o.tmQmInspectDetailId
                }))  


                this.$nextTick(()=>{
                    this.$refs.select22.showModle()
                })
            }
        },
        // 检验项目 明细 查询
        projectDetailSelectChange(key=""){
            this.projectDetailInit(key)
        },
        // 检验方法
        async standardInit(key=""){
            const {code,data={}}= await httpHandle({
                url: "/iiot/inspectMethod/listInspectMethodForSelect",
                method: "get",
                url_params:{
                    methodNo: key
                }
            })
            

            if(code==200){
                this.standardSelectOption=data.map(o=>Object.assign({
                    text: `${o.methodName}`,
                    value:o.tmQmInspectMethodId
                }))  
            }
        },
        // 检验方法 查询
        standardSelectChange(key=""){
            this.standardInit(key)
        },
        // 添加 项目
        addProject(){
            this.value1=""
            this.showPicker1=true
        },
        // 添加 项目 保存
        async submit1(){
            const {ttQmTaskId}=this.$route.query


            if(!this.value1.trim()){
                showFailToast("文本必填！")
                return
            }

            const _json={
                ttQmTaskId:ttQmTaskId,
                inspectName: this.value1.trim()
            }

            const {code,data={}}= await httpHandle({
                url: '/iiot/inspect/addInspect',
                method: "post",
                payload: _json
            })
            
            if(code==200){
                showSuccessToast("提交成功！")
                this.showPicker1=false


                this.projectInit()   // 项目
                this.project=""
                this.$refs.select11.reset()


                this.projectDetail=""   // 明细
                this.$refs.select22.reset()
            }
        },
        // 添加 项目明细
        addProjectDetail(){

            if(!this.project){
                showFailToast("检验项目未选择！")
                return
            }

            this.value2=""
            this.showPicker2=true
        },
        // 添加 项目明细 保存
        async submit2(){
            const {ttQmTaskId}=this.$route.query


            if(!this.value2.trim()){
                showFailToast("文本必填！")
                return
            }

            const _json={
                ttQmTaskId:ttQmTaskId,
                inspectDetailName:this.value2.trim(),
                tmQmInspectId: this.project
            }

            const {code,data={}}= await httpHandle({
                url: '/iiot/inspectDetail/addInspectDetail',
                method: "post",
                payload: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.showPicker2=false

                this.projectDetail=""   // 明细
                this.$refs.select22.reset()
            }
        },
        // 添加 检验方法
        addStandard(){
            this.value3=""
            this.showPicker3=true
        },
        // 添加 检验方法 保存
        async submit3(){
            const {ttQmTaskId}=this.$route.query


            if(!this.value3.trim()){
                showFailToast("文本必填！")
                return
            }

            const _json={
                ttQmTaskId:ttQmTaskId,
                methodName:this.value3.trim(),
            }

            const {code,data={}}= await httpHandle({
                url: '/iiot/inspectMethod/addInspectMethod',
                method: "post",
                payload: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")
                this.showPicker3=false

                this.standard=""   // 检验方法
                this.$refs.select33.reset()
                this.standardInit()   // 方法

            }
        },
        // 提交
        async submit5(){
            const {ttQmTaskId}=this.$route.query

            if(!this.project){
                showFailToast("检验项目必填！")
                return
            }

            if(!this.projectDetail){
                showFailToast("检验明细必填！")
                return
            }

            if(!this.standard){
                showFailToast("检验方法必填！")
                return
            }
            
            const _json={
                ttQmTaskId:ttQmTaskId,
                tmQmInspectId: this.project, // 项目
                tmQmInspectDetailId: this.projectDetail,  // 明细
                tmQmInspectMethodId: this.standard   // 方法
            }

            const {code,data={}}= await httpHandle({
                url: '/iiot/qmTaskResult/saveTaskResult',
                method: "post",
                payload: _json
            })

            if(code==200){
                showSuccessToast("提交成功！")

                setTimeout(()=>{
                    this.$router.go(-1)
                },600)
            } 
        }
    },
  }
</script>