<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>不合格项</v-tab>
                    <v-tab value="2" hide-slider>异常转序</v-tab>
                </v-tabs>
            </template>
        </AppBarPage>


        <v-btn style="position:fixed;top:220px;right:16px;z-index: 11;color: #fff;" icon="mdi-plus" color="secondary" @click="initHandle"><span style="color: #fff;">刷新</span></v-btn>


        <div style="height: 50px;"></div>




        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <!--  url="/iiot/abnormal/list" -->
                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    :children="children1"
                    :showSearchBtn="!true"
                    :auto="false"
                    :pagingShow="false"
                    :params="{ 

                    }"
                    @searchClick="searchClick"
                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <!-- <v-col cols="5">
                                    <span class="font-weight-medium">异常流水</span>
                                </v-col> -->
                                <v-col cols="11">
                                    <p class="font-weight-light text-right" style="color:#00E5FF;">{{ FormatDictionary("qm_defect_status",props.items.defectStatus)["lable"]  }}</p>
                                </v-col>

                                
                                <!-- <v-col cols="6">
                                    <p class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ formatStatus(props.items)  }}</p>
                                </v-col> -->
                            </v-row>
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.abnormalNo  }}</p>
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">检验项目:</span>
                                        <span>{{ props.items.inspectName   }}</span>
                                    </p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">检验明细:</span>
                                        <span>{{ props.items.inspectDetailName   }}</span>
                                    </p>
                                </v-col>
                            </v-row>


                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">不良类别:</span>
                                        <span>{{ props.items.reasonName   }}</span>
                                    </p>
                                </v-col>
                            </v-row>

                            <!-- <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">检验结果:</span>
                                        <span>{{ props.items.resultValue   }}</span>
                                    </p>
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">不良描述:</span>
                                        <span>{{ props.items.remark   }}</span>
                                    </p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <span class="font-weight-medium text">工位:</span>
                                        <span>{{ props.items.nodeLevelName   }}</span>
                                    </p>
                                </v-col>
                            </v-row>



                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light">
                                        <!-- <span class="font-weight-medium text">:</span> -->
                                        <span :style="`color:${ props.items.inspectResult=='10'?'#4caf50':'red'}`">{{ props.items.inspectResult=='10'?'合格':'不合格'   }}</span>
                                    </p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4" class="text-left">
           
                                
                                </v-col>

                            <v-col cols="4" class="text-center">

                            </v-col>

                            <v-col cols="4" class="text-right">
                                <v-btn @click="abarbeitungDetail(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">整改</v-btn>
                            </v-col>
                        </v-row>
                            
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <v-window-item value="2" class="v-window-item-table">
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    :children="children2"
                    :showSearchBtn="!true"
                    :auto="false"
                    :pagingShow="false"
                    :params="{ 
           
                    }"
                    @searchClick="searchClick2"
                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                        <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                    </v-col>

                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium text-left text-teal-lighten-1" color="primary">{{ FormatDictionary('conversion_status',props.items.conversionState)['lable'] }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-light text-teal-lighten-1">{{ props.items.conversionNo }}</p>
                                </v-col>
                            </v-row>
        
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">序列号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" >{{ props.items.sn }}</p>
                                </v-col>
                            </v-row>
                            
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">发起工序:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" >{{ props.items.initiateProcess }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">拦截工序:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" >{{ props.items.interceptProcess }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">例外转序原因:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" >{{ props.items.conversionDesc }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">整机物料:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" >{{ props.items.partName }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">发起人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" >{{ props.items.initiateByName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">发起时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light" >{{ props.items.createDate }}</p>
                                </v-col>
                            </v-row>

  
                            <UploaderImageComponents 
                                :initPath="props.items.initiatePath"
                                preview
                            />


                        <!-- <v-row no-gutters class="text">
                            <v-col cols="6" class="text-left">
                                <v-btn v-if="props.items.conversionState=='10'" @click="dischargedClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">放行</v-btn>
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn v-if="props.items.conversionState!='30'" @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">关闭</v-btn>
                            </v-col>
                        </v-row> -->



                        <v-row no-gutters class="text">
                            <v-col cols="6" class="text-left">
                                <!-- <v-btn v-if="props.items.conversionState=='10'" @click="dischargedClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">放行</v-btn> -->
                            </v-col>
                            <v-col cols="6" class="text-right">
                                <v-btn v-if="props.items.conversionState!='30'" @click="detailClick(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">关闭</v-btn>
                            </v-col>
                        </v-row>

                    </v-card>
                    </template>
                </TableComponents>
            </v-window-item>
        </v-window>


        <!-- <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

        <SearchPage 
            ref="searchPage2" 
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        /> -->


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    // import  SearchPage from './search.vue' 
    // import  SearchPage2 from './search.vue' 





    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast } from 'vant';

  export default {
    components:{
        AppBarPage,
        TableComponents,
        UploaderImageComponents

    },
    data: () => ({
        tab: '1',


        children1:[],   // table 1
        children2:[],   // table 2


        pageSearchConfig:{},  // 查询信息  11
        pageSearchConfig2:{},  // 查询信息  22


    }),
    created(){
        // 判断 状态

        this.initHandle()
    },
    methods: {
        // 初始化
        async initHandle(){
            const {ttPpOrderSnId,ttQmTaskId}=this.$route.query


            // 不合格
            const _resuilt1= await httpHandle({
                url:'/iiot/qmTaskResult/getCheckItemDefectList',
                method: "get",
                url_params:{
                    ttQmTaskId:ttQmTaskId
                    // ttQmTaskId:"500955633333637120"
                } 
            })


            // 例外转序
            const _resuilt2= await httpHandle({
                url:'/iiot/abnormalConversion/list',
                method: "get",
                url_params:{
                    ttPpOrderSnId:ttPpOrderSnId
                    // ttPpOrderSnId:"469089583516418048"
                } 
            })


            if(_resuilt1.code==200){
                this.children1=_resuilt1.data?.dataList||[]
            } 


            if(_resuilt2.code==200){
                this.children2=_resuilt2.data||[]
            }

        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 详情
        async detailClick(props){
            const {items}=props
            
            
            this.$router.push({
                path:'/anomalyInitiate/detail', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId,pageType:'search' }
            }) 

        }, 
        // 处理 状态
        formatStatus(items){


            let _text=""

            switch (items.abnormalState) {
                case '10':  
                    _text="待转发"
                    break;
                case '20':  
                    _text="待指派"
                    break;   
                case '30':  
                    _text="待处理"
                    break;    
                case '40':  
                    _text="待关闭"
                    break;   
                case '90':  
                    _text="已关闭"
                    break; 
                case '60':  
                    _text="已驳回"
                    break;      
                default:
                    break;
            }

            return _text
     


        },
        // 查询
        searchClick(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage.showDrawer()
        },
        // 查询结果
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}
            

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })

        },
        // 查询
        searchClick2(){
            // console.log( this.$refs.searchPage )
            this.$refs.searchPage2.showDrawer()
        },
        // 查询结果
        searchHandle2(option){
            this.pageSearchConfig2=option
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle2(opiton){
            this.pageSearchConfig2={}
            
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 发起异常
        sponsorHandle(){
            
            this.$router.push({
                path:'/anomalyInitiate/sponsor', 
                query:{ }
            })    
        },
        // 异常转发
        transpondClick(props){
            const {items}=props
            
            // 待转发
            this.$router.push({
                path:'/anomalyInitiate/transpond', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }

            })       
        },
        // 异常指派
        appointClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/appoint', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }

            }) 
        },
        // 异常处理
        disposeClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/dispose', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }

            }) 
        },
        // 异常关闭
        closeClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/close', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }

            }) 
        },
        // 异常变更
        alterationError(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/sponsor', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }
            }) 
        },
        // 节点详情
        nodeDetail(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiate/content', 
                query:{ ttQmAbnormalId: items.ttQmAbnormalId }
            }) 
        },
        // 整改
        abarbeitungDetail(props){
            const {items}=props
            // console.log(items)
            // return
            this.$router.push({
                path:'/processDisqualification/detail', 
                query:{ ttQmDefectId: items.ttQmDefectId  }
            }) 

        },
        // 关闭
        async detailClick(props){
            const {items}=props

            this.$router.push({
                path:'/anomalyInitiateSection/close', 
                query:{ ttQmAbnormalConversionId: items.ttQmAbnormalConversionId  }
            }) 

        },
    },
  }
</script>