<template>
    <span>
        <AppBarPage>
            <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                    class="custem-tabs-global"
                >
                    <v-tab value="1" hide-slider>待检验</v-tab>
                    <v-tab v-if="showTab2" value="2" hide-slider>检验完成</v-tab>
                </v-tabs>
            </template>
        </AppBarPage>
        <div style="height: 50px;"></div>

        <v-btn v-if="tab==1" style="position:fixed;top:220px;right:16px;z-index: 11;" icon="mdi-plus" color="secondary" @click="addHandle"></v-btn>

        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">
                <ScanBarComponents 
                    :searchLength="10"
                    placeholder="请扫描或输入 SN号"
                    @searchClick="barSearchClick"
                />
                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    url="/iiot/qmTask/list"
                    method="post"
                    :showSearchBtn="showSearchBtn1"
                    :auto="false"
                    :params='{ 
                        "taskType":"IPQC",
                        processQueryType:processQueryType,    
                        partType:partType,
                        "params": {
                            "statusList": [
                            "N",
                            "R"
                            ],
                        },
                        ...pageSearchConfig
                    }' 
                    :formatData="(data)=> data.map(o=> Object.assign(o,{_taskQty:'1'}) )  "
                    @searchClick="searchClick"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="1">
                                    <!-- <p class="font-weight-medium text-left text-teal-lighten-1">{{ FormatDictionary("process_state",props.items.processState)["lable"] }}</p> -->
                                </v-col>
                                <v-col cols="10">
                                    <p class="font-weight-medium text-right text-teal-lighten-1">{{ FormatDictionary("process_state",props.items.processState)["lable"] }}</p>
                                    <!-- <p class="text-truncate text-right font-weight-medium text-right text-teal-lighten-1" color="primary">{{ FormatDictionary("qm_task_status",props.items.taskStatus)["lable"] }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12" color="primary">
                                    <p class="text-left font-weight-medium" style="color:#00E5FF;">
                                        {{ props.items.partNo }}-{{ props.items.partName }}
                                    </p>
                                </v-col>   
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">任务流水号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.taskNo   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">订单号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.orderNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text">
                                        <span>产品SN号: </span>
                                        <span>{{props.items.sn}}</span>
                                    </p>
                                </v-col>

                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">工作中心:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.nodeLevelName}}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">报检时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.requestTime }}</p>
                                </v-col>
                            </v-row>


                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">重新报检:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ FormatDictionary("yes_no",props.items.isAnewInspect)["lable"] }}</p>
                                </v-col>
                            </v-row>


                            <!-- <v-row v-if="props.items.taskStatus=='R'" no-gutters class="text">
    
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-light" style="margin-top: 6px;">
                                        <span class="font-weight-medium text">检验数量:</span>
                                        {{ props.items.taskQty  }}
                                    </p>
                                </v-col>
                                <v-col cols="4" class="text-left">
                                </v-col>
                            </v-row> -->
                            <!-- <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">合格数量:</p>
                                </v-col>
                                <v-col cols="8">
                                    <van-field v-model="props.items._taskQty" style="position:relative;padding:0px;top:-4px;" class="custem-input-index1" placeholder="合格数量" autocomplete="off" />
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="6" class="text-left">
                                    <!-- <v-btn v-if="(props.items.taskStatus=='R') && props.items.processState=='D'" @click="accomplishClick(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">检验确认</v-btn> -->
                                </v-col>
                                <v-col cols="6" class="text-right">
                                    <v-btn @click="detailClick(props)" style="font-size:20px;" color="error mt-1" density="compact" :rounded="0" variant="plain">检验</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <v-window-item value="2" class="v-window-item-table">
                <ScanBarComponents 
                    :searchLength="10"
                    placeholder="请扫描或输入 SN号"
                    @searchClick="barSearchClick2"
                />
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    url="/iiot/qmTask/list"
                    method="post"
                    :showSearchBtn="true"   
            
                    :params='{ 
                        "taskType":"IPQC",
                        partType:partType,
                        "params": {
                            "statusList": ["F"],
                        },
                        ...pageSearchConfig2
                    }' 
                    @searchClick="searchClick2"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="1">
                                    <!-- <p class="font-weight-medium text-left text-teal-lighten-1">{{ FormatDictionary("process_state",props.items.processState)["lable"] }}</p> -->
                                </v-col>
                                <v-col cols="10">
                                    <p class="font-weight-medium text-right text-teal-lighten-1">{{ FormatDictionary("process_state",props.items.processState)["lable"] }}</p>
                                    <!-- <p class="text-truncate text-right font-weight-medium text-right text-teal-lighten-1" color="primary">{{ FormatDictionary("qm_task_status",props.items.taskStatus)["lable"] }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12" color="primary">
                                    <p class="text-left font-weight-medium" style="color:#00E5FF;">
                                        {{ props.items.partNo }}-{{ props.items.partName }}
                                    </p>
                                </v-col>   
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">任务流水号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.taskNo   }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">订单号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.orderNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text">
                                        <span>产品SN号: </span>
                                        <span>{{props.items.sn}}</span>
                                    </p>
                                </v-col>

                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">工作中心:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="text-truncate font-weight-medium font-weight-light">{{ props.items.nodeLevelName}}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text">
                                        入库合格时间:
                                        <span>{{ props.items.responseTime }}</span>
                                    </p>
                                </v-col>
                            </v-row>
                            
                            <!-- <v-row v-if="props.items.taskStatus=='R'" no-gutters class="text">
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-light" style="margin-top: 6px;">
                                        <span class="font-weight-medium text">检验数量:</span>
                                        {{ props.items.taskQty  }}
                                    </p>
                                </v-col>
                                <v-col cols="6" class="text-left">
                                    <van-field v-model="props.items._taskQty" style="padding: 0px;" class="custem-input-index1" placeholder="合格数量" autocomplete="off" />
                                </v-col>
                            </v-row> -->
                            <v-row no-gutters class="text">
                                <v-col cols="6" class="text-left">
                                </v-col>
                                <v-col cols="6" class="text-right">
                                    <!-- <v-btn @click="detailHandle(props)" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn> -->
                                    <v-btn @click="detailClick(props,'detail')" color="primary mt-1" density="compact" :rounded="0" variant="plain">详情</v-btn>
                                    
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>
        </v-window>


        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px',height:'260px',width:'80%'}"
            round 
            closeable
        >
            <h3>检验选择</h3>

            <div>
                <div style="height: 6px;"></div>
                <p class="font-weight-medium text text-teal-lighten-1">{{ menuTopTitle  }}</p>
                <div style="height: 20px;"></div>
                
                <v-btn v-if="showBtn1" block color="primary" @click="routerPush('2')">
                    工序检验
                </v-btn>
                <div style="height: 16px;"></div>
                <v-btn v-if="showBtn2" block color="indigo" @click="routerPush('3')">
                    调试检验
                </v-btn>
                <div style="height: 16px;"></div>

                <v-btn v-if="showBtn3" block color="purple" @click="routerPush('4')">
                    入库检验
                </v-btn>
            </div>
        </van-popup>

        <SearchPage 
            ref="searchPage" 
            @resetHandle="resetHandle"
            @searchHandle="searchHandle"
        />

        <SearchPage2 
            ref="searchPage2" 
            @resetHandle="resetHandle2"
            @searchHandle="searchHandle2"
        />

    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import TableComponents from '@/packages/Table.vue'
    import {httpHandle} from '@/http/http'  // api
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import  SearchPage from './search.vue' 
    import  SearchPage2 from './search.vue' 


    import {OverHTTP} from '@/http/equipment/affirm'   // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';


  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        SearchPage,
        SearchPage2,
        TableComponents
    },
    data: () => ({
        showSearchBtn1:true,   // 显示查询按钮
        showTab2:true,
        tab: '1',
        pageActive:'',  

        processQueryType:"",    
        partType:"",

        showBtn1:false,   // 显示 工序按钮
        showBtn2:false,   // 显示 装调按钮
        showBtn3:false,   // 显示 入库按钮


        pageSearchConfig:{},  // 查询信息 11
        pageSearchConfig2:{},  // 查询信息 22


        menuTopTitle:"",   // 菜单头部显示值
        bufferData:{},  // 缓存数据
        showPicker:false
    }),
    watch: {
        'tab': { 
            handler(value=''){
                this.$nextTick(()=>{
                    setTimeout(()=>{
                        if(this.tab=='1'){
                            this.$refs.table1.initFunc(1)
                        }
                        if(this.tab=='2'){
                            this.$refs.table2.initFunc(1) 
                        }
                    },300)
                })
            },
            deep: true, 
            immediate: true, 
        },
    },
    created(){
        this.initHandle()

        // 重复报检 查询
        this.showSearchBtn1=true
        
        this.$nextTick(()=>{
            const {path}=this.$route

            // 调试检不需要 查询
            if( path == '/process/index/adjustment' ){
                this.showSearchBtn1=false
                return
            }

            this.propertyInit()
        })


        // 刷新页面
        this.$root.$emitter.on("update_process_page1",(tabs='1')=>{
            this.tab=tabs
        })
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 重复报检
        propertyInit(){
            const _text = localStorage.getItem("process_index_propertyChangeValue")||""

            if(_text){

                this.pageSearchConfig=Object.assign(this.pageSearchConfig,{
                    isAnewInspect:_text
                })

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc(1)
                    
                    setTimeout(()=>{
                        this.$refs.searchPage.setProperty(_text)
                    },200)
                })

            }

        },
        initHandle(){
            const {tabs}=this.$route.query

            if(tabs){
                this.tab=tabs
            }

            const _path=this.$route.fullPath

            //this.$refs.table2.initFunc(1)

            //  /process/index/working    
            //  /process/index/adjustment   
            //  /process/index/put    入库检验
            //  /process/index/self    自制件

            this.processQueryType=""
            this.partType=''
            this.showTab2=true


            this.$nextTick(()=>{
                switch (_path) {
                    case '/process/index/working':   // 工序检验
                        this.processQueryType="A"
                        this.partType='ZPJ'
                        this.showTab2=false

                        break;
                    case '/process/index/adjustment':   // 调试检验
                        this.processQueryType="B"
                        this.partType='ZPJ'
                        this.showTab2=false
                        break;
                    case '/process/index/put':   // 入库检验
                        this.processQueryType="C"
                        this.partType='ZPJ'
                        break;
                    case '/process/index/self':   // 自制件
                        this.partType='JGJ'  
                        break;       
                    default:
                        break;
                }


                this.$nextTick(()=>{
                    setTimeout(()=>{
                        if(this.tab=='1'){
                            this.$refs.table1.initFunc(1)
                        }
                        if(this.tab=='2'){
                            this.$refs.table2.initFunc(1) 
                        }
                    },300)
                })
            })



            // console.log( _path )
            //         processQueryType:"",    
           // partType:"",


        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            const {code,data=[]}= await httpHandle({
                url:'/iiot/orderSn/listOrderSnForSelect',
                method: "get",
                url_params:{
                    sernr: _value
                }
            })

            if(code==200){

                if(!data.length){
                    showFailToast("SN号不存在！")
                    return
                }    
                this.$refs.table1.initFunc(1,{
                    ttPpOrderSnId: (data[0]||{}).ttPpOrderSnId
                })
            }
        },
        // 头部 查询 222
        async barSearchClick2(value=''){
            const _value=value.trim()

            const {code,data=[]}= await httpHandle({
                url:'/iiot/orderSn/listOrderSnForSelect',
                method: "get",
                url_params:{
                    sernr: _value
                }
            })

            if(code==200){

                if(!data.length){
                    showFailToast("SN号不存在！")
                    return
                }    
                this.$refs.table2.initFunc(1,{
                    ttPpOrderSnId: (data[0]||{}).ttPpOrderSnId
                })
            }
        },
        // 检验
        async detailClick(props,active=''){
            const {items}=props

            this.pageActive=active
            this.bufferData=items
            this.menuTopTitle=""

            const {code,data={}}= await httpHandle({
               url:`/iiot/part/${items.tmBasPartId}`,
               method: "get"
            })
           
            if(code==200){
                //  其它  ||  自制件 
                if( ['ZF01','ZF02','ZF03','ZF04'].includes(data.mtart) ){
                    // this.showPicker=true
                    // this.menuTopTitle=this.FormatDictionary('process_state',items.processState)['lable']

                    // // 状态 == A
                    // // items.processState=""
                    // if( (items.processState=="A") || !items.processState ){
                    //     this.showBtn1=true   // 显示 工序按钮
                    //     this.showBtn2=false   // 显示 装调按钮
                    //     this.showBtn3=false   // 显示 入库按钮
                    // }

                    // // 状态 == B
                    // if( items.processState=="B" ){
                    //     this.showBtn1=true   // 显示 工序按钮
                    //     this.showBtn2=true   // 显示 装调按钮
                    //     this.showBtn3=false   // 显示 入库按钮
                    // }

                    // // 状态 ==  C
                    // if( (items.processState=="C") || (items.processState=="D") ){
                    //     this.showBtn1=true   // 显示 工序按钮
                    //     this.showBtn2=true   // 显示 装调按钮
                    //     this.showBtn3=true   // 显示 入库按钮
                    // }


                    const _path=this.$route.fullPath

                    switch (_path) {
                        case '/process/index/working':   // 工序检验
                            this.$router.push({
                                path:'/process/detail2', 
                                query:{ qcType:'IPQCA', _pageActive:active, ttQmTaskId: items.ttQmTaskId,_pageIndex:2 }
                            }) 
                            break;
                        case '/process/index/adjustment':   // 调试检验
                            this.$router.push({
                                path:'/process/detail3', 
                                query:{ qcType:'IPQCB', _pageActive: active, ttQmTaskId: items.ttQmTaskId, _pageIndex:3 }
                            })  
                            break;
                        case '/process/index/put':   // 入库检验
                            this.$router.push({
                                path:'/taskList/index', 
                                query:{  qcType:'IPQCC', _pageActive: active, ttQmTaskId: items.ttQmTaskId, _pageIndex:4 }
                            }) 
                            break;
                        // case '/process/index/self':   // 自制件
                        //     this.partType='JGJ'  
                        //     break;       
                        default:
                            break;
                    }    


                }else{
                    this.$nextTick(()=>{
                        this.$router.push({
                            path:'/process/detail', 
                            query:{ 
                                _pageActive: active,
                                ttQmTaskId: items.ttQmTaskId,
                                _pageIndex:1 
                            }
                        }) 
                    })

                }
            }
        },
        // 查询
        searchClick(){
            this.$refs.searchPage.showDrawer(this.tab)
        },
        // 查询结果
        searchHandle(option){
            this.pageSearchConfig=option
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        },
        // 查询 重置
        resetHandle(opiton){
            this.pageSearchConfig={}
            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
            
        },
        // 查询 222
        searchClick2(){
            this.$refs.searchPage2.showDrawer(this.tab)
        },
        // 查询结果 222
        searchHandle2(option){
            this.pageSearchConfig2=option
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 查询 重置 222
        resetHandle2(opiton){
            this.pageSearchConfig2={}
            this.$nextTick(()=>{
                this.$refs.table2.initFunc(1)
            })
        },
        // 详情跳转
        routerPush(active){
            const {bufferData}=this


            switch (active) {
                case "2":   // 工序检
                    this.$router.push({
                        path:'/process/detail2', 
                        query:{ qcType:'IPQCA', _pageActive: this.pageActive, ttQmTaskId: bufferData.ttQmTaskId,_pageIndex:2 }
                    })  
                    break;
                case "3":   // 调试检验
                    this.$router.push({
                        path:'/process/detail3', 
                        query:{ qcType:'IPQCB', _pageActive: this.pageActive, ttQmTaskId: bufferData.ttQmTaskId, _pageIndex:3 }
                    })  
                    break;
                case "4":   // 入库检验
                    this.$router.push({
                        path:'/taskList/index', 
                        query:{  qcType:'IPQCC', _pageActive: this.pageActive, ttQmTaskId: bufferData.ttQmTaskId, _pageIndex:4 }
                    })  
                
                    // this.$router.push({
                    //     path:'/process/detail4', 
                    //     query:{  qcType:'IPQCC', _pageActive: this.pageActive, ttQmTaskId: bufferData.ttQmTaskId, _pageIndex:4 }
                    // })  
                    break;            
                default:
                    break;
            }

 
        },   
        // 检验完成
        async accomplishClick(props){
            const {items}=props

            const _number=Number( items._taskQty||"" )
            
            if(!_number){
                showFailToast("合格数量必填！")
                return
            }

            if(_number>Number(items.taskQty)){
                showFailToast("合格数量不能大于检验数量！")
                return
            }


            const _json={
                "ttQmTaskId": items.ttQmTaskId,
                "taskQty":  items.taskQty,
                "qualifiedQty":  items.taskQty,
                "version":  items.version,
                "acceptQty":  _number,   // 合格数
            }

            const {code,data={}}= await httpHandle({
                url:'/iiot/qmTask/finishQmTask',
                method: "post",
                payload:_json
            })

            if(code==200){
                showSuccessToast("提交成功！")

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc(1)
                    // this.tab='2'
                })

            }


        },
        // 添加
        addHandle(){
            this.$router.push({
                path:'/process/add', 
                query:{ }
            }) 
        },
        // 详情
        detailHandle(props){
            const {items}=props

            // this.$router.push({
            //     path:'/process/checkDetail', 
            //     query:{ ttQmTaskId: items.ttQmTaskId,_page:"process" }
            // }) 
            
        },     

    },
  }
</script>