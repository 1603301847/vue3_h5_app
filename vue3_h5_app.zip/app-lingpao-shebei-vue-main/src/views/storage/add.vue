<template>
    <span>
        <AppBarPage>
        </AppBarPage>

        <v-row no-gutters style="margin-bottom:8px;">
            <v-col cols="8">
                <v-icon icon="mdi-bullhorn" size="16" color="error"></v-icon>
                <span style="padding-left:6px;">添加异常</span>
            </v-col>
            <v-col cols="4" class="text-right" style="padding-right:6px">
                <!-- <span class="font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.equipmentName }}</span> -->
            </v-col>
        </v-row>



        <v-sheet elevation="2" rounded class="custem-card">



            <SelectComponents 
                v-model="user"
                ref="select11"
                label="物料编码"
                :option="repairmanSelectOption"
            />

            <van-field v-model="reqQty" type="number" placeholder="请输入" label="数量" autocomplete="off" />


            <SelectComponents 
                v-model="type"
                ref="select22"
                label="异常类型"
                :option="typeSelectOption"
            />

            <SelectComponents 
                v-model="type2"
                ref="select33"
                label="处理类型"
                :option="type2SelectOption"
            />


            <van-field v-model="abnormalExplain" placeholder="请输入" label="异常说明" autocomplete="off" />
            <van-field v-model="disposeExplain" placeholder="请输入" label="处理说明" autocomplete="off" />
   

        </v-sheet>

        <v-row no-gutters>
            <v-col cols="12">
                <v-btn
                    block
                    color="primary"
                    @click="onSubmit"
                >
                    提交
                </v-btn>
            </v-col>

        </v-row>
        <div style="height: 80px;"></div>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'
    import SelectComponents from '@/packages/Select.vue'


    import { showSuccessToast,showFailToast } from 'vant'
    import {httpHandle} from '@/http/http'  // api




  export default {
    components:{
        AppBarPage,
        SelectComponents
    },
    data: () => ({
        bufferRow:{},  // 行数据




        user:"",     // 物料编码    
        repairmanSelectOption:[],   // 物料编码 数据

        reqQty:"",  // 数量

        
        type:"",     // 异常类型    
        typeSelectOption:[],   // 异常类型 数据

        type2:"",     // 处理异常类型    
        type2SelectOption:[],   // 处理异常类型 数据

        abnormalExplain:"",  // 异常说明
        disposeExplain:"",  // 处理说明
    }),
    created(){
        this.initFunc()
        this.initRepairman()  
    },
    methods: {
        // 初始化
        initFunc(){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            // 异常类型
            const _selectAttribute=_bufferDictionaries["ccgl_abnormal_type"]||[]    // 属性
            this.typeSelectOption=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

            // 处理类型
            const _selectAttribute2=_bufferDictionaries["ccgl_abnomal_dispose"]||[]    // 属性
            this.type2SelectOption=_selectAttribute2.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据

            
            
            
        },
        // 物料编码
        async initRepairman(){
            
            const {deliverySlipId}=this.$route.query

            const _data= await httpHandle({
                url:`/iiot/deliverySlipPart/dict/${deliverySlipId}`,
                method:"get",


            }) 

            this.repairmanSelectOption=(_data||[]).map(o=>Object.assign({
                text:`${o.dictValue||''}-${o.dictLabel||''}`,
                value:o.dictValue
            }))

        },
        // 确认维修
        async onSubmit(){
            const {deliverySlipId,deliverySlipType,poNo,srmNo}=this.$route.query


            const json={
                abnormalId: null,
                deliverySlipId: deliverySlipId,
                deliverySlipType: deliverySlipType,
                poNo: poNo,
                srmNo: srmNo,
                abnormalType: null,
                abnormalExplain: null,
                partNo: null,
                reqQty: null,
                partName: null,
                submitDatetime: null,
                submitUser: null,
                disposeType: null,
                disposeExplain: null,
                disposeUser: null,
                disposeDatetime: null,
                dataState: 2,
                createBy: null,
                createTime: null,
                updateBy: null,
                updateTime: null,
                delFlag: null,
                version: null
            }
            
            const _json={
                ...json,
                partNo:this.user,     // 物料编码    
                reqQty:this.reqQty,  // 数量
                abnormalType:this.type,     // 异常类型    
                disposeType:this.type2,     // 处理异常类型    
                abnormalExplain:this.abnormalExplain,  // 异常说明
                disposeExplain:this.disposeExplain,  // 处理说明
            }


            const {code,data={}}= await httpHandle({
                url:'/iiot/deliverySlipAbnormal',
                method: 'post',
                payload:_json
            })

            if(code==200){
                showSuccessToast('提交成功！')


                this.$router.push({
                    path:'/storage/take', 
                    query:{ deliverySlipId:deliverySlipId }
                }) 
            }
            
        },


    },
  }
</script>