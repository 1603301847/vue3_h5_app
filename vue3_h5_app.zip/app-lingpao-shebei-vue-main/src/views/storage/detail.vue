<template>
    <span>
        <AppBarPage>


        </AppBarPage>

        <!-- <ScanBarComponents 
            ref="ScanBar"
            placeholder="请扫描或输入 GPS编码"
            @searchClick="barSearchClick"
        />

        <ScanBarComponents 
            ref="ScanBar2"
            placeholder="请扫描或输入 产品序列号"
            @searchClick="barSearchClick2"
        /> -->

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-rocket-launch" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">送货单信息</span>
                </v-col>
                <v-col cols="5">
                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p> -->
                </v-col>
            </v-row>
            <div style="height: 6px;"></div>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">送货单类型:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{  FormatDictionary('ccgl_delivery_slip_type',bufferRow.deliverySlipType)['lable']  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">送货单号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.poNo }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">srm单号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.srmNo }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">送货单状态:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{  FormatDictionary('ccgl_delivery_slip_state',bufferRow.deliverySlipState)['lable']  }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">制表日期:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.creatDate }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">要货日期:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.needDate }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">发货日期:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.sendDatetime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">供应商编码:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.supplierCode }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">供应商名称:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.supplierName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">联系电话:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.sendUserTel }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">仓库编码:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.storageNo }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">仓库名称:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.storageName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">收货人账号:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.signForUserCode }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">收货人名称:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.signForUserName }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">收货时间:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{ bufferRow.signForDatetime }}</p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <p class="font-weight-medium text">是否上报:</p>
                </v-col>
                <v-col cols="8">
                    <p class="font-weight-light text-left">{{  FormatDictionary('sys_yes_no',bufferRow.sendState)['lable']  }}</p>
                </v-col>
            </v-row>




        </v-sheet>


        <v-sheet elevation="2" rounded class="custem-card" >
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-card-bulleted-outline" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">物料明细</span>
                </v-col>
                <v-col cols="5">
                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p> -->
                </v-col>
            </v-row>
            <div style="padding: 6px 6px;">
                <TableComponents
                    ref="table1"
                    :children="list1"
                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="5">
                                    <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                    <!-- <p class="text-truncate font-weight-medium font-weight-light">点检设备</p> -->
                                </v-col>
                                <v-col cols="1" class="text-right">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料编码:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.partNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料名称:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.partName  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">采购订单号:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.refNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">数量:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.reqQty  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料批次:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.batch  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">生产日期:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.wipDate  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">是否关键件:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{  FormatDictionary('sys_yes_no',props.items.isKeySpareParts)['lable']  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">检验类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{  FormatDictionary('srm_testing_state',props.items.testingState)['lable']  }}</p>
                                </v-col>
                            </v-row>
   
    

                            <span v-if="props.items.deliverySlipType !='1' ">
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">工位编码:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="font-weight-light">{{ props.items.ulocNo  }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">工位名称:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="font-weight-light">{{ props.items.ulocName  }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">点位编码:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="font-weight-light">{{ props.items.positionNo  }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">订单号:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="font-weight-light">{{ props.items.orderNo  }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">机号:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="font-weight-light">{{ props.items.sn  }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">交货单号:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="font-weight-light">{{ props.items.dnNo  }}</p>
                                    </v-col>
                                </v-row>
                                <v-row no-gutters class="text">
                                    <v-col cols="4">
                                        <p class="font-weight-medium text">交货单行号:</p>
                                    </v-col>
                                    <v-col cols="8">
                                        <p class="font-weight-light">{{ props.items.poRow  }}</p>
                                    </v-col>
                                </v-row>
                            </span>

                        </v-card>
                    </template>
                </TableComponents>
            </div>

        </v-sheet>


        <v-sheet elevation="2" rounded class="custem-card" >
            <v-row no-gutters class="custem-card-title">
                <v-col cols="7">
                    <v-icon icon="mdi-alert-circle-outline" size="16" color="error"></v-icon>
                    <span class="font-weight-medium">异常明细</span>
                </v-col>
                <v-col cols="5">
                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ bufferRow.abnormalNo }}</p> -->
                </v-col>
            </v-row>
            <div style="padding: 6px 6px;">
                <TableComponents
                    ref="table2"
                    :children="list2"
                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="5">
                                    <!-- <p class="text-truncate font-weight-light">{{ props.items.partName }}</p> -->
                                    <!-- <p class="text-truncate font-weight-medium font-weight-light">点检设备</p> -->
                                </v-col>
                                <v-col cols="1" class="text-right">
                                    <!-- <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> -->
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料编码:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.partNo  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">物料名称:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.partName  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">数量:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.reqQty  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">异常类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ FormatDictionary('ccgl_abnormal_type',props.items.abnormalType)['lable']  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">异常说明:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.abnormalExplain  }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">提报时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ props.items.submitDatetime  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">提报人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{  props.items.submitUser  }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">处理类型:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{  props.items.disposeType }}</p>
                                </v-col>
                            </v-row>
   
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">处理说明:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{  props.items.disposeExplain }}</p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">处理人:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{  props.items.disposeUser }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">处理时间:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{  props.items.disposeDatetime }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4">
                                    <p class="font-weight-medium text">数据状态:</p>
                                </v-col>
                                <v-col cols="8">
                                    <p class="font-weight-light">{{ FormatDictionary('ccgl_abnomal_state',props.items.dataState)['lable']  }}</p>
                                </v-col>
                            </v-row>

                        </v-card>
                    </template>
                </TableComponents>
            </div>

        </v-sheet>

        <div style="height: 62px;"></div>
    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'

    import ScanBarComponents from '@/packages/ScanBar.vue'
    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast,showFailToast,showToast } from 'vant';
    import TableComponents from '@/packages/Table.vue'



  export default {
    components:{
        AppBarPage,
        ScanBarComponents,
        TableComponents
    },
    data: () => ({
        bufferRow: {},


        list1:[],  // 物料明细
        list2:[],  // 异常明细


    }),
    created(){
        this.initFunc()
    },
    methods: {
        // 全局 气泡 提示
        GlobalTooltipFunc(text=""){
            showToast({
                message:text,
                overlay:true,
                closeOnClickOverlay:true,
                duration:0
            })
        },
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化
        async initFunc(){
            const {deliverySlipId=''}=this.$route.query

            const {code,data={}}= await httpHandle({
                url:`/iiot/deliverySlip/all/${deliverySlipId}`,
                method:'get',
            })

            if(code==200){
                this.bufferRow=data.deliverySlip   // 基础数据

                this.list1=data.partList  // 物料明细
                this.list2=data.abnormalList  // 异常明细

                this.$nextTick(()=>{
                    this.$refs.table1.initFunc()
                    this.$refs.table2.initFunc()


                })
            }
        },
        // 头部 查询 111
        async barSearchClick(value=''){
            const _value=value.trim()

            const {code,data=[]}= await httpHandle({
                url:'/iiot/qmTask/listQmTaskSnForSelect',
                method: "get",
                url_params:{
                    sn: _value
                }
            })

            if(code==200){

                if(!data.length){
                    showFailToast("SN号不存在！")
                    return
                }    

                // this.ttPpOrderSnId=data[0]?.ttPpOrderSnId
                showSuccessToast("扫描成功！")


            }
        },
        // 扫码  参评序列号
        barSearchClick2(value=''){

        },
        // 绑定
        async submit(){
            
        }



    },
  }
</script>
