<template>
    <span>
        <AppBarPage>
            <!-- <template v-slot:appTabs>
                <v-tabs
                    v-model="tab"
                    density="comfortable"
                    align-with-title
                >
                    <v-tab value="1">当前点检任务</v-tab>
                    <v-tab value="2">我的点检任务</v-tab>
                </v-tabs>
            </template> -->
        </AppBarPage>
        <!-- <div style="height: 50px;"></div> -->
        <v-btn style="width:58px;height:58px;position:fixed;top:286px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="primary" @click="searchFunc">查询</v-btn>
        <v-btn style="width:58px;height:58px;position:fixed;top:352px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="restFunc">重置</v-btn>
        
        <!-- <v-btn style="width:58px;height:58px;position:fixed;top:418px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="secondary" @click="selectAllFunc">全选</v-btn>
        <v-btn style="width:58px;height:58px;position:fixed;top:483px;right:16px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="sumitFunc">提交<br/>点检</v-btn> -->


                <ScanBarComponents 
                    ref="scanBar1"
                    placeholder="扫描或输入 设备"
                    @searchClick="barSearchClick"
                />


                <!-- <van-field
                    v-model="fieldValue"
                    is-link
                    readonly
                    label="工厂节点"
                    placeholder="请选择工厂节点"
                    type="textarea"
                    autocomplete="off"
                    :autosize=" { maxHeight: 100, minHeight: 32 }"
                    @click="show = true"
                />
                <van-popup v-model:show="show" round position="bottom">
                    <v-row no-gutters class="text">
                        <v-col cols="6">
                        <v-btn
                            block
                            color="warning"
                            elevation="0"
                            style="border-radius: 0px;"
                            @click="factoryReset"
                        >
                            重置
                        </v-btn>
                    </v-col>
                    <v-col cols="6">
                        <v-btn
                            block
                            color="cyan"
                            elevation="0"
                            style="border-radius: 0px;"
                            @click="factoryAffirm"
                        >
                            确定
                        </v-btn>
                    </v-col>
                    </v-row>


                    <van-cascader
                        v-if="hideFactory"
                        v-model="factoryID"
                        title="请选择工厂节点"
                        :options="options"
                        active-color="#4CAF50"
                        :field-names="{text:'nodeLevelName',value:'tmBasNodeLevelId',children:'children'}"
                        @close="show = false"
                        @change="onFinish"
                    />
                </van-popup> -->


                <SelectComponents 
                    v-model="area"
                    ref="select778"
                    label="计量区域"
                    showSearch
                    :option="areaSelectOption"
                    @onChange="areaOnChange"
                    @onSearchChange="areaSearchChange"
                />
                


                <SelectComponents 
                    v-model="process"
                    ref="select123"
                    label="设备"
                    showSearch
                    :option="processSelectOption"
                    @onChange="processOnChange"
                    @onSearchChange="equipmentSearchChange"

                />


        <v-window v-model="tab">
            <v-window-item value="1" class="v-window-item-table">



                <TableComponents
                    v-if="tab=='1'"
                    ref="table1"
                    url="/iiot/collectParameters/findEnergyRecordManually"
                    :showSearchBtn="!true"
                    :params="{
                        tmBasEquipmentAreaId:_tmBasEquipmentAreaId,
                        lineNo: nodeCode,   // 产线编码 
                        equipmentNo: process, // 设备编码 
                        // pageSize:pageSize,
                        // params:{typeList:['dj']},

                        // // equipmentType:process,       // 设备类型
                        // tmBasNodeLevelId:factoryID,  // 工厂

                        // typeList:['N','C'],
                        // tmBasEquipmentTypeId:process,    // 设备类型
                        // // taskState:'N',

                        // tmBasEquipments:tmBasEquipments,
                        // ...pageSearchConfig1
                    }"
                    method="get"
                    refreshFunc
                    @searchClick="searchClick1"
                    @refresh="refreshTable"

                >
                    <template v-slot:tableBody="props">
                        <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="12">
                                    <!-- <van-checkbox v-model="props.items._checked" checked-color="#4CAF50" shape="square" style="position:relative;top:4px;display:inline-block;margin-right:12px;"></van-checkbox> -->
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                    <!-- <span class="font-weight-medium">点检设备</span> -->
                                    
                                </v-col>
                                <!-- <v-col cols="5">

                                    <span class="font-weight-medium">点检设备</span>
                                </v-col>
                                <v-col cols="3">

                                    <p class="text-truncate font-weight-medium text-right text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p> 
                                </v-col> -->
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text ">电表:</span>
                                        <span>{{ props.items.equipmentName  }}</span> 
                                    </p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text ">电表型号:</span>
                                        <span>{{ props.items.deviceModel  }}</span> 
                                    </p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text ">计量区域:</span>
                                        <span>{{ props.items.equipmentAreaName  }}</span> 
                                    </p>
                                </v-col>
                            </v-row>

                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text ">上次读表数据:</span>
                                        <span style="color: aqua;">{{ props.items.endVal  }} KM.h</span> 
                                    </p>
                                </v-col>
                            </v-row>

                            <UploaderImageComponents 
                                :initPath="props.items.energyPicture"
                                preview
                            />

                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item>

            <!-- <v-window-item value="2" class="v-window-item-table">
                <ScanBarComponents 
                    ref="scanBar2"
                    placeholder="扫描或输入 区域码"
                    @searchClick="barSearchClick2"
                />
                <TableComponents
                    v-if="tab=='2'"
                    ref="table2"
                    url="/iiot/checkTask/listForApp"
                    :showSearchBtn="true"
                    :params="{
                      params:{typeList:['dj']},
                        taskState:'C',
                        tmBasEquipments:tmBasEquipments,
                        ...pageSearchConfig2
                    }"
                    method="post"
                    @searchClick="searchClick2"
                    refreshFunc
                    @refresh="refreshTable"

                >
                <template v-slot:tableBody="props">
                    <v-card>
                            <v-row no-gutters class="table-title">
                                <v-col cols="1">
                                    <v-badge :content="props._index+1" color="primary" inline></v-badge>
                                </v-col>
                                <v-col cols="5">
                                    <span class="font-weight-medium">点检设备</span>
                                </v-col>
                                <v-col cols="1">
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="12">
                                    <p class="font-weight-medium text-left text-teal-lighten-1" color="primary">{{ props.items.equipmentName }}</p>
                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                   
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">点检类型:   </span>
                                        {{ FormatDictionary('CHECK_TYPE',props.items.taskType)['lable']   }}
                                    </p>
                                </v-col>
                                <v-col cols="6">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">申请人:    </span>
                                        {{ props.items.createBy  }}
                                    </p>
                                </v-col>
             
                            </v-row>
  
                            <v-row no-gutters class="text">
           
                                <v-col cols="12">
                                    <p class="text-truncate font-weight-light">
                                        <span class="font-weight-medium text">申请时间:   </span>
                                        {{ props.items.createDate  }}
                                    </p>

                                </v-col>
                            </v-row>
                            <v-row no-gutters class="text">
                                <v-col cols="4" class="text-center">

                                </v-col>
                                <v-col cols="4" class="text-center">
                                    <v-btn @click="cancelHandle(props)" color="error mt-1" density="compact" :rounded="0" variant="plain">取消点检</v-btn>
                                </v-col>
                                <v-col cols="4" class="text-right">
                                    <v-btn @click="experienceEdit(props)" color="orange mt-1" density="compact" :rounded="0" variant="plain">点检</v-btn>
                                </v-col>
                            </v-row>
                        </v-card>
                    </template>
                </TableComponents>
            </v-window-item> -->
        </v-window>






    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'  // 点检设备  点检记录
    import TableComponents from '@/packages/Table.vue'
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import SelectComponents from '@/packages/Select.vue'

    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import {FormatTree} from '@/utils/data'   // utils

    import {httpHandle} from '@/http/http'  // api


    import { showSuccessToast,showFailToast } from 'vant'
    import { showDialog  } from 'vant'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'




  export default {
    components:{
        AppBarPage,

        SelectComponents,
        ScanBarComponents,
        UploaderImageComponents,
        TableComponents
    },
    data: () => ({
        pageSize:10,
        factoryShow:true,  // 显示 工厂
        nodeCode:"",
        fieldSelectValue:{},

        hideFactory:true,
        drawer: false,
        show:false,   // 工厂 show
        fieldValue:"",  // 工厂显示值
        options:[],    // 工厂 数据
        factoryID:"",   // 工厂选中ID


        tab: '1',
        _tmBasEquipmentAreaId:"",

        area:"",   // 计量区域 
        areaSelectOption:[],   // 计量区域 数据

        process:"",   // 设备类型 
        processSelectOption:[],   // 设备类型 数据

        bufferTree:[],   // 工厂数据

        pageSearchConfig1:{},  // 查询信息   11
        pageSearchConfig2:{},  // 查询信息   22


        tmBasEquipments:[],   // 设备ID 数组
        showSelect:true,
        tmBasNodeLevelId:"",   // 设备ID
        equipment:"",  // 设备
        equipmentSelectOption:[],   // 设备 数据
        equipmentSelectOptionData:[],  // 设备 原始 数据
    }),
    created(){
        // this.initFunc()
        this.getContentHttp()  // 设备

        // this.factoryTreeHTTP()
        // this.refreshTable()



        this.areaHttp()  // 计量区域

    },
    methods: {
        // 数据字典 格式化
        FormatDictionary(key="",valueKey=""){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")
            const _obj=(_bufferDictionaries[key] || [] )
            const _option=_obj.filter(o=>valueKey==o.value)[0]||{}
            return _option
        },
        // 初始化 工厂
        async initFunc(noOrName="",callBack){
            // const {data=[]} = await FactoryTreeHTTP()
            // const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")

            // this.bufferTree=data
            // // console.log(_tree)
            // this.options=_tree
            
            const {code,data=[]}= await httpHandle({
                url:'/iiot/nodeLevel/getNodeLevelByLineNode',
                method:"get",
                url_params:{
                    noOrName:noOrName
                }
            }) 

            if(code==200){
                const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")

                this.bufferTree=data
                this.options=_tree

                callBack && callBack()
            }


        },
        // 计量区域 数据
        async areaHttp(name=""){

            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipmentArea/findEquipmentArealist',
                method:"get",
                url_params:{
                    enabled:1,
                    name:name
                }
            }) 

            if(code==200){
                this.areaSelectOption=data.map(o=>Object.assign({
                    text:`${o.name}`,
                    value:o.tmBasEquipmentAreaId
                }))  
            }
        }, 
        // 设备类型 数据
        async getContentHttp(equipmentNo="",tmBasEquipmentAreaId=""){
            const {nodeCode=''}=this

            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipment/getEquipmentByKey',
                method:"get",
                url_params:{
                    tmBasEquipmentAreaId:tmBasEquipmentAreaId,// 计量区域
                    nodeCode:nodeCode,    // 产线编码
                    equipmentNo:equipmentNo,   // 设备编码
                }

            }) 

            if(code==200){
                this.processSelectOption=data.map(o=>Object.assign({
                    text:`${o.equipmentNo}-${o.equipmentName}`,
                    value:o.equipmentNo
                }))  

                // this.$nextTick(()=>{

                //     // v-model="process"
                //     // ref="select123"

                //     const _process=(localStorage.getItem("examineHistory_index_buffer_equipment_value")||'')
                //     // console.log(_process)
                //     if(_process){
                //         this.process=_process
                //         this.$refs.select123 && this.$refs.select123.setValue( _process )  // 设备
                    
                    
                //         this.$nextTick(()=>{
                //             setTimeout(()=>{
                //                 this.$refs.table1.initFunc(1)
                //             },1000)
                //         })
                //     }


                // })
            }
        }, 
        // 工厂 完成
        onFinish ({ selectedOptions }){


            if(!selectedOptions.length) return

            // tmBasNodeLevelId:“465621691089092608
            let _tmBasNodeLevelId= (selectedOptions[ selectedOptions.length-1 ]||{})["tmBasNodeLevelId"]

            this.factoryID=_tmBasNodeLevelId
            this.fieldValue = selectedOptions.map((o) => o.nodeLevelName).join('/')
            

            this.fieldSelectValue=selectedOptions[selectedOptions.length-1]||{}
            // console.log( selectedOptions )
            // this.fieldValue=""   // 工厂显示值

            // this.$nextTick(()=>{
            //     const _json={
            //         id:_tmBasNodeLevelId,
            //         text: this.fieldValue
            //     }
            //     localStorage.setItem("examineHistory_index_buffer_nodeLevel_option",JSON.stringify(_json))
            // })

        },
        // 工厂确定
        async factoryAffirm(){
            this.show=false



            // this.$nextTick(()=>{
            //         this.$refs.selectContent.showModle()
            // })
            // this.$nextTick(()=>{
            //     this.searchHandle()
            // })
            

            
            this.$nextTick(async ()=>{
                this.nodeCode=this.fieldSelectValue.nodeLevelNo


                this.$nextTick( async ()=>{
                    await this.getContentHttp()
                    this.$refs.select123.showModle()
                })           
            })

        },
        // table 刷新
        refreshTable(){

            // this.$refs["scanBar1"] && this.$refs["scanBar1"].reset()
            // this.$refs["scanBar2"] && this.$refs["scanBar2"].reset()
            // this.tmBasEquipments=[]

            this.$nextTick(()=>{
                if(this.tab=="1"){
                    this.$refs.table1.initFunc(1,{})
                }

                if(this.tab=="2"){
                    this.$refs.table2.initFunc(1,{})
                }
            })

        },
        // 计量区域
        async areaSearchChange(key=""){
            this.areaHttp(key)
        },
        // 设备查询
        async equipmentSearchChange(key=""){
            this.getContentHttp(key)
        },
        // 初始化 设备 
        async equipmentHTTP(keyNo=""){
            // const {tmBasNodeLevelId}=this
            // // 展示  equipmentNo +  equipmentName  值  tmBasEquipmentId
            // const {code,data=[]}= await httpHandle({
            //     url:'/iiot/equipment/list',
            //     method:"get",
            //     url_params:{
            //         tmBasNodeLevelId: tmBasNodeLevelId,
            //         equipmentNo:keyNo
            //     }

            // }) 

            // if(code==200){
            //     this.equipmentSelectOptionData=data
            //     this.equipmentSelectOption=data.map(o=>Object.assign({
            //         text:`${o.equipmentNo}-${o.equipmentName}`,
            //         value:o.tmBasEquipmentId
            //     })).splice(0,100)  
            // }
        },
        // 设备 选中
        equipmentConfirm(value=''){
            // const _obj=this.equipmentSelectOptionData.filter(o=>o.tmBasEquipmentId==value)[0]||{}
            
            this.tmBasEquipments=(value?value.split(","):[])


            this.$nextTick(()=>{
                if(this.tab=="1"){
                    this.$refs.table1.initFunc(1,{})
                }

                if(this.tab=="2"){
                    this.$refs.table2.initFunc(1,{})
                }
            })
        },
        // 计量区域  切换
        async areaOnChange(value=""){
            // tmBasEquipmentAreaId

            this._tmBasEquipmentAreaId=value
            await this.getContentHttp('',value)

            this.$nextTick( async ()=>{
                this.$refs.select123.showModle()
            })  
        },
        // 工厂数据
        async factoryTreeHTTP(){



            const {data=[]} = await FactoryTreeHTTP()
            this.bufferTree=data

            // 初始化

            // this.$nextTick(()=>{
            //     const _option=JSON.parse( (localStorage.getItem("examineHistory_index_buffer_nodeLevel_option")||'{}') )
            //     // console.log(_option)
            //     if(_option.id){
            //         this.hideFactory=false
            //         this.factoryID=_option.id

            //         this.$nextTick(()=>{
            //             this.hideFactory=true
            //             this.fieldValue=_option.text // 工厂显示值

                        
            //             this.$nextTick(()=>{
            //                 setTimeout(()=>{
            //                     this.$refs.table1.initFunc(1)
            //                 },1000)
            //             })

            //         })
            //     }


            // })

        },
        // 点检 111
        async experienceEditTo(props){
            const {items}=props

            const {code}= await httpHandle({
                    url:"/iiot/checkTask/checkTask",
                    method:'post',
                    payload:{
                        ttCheckTaskId:items.ttCheckTaskId
                    }
                })


                if(code==200){
                    showSuccessToast('提交成功！')

                    this.tab='1'
                    this.$nextTick(()=>{
                        this.$refs.table1.initFunc()
                    })
                }
        },
        // 点检
        async experienceEdit(props){
            const {items}=props


            this.$router.push({
                path:'/examineHistory/detail',
                query:{ttCheckTaskId: items.ttCheckTaskId,row: JSON.stringify(items) }
            })

            setTimeout(() => {
                this.$root.$emitter.emit("update_examineHistory_page_index")
            }, 1000);

        },
        // 设备 change 
        processOnChange(value=''){
            // localStorage.setItem("examineHistory_index_buffer_equipment_value",value)
        },
        // 取消点检
        async cancelHandle(props){
            const {items}=props

            showDialog({
                title: '取消确认',
                message: '取消后数据不可恢复，确认取消！',
                theme: 'round-button',
                closeOnClickOverlay:true,
            }).then(async () => {


                const {code}= await httpHandle({
                    url:"/iiot/checkTask",
                    method:'PUT',
                    payload:{
                        "ttCheckTaskId": items.ttCheckTaskId, // 当前数据ttCheckTaskId字段 点检任务id
                        "taskState": 'N'    // 前数据 taskState  点检状态 修改状态为'N'",
                    }
                })


                if(code==200){
                    showSuccessToast('提交成功！')

                    this.tab='1'
                    this.$nextTick(()=>{
                        this.$refs.table1.initFunc()
                    })
                }


            });




        },
        // 头部 查询 11
        async barSearchClick(value=''){
            const _value=value.trim()
            await this.getContentHttp(_value)

            this.$nextTick(()=>{
                this.$refs.select123.showModle()
            })

            // this.factoryReset()  // 工厂 重置

            // this.initFunc(_value,()=>{
            //     this.show=true
            // })

            // const _newList=this.bufferTree.filter(o=>o.nodeLevelNo==_value)[0]||{}
            // if(!_newList.tmBasNodeLevelId){
            //     showFailToast("无工厂节点！")
            //     return
            // }

            // this.showSelect=false
            // this.tmBasNodeLevelId=_newList.tmBasNodeLevelId
            // this.$nextTick(async()=>{

            //     this.showSelect=true
            //     await this.equipmentHTTP("")

                
            //     this.$nextTick(()=>{
            //         this.$refs.selectContent.showModle()
            //     })
            // })

        },
        // 工厂 重置
        factoryReset(){
            this.fieldValue=""   // 工厂显示值
            this.fieldSelectValue={}  // 工厂选中值
            this.nodeCode=""
            this.show = false
            this.getContentHttp()


            this.hideFactory=false
            this.$nextTick(()=>{
                this.hideFactory=true
            })
        },
        // 头部 查询 22
        async barSearchClick2(value=''){
            // const _value=value.trim()

            // const _newList=this.bufferTree.filter(o=>o.nodeLevelNo==_value)[0]||{}
            // if(!_newList.tmBasNodeLevelId){
            //     showFailToast("无工厂节点！")
            //     return
            // }

            // this.showSelect=false
            // this.tmBasNodeLevelId=_newList.tmBasNodeLevelId
            // this.$nextTick(async()=>{

            //     this.showSelect=true
            //     await this.getContentHttp("")

            //     this.$nextTick(()=>{
            //         this.$refs.selectContent.showModle()
            //     })
            // })

        },
        // 查询 11
        searchClick1(){
            // this.$refs.searchPage1.showDrawer()
        },
        // 查询结果 11
        searchHandle1(option){
            // this.pageSearchConfig1=option
            // this.$nextTick(()=>{
            //     this.$refs.table1.initFunc(1)
            // })
        },
        // 查询 重置 11
        resetHandle1(opiton){
            // this.pageSearchConfig1={}
            // this.$nextTick(()=>{
            //     this.$refs.table1.initFunc(1)
            // })

        },
        // 查询 22
        searchClick2(){
            // this.$refs.searchPage2.showDrawer()
        },
        // 查询结果 22
        searchHandle2(option){
            // this.pageSearchConfig2=option
            // this.$nextTick(()=>{
            //     this.$refs.table2.initFunc(1)
            // })
        },
        // 查询 重置 22
        resetHandle2(opiton){
            // this.pageSearchConfig2={}


            // this.$nextTick(()=>{
            //     this.$refs.table2.initFunc(1)
            // })

        },
        // tabble 全选
        selectAllFunc(){
            // this.$refs.table1.selectAll()
        },
        // 提交点检
        async sumitFunc(){
            // const _select=this.$refs.table1.resultData().filter(o=>o._checked)
            // // console.log(_select)

            // if(!_select.length){
            //     showFailToast('未选择数据！')
            //     return
            // }

            // // let _newList= new Set( _select.map(o=>o.equipmentType) )


            // // if(_newList.length>1){
            // //     showFailToast('设备类型不一致，不能批量提交！')
            // //     return
            // // }

            // const {code,data=[]}= await httpHandle({
            //     url:'/iiot/checkTask/checkTask',
            //     method: "post",
            //     payload:{
            //         ttCheckTaskId: _select[0]?.ttCheckTaskId
            //     }
            // })

            // if(code==200){
            //     const _json={
            //         checkTaskRecords: data.map(o=> Object.assign({
            //             checkResult: o.checkResult||'',
            //             checkResultContent:o.checkResultContent||'',
            //             inspectValue:o.inspectValue||'',
            //             judgmentResult: o.judgmentResult||'',
            //             ttCheckTaskId: o.ttCheckTaskId||'',
            //             ttCheckTaskRecordId: o.ttCheckTaskRecordId||'',
            //             ttCheckTaskIds: _select.map(o=>o.ttCheckTaskId),
            //         }) )
            //     }


            //     const _result= await httpHandle({
            //         // url:'/iiot/checkTaskRecord/submitCheckTaskRecord',
            //         url:'/iiot/checkTaskRecord/submitCheckTaskRecords',
            //         method: "post",
            //         payload:_json
            //     })


            //     if(_result.code==200){
            //         showSuccessToast("提交成功！")
            //         this.$refs.table1.initFunc(1)
            //     }

            // }


        },
        // 重置
        restFunc(){
            this.fieldValue="" // 工厂显示值
            this.factoryID=""  // 工厂选中ID

            this.area=""   // 计量区域

            this.$refs["scanBar1"] && this.$refs["scanBar1"].reset()

            this.fieldSelectValue={}   // 工厂选中ID
            this.process=''  // 设备类型
            // this.pageSize=10


            this.hideFactory=false
            this.$nextTick(()=>{
                this.hideFactory=true

                this.$refs.select123 && this.$refs.select123.reset()

                this.$refs.select778 && this.$refs.select778.reset()

                

                this.$refs.table1.initFunc(1)
                this.getContentHttp()

            })
        },
        // 查询
        searchFunc(){
            // this.pageSize=50

            this.$nextTick(()=>{
                this.$refs.table1.initFunc(1)
            })
        }
    },
  }
</script>
<style lang="scss">
.hide-select-equipment-input{
    >span >div.van-cell {
        visibility: hidden;
    }
}
</style>