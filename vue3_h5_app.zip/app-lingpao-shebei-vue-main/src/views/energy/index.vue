<template>
    <span>
        <AppBarPage>
        </AppBarPage>


        <!-- <ScanBarComponents 
            placeholder="扫描或输入 产线"
            @searchClick="barSearchClick"
        /> -->

        <v-btn style="position:fixed;top:160px;right:26px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="secondary" @click="searchHandle">查询</v-btn>
        <v-btn style="position:fixed;top:222px;right:26px;z-index: 11;color: #fff !important;" icon="mdi-plus" color="warning" @click="restFunc">重置</v-btn>


        <ScanBarComponents 
            ref="scanBar1"
            placeholder="扫描或输入 设备"
            @searchClick="barSearchClick2"
        />

        <v-sheet elevation="2" rounded class="pa-1">
            <!-- <van-field
                v-model="fieldValue"
                is-link
                readonly
                label="工厂节点"
                placeholder="请选择工厂节点"
                type="textarea"
                autocomplete="off"
                
                @click="show = true"
            />
            <van-popup v-model:show="show" round position="bottom">
                <v-row no-gutters class="text">
                    <v-col cols="6">
                        <v-btn
                            block
                            color="warning"
                            elevation="0"
                            style="border-radius: 0px;"
                            @click="factoryReset"
                        >
                            重置
                        </v-btn>
                    </v-col>
                    <v-col cols="6">
                        <v-btn
                            block
                            color="cyan"
                            elevation="0"
                            style="border-radius: 0px;"
                            @click="factoryAffirm"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>

                <van-cascader
                    v-if="factoryShow"
                    title="请选择工厂节点"
                    :options="options"
                    active-color="#4CAF50"
                    :field-names="{text:'nodeLevelName',value:'tmBasNodeLevelId',children:'children'}"
                    @close="show = false"
                    @change="onFinish"
                />
            </van-popup> -->

            <SelectComponents 
                v-model="area"
                ref="select778"
                label="计量区域"
                showSearch
                :option="areaSelectOption"
                @onChange="areaOnChange"
                @onSearchChange="areaSearchChange"
            />

            <SelectComponents 
                v-model="equipment"
                ref="selectContent"
                label="设备"
                placeholderSearch="请输入设备编号"
                showSearch
                :option="equipmentSelectOption"
                @onFieldClick="onEquipmentFieldClick"
                @onSearchChange="equipmentSearchChange"
                @onChange="equipmentConfirm"
            />

        </v-sheet>
        <div style="height:12px"></div>

        <!-- <v-sheet elevation="2" rounded class="pa-2">
            <div style="border-bottom: 1px solid #ccc;margin-bottom: 16px;">
                <v-icon icon="mdi-table" size="16" color="primary"></v-icon>
                设备列表
            </div>

            <v-row v-if="tableList.length" v-for="(o,i) in tableList" :key="i" style="padding: 0px 4px;margin:12px 0px 12px 0px" no-gutters class="text">
                <v-col cols="10">
                    <p class="text-truncate font-weight-medium text">{{ `${o.equipmentNo}-${o.equipmentName}` }}</p>
                </v-col>
                <v-col cols="2" class="text-right">
                    <v-icon @click="removeIcon(o)" icon="mdi-delete-forever" size="26" color="error"></v-icon>
                </v-col>
            </v-row>
            <p v-else class="text-center" >
                <v-icon icon="mdi-emoticon-sad-outline" style="position:relative;top:-2px"></v-icon>
                无数据！
            </p>
        </v-sheet> -->

        <!-- <div style="height:12px"></div> -->

        <!-- <v-sheet elevation="2" rounded class="pa-2">
            <div style="height: 12px;"></div>
            <v-row no-gutters class="text">
                <v-col cols="4">
                    <v-icon icon="mdi-power-socket-uk" size="16" color="primary"></v-icon>

                    点检类型
                </v-col>
                <v-col cols="8">
                    <van-checkbox v-model="checked1" disabled shape="square" style="margin-top:2px;">设备</van-checkbox>
                </v-col>
            </v-row>
            <div style="height: 12px;"></div>

            <v-row no-gutters class="text">
                <v-col cols="4">
                    <v-icon icon="mdi-zodiac-aquarius" size="16" color="primary"></v-icon>
                    应用范围
                </v-col>
                <v-col cols="8">
                    <van-checkbox v-model="checked2" disabled shape="square" style="margin-top:2px;">设备</van-checkbox>
                </v-col>
            </v-row>
            <div style="height:12px;"></div>
        </v-sheet> -->
        <div style="height:12px;"></div>

        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-alert-circle" size="16" color="warning"></v-icon>
                    <span class="font-weight-medium">历史数据</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light font-weight-medium">
                        <span>产线:</span>
                        <span style="color: aqua;padding-left: 12px;">{{ bufferRow.lineName  }}</span>
                    </p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light font-weight-medium">
                        <span>电表:</span>
                        <span style="color: aqua;padding-left: 12px;">{{ bufferRow.equipmentName  }}</span>
                    </p>
                </v-col>
            </v-row>
            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light font-weight-medium">
                        <span>电表型号:</span>
                        <span style="color: aqua;padding-left: 12px;">{{ bufferRow.deviceModel  }}</span>
                    </p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="text-truncate font-weight-light">
                        <span class="font-weight-medium text ">计量区域:</span>
                        <span>{{ bufferRow.equipmentAreaName  }}</span> 
                    </p>
                </v-col>
            </v-row>

            <v-row no-gutters class="text">
                <v-col cols="12">
                    <p class="font-weight-light font-weight-medium">
                        <span>上次读表数据:</span>
                        <span style="color: aqua;padding-left: 12px;padding-right: 12px;">{{ bufferRow.endVal  }}</span>
                        KW.h
                    </p>
                </v-col>
            </v-row>

            <UploaderImageComponents 
                v-model="bufferFileListPreview"
                preview
            />

        </v-sheet>


        <v-sheet elevation="2" rounded class="custem-card">
            <v-row no-gutters class="custem-card-title">
                <v-col cols="6">
                    <v-icon icon="mdi-plus" size="16" color="primary"></v-icon>
                    <span class="font-weight-medium">数据录入</span>
                </v-col>
                <v-col cols="6">
                    <!-- <p @click="checkExpress" class="font-weight-medium text-right text-teal-lighten-1" color="primary">查看维修经验</p> -->
                </v-col>
            </v-row>
 
            <van-field v-model="text1" placeholder="请输入" autocomplete="off" type="number" label="用电累积数">
                <template #button>
                    KW.h
                </template>
            </van-field>

            <van-field v-model="text2" placeholder="请输入" autocomplete="off" type="number" label="电流量">
                <template #button>
                    A
                </template>
            </van-field>
            <van-field v-model="text3" placeholder="请输入" autocomplete="off" type="number" label="电压量">
                <template #button>
                    V
                </template>
            </van-field>


            <UploaderImageComponents 
                v-model="bufferFileList"
            />


        </v-sheet>

        <v-row no-gutters class="text">
            <v-col cols="12">
                <v-btn @click="submit" block color="primary">
                    提交
                </v-btn>
            </v-col>
        </v-row>


    </span>
</template>
<script>
    import AppBarPage from '@/components/AppBar.vue'   // 设备报修
    import ScanBarComponents from '@/packages/ScanBar.vue'
    import SelectComponents from '@/packages/Select.vue'
    import UploaderImageComponents from '@/packages/UploaderImage.vue'

    import { showSuccessToast,showFailToast } from 'vant'

    
    import {FactoryTreeHTTP} from '@/http/equipment/repairs'   // api
    import {httpHandle} from '@/http/http'  // api
    
    import {FormatTree} from '@/utils/data'   // utils


  export default {
    components:{
        AppBarPage,
        SelectComponents,
        UploaderImageComponents,
        ScanBarComponents
    },
    data: () => ({
        factoryShow:true,  // 显示 工厂
        bufferFileListPreview:[],   // 图片预览


        checked1:true,  
        checked2:true,  
        bufferTree:[],   // 缓存树结构

        bufferRow:{},   // 数据
        nodeCode:"",  // 产线编码
        bufferFileList:[],  // 缓存图片

        tableList:[],  // 列表


        text1:"",  // 
        text2:"",  // 
        text3:"",  // 



        show:false,   // 工厂 show
        fieldValue:"",  // 工厂显示值
        fieldSelectValue:{},  // 工厂选中值
        options:[],    // 工厂 数据


        area:"",   // 计量区域 
        areaSelectOption:[],   // 计量区域 数据

        equipment:"",  // 设备
        equipmentSelectOption:[],   // 设备 数据
        equipmentSelectOptionData:[],  // 设备 原始 数据

    }),
    created(){
        // this.initFunc()
        this.equipmentHTTP()

        this.areaHttp()  // 计量区域

    },
    methods: {
        // 初始化 工厂
        async initFunc(noOrName="",callBack){
            // const {data=[]} = await FactoryTreeHTTP()
            // const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")

            // this.bufferTree=data
            // // console.log(_tree)
            // this.options=_tree
            
            const {code,data=[]}= await httpHandle({
                url:'/iiot/nodeLevel/getNodeLevelByLineNode',
                method:"get",
                url_params:{
                    noOrName:noOrName
                }
            }) 

            if(code==200){
                const _tree=FormatTree(data,"tmBasNodeLevelId", "parentId")

                this.bufferTree=data
                this.options=_tree

                callBack && callBack()
            }


        },
        // 初始化 设备 
        async equipmentHTTP(equipmentNo="",tmBasEquipmentAreaId=""){
            const {fieldSelectValue={},nodeCode=''}=this


            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipment/getEquipmentByKey',
                method:"get",
                url_params:{
                    tmBasEquipmentAreaId:tmBasEquipmentAreaId,  // 计量区域
                    nodeCode:nodeCode,    // 产线编码
                    equipmentNo:equipmentNo,   // 设备编码
                }

            }) 

            if(code==200){
                this.equipmentSelectOptionData=data
                this.equipmentSelectOption=data.map(o=>Object.assign({
                    text:`${o.equipmentNo}-${o.equipmentName}`,
                    value:o.equipmentNo
                }))
            }
        },
        // 头部 查询
        async barSearchClick(value){
            // console.log(value)
            const _value=value.trim()
            const {bufferTree}=this


            this.factoryReset()  // 工厂 重置

            this.initFunc(_value,()=>{
                this.show=true
            })


            // const _newList=bufferTree.filter(o=>o.nodeLevelNo==_value)[0]||{}
            // if(!_newList.tmBasNodeLevelId){
            //     showFailToast("无工厂节点！")
            //     return
            // }
            
            // this.$nextTick(async()=>{
            //     await this.equipmentHTTP("",_newList.tmBasNodeLevelId)

            //     this.$nextTick(()=>{
            //         this.$refs.selectContent.showModle()
            //     })
            // })

        },
        // 工厂 完成
        onFinish ({ selectedOptions }){
            // this.show = false;
            // console.log(selectedOptions)
            this.fieldSelectValue=selectedOptions[selectedOptions.length-1]||{}
            this.fieldValue = selectedOptions.map((o) => o.nodeLevelName).join('/')
        
            // this.$nextTick(()=>{
            //     console.log( this.fieldSelectValue.tmBasNodeLevelId )
            // })

   
        },
        // 工厂 重置
        factoryReset(){
            this.fieldValue=""   // 工厂显示值
            this.fieldSelectValue={}  // 工厂选中值
            this.show = false
            this.nodeCode=""
            this.factoryShow=false
            this.$nextTick(async ()=>{
                await this.equipmentHTTP()

                this.factoryShow=true
            })
        },
        // 工厂确定
        async factoryAffirm(){
            this.show=false



            // this.$nextTick(()=>{
            //         this.$refs.selectContent.showModle()
            // })
            // this.$nextTick(()=>{
            //     this.searchHandle()
            // })
            
            // console.log( this.fieldSelectValue )
            
            this.$nextTick(()=>{
                this.nodeCode=this.fieldSelectValue.nodeLevelNo

                this.$nextTick( async ()=>{
                    await this.equipmentHTTP()
                    this.$refs.selectContent.showModle()
                })           
            })

        },
        // 计量区域 数据
        async areaHttp(name=""){

            const {code,data=[]}= await httpHandle({
                url:'/iiot/equipmentArea/findEquipmentArealist',
                method:"get",
                url_params:{
                    enabled:1,
                    name:name
                }
            }) 

            if(code==200){
                this.areaSelectOption=data.map(o=>Object.assign({
                    text:`${o.name}`,
                    value:o.tmBasEquipmentAreaId
                }))  
            }
        }, 
        // 计量区域  切换
        async areaOnChange(value){
            // tmBasEquipmentAreaId
            await this.equipmentHTTP('',value)

            this.$nextTick( async ()=>{
                this.$refs.selectContent.showModle()
            })  
        },
        // 计量区域
        async areaSearchChange(key=""){
            this.areaHttp(key)
        },
        // 设备点击
        async onEquipmentFieldClick(){

            // await this.equipmentHTTP()

            // this.$refs.selectContent.showModle()
        },
        // 设备查询
        async equipmentSearchChange(key=""){
            this.equipmentHTTP(key)
        },
        // 重置
        restFunc(){
            this.fieldValue="" // 工厂显示值
            this.factoryID=""  // 工厂选中ID
            this.area=""   // 计量区域

            this.$refs["scanBar1"] && this.$refs["scanBar1"].reset()

            this.nodeCode=""
            this.fieldSelectValue={}   // 工厂选中ID
            this.equipment=''  // 设备类型
            // this.pageSize=10
            this.bufferRow={}

            this.hideFactory=false
            this.$nextTick(()=>{
                this.hideFactory=true
                
                this.$refs.select778 && this.$refs.select778.reset()

                this.$refs.selectContent && this.$refs.selectContent.reset()
                this.equipmentHTTP()
            })
        },
        // 扫描设备
        barSearchClick2(value){
            const _value=value.trim()
            this.equipmentHTTP(_value)

            this.$refs.selectContent.showModle()
        },
        // 查找设备
        async searchHandle(){

            const {equipment}=this    

            if(!equipment){
                showFailToast('设备未选择！')
                return
            }

            const {code,data={}}= await httpHandle({
                // url:'/collect/energySources/getEnergyRecordManually',
                url:'/iiot/collectParameters/getEnergyRecordManually',
                method: "get",
                url_params:{
                    equipmentNo: equipment,
                    // equipmentCode:equipment,  // 设备
                }
            })


            if( code==200){
                this.bufferRow=data

                // 图片预览
                if(data.energyPicture){
                    this.bufferFileListPreview=data.energyPicture.split(',').map(o=>Object.assign({url:o}))
                }

            }

        
        },
        // 设备 选中
        equipmentConfirm(value){
            // const _obj=this.equipmentSelectOptionData.filter(o=>o.tmBasEquipmentId==value)
            
            // 去重
            // if( this.tableList.filter(o=>o.tmBasEquipmentId==value).length   ){
            //     showFailToast("已添加！")
            //     return
            // }

            // this.tableList=_obj

            this.$nextTick(()=>{
                this.searchHandle()
            })

        },
        // 设备 删除
        removeIcon(items){
            this.tableList=this.tableList.filter(o=>o.tmBasEquipmentId!=items.tmBasEquipmentId)
        },
        // 提交 确定
        async submit(){


            if( !this.equipment ){
                showFailToast('设备不能为空！')
                return
            }

            if( !this.text1 ){
                showFailToast('用电累积数不能为空！')
                return
            }

            const _json={
                lineNo: this.nodeCode, // 产线编码
                equipmentNo: this.equipment, //   设备编码
                totalElectricityNums: Number(this.text1), //   用电累积数
                voltageNums: Number(this.text2), //   电压
                electricityNums: Number(this.text3), //   电流
                energyPicture: this.bufferFileList.map(o=>o.url).join()  // 图片
            }


            const {code,data={}}= await httpHandle({
                url:'/collect/energySources/energyRecordManually',
                method: "post",
                payload:_json
            })


            if(code==200){
                showSuccessToast("提交成功！")
                this.searchHandle()
            }

        }
    },
  }
</script>