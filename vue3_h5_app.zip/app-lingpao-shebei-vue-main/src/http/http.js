import instance from '@/http/instance'

import store from '@/store/index'
import router from '@/router/index'

import { showSuccessToast,showFailToast } from 'vant'

import {baseURLApp,portBase} from '@/config.js'


// post 请求
export const httpHandle = async(option={})=>{
    // const {access_token}=store.state.actionsStore.bufferLoginMessage
    // console.log(access_token)
    const access_token=localStorage.getItem("_token")



    

    // 正式环境
    let _baseURL=""
    if( process.env.NODE_ENV=="production" ){
        _baseURL=( localStorage.getItem("_custemIP") || (baseURLApp+portBase) ) 
    }

    try {

        if(!access_token && !option["noToken"]){
            showFailToast("Token失效！")
            router.push('/login')

            return new Promise((resolve, reject) => {})
        }

        // 格式化 url
        const _bufferParmasURL=Object.entries((option["url_params"]||{}));
        let _parmasURL="";  
        let _paramsRESTful=option["url_RESTful"]||"";

        // 格式化 url
        if(_bufferParmasURL.length){
            _bufferParmasURL.map(o=>{ _parmasURL+=`${o[0]}=${o[1]}&` });
            _parmasURL=`?${_parmasURL.slice(0,_parmasURL.length-1)}`
        }


        return new Promise((resolve, reject) => {
            instance({
                method: option["method"],
                url: _baseURL + option["url"]+_paramsRESTful+_parmasURL,
                data: option.formData ? option["payload"]: JSON.stringify( (option["payload"]||{}) ), 
                headers: option.formData ?
                    {
                        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', // 表单提交
                        'Access-Control-Allow-Origin': '*',
                        'Authorization': 'Bearer '+access_token
                    }
                    :
                    {
                        // 'Content-Type': 'application/json',
                        'Content-Type': ( option["method"].toLocaleLowerCase()=='get') ? 'application/x-www-form-urlencoded;charset=UTF-8': 'application/json', // get | post
                        'Access-Control-Allow-Origin': '*',
                        'Authorization': 'Bearer '+access_token
                    },


            })
            .then((res)=>{
                // console.log(res)

                if(!res){
                    return
                }

                if(res?.code==500){
                    // reject(res)
                    // showFailToast(`[${res.code}] ${res.msg||''}`);

                    showFailToast({
                        message: `${res.msg||''}`,
                        overlay:true,
                        closeOnClickOverlay:true,
                        duration:15000
                    })


                    return
                }

                if (res){
                    resolve(res)
                }
              })
            .catch((error) => {
                reject(error)
            })
        })        
    } catch (error) {
        // console.error(error);
    }

}