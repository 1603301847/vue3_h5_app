import {httpHandle} from '@/http/http'


// 检验码
export const codeHTTP= async(params)=>{
    // console.log( params )
    return await httpHandle({
        url:"/code",
        method:'get',
        noToken:true
    })
}

// 登录
export const loginHTTP= async(params)=>{
    // console.log( params )
    return await httpHandle({
        url:"/auth/login",
        method:'post',
        payload:params.payload,
        noToken:true
    })
}