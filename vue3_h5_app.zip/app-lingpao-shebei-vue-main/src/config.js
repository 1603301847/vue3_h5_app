// 版本号
export const AppVersion="0.1.39"


// 本机环境
// export const baseURLApp="http://192.168.0.113:8188"
// export const portBase = "/stage-api"

// 许建斌
// export const baseURLApp="http://192.168.0.107:10001"
// export const portBase = ""


// 测试环境
// export const baseURLApp="https://172.16.65.249:8168"
// export const portBase = "/stage-api"


// // 正式环境
export const baseURLApp="http://10.193.134.146:80"
export const portBase = "/prod-api"

