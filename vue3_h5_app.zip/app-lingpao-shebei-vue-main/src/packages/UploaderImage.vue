<template>
    <span>
        <div style="padding: 0px 12px 0px 12px;">
            <p v-if="preview" class="font-weight-medium text" style="margin-bottom:8px;">图片预览 </p>
            <p v-else style="margin-bottom:8px;" class="font-weight-medium text"> 图片上传 </p>

            <!--  capture="camera" -->
            <van-uploader
                v-if="!preview"
                :after-read="afterRead"
                :preview-image="false"
       
            />
            <div class="custem-iamge-upload">
                <li v-for="(o,i) in bufferFileList" :key="i" @click="checkImage(bufferFileList)">
                    <img :src="o" />
                    <v-icon v-if="!preview" @click="removeClick(o,$event)" class="icon" icon="mdi-close-circle-outline" color="red"></v-icon>
                </li>
            </div>
        </div>
    </span>
</template>
<script>
    import {httpHandle} from '@/http/http'  // api
    import { showSuccessToast, showFailToast } from 'vant'
    import { showImagePreview } from 'vant'

  export default {
    components:{

    },
    emits: ["update:modelValue","onChange"],
    data: () => ({
        bufferFileList:[]
    }),
    watch: {
        modelValue: {
            handler(list=[]){
                this.bufferFileList=list
            },
            deep: true,
            immediate: true,
        },
        initPath:{
            handler(path=""){
                if(path){
                    this.bufferFileList=path.split(',').map(o=>Object.assign({url:o}))
                }
            },
            deep: true,
            immediate: true,
        }
    },
    methods: {
        // 图片放大
        checkImage(bufferFileList=[]){
            if( !bufferFileList.length ) return
            // showImagePreview( bufferFileList.map(o=>o.url) )
            showImagePreview(this.bufferFileList)
        },
        // 图片上传
        async afterRead (file){


            if( !file.file.type.includes("image") ){
                showFailToast("只能选择图片！")
                return
            }

            // // 限制图片大小
            // if( file.file.size>= (1024*1024*19) ){
            //     showFailToast("图片超过20M！")
            //     return
            // }

            // 图片 上限
            if( this.bufferFileList.length>2 ){
                showFailToast("最多只能选择3张图片！")
                return
            }



            let _formData= new FormData()
            _formData.append("file",file.file)

            // console.log(_formData)
            const {code,data={}}= await httpHandle({
                // url:'/file/upload',
                url:'/iiot/uploadFile/file',
                method: "post",
                formData:true,
                payload:_formData
            })

            if(code==200){
                this.bufferFileList= this.bufferFileList.concat([data] )
                showSuccessToast("图片上传成功！")
                // console.log(this.bufferFileList)

                this.$emit('update:modelValue', JSON.parse( JSON.stringify(this.bufferFileList) ) )
            }else{
                showFailToast("图片上传失败！")
            }


       },
       // 删除图片
       removeClick(option,event){
            event.stopPropagation()
            this.bufferFileList=JSON.parse(JSON.stringify(this.bufferFileList)).filter(o=>o!=option)

            this.$nextTick(()=>{
                    this.$emit('update:modelValue', JSON.parse( JSON.stringify(this.bufferFileList) ) )
            })
       }
    },
    props: {
        modelValue:{
            type: Array,
            default: ()=> []
        },
        initPath:{
            type: String,
            default: ()=> ''
        },
        // 预览
        preview:{
            type: Boolean,
            default: ()=> false
        }
    }
  }
</script>
