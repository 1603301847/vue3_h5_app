<template>
    <span>
 
        <v-card v-if="paging && pagingShow" elevation="0" style="margin-bottom: 0px;">
            <v-btn
                variant="outlined"
                size="x-small"
                icon
                color="primary"
                style="margin-right:6px;width:28px;height:28px;"
                @click="previousHandle"
            >
                <v-icon size="28">mdi-chevron-left</v-icon>
            </v-btn>
            <v-btn
                variant="outlined"
                size="x-small"
                icon
                color="primary"
                style="width:28px;height:28px;"
                @click="nextHandle"
            >
                <v-icon size="28">mdi-chevron-right</v-icon>
            </v-btn>
            <span style="position:relative;top:3px;margin-left:6px;font-size: 14px;">
                <span>第</span>
                <span style="padding-left:1px;padding-right:1px;">{{ current }}</span>
                <span style="margin-right:3px;">页</span>
                <span>共</span>
                <span style="padding-left:1px;padding-right:1px;">{{ page }}</span>
                <span style="margin-right:3px;">页</span>

                <span>总</span>
                <span style="padding-left:1px;padding-right:1px;">{{ totalNum }}</span>
                <span>条</span>

                
            </span>

            <span  style="position:relative;top:1px;margin-left:0px;">
                <v-btn v-if="showSearchBtn" style="padding-left:8px;padding-right:4px;" @click="searchClick" variant="plain" color="primary">
                    <v-icon size="24" icon="mdi-magnify"></v-icon>
                    查询
                </v-btn>
                <v-btn @click="refreshClick" :style="'min-width: 42px;width: 42px'" variant="plain" color="primary" style="padding: 0;">
                    <!-- <v-icon size="24" icon="mdi-magnify"></v-icon> -->
                    刷新
                </v-btn>
            </span>
        </v-card>

        <slot 
            v-if="items.length"
            v-for="(o,i) in items" :key="i" 
            name="tableBody" 
            :items="o"
            :_index="i"
        >
        </slot>
        <p v-else class="text-center" style="padding-top:12px;">
            <v-icon icon="mdi-emoticon-sad-outline"></v-icon>
            无数据！
        </p>

    
    </span>
</template>
<script>
    import {httpHandle} from '@/http/http'

    import {TableHTTP} from '@/http/global'   // api

import { showSuccessToast, showFailToast } from 'vant';
  export default {
    components:{

    },
    emits: ["searchClick","refresh"],
    data: () => ({
        totalNum:0,   // 总
        current:1, // 当前
        page:0,    // 页数

        paging:true,   // 分页

        // 列表数据
        items:[
            // {
            //     name:1,
            //     age:2
            // },

        ]
    }),
    watch: {
        'children': { 
            handler(list){
                if(list){
                    this.items=list
                }
            },
            deep: true, 
            immediate: true, 
        },
    },
    created(){
        const {auto,url}=this

        if(auto && url){
            this.initFunc()
        }

    },
    methods: {
        // 上一页
        previousHandle(){
            const {current}=this

            if(current==1){
                showFailToast("第一页！");
                return
            }

            this.current=current-1
            this.$nextTick(()=>{
                this.initFunc(this.current)
            })
        },
        // 下一页
        nextHandle(){
            const {current,page}=this

            if(current>=page){
                showFailToast("最后一页！");
                return
            }

            this.current=current+1
            this.$nextTick(()=>{
                this.initFunc(this.current)
            })
        },
        // 初始化
        async initFunc(_current=1,option){
            const {url,params={},children,method,formatData}=this

            if(children){
                this.items=children
                this.paging=false
                return
            }
  
            const _params={
                pageNum: _current,
                pageSize: 10,
                ...params,
                ...option
            }
    
            const {code,total=0,msg='',data,rows}=await httpHandle({
                method:method,
                url:url,
                payload: method=='post'?_params:{},
                url_params: method=='get'?_params:{}
            })

            if(code==200){
                this.totalNum=total
                this.current=_current
                // this.page=Math.ceil(total/10)
                this.page=Math.ceil(total/ (_params.pageSize) )
                this.items= (formatData?formatData((data||rows||[])): (data||rows||[])).map((k,i)=> Object.assign(k,{_index:i+1}) )


            } 

        },
        // 刷新
        refreshClick(){
            const {refreshFunc}=this
            !refreshFunc && this.initFunc(1)
            this.$emit("refresh")
        },
        searchClick(){
            this.$emit("searchClick")
        },
        // 返回数据
        resultData(){
            return this.items||[]
        },
        // 全选
        selectAll(){
            this.items=this.items.map(o=>Object.assign(o,{_checked:true}))
        }
    },
    props: {
        method:{
            type: String,
            default: ()=> "get" 
        },
        refreshFunc:{
            type: Boolean,
            default: ()=> false   
        },
        // 显示 查询 按钮
        showSearchBtn:{
            type: Boolean,
            default: ()=> false        
        },
        // 自动初始化
        auto:{
            type: Boolean,
            default: ()=> true
        },
        // 显示 分页
        pagingShow:{
            type: Boolean,
            default: ()=> true
        },
        // 显示分页 信息
        pagingText:{
            type: Boolean,
            default: ()=> true
        },
        // 子级
        children:{
            // type: Array,
            // default: ()=> undefined
        },
        // url
        url:{
            type: String,
            default: ()=> ""
        }, 
        // 参数
        params:{
            type: Object,
            default: ()=> {}
        },
        // 格式化 数据
        formatData:{
            
        }
    }
  }
</script>