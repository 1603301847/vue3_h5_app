<template>
    <span>
        <van-field
            v-model="fieldValue"
            is-link
            readonly
            :required="required"
            :label="label"
            :placeholder="placeholder"
            autocomplete="off"
            @click="showPicker = true"
        >
        </van-field>
        <van-popup v-model:show="showPicker" round position="bottom">

            <van-picker-group
                title="预约日期"
                :tabs="['选择日期']"

                @confirm="onConfirm"
                @cancel="showPicker = false"
                >
                    <van-date-picker
                        v-model="currentDate"
                        :columns-type="columnsType"
                        :min-date="minDate"
                        :max-date="maxDate"
                    />
                    <!-- <van-time-picker v-model="currentTime" /> -->
                </van-picker-group>


            <!-- <van-date-picker
                v-model="currentDate"
                title="选择日期"
                :min-date="minDate"
                :max-date="maxDate"
                @confirm="onConfirm"
            /> -->
        </van-popup>
    </span>
</template>
<script>
import { showSuccessToast, showFailToast } from 'vant';
import { ref } from 'vue';

  export default {
    components:{

    },
    emits: ["update:modelValue"],
    data: () => ({
        fieldValue:"",
        showPicker:false,

        currentDate:[],
        currentDate2:[],


        // currentDate :['2021', '01', '01'],
        minDate: new Date(2018, 0, 1),
        maxDate: new Date(2028, 11, 1),

        currentTime:['12', '00']
    }),

    methods: {
        // 设置值
        setValue(value=""){

            if(value){
                this.fieldValue=value
                this.currentDate=ref( value.split("-") )
            }
            
        },
        // 重置
        reset(){
            this.fieldValue = ''
            this.$emit('update:modelValue','') 
        },
        // 日期选择
        onConfirm(){
            const _date=this.currentDate
            const _time=this.currentTime

            // const _format=`${_date.join("-")} ${_time.join(":")}`
            const _format=`${_date.join("-")}`


            this.showPicker = false
            this.fieldValue = _format

            this.$emit('update:modelValue',_format)

        }
    },
    props: {
        modelValue:{
            type: String,
            default: ()=> ""
        },
        // 模式
        columnsType:{
            type: Array,
            default: ()=> ['year', 'month', 'day']
        },
        // label
        label:{
            type: String,
            default: ()=> "标题"
        },
        // placeholder
        placeholder:{
            type: String,
            default: ()=> "请选择"
        }, 
        // required
        required:{
            type: Boolean,
            default: ()=> false
        }

    }
  }
</script>