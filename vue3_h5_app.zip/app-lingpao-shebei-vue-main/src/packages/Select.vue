<template>
    <span>
        <van-field
            v-model="fieldValue"
            is-link
            readonly
            :required="required"
            :label="label"
            :placeholder="placeholder"
            autocomplete="off"
            :type="multiple? 'textarea':'text'"
            @click="fieldClick"
        >
        </van-field>


        <!-- 单选 新的 -->
        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px 12px 4px 12px',height:'60%',width:'90%'}"
            round 
        >
            <div style="height:98%;padding-bottom:40px;">

                <div style="height:100%;">
                    <v-row no-gutters style="font-weight:bold;border-bottom: 1px solid #ccc;padding-bottom: 5px;">
                        <v-col cols="6">
                            <p>{{ label }}-选择框</p>
                        </v-col>
                        <v-col cols="6" class="text-right">
                            <span style="position:relative;top:4px;">{{ BufferOption.filter(o=>o._checked).length }}</span>
                            <v-btn v-if="selectAll" @click="selectAllHandle" color="primary mt-1" density="compact" :rounded="0" variant="plain">全选</v-btn>

                        </v-col>
                    </v-row>
                    <v-row v-if="showSearch" no-gutters>
                        <v-col cols="8">
                            <van-search 
                                v-model="valueSearch" 
                                shape
                                :placeholder="placeholderSearch" 
                                style="padding-left: 0px;"
                                :clearable="false"
                            />
                        </v-col>
                        <v-col cols="2">
                            <v-btn @click="searchHandle(true)" variant="plain" color="primary" block style="margin-top:8px;">
                                查询
                            </v-btn>
                        </v-col>
                        <v-col cols="2">
                            <v-btn @click="searchHandle(false)" variant="plain" block style="margin-top:8px;">
                                重置
                            </v-btn>
                        </v-col>
                    </v-row>

                    <ul v-if="BufferOption.length" :style="`height: ${showSearch?'73%':'90%'};overflow-y:auto;padding-right:12px;padding-bottom: 20px;`">
                        <li 
                            v-for="(o,i) in BufferOption" :key="i"
                            :style="`padding: 6px 22px 6px 6px;position:relative;color:${o._searchColor?'#FF9800':'#000'};`"
                            @click="checkChange(o)" 
                        >
                            <p class="text-truncate" style="height: 24px;">{{o.text}}</p>
                            <van-checkbox 
                                style="position:absolute;top:8px;right:0px"
                                v-model="o._checked" 
                                shape="square"
                                checked-color="#4CAF50"  
                                disabled
                                class="custem-select-checkbox"
                                ></van-checkbox>
                        </li>
                    </ul>

                    <p v-else class="text-center" style="margin-top:16px;">无数据!</p>
                </div>
            
                <v-row no-gutters>
                    <v-col cols="6" class="text-center">
                        <v-btn variant="plain" block @click="()=> showPicker=false ">
                            取消
                        </v-btn>
                    </v-col>
                    <v-col cols="6" class="text-center">
                        <v-btn
                            variant="plain"
                            color="primary"
                            block
                            @click="confirmHandle"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>

            </div>

        </van-popup>
    </span>
</template>
<script>
import { showSuccessToast, showFailToast } from 'vant';
  export default {
    components:{

    },
    emits: ["update:modelValue","onChange","onFieldClick","onSearchChange"],
    data: () => ({
        BufferOption:[],   //  缓存

        selectedValues: [],
        columns:[
            // { text: '杭州', value: 'Hangzhou' },
            // { text: '宁波', value: 'Ningbo' },
        ],
        fieldValue:"",
        showPicker:false,

        valueSearch:"",   // 查询关键字
    }),
    watch: {
        'option': { 
            handler(list=[]){
                // console.log(list)
                this.BufferOption=JSON.parse( JSON.stringify(list) )

                this.$nextTick(()=>{
                    if( this.modelValue ){
                        this.setValue(this.modelValue)
                    }
                })
            },
            deep: true, 
            immediate: true, 
        },
        'showPicker': { 
            handler(active){
                this.$nextTick(()=>{

                    if(active && this.modelValue){
        

                        // 单选 多选
                        if(!this.multiple){
                            this.BufferOption.map(o=> Object.assign(o,{_checked: (o.value==this.modelValue)?true:false}) )
                        }else{
             
                            const _ids= this.modelValue.split(",")||[]

                            _ids.map(k=>{
                                this.BufferOption.map(o=>{
                                    var json=o
                                    if(o.value==k){
                                        json._checked=true
                                    }
                                    return json
                                })
                            })
                            // console.log( this.modelValue.split(",") )
                            // this.BufferOption.map(o=> Object.assign(o,{_checked: (o.value==this.modelValue)?!_checked:o._checked}) )
                        }

                    }
                })
            },
            deep: true, 
            immediate: true, 
        },
    },
    methods: {
        showModle(){
            this.showPicker = true
        },
        // 输入框 单击
        fieldClick(){

            if(this.disabled){
                return
            }

            if(!this.forbidShow){
                this.showPicker = true

            }

            this.$emit('onFieldClick')


        },
        // 设置 显示值
        setfieldValue(text=""){
            this.fieldValue=text
        }, 
        // 重置
        reset(){
            this.fieldValue=""
            this.BufferOption.map(o=> Object.assign(o,{_checked:false}) )
            this.$emit('update:modelValue',"")
        },
        // 设置 初始值
        setValue(value=""){
            
            // 单选 多选
            if(!this.multiple){

                const _option= JSON.parse(JSON.stringify(this.BufferOption)).filter(o=>o.value==value)[0]||{}
                this.fieldValue=_option.text

            }else{

                const _ids= value.split(",")||[]

                _ids.map(k=>{
                    this.BufferOption.map(o=>{
                        var json=o
                        if(o.value==k){
                            json._checked=true
                        }
                        return json
                    })
                })

                this.fieldValue=this.BufferOption.filter(o=>o._checked).map(o=>o.text).join()
                // this.BufferOption.map(o=> Object.assign(o,{_checked: (o.value==this.modelValue)?!_checked:o._checked}) )
            }
  


            // this.$emit('update:modelValue', value)
        },
        // 确定
        confirmHandle(){
            const {multiple}=this
            const _obj=this.BufferOption.filter(o=>o._checked==true)

            // 多选 | 单选
            if(multiple){
                // console.log(_obj.map(o=>o.value).join())
                this.fieldValue = _obj.map(o=>o.text).join()
                this.$emit('update:modelValue', (_obj.map(o=>o.value).join()||'') )
                this.$emit('onChange', _obj.map(o=>o.value).join() )        
            }else{
                this.fieldValue = (_obj[0]||{}).text
                this.$emit('update:modelValue', ((_obj[0]||{}).value||'') )
                this.$emit('onChange', (_obj[0]||{}).value,(_obj[0]||{}))
            }




            this.showPicker = false
        },
        // checkbox 点击
        checkChange(option){
            const {multiple}=this
            const {_checked,value}=option


            // 单选 多选
            if(!multiple){
                this.BufferOption.map(o=> Object.assign(o,{_checked: (o.value==value)?!_checked:false}) )
            }else{
                this.BufferOption.map(o=> Object.assign(o,{_checked: (o.value==value)?!_checked:o._checked}) )
            }
        },
        multipleHandle(){
            const _checkedList=this.BufferOption.filter(o=>o._checked)
            const _value=_checkedList.map(o=>o.value).join()
            this.showPicker=false
            this.fieldValue=_checkedList.map(o=>o.text).join()

            this.$emit('update:modelValue', _value)
            this.$emit('onChange', _checkedList)
        },
        // 搜索查询 | 重置
        searchHandle(active){
            const _value=this.valueSearch.trim()
            const {filterSearch}=this
            

            // 前端 过滤
            if(filterSearch && active){
                const _bufferOption=this.BufferOption.map(o=>Object.assign(o,{_searchColor:false}))
                const _inHasData=_bufferOption.filter(o=>o.text.includes(_value) ).map(k=>Object.assign(k,{_searchColor:true})) //包含数据
                
                // 不存在
                if(!_inHasData.length){
                    showFailToast("不存在！")
                    return
                }
                
                const _notHasData=_bufferOption.filter(o=>!o.text.includes(_value) ) //不包含数据

                const _checkedData=_notHasData.filter(o=>o._checked)   // 选中
                const _notCheckedData=_notHasData.filter(o=>!o._checked)   // 未选中

                this.BufferOption= _inHasData.concat(_checkedData).concat(_notCheckedData)
                return
            }

            // 查询 | 重置
            if(active){
                this.$emit('onSearchChange',_value)
            }else{
                this.valueSearch=''
                this.BufferOption=this.option

                this.$nextTick(()=>{
                    this.BufferOption=this.BufferOption.map(o=> Object.assign(o,{_checked: false}) )
                })
                this.$emit('onSearchChange','')
            }
        },
        // 全选
        selectAllHandle(){
            this.BufferOption.map(o=> Object.assign(o,{_checked:true}) )
            // console.log(8888)

            // this.$nextTick(()=>{
            //     const _obj=this.BufferOption.filter(o=>o._checked==true)

            //     // 多选 
            //     if(this.multiple){
            //         // console.log(_obj.map(o=>o.value).join())
            //         this.fieldValue = _obj.map(o=>o.text).join()
            //         // this.$emit('update:modelValue', (_obj.map(o=>o.value).join()||'') )
            //         // this.$emit('onChange', _obj.map(o=>o.value).join() ) 
            //         // console.log(_obj)
            //     }
            // })
        }
    },
    props: {
        modelValue:{
            // type: String,
            // default: ()=> ""
        },
        // 不可编辑
        disabled:{
            type: Boolean,
            default: ()=> false      
        },
        // 显示 查询框
        showSearch:{
            type: Boolean,
            default: ()=> false   
        },
        // 禁止弹出
        forbidShow:{
            type: Boolean,
            default: ()=> false 
        },
        // 多选
        multiple:{
            type: Boolean,
            default: ()=> false 
        },
        // label
        label:{
            type: String,
            default: ()=> "标题"
        },
        // placeholder
        placeholder:{
            type: String,
            default: ()=> "请选择"
        }, 
        placeholderSearch:{
            type: String,
            default: ()=> "请输入搜索关键词"
        }, 
        // 下拉数据
        option:{
            type: Array,
            default: ()=> []
        },
        selectAll:{
            type: Boolean,
            default: ()=> false 
        },
        // required
        required:{
            type: Boolean,
            default: ()=> false
        },
        // 前端过滤
        filterSearch:{
            type: Boolean,
            default: ()=> false 
        }
    }
  }
</script>