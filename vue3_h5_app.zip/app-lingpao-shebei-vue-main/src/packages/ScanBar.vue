<template>
    <span>

        <v-card
            class="mx-auto mb-2 card-scan-container"
            density="compact"
            elevation="3"

        >
            <v-card-text :class="`scan-module-card-container ${!showScanIcon ? 'hide-scan':''}`">
                <v-icon v-if="showScanIcon" @click="prependIcon" class="left-icon-btn alipay-scan"  color="primary" icon="mdi-line-scan"></v-icon>
                <v-icon @click="appendIcon" color="primary" class="right-icon-btn" icon="mdi-magnify"></v-icon>

                <v-text-field
                    v-model="inputValue"
                    density="compact"
                    variant="solo"
                    elevation="0"
                    :label="placeholder"
                    single-line
                    hide-details
                    :loading="loading"
                    class="scan-module-text-field"
                    autocomplete="off"
                   
                >
                    <!-- <template v-slot:prepend-inner>
                        <v-icon @click="prependIcon($event)"  color="primary" icon="mdi-line-scan"></v-icon>
                    </template> -->
                    <!-- <template v-slot:append-inner>
                        <v-icon @click="appendIcon" color="primary" icon="mdi-line-scan"></v-icon>
                    </template> -->

                </v-text-field>
            </v-card-text>
        </v-card>

        <div v-if="scanShow" class="scan-custem-container">
            <div id="scanBaseID"></div>
            <div class="close-btn" @click="stopScan">关闭</div>
        </div>


        <van-popup v-model:show="scanShowPC" class="pc-dalog-scan">
            <div class="text-right">
                <span
                    style="padding: 18px 18px;display: inline-block;color:#fff;font-size:22px;font-weight:bold;"
                    @click="closeScanPC"
                >
                    关闭
                </span>
            </div>
            <div id="reader" class="reader-scan">
                <video id="video" style="height: 100%;width: 100%;"></video>
            </div>
            <div class="scan-table-rack">
                <div class="box">
                    <span class="across across-left-top"></span>
                    <span class="across across-left-bottom"></span>
                    <span class="across across-right-top"></span>
                    <span class="across across-right-bottom"></span>

                    <span class="vertical vertical-left-top"></span>
                    <span class="vertical vertical-left-bottom"></span>
                    <span class="vertical vertical-right-top"></span>
                    <span class="vertical vertical-right-bottom"></span>
                </div>
            </div>
        </van-popup>

    </span>

</template>
<script>
    import {Html5Qrcode,Html5QrcodeScanner} from "html5-qrcode"
    import * as ZXing from './zxing.min.js'

    import { showSuccessToast, showFailToast } from 'vant';

let scan = null;

  export default {
    components:{

    },
    emits: ["searchClick"],
    data: () => ({
        loading:false,    // loding
        inputValue:"",    // 扫码结果

        scanShow:false,   // 显示扫码组件

        scanShowPC:false,   // 显示扫码组件  PC

        _html5QrCode:undefined,   // 相机对象 旧的

        _codeReader:undefined,   // 新的PC 相机对象
    }),
    watch: {
        'inputValue': { 
            handler(value=""){
                const _text= value.trim()
                const {searchLength}=this
                
                // 自动触发
                if(_text && _text.length>=1){
                    // console.log(_text)

                    
                    // 控制位数 
                    if(searchLength){
                        if( _text.length == searchLength  ){
                            this.$emit("searchClick", _text )  
                        }
                    }else{
                        this.$emit("searchClick", _text )  
                    }

              
                }
            },
            deep: true, 
            immediate: true, 
        },
    },
    created(){
        // const that=this
        // this.$nextTick(()=>{

        //     // 支付宝
        //     if( /AlipayClient/.test(window.navigator.userAgent) ){

        //         // function ready(callback) {
        //         //     // 如果jsbridge已经注入则直接调用
        //         //     if (window.AlipayJSBridge) {
        //         //         callback && callback();
        //         //     } else {
        //         //         // 如果没有注入则监听注入的事件
        //         //         document.addEventListener('AlipayJSBridgeReady', callback, false);
        //         //     }
        //         // }

        //         // ready(function() {
        //         //     document.querySelector('.alipay-scan').addEventListener('click', function() {


        //         //     });
        //         // });

        //     }



        // })

    },
    methods: {
        setInputText(text=''){
            this.inputValue=text
        },
        // 重置
        reset(){
            this.inputValue=''
        },
        // PC 扫码完成
        scanPCFinish(){
            this.closeScanPC()
            this.$emit("searchClick", this.inputValue.trim() )  
        },
        // PC 扫描 旧的
        scanSatrtHandle(){
            // const that=this

            // that.inputValue = ""


            // // This method will trigger user permissions
            // Html5Qrcode.getCameras().then(devices => {
            //     /**
            //      * devices would be an array of objects of type:
            //      * { id: "id", label: "label" }
            //      */
            //     if (devices && devices.length) {
            //     // devices 多个摄像头
            //     // var cameraId = devices.length>1 ? devices[1].id:devices[0].id;
            //     // .. use this to start scanning.
            //     // showFailToast(`${devices.length}`)

            //     const html5QrCode = new Html5Qrcode(/* element id */ "reader")
            //     const _config={
            //         fps: 500,    //  扫码速度 Optional, frame per seconds for qr code scanning
            //         qrbox: { width: 250, height: 250 }  // 扫描区域大小 Optional, if you want bounded box UI
            //     }
                        
            //     // 调后置摄像头
            //     html5QrCode.start({ facingMode: "environment" }, _config,
            //         (decodedText, decodedResult) => {
            //             // alert(`${decodedText}`)
            //             // do something when code is read
            //             that.inputValue = String(decodedText).trim()
            //             that.scanPCFinish()
            //         },
            //         (errorMessage) => {
            //         // parse error, ignore it.
            //         })
            //         .catch((err) => {
            //             console.log(err)
            //             // Start failed, handle it.
            //         })

            //         that._html5QrCode=html5QrCode
            //     }

            // }).catch(err => {
            //     // 权限 err
            //     showFailToast("未获取到相机权限！")
            // });

        },
        // PC 扫描 新的
        scanSatrtHandle2(){
            const that=this

            Html5Qrcode.getCameras().then(devices => {
                /**
                 * devices would be an array of objects of type:
                 * { id: "id", label: "label" }
                */
                if (devices && devices.length) {
                    // devices 多个摄像头
                    // var cameraId = devices.length>1 ? devices[1].id:devices[0].id;
                    // .. use this to start scanning.
                    // showFailToast(`${devices.length}`)
                    // console.log(devices)  
                    // console.log(111)

                    const _devices=devices.reverse()
                    const selectedDeviceId = _devices[0].id
                    const codeReader = new ZXing.BrowserMultiFormatReader()
                    
                    that._codeReader=codeReader
                    codeReader.decodeFromVideoDevice(selectedDeviceId, 'video', (result,err) => {
                        if (result) {
                            const {text=""}=result
                            // showSuccessToast( String(text).trim() )
                            that.inputValue = String(text).trim()
                            that.scanPCFinish()
                        }
                        if (err && !(err instanceof ZXing.NotFoundException)) {
                            showFailToast(`扫码错误: [${err}]`)
                        }
                    })

                }
            }).catch(err => {
                // 权限 err
                showFailToast("未获取到相机权限！")
            });
        },
        // PC 关闭扫码
        closeScanPC(){
            const that=this

            if( this._codeReader ){
                this._codeReader.reset()
                this._codeReader=undefined
            }

            setTimeout(()=>{
                this.$nextTick(()=>{
                    this.scanShowPC=false
                    this._codeReader=undefined
                })
            },300)

            // if(this._html5QrCode){
            //     this._html5QrCode.stop().then((ignore) => {
            //     // QR Code scanning is stopped.
            //     // showSuccessToast('停止成功')
            //     // console.log("停止成功")

            //     that.$nextTick(()=>{
            //         that.scanShowPC=false
            //         that._html5QrCode=undefined
            //     })

            //     }).catch((err) => {
            //         // Stop failed, handle it.
            //         showFailToast("停止失败！")
            //     });
            // }
        },
        // 扫码完成
        scanaAcomplish(){
            this.$emit("searchClick", this.inputValue.trim() )  
        },
        // 头部
        prependIcon(){
            const that=this
            // this.$emit("prependIconClick","1");

            // 支付宝
            if( (/AlipayClient/.test(window.navigator.userAgent)) && AlipayJSBridge ){

                // if(!AlipayJSBridge){
                //     showFailToast('扫码加在失败！')
                //     return;
                // }

                AlipayJSBridge.call('scan', {
                    scanType:['qrCode','barCode'],
                }, function(result={}) {
                    const {codeContent=''}=result
                    const _text=codeContent.trim()
                    that.inputValue = _text

                    if(_text){
                        that.$emit("searchClick", _text )  
                    }else{
                        showFailToast("不存在！")
                    }
                });

                return
            }

            //  浏览器 | app 
            if (!window.plus){
                // 浏览器
                this.scanShowPC=true
                showSuccessToast("相机加载中")
                this.$nextTick(()=>{
                    // this.scanSatrtHandle() // 111
                    this.scanSatrtHandle2() // 222
                })
            }else{
                this.startScan()   // app
            }


        },
        // 扫码 尾部
        appendIcon(){
            const _value=(this.inputValue).trim()   

            // if(!_value){
            //     showFailToast('');
            //     return
            // }

            this.$emit("searchClick",_value)  
        },
        // 显示 loading
        showLoading(active=false){
            this.loading=active
        },
        //开始扫描
        startScan() {
          if (!window.plus) return

          this.scanShow=true
          this.inputValue=""

          this.$nextTick(()=>{
            this.startRecognize()
            showSuccessToast("相机加载中")
            setTimeout(()=>{
                scan.start()

                // ws = plus.webview.currentWebview()
                // // 创建子窗口
			    // var view = null;
                // view = new plus.nativeObj.View('nbutton', {
				// 	bottom: '28%',
				// 	left: '30%',
				// 	width: '40%',
				// 	height: '44px'
				// }, [{
				// 	tag: 'font',
				// 	id: 'text',
				// 	text: '请扫描二维码',
				// 	textStyles: {
				// 		color: '#FFFFFF'
				// 	}
				// }]);
				// ws.append(view);

            },1500)
          })
        },
        // 停止扫码 
        stopScan(){
          this.closeScan()
          this.cancelScan()

          this.scanShow=false
        },
        //创建扫描控件
        startRecognize() {
          let that = this;
          if (!window.plus) return;
          scan = new plus.barcode.Barcode(
            'scanBaseID',
            [0,1,2,3,4,5], // 只扫二维码
            {
                // top:'100px',
                // left:'100px',
                // width: '100%',
                // height: '200px',
                // position: 'absolute',
                scanbarColor: '#f1c01f',
                frameColor: '#c0ff01'
            }
        )
          scan.onmarked = onmarked;
  
          function onmarked(type, result, file) {
            // switch (type) {
            //   case plus.barcode.QR:
            //     type = 'QR';
            //     break;
            //   case plus.barcode.EAN13:
            //     type = 'EAN13';
            //     break;
            //   case plus.barcode.EAN8:
            //     type = 'EAN8';
            //     break;
            //   default:
            //     type = '其它' + type;
            //     break;
            // }
            result = result.replace(/\n/g, '')
            that.inputValue = String(result).trim()
            // alert(result)

            that.stopScan() // 停止

            that.$nextTick(()=>{
                that.scanaAcomplish()
            })
  
          }
        },
        //关闭扫描
        cancelScan() {
          if (!window.plus) return;
          scan.cancel();
        },
        //关闭条码识别控件
        closeScan() {
          if (!window.plus) return;
          scan.close();
        },
    },
    beforeUnmount(){
        this.closeScanPC()  // 停止
        this.stopScan() // 停止
    },
    props: {
        searchLength:{
            // type: Number,
            // default: ()=> 1  
        },

        // 
        showScanIcon:{
            type: Boolean,
            default: ()=> true
        },
        // placeholder
        placeholder:{
            type: String,
            default: ()=> "请输入..."
        }, 
    }
  }
</script>

<style lang="scss">
    .pc-dalog-scan{
        position: fixed;
        z-index: 9999;
        // position: relative;
        background:#000;
        max-height:inherit;
        max-width:inherit;
        padding:0px;
        width:100%;
        height:100%;

        .text-right{
            // height: 20%;
        }

        .scan-table-rack{
            width: 260px;
            height: 260px;
            position: fixed !important;

            top: calc(50% - 190px);
            left: calc(50% - 130px);

            // position: absolute;
            // z-index: 999999999;
            margin: 0px auto;
            // background: red;

            >div.box{
                width: 100%;
                height: 100%;
                // background: violet;
                position: relative;
                // background: #ccc;

                span.across{
                    position: absolute;
                    z-index: 21;
                    width: 38px;
                    height: 6px;
                    background: rgba($color: #00e676, $alpha: 0.7);


                    &.across-left-top{
                        left: 0px;
                        top: 0px;
                    }
                    &.across-right-top{
                        right: 0px;
                        top: 0px;
                    }
                    &.across-left-bottom{
                        left: 0px;
                        bottom: 0px; 
                    }
                    &.across-right-bottom{
                        right: 0px;
                        bottom: 0px; 
                    }
                }


                span.vertical{
                    position: absolute;
                    z-index: 21;
                    width: 6px;
                    height: 38px;
                    background: rgba($color: #00e676, $alpha: 0.7);



                    &.vertical-left-top{
                        left: 0px;
                        top: 0px;
                    }
                    &.vertical-right-top{
                        right: 0px;
                        top: 0px;
                    }
                    &.vertical-left-bottom{
                        left: 0px;
                        bottom: 0px; 
                    }
                    &.vertical-right-bottom{
                        right: 0px;
                        bottom: 0px; 
                    }
                }

            }


            
        }

        .reader-scan{
            // position: fixed;
            // z-index: 99999;
            // top: 80px;
            width:100%;
            position: relative;
            // height: 100%;


        }
    }
    .scan-module-card-container{
        padding:0px 46px 0px 46px;
        position: relative;

        &.hide-scan{
            padding-left: 12px;
        }

        .left-icon-btn{
            font-size: 28px;
            position: absolute;
            top: 6px;
            left: 8px;
            z-index: 11;
        }

        .right-icon-btn{
            font-size: 28px;
            position: absolute;
            top: 8px;
            right: 8px;
            z-index: 11;
        }

        .scan-module-text-field{
            .v-label.v-field-label{
                margin-left: 0px;
            }
            .v-field__input{
                padding-left: 0px;
                padding-right: 0px;
            }
            .v-field{
                box-shadow: none;
            }
        }
    }

  .scan-custem-container{
    // height: 100%;
    // position: fixed;
    // top: 0px;
    // left: 0px;
    // height: 100%;
    // width: 100%;
    // z-index: 999999;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    position: fixed;
    z-index: 9999998;

    background: #000;



    .close-btn{
        position: fixed;
        top: 0px;
        left: 0px;
        z-index: 9999999;
        width: 100%;
        height: 8%;
        font-size: 22px;
        color: #fff;
        text-align: right;
        padding-top: 12px;
        padding-right: 12px;
        font-weight: bold;
    }


    #scanBaseID {
        width: 100%;
        height: 92%;
        position: fixed;
        left: 0px;
        top: 8%;
        z-index: 999;
        text-align: center;
        color: #fff;
        background: #ccc;
    }

  }


</style>