import { createRouter, createWebHistory,createWebHashHistory } from 'vue-router'


const routes = [
  {
    path:'/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'home',
    meta:{tittle:"首页"},
    component: () => import('@/components/Home.vue')
  },
  {
    path: '/login',
    name: 'login',
    meta:{tittle:"登录"},
    component: () => import('@/components/Login.vue')
  },
  {
    path: '/equipment',
    name: 'equipment',
    meta:{tittle:"设备报修"},
    component: () => import('@/views/equipmentRepairs/index.vue')
  },
  {
    path: '/equipment/repairs',
    name: 'equipmentRepairs',
    meta:{tittle:"设备报修-详情"},
    component: () => import('@/views/equipmentRepairs/repairs.vue')
  },
  {
    path: '/equipment/maintain',
    name: 'equipmentMaintain',
    meta:{tittle:"设备维修"},
    component: () => import('@/views/equipmentMaintain/index.vue')
  },
  {
    path: '/equipment/maintain/detail',
    name: 'equipmentMaintainDetail',
    meta:{tittle:"设备维修-详情",keepAlive:true},
    component: () => import('@/views/equipmentMaintain/detail.vue')
  },
  {
    path: '/equipment/maintain/experience',
    name: 'equipmentMaintainExperience',
    meta:{tittle:"维修经验查看"},
    component: () => import('@/views/equipmentMaintain/experience.vue')
  },
  {
    path: '/equipment/maintain/experienceDetail',
    name: 'equipmentMaintainExperienceDetail',
    meta:{tittle:"维修经验详情"},
    component: () => import('@/views/equipmentMaintain/experienceDetail.vue')
  },
  {
    path: '/equipment/maintain/experienceEdit',
    name: 'equipmentMaintainExperienceEdit',
    meta:{tittle:"维修经验填写"},
    component: () => import('@/views/equipmentMaintain/experienceEdit.vue')
  },
  {
    path: '/equipment/equipmentAffirm',
    name: 'equipmentAffirm',
    meta:{tittle:"维修确认"},
    component: () => import('@/views/equipmentAffirm/index.vue')
  },
  {
    path: '/equipment/equipmentAffirm/detail2',
    name: 'equipmentAffirmDetail2',
    meta:{tittle:"维修确认-详情"},
    component: () => import('@/views/equipmentAffirm/detail2.vue')
  },
  {
    path: '/equipmentAffirm/detail',
    name: 'equipmentAffirmDetail',
    meta:{tittle:"发表评价"},
    component: () => import('@/views/equipmentAffirm/detail.vue')
  },
  {
    path: '/equipmentMessage',
    name: 'equipmentMessage',
    meta:{tittle:"维修历史信息"},
    component: () => import('@/views/equipmentMessage/index.vue')
  },
  {
    path: '/equipmentMessage',
    name: 'equipmentMessage',
    meta:{tittle:"维修历史信息"},
    component: () => import('@/views/equipmentMessage/index.vue')
  },
  {
    path: '/equipmentMessage/detail',
    name: 'equipmentMessageDetail',
    meta:{tittle:"维修经验填写"},
    component: () => import('@/views/equipmentMessage/detail.vue')
  },
  {
    path: '/equipmentMessage/maintainDetail',
    name: 'equipmentMessageMaintainDetail',
    meta:{tittle:"维修详情"},
    component: () => import('@/views/equipmentMessage/maintainDetail.vue')
  },
  {
    path: '/equipmentMessage/analyst',
    name: 'equipmentMessageAnalyst',
    meta:{tittle:"故障分析"},
    component: () => import('@/views/equipmentAnalyst/index.vue')
  },
  {
    path: '/equipment/leaveOrder',
    name: 'equipmentLeaveOrder',
    meta:{tittle:"遗留单详情"},
    component: () => import('@/views/equipmentLeaveOrder/index.vue')
  },



  {
    path: '/maintain/index',
    name: 'maintainIndex',
    meta:{tittle:"设备保养",keepAlive:true},
    component: () => import('@/views/maintain/index.vue')
  },
  {
    path: '/maintain/detail',
    name: 'maintainDetail',
    meta:{tittle:"实施保养"},
    component: () => import('@/views/maintain/detail.vue')
  },
  {
    path: '/maintain/add',
    name: 'maintainAdd',
    meta:{tittle:"工时添加"},
    component: () => import('@/views/maintain/add.vue')
  },
  {
    path: '/maintainMessage/index',
    name: 'maintainMessageIndex',
    meta:{tittle:"保养历史信息"},
    component: () => import('@/views/maintainMessage/index.vue')
  },

  {
    path: '/maintainMessage/detailHistory',
    name: 'maintainMessageDetailHistory',
    meta:{tittle:"保养历史详情"},
    component: () => import('@/views/maintainMessage/detailHistory.vue')
  },

  {
    path: '/equipmentRecord/index',
    name: 'equipmentRecordIndex',
    meta:{tittle:"设备台账"},
    component: () => import('@/views/equipmentRecord/index.vue')
  },
  {
    path: '/equipmentRecord/file',
    name: 'equipmentRecordFile',
    meta:{tittle:"文档信息"},
    component: () => import('@/views/equipmentRecord/file.vue')
  },



  {
    path: '/maintainMessage/detail',
    name: 'maintainMessageDetail',
    meta:{tittle:"工时信息"},
    component: () => import('@/views/maintainMessage/detail.vue')
  },
  {
    path: '/anomalyInitiate/index',
    name: 'anomalyInitiateIndex',
    meta:{tittle:"异常发起"},
    component: () => import('@/views/anomalyInitiate/index.vue')
  },
  {
    path: '/anomalyInitiate/index/transpond',
    name: 'anomalyInitiateIndexTranspond',
    meta:{tittle:"异常-待转发"},
    component: () => import('@/views/anomalyInitiate/transpondIndex.vue')
  },
  {
    path: '/anomalyInitiate/index/appointIndex',
    name: 'anomalyInitiateIndexAppointIndex',
    meta:{tittle:"异常-待指派"},
    component: () => import('@/views/anomalyInitiate/appointIndex.vue')
  },
  {
    path: '/anomalyInitiate/index/disposeIndex',
    name: 'anomalyInitiateIndexDisposeIndex',
    meta:{tittle:"异常-待处理"},
    component: () => import('@/views/anomalyInitiate/disposeIndex.vue')
  },
  {
    path: '/anomalyInitiate/index/closeIndex',
    name: 'anomalyInitiateIndexCloseIndex',
    meta:{tittle:"异常-待关闭"},
    component: () => import('@/views/anomalyInitiate/closeIndex.vue')
  },


  {
    path: '/anomalyInitiate/detail',
    name: 'anomalyInitiateDetail',
    meta:{tittle:"异常详情"},
    component: () => import('@/views/anomalyInitiate/detail.vue')
  },
  {
    path: '/anomalyInitiate/transpond',
    name: 'anomalyInitiateTranspond',
    meta:{tittle:"异常转发"},
    component: () => import('@/views/anomalyInitiate/transpond.vue')
  },
  {
    path: '/anomalyInitiate/appoint',
    name: 'anomalyInitiateAppoint',
    meta:{tittle:"异常指派"},
    component: () => import('@/views/anomalyInitiate/appoint.vue')
  },
  {
    path: '/anomalyInitiate/dispose',
    name: 'anomalyInitiateDispose',
    meta:{tittle:"异常处理"},
    component: () => import('@/views/anomalyInitiate/dispose.vue')
  },
  {
    path: '/anomalyInitiate/close',
    name: 'anomalyInitiateClose',
    meta:{tittle:"异常关闭"},
    component: () => import('@/views/anomalyInitiate/close.vue')
  },
  {
    path: '/anomalyInitiate/sponsor',
    name: 'anomalySponsor',
    meta:{tittle:"发起异常"},
    component: () => import('@/views/anomalyInitiate/sponsor.vue')
  },
  {
    path: '/anomalyInitiate/content',
    name: 'anomalyContentPage',
    meta:{tittle:"异常节点"},
    component: () => import('@/views/anomalyInitiate/content.vue')
  },
  {
    path: '/anomalyInitiate/search',
    name: 'anomalySearchIndex',
    meta:{tittle:"异常查询"},
    component: () => import('@/views/anomalyInitiate/searchIndex.vue')
  },
  {
    path: '/anomalyInitiateSection/index',
    name: 'anomalyInitiateSectionIndex',
    meta:{tittle:"例外转序发起"},
    component: () => import('@/views/anomalyInitiateSection/index.vue')
  },
  {
    path: '/anomalyInitiateSection/dispose',
    name: 'anomalyInitiateSectionDispose',
    meta:{tittle:"例外转序处理"},
    component: () => import('@/views/anomalyInitiateSection/dispose.vue')
  },
  {
    path: '/anomalyInitiateSection/search',
    name: 'anomalyInitiateSectionSearch',
    meta:{tittle:"例外转序查询"},
    component: () => import('@/views/anomalyInitiateSection/search.vue')
  },

  {
    path: '/anomalyInitiateSection/add',
    name: 'anomalyInitiateSectionAdd',
    meta:{tittle:"例外转序编辑"},
    component: () => import('@/views/anomalyInitiateSection/add.vue')
  },
  {
    path: '/anomalyInitiateSection/discharged',
    name: 'anomalyInitiateSectionDischarged',
    meta:{tittle:"异常放行"},
    component: () => import('@/views/anomalyInitiateSection/discharged.vue')
  },
  {
    path: '/anomalyInitiateSection/close',
    name: 'anomalyInitiateSectionClose',
    meta:{tittle:"异常关闭"},
    component: () => import('@/views/anomalyInitiateSection/close.vue')
  },


  {
    path: '/qualityMaterial/index',
    name: 'qualityMaterialIndex',
    meta:{tittle:"来料检测"},
    component: () => import('@/views/qualityMaterial/index.vue')
  },
  {
    path: '/qualityMaterial/add',
    name: 'qualityMaterialAdd',
    meta:{tittle:"来料检测-新增"},
    component: () => import('@/views/qualityMaterial/add.vue')
  },


  {
    path: '/qualityMaterial/detail',
    name: 'qualityMaterialDetail',
    meta:{tittle:"原材料检验"},
    component: () => import('@/views/qualityMaterial/detail.vue')
  },
  {
    path: '/qualityMaterial/checkout',
    name: 'qualityMaterialCheckout',
    meta:{tittle:"质量检验"},
    component: () => import('@/views/qualityMaterial/checkout.vue')
  },
  {
    path: '/qualityMaterialDisqualification/index',
    name: 'qualityMaterialDisqualification',
    meta:{tittle:"来料检测-不合格处理任务"},
    component: () => import('@/views/qualityMaterialDisqualification/index.vue')
  },
  {
    path: '/qualityMaterialDisqualification/detail',
    name: 'qualityMaterialDisqualificationDetail',
    meta:{tittle:"来料检测-不合格处理单",},
    component: () => import('@/views/qualityMaterialDisqualification/detail.vue')
  },
  {
    path: '/process/index',
    name: 'processIndex',
    meta:{tittle:"过程检测",},
    component: () => import('@/views/process/index.vue')
  },
  {
    path: '/processPreview/index',
    name: 'processPreviewIndex',
    meta:{tittle:"检验预览",},
    component: () => import('@/views/processPreview/index.vue')
  },
  {
    path: '/processPreview/detail',
    name: 'processPreviewDetail',
    meta:{tittle:"检验预览-详情",},
    component: () => import('@/views/processPreview/detail.vue')
  },

  {
    path: '/process/add',
    name: 'processAdd',
    meta:{tittle:"过程检测-新增",},
    component: () => import('@/views/process/add.vue')
  },
  {
    path: '/process/detail',
    name: 'processDetail',
    meta:{tittle:"质量检验(自制件检验)",},
    component: () => import('@/views/process/detail.vue')
  },




  {
    path: '/process/index/working',
    name: '/processIndexWorking',
    meta:{tittle:"过程检测-工序检验",},
    component: () => import('@/views/process/index.vue')
  },
  {
    path: '/process/index/adjustment',
    name: '/processIndexAdjustment',
    meta:{tittle:"过程检测-调试检验",},
    component: () => import('@/views/process/index.vue')
  },  {
    path: '/process/index/put',
    name: '/processIndexPut',
    meta:{tittle:"过程检测-入库检验",},
    component: () => import('@/views/process/index.vue')
  },
  {
    path: '/process/index/self',
    name: '/processIndexSelf',
    meta:{tittle:"过程检测-自制件",},
    component: () => import('@/views/process/index.vue')
  },

  {
    path: '/process/index/abarbeitung',
    name: '/processIndexAbarbeitung',
    meta:{tittle:"整改",},
    component: () => import('@/views/process/abarbeitung.vue')
  },



  {
    path: '/process/detail2',
    name: 'processDetail2',
    meta:{tittle:"质量检验(工序检验)",},
    component: () => import('@/views/process/detail.vue')
  },
  {
    path: '/process/detail3',
    name: 'processDetail3',
    meta:{tittle:"质量检验(调试检验)",},
    component: () => import('@/views/process/detail.vue')
  },
  {
    path: '/process/detail4',
    name: 'processDetail4',
    meta:{tittle:"质量检验(入库检验)",},
    component: () => import('@/views/process/detail.vue')
  },

  {
    path: '/processDisqualification/index',
    name: 'processDisqualificationIndex',
    meta:{tittle:"过程检验-不合格处理列表",},
    component: () => import('@/views/processDisqualification/index.vue')
  },
  {
    path: '/processDisqualification/index2',
    name: 'processDisqualificationIndex2',
    meta:{tittle:"过程检验-不合格处理",},
    component: () => import('@/views/processDisqualification/index2.vue')
  },


  {
    path: '/process/remould/index',
    name: 'processRemouldIndex',
    meta:{tittle:"整改列表",},
    component: () => import('@/views/process/remould.vue')
  },

  {
    path: '/processDisqualification/detail',
    name: 'processDisqualificationDetail',
    meta:{tittle:"过程检验-不合格处理单",},
    component: () => import('@/views/processDisqualification/detail.vue')
  },


  {
    path: '/processProductionLine/index',
    name: 'processProductionLineIndex',
    meta:{tittle:"产线检验-不合格处理单",},
    component: () => import('@/views/processProductionLine/index.vue')
  },
  {
    path: '/processProductionLine/detail',
    name: 'processProductionLineDetail',
    meta:{tittle:"产线检验-不合格处理单",},
    component: () => import('@/views/processProductionLine/detail.vue')
  },


  {
    path: '/processQualifiedProductionLine/index',
    name: 'processQualifiedProductionLineIndex',
    meta:{tittle:"产线检验",},
    component: () => import('@/views/processQualifiedProductionLine/index.vue')
  },
  {
    path: '/processQualifiedProductionLine/add',
    name: 'processQualifiedProductionLine',
    meta:{tittle:"产线检验-新增",},
    component: () => import('@/views/processQualifiedProductionLine/add.vue')
  },
  {
    path: '/processQualifiedProductionLine/detail',
    name: 'processQualifiedProductionLineDetail',
    meta:{tittle:"产线检验(自制件)",},
    component: () => import('@/views/processQualifiedProductionLine/detail.vue')
  },

  {
    path: '/processQualifiedProductionLine/detail2',
    name: 'processQualifiedProductionLineDetail2',
    meta:{tittle:"产线检验",},
    component: () => import('@/views/processQualifiedProductionLine/detail.vue')
  },
  {
    path: '/processQualifiedProductionLine/detail3',
    name: 'processQualifiedProductionLineDetail3',
    meta:{tittle:"产线检验(装调自检)",},
    component: () => import('@/views/processQualifiedProductionLine/detail.vue')
  },
  {
    path: '/processQualifiedProductionLine/detail4',
    name: 'processQualifiedProductionLineDetail4',
    meta:{tittle:"产线检验",},
    component: () => import('@/views/processQualifiedProductionLine/detail.vue')
  },


  {
    path: '/taskList/index',
    name: 'taskListIndex',
    meta:{tittle:"入库检任务列表",},
    component: () => import('@/views/taskList/index.vue')
  },
  {
    path: '/taskList/putStorage',
    name: 'taskListPutStorage',
    meta:{tittle:"入库检任务列表",},
    component: () => import('@/views/taskList/putStorage.vue')
  },
  {
    path: '/taskList/order',
    name: 'taskListOrder',
    meta:{tittle:"订单配置",},
    component: () => import('@/views/taskList/order.vue')
  },
  {
    path: '/taskList/GPS',
    name: 'taskListGPS',
    meta:{tittle:"GPS绑定",},
    component: () => import('@/views/taskList/GPS.vue')
  },
  {
    path: '/taskList/result',
    name: 'taskListResult',
    meta:{tittle:"整改结果列表",},
    component: () => import('@/views/taskList/result.vue')
  },


  {
    path: '/examineConfirm/index',
    name: 'examineConfirmIndex',
    meta:{tittle:"设备点检-点检确认",},
    component: () => import('@/views/examineConfirm/index.vue')
  },
  {
    path: '/examineConfirm/detail',
    name: 'examineConfirmDetail',
    meta:{tittle:"点检单",},
    component: () => import('@/views/examineConfirm/detail.vue')
  },
  {
    path: '/examineCreation/index',
    name: 'examineCreationIndex',
    meta:{tittle:"任务创建",},
    component: () => import('@/views/examineCreation/index.vue')
  },
  {
    path: '/examineCreation/detail',
    name: 'examineCreationDetail',
    meta:{tittle:"设备点检",},
    component: () => import('@/views/examineCreation/detail.vue')
  },
  {
    path: '/examineHistory/index',
    name: 'examineHistoryIndex',
    meta:{tittle:"设备点检",keepAlive:true},
    component: () => import('@/views/examineHistory/index.vue')
  },
  {
    path: '/examineHistory/detail',
    name: 'examineHistoryDetail',
    meta:{tittle:"设备点检",keepAlive:true},
    component: () => import('@/views/examineHistory/detail.vue')
  },
  {
    path: '/examineQuery/index',
    name: 'examineQueryIndex',
    meta:{tittle:"设备点检-查询",},
    component: () => import('@/views/examineQuery/index.vue')
  },


  {
    path: '/examineSearch/index',
    name: 'examineSearchIndex',
    meta:{tittle:"点检历史信息",},
    component: () => import('@/views/examineSearch/index.vue')
  },
  {
    path: '/examineSearch/detail',
    name: 'examineSearchDetail',
    meta:{tittle:"点检单",},
    component: () => import('@/views/examineSearch/detail.vue')
  },
  {
    path: '/replacement/index',
    name: 'replacementIndex',
    meta:{tittle:"备件领用",},
    component: () => import('@/views/replacement/index.vue')
  },
  {
    path: '/backlog/index',
    name: 'backlogIndex',
    meta:{tittle:"待办",},
    component: () => import('@/views/backlog/index.vue')
  },
  {
    path: '/outPutHistory/index',
    name: 'outPutHistory',
    meta:{tittle:"出入库查询",},
    component: () => import('@/views/outPutHistory/index.vue')
  },
  {
    path: '/outPutHistory/detail',
    name: 'outPutHistoryDetail',
    meta:{tittle:"备件信息",},
    component: () => import('@/views/outPutHistory/detail.vue')
  },
  {
    path: '/outPutApply/index',
    name: 'outPutApplyIndex',
    meta:{tittle:"出入库申请",},
    component: () => import('@/views/outPutApply/index.vue')
  },
  {
    path: '/outPutApply/put',
    name: 'outPutApplyPut',
    meta:{tittle:"备品备件出入库",},
    component: () => import('@/views/outPutApply/put.vue')
  },
  {
    path: '/outPutManage/index',
    name: 'outPutManageIndex',
    meta:{tittle:"出入库管理",},
    component: () => import('@/views/outPutManage/index.vue')
  },

{
  path: '/wmsStock/index',
    name: 'wmsStockIndx',
  meta:{tittle:"wms指定库存"},
  component: () => import('@/views/wmsStock/index.vue')
},
{
  path: '/wmsTrasfer/index',
    name: 'wmsTrasferIndx',
  meta:{tittle:"备件调拨任务"},
  component: () => import('@/views/wmsTrasfer/index.vue')
},

{
  path: '/wmsTrasfer/detail',
    name: 'wmsTrasferDetail',
  meta:{tittle:"备件退库发起",},
  component: () => import('@/views/wmsTrasfer/detail.vue')
},

{
  path: '/wmsTrasfer/put',
    name: 'wmsTrasferPut',
  meta:{tittle:"备件调拨发起",},
  component: () => import('@/views/wmsTrasfer/put.vue')
},



  {
    path: '/outPutManage/detail',
    name: 'outPutManageDetail',
    meta:{tittle:"修改仓储物流-备品备件出入库",},
    component: () => import('@/views/outPutManage/detail.vue')
  },
  {
    path: '/center/station',
    name: 'centerStation',
    meta:{tittle:"绑定工位",},
    component: () => import('@/views/center/station.vue')
  },
  {
    path: '/outPutApply/giveBack',
    name: 'outPutApplyGiveBack',
    meta:{tittle:"归还",},
    component: () => import('@/views/outPutApply/giveBack.vue')
  },
  {
    path: '/storage/index',
    name: 'storageIndex',
    meta:{tittle:"SRM到货签收",},
    component: () => import('@/views/storage/index.vue')
  },
  {
    path: '/storage/detail',
    name: 'storageDetail',
    meta:{tittle:"送货单明细",},
    component: () => import('@/views/storage/detail.vue')
  },
  {
    path: '/storage/take',
    name: 'storageTake',
    meta:{tittle:"收货",},
    component: () => import('@/views/storage/take.vue')
  },
  {
    path: '/storage/add',
    name: 'storageAdd',
    meta:{tittle:"添加异常",},
    component: () => import('@/views/storage/add.vue')
  },
  {
    path: '/storageManagement/index',
    name: 'storageManagementIndex',
    meta:{tittle:"收货管理",},
    component: () => import('@/views/storageManagement/index.vue')
  },
  {
    path: '/storageManagement/error',
    name: 'storageError',
    meta:{tittle:"异常",},
    component: () => import('@/views/storageManagement/error.vue')
  },
  {
    path: '/storageManagement/errorAdd',
    name: 'storageErrorAdd',
    meta:{tittle:"仓储物料-SRM送货单-异常",},
    component: () => import('@/views/storageManagement/errorAdd.vue')
  },
  {
    path: '/storageManagement/putin',
    name: 'storagePutin',
    meta:{tittle:"入库",},
    component: () => import('@/views/storageManagement/putin.vue')
  },
  {
    path: '/battery/index',
    name: 'batteryIndex',
    meta:{tittle:"电池曲线数据调试",},
    component: () => import('@/views/battery/index.vue')
  },
  {
    path: '/energy/index',
    name: 'energyIndex',
    meta:{tittle:"电表数据录入",},
    component: () => import('@/views/energy/index.vue')
  },
  {
    path: '/energy/search',
    name: 'energySearch',
    meta:{tittle:"电表数据查询",},
    component: () => import('@/views/energy/search.vue')
  },



  // {
  //   path: '/process/checkDetail',
  //   name: 'processCheckDetail',
  //   meta:{tittle:"详情",},
  //   component: () => import('@/views/process/detail2.vue')
  // },




  {
    path: '/test/form',
    name: 'testForm',
    meta:{tittle:"表单测试页面"},
    component: () => import('@/views/test/Form.vue')
  },
  {
    path: '/test/date',
    name: 'testDate',
    meta:{tittle:"日期测试页面"},
    component: () => import('@/views/test/Date.vue')
  },
  {
    path: '/test/snackbar',
    name: 'snackBar',
    meta:{tittle:"消息测试页面"},
    component: () => import('@/views/test/Snackbar.vue')
  },
  {
    path: '/test/bi',
    name: 'bi',
    meta:{tittle:"BI-测试页面"},
    component: () => import('@/views/test/BI.vue')
  },
  {
    path: '/test/saoma',
    name: 'saoma',
    meta:{tittle:"扫码-测试页面"},
    component: () => import('@/views/test/Saoma.vue')
  },

  {
    path: '/test/weixin',
    name: 'saomaWeixin',
    meta:{tittle:"微信-测试"},
    component: () => import('@/views/test/weixin.vue')
  },


  {
    path: '/process/addProjiect',
    name: 'processAddProjiect',
    meta:{tittle:"新增"},
    component: () => import('@/views/process/addProjiect.vue')
  },



  {
    path: '/password',
    name: 'password',
    meta:{tittle:"修改密码"},
    component: () => import('@/views/center/password.vue')
  },

  {
    path: '/404',
    name:'404',
    meta:{tittle:"页面丢失了"},
    component:()=> import('@/components/404.vue')
  },
  {
    path:'/:pathMatch(.*)',
    redirect: '/404'
  }

]

const router = createRouter({
  // history: createWebHistory(process.env.BASE_URL),
  history: createWebHashHistory(),
  routes
})

export default router
