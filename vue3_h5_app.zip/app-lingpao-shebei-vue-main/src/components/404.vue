<template>
    <v-img
        :src="image"
    ></v-img>
</template>
  
<script>
export default {
    data: () => ({ 
        image: require("@/assets/404.png")
    }),
}
</script>
  

  