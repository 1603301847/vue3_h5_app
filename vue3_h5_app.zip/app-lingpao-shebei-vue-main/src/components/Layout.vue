<template>
    <span>
        <!-- <AppBarPage /> -->
        <!-- <span>111</span> -->
  
        <div class="layout-container" style="padding-bottom: 260px;">
            <!-- <keep-alive>
                <router-view/>
            </keep-alive> -->

            <router-view v-slot="{ Component }">
                <!-- 路由的meta信息中，设置了keepAlive为true的路由将会被缓存 -->
                <keep-alive>
                <component :is="Component" v-if="$route.meta.keepAlive" :key="$route.name"  />
                </keep-alive>
                <!-- 没设置keepAlive的路由就是默认的路由 -->
                <component :is="Component" v-if="!$route.meta.keepAlive" :key="$route.name"  />
            </router-view>


            <!-- <router-view /> -->

            <!-- <router-view v-if="$route.meta.keepAlive" v-slot="{ Component }">
                <keep-alive >
                    <component :is="Component" />
                </keep-alive>
            </router-view>
            <router-view v-if="!$route.meta.keepAlive" /> -->

        </div>

        <CenterComponent 
            v-if="showBottomNavigation"
        />


        <BottomNavigationPage v-if="showBottomNavigation" />
    </span>
  </template>
<script>
    import CenterComponent from '@/components/home/Center.vue'
    import AppBarPage from '@/components/AppBar.vue'
    import BottomNavigationPage from '@/components/BottomNavigation.vue'
  
  export default {
    components:{
      AppBarPage,
      BottomNavigationPage,
      CenterComponent
    },
    data:()=>({ 
        showBottomNavigation:false
    }),
    watch: {
        $route: { 
            handler(to){
                const {path}=to;

                if( ['/','/login'].includes(path) ){
                    this.showBottomNavigation=false
                }else{
                    this.showBottomNavigation=true
                }
            },
            deep: true, 
            immediate: true, 
        }
    },
    created(){
  
    },
    methods:{
  
  
  
    }
  }
  </script>

  