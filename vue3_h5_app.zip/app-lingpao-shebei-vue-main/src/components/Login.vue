<template>
    <div class="login-page">

      <div class="form-container">
        <v-card
          class="mx-auto pa-4 pb-4"
          elevation="0"
          max-width="448"
          rounded="lg"
        >
          <v-img
              class="mx-auto mb-10"
              max-width="218"
              :src="logoImage"
              @click="imageClick"
          ></v-img>

          <v-form ref="form">

          <div class="text-subtitle-1 text-medium-emphasis">用户名</div>

          <v-text-field
              v-model="formValue.name"
            placeholder="请输入用户名"
            prepend-inner-icon="mdi-account"
            variant="solo"
            density="compact"
            autocomplete="off"
            :rules="[
                  v => !!v || '用户名必填！',
              ]"
              required
              @blur=" hideBottomFunc1(false)  "
              @focus=" hideBottomFunc1(true) "

          ></v-text-field>

          <div class="text-subtitle-1 text-medium-emphasis d-flex align-center justify-space-between">
            密码

            <!-- <a
              class="text-caption text-decoration-none text-blue"
              href="#"
              rel="noopener noreferrer"
              target="_blank"
            >
              忘记密码?</a> -->
          </div>

          <v-text-field
              v-model="formValue.password"
            :append-inner-icon="visible ? 'mdi-eye-off' : 'mdi-eye'"
            :type="visible ? 'text' : 'password'"
            placeholder="请输入密码"
            autocomplete="off"
            prepend-inner-icon="mdi-lock-outline"
            variant="solo"
            density="compact"
            :rules="[
                  v => !!v || '密码必填！',
              ]"
              required
            @click:append-inner="visible = !visible"
            @blur=" hideBottomFunc2(false) "
            @focus=" hideBottomFunc2(true) "
          ></v-text-field>

          <div style="margin-bottom: 12px;">
            <van-checkbox v-model="checkedPas">
              <span style="color: #fff;">记住密码？</span>
            </van-checkbox>
          </div>

          <!-- <v-card
            class="mb-12"
            color="surface-variant"
            variant="tonal"
          >
            <v-card-text class="text-medium-emphasis text-caption">
              Warning: After 3 consecutive failed login attempts, you account will be temporarily locked for three hours. If you must login now, you can also click "Forgot login password?" below to reset the login password.
            </v-card-text>
          </v-card> -->

          <!-- <v-row no-gutters>
            <v-col cols="4">
              <v-text-field
                v-model="formValue.code"
                placeholder="验证码"
                prepend-inner-icon="mdi-xml"
                variant="solo"
                density="compact"
                :rules="[
                      v => !!v || '验证码必填！',
                  ]"
                  required
                ></v-text-field>
            </v-col>
            <v-col cols="7" class="pl-3">
              <v-img
                style="height:42px;width:98px;display: inline-block;position:relative;top:0px;"
                height="35"
                width="82"
                :src="data64Image"
                @click="getCode"
              ></v-img>
              <v-btn
                color="primary"
                density="compact"
                variant="plain"
                style="padding:0px;position:relative;top:-16px;left:8px;"
                @click="getCode"
              >
                获取验证码
              </v-btn>
            </v-col>

          </v-row> -->

          </v-form>





          <v-btn
            block
            class="login-btn"
            size="large"
            variant="tonal"
            @click="loginHandle"
          >
            登 录
          </v-btn>

          <!-- <v-card-text class="text-center">
            <a
              class="text-blue text-decoration-none"
              href="#"
              rel="noopener noreferrer"
              target="_blank"
            >
              Sign up now <v-icon icon="mdi-chevron-right"></v-icon>
            </a>
          </v-card-text> -->
        </v-card>
      </div>
        <!-- <v-img
            max-width="218"
            :src="logoImageBack"

        ></v-img> -->

      <van-popup
            v-model:show="showPicker"
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round
            :close-on-click-overlay="false"
        >
            <div>
                <div style="margin-bottom: 12px;margin-top: 32px;">

                  <p>管理员密码</p>
                  <v-text-field
                    v-model="IPPassword"
                    density="compact"
                    variant="solo"
                    elevation="0"
                    placeholder="管理员密码"
                    single-line
                    hide-details
                    autocomplete="off"
                  >
                  </v-text-field>
                  <div style="height: 22px;"></div>

                  <p>设备IP地址</p>
                  <v-text-field
                    v-model="custemIPValue"
                    density="compact"
                    variant="solo"
                    elevation="0"
                    placeholder="自定义IP地址"
                    single-line
                    hide-details
                    autocomplete="off"
                  >
                    <!-- <template v-slot:prepend-inner>
                        <v-icon @click="()=> custemIPValueNumber=0"  color="primary" icon="mdi-close"></v-icon>
                    </template>
                    <template v-slot:append-inner>
                        <v-icon @click="setIPHandle" color="primary" icon="mdi-check-bold"></v-icon>
                    </template> -->

                  </v-text-field>
                  <p style="color: #ccc;">例如: http://172.16.65.249/stage-api</p>
                </div>

                <div style="height:32px;"></div>
                <v-row no-gutters>
                    <v-col cols="6" class="text-center">
                        <v-btn variant="plain" block @click="cancelFunc">
                            取消
                        </v-btn>
                    </v-col>
                    <v-col cols="6" class="text-center">
                        <v-btn
                            variant="plain"
                            color="primary"
                            block
                            @click="confirmHandle"
                        >
                            确定
                        </v-btn>
                    </v-col>
                </v-row>
                <div style="height: 12px;"></div>
            </div>

      </van-popup>

      <div v-if="!hideBottom1 && !hideBottom2" class="bottom-text-login">
        <p class="font-weight-medium">零跑科技</p>
        <!-- <p>Copyright@2022-2039</p> -->
      </div>

    </div>
</template>

<script>
  import {JSEncrypt} from 'jsencrypt'
  import {loginHTTP} from '@/http/login'   // api
  import { showSuccessToast,showFailToast } from 'vant'
  import {httpHandle} from '@/http/http'  // api



// 密钥
const publicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDDUWQteEr5ZCpOgO0NJ7SM706M\n' +
  'fUleLNxE/8tYhiEkViZ1TISv1oycR8oxO2PCQEAp8ek+RxpJVxGmhl6PWUIVCvr4\n' +
  'ZhBBv3B1aRhq1o5ZIvBkosDnFm+jWfX/LJ4R4uXMHXS7/xxPSz8OKOMs2IG9KdOq\n' +
  '+TLKFsTgqjKDWuOL9QIDAQAB'
const privateKey = 'MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAMNRZC14SvlkKk6A\n' +
  '7Q0ntIzvTox9SV4s3ET/y1iGISRWJnVMhK/WjJxHyjE7Y8JAQCnx6T5HGklXEaaG\n' +
  'Xo9ZQhUK+vhmEEG/cHVpGGrWjlki8GSiwOcWb6NZ9f8snhHi5cwddLv/HE9LPw4o\n' +
  '4yzYgb0p06r5MsoWxOCqMoNa44v1AgMBAAECgYEAsE9NZbo7u4oOopTA52obEkmH\n' +
  'F0yVKPzHzUU2Mu/JBPr7dlEfSXcbsIshWnWo5JWJFhP4Hy6h7Og6155dx3qkKbOL\n' +
  'FQ9Shwr6ffJ8obLhmdQHIBCt5j58bth7oBGO/kCRGKAtCCnzfwJn/OuwSLQDgUkd\n' +
  '/ED9euQt7wXGj4zsGBUCQQDy8qvkGm2WeGTDCw/3DBswGK3yY591E45Gpn8bdddI\n' +
  'ByTWQpCsW6PlVQhYPe8ugUn1DWU7p9qo5Nbl7HXO2D6TAkEAzc+m0BH42WVaEyDi\n' +
  'JJa8yLQQk67b2jWIeg+NlJhNk+1dkLowPlVdd8F2GPDuxF4Cfnnsg/XP3OSxh5Ap\n' +
  'RSWYVwJAEUkw78btmzIvwSztUt+ao55t6fwqoVLl4aMBEjwdODPB7DjKQGk4zR1y\n' +
  'vYySkxWB5JyyYj88MJ4vqCZd73y1XwJAD9l4+DcaGevTNvvmTnkJSs+LI0RpC/Hp\n' +
  'c7T060ebWdQCy517D6HVU96jMKKFULwIpyLOkw8AFfvKrCzu8LNHewJBALFSNdle\n' +
  'XX5yzD1eMbIRTMKZ8PlD8JdFoPjX7sq5JLURjPkoc/Z6kNoLpDrvgW4U0Ipk/xiz\n' +
  'Yn9C33IPqIqjg5k='



  // 加密
  function encrypt(txt) {
    const encryptor = new JSEncrypt()
    encryptor.setPublicKey(publicKey) // 设置公钥
    return encryptor.encrypt(txt) // 对数据进行加密
  }

  // 解密
  function decrypt(txt) {
    const encryptor = new JSEncrypt()
    encryptor.setPrivateKey(privateKey) // 设置私钥
    return encryptor.decrypt(txt) // 对数据进行解密
  }


  export default {
    data: () => ({
        hideBottom1:false,
        hideBottom2:false,


        checkedPas:false,


        custemIPValueNumber:0,    // 计数
        custemIPValue:"",   // 自定义IP

        showPicker: false,  //
        IPPassword:"",   // IP 密码

        // 表单数据
        formValue:{
            name: '',
            password:'',
            code:""
        },

        logoImage: require("@/assets/loginApp.png"),
        // logoImageBack: require("@/assets/login-ba.jpg"),

        visible: false,

        data64Image:"",
        uuid:""
    }),
    created(){
      this.initFunc()
    },
    methods:{
        // 隐藏底部
        hideBottomFunc1(active){
          // if (window.plus) return
          this.hideBottom1=active
        },
        hideBottomFunc2(active){
          // if (window.plus) return
          this.hideBottom2=active
        },
        async initFunc(){
          // const {uuid,img}=await codeHTTP()
          // console.log(img)



          this.checkedPas= JSON.parse(  localStorage.getItem("bufferCheckedPas") )



          // 登录信息
          const {name,password}= JSON.parse( localStorage.getItem("bufferLoginMessage") || "{}" )
          this.formValue.name=name
          this.formValue.password=password


          // this.data64Image=`data:image/gif;base64,${img}`
          // this.uuid=uuid

          this.formValue.code=""
        },
        async loginHandle () {
            const {uuid,checkedPas}=this;
            const _code=this.formValue.code
            const {name,password} = this.formValue
            const {valid} = await this.$refs.form.validate()




            if(!valid){
              // alert('表单不完整！')
              return
            }

            const {code,data={}}=await loginHTTP({
              payload:{
                code: _code,
                uuid: uuid,
                username:name,
                password:encrypt( password )
              }
            });


            if(code==200){


              localStorage.setItem("bufferCheckedPas", JSON.stringify(checkedPas) )


              if(checkedPas){
                // 登录信息
                localStorage.setItem("bufferLoginMessage", JSON.stringify({
                  name:name,
                  password:password,
                }))
              }else{
                // 登录信息
                localStorage.setItem("bufferLoginMessage", JSON.stringify({
                  name:"",
                  password:"",
                }))
              }



              // token
              localStorage.setItem("_token",data.access_token)

              // 菜单 清除
              localStorage.setItem("bufferGlobalMenuList","")


              // 获取 用户信息
              await this.getUserInfo()

              // 工位
              await this.getStation()

              // 获取 数据字典
              await this.dictionariesGET()

              showSuccessToast('登录成功！');
              this.$router.push("/");
            }

        },
        async getStation(){
          const {code,data={}}= await httpHandle({
            url:'/iiot/userUloc/getUserUlocByUser',
            method:'GET'
          })

          if(code==200){
            localStorage.setItem("bufferUserStation", JSON.stringify(data) )
          }
        },
        async getUserInfo(){
          const {code,user={},permissions=[]}= await httpHandle({
            url:'/system/user/getInfo',
            method:'GET'
          })

          if(code==200){
            localStorage.setItem("bufferUserInfo", JSON.stringify(user) )
            localStorage.setItem("bufferPermissions", JSON.stringify(permissions) )
          }
        },
        // 全局数据字典
        async dictionariesGET(){

          const obj= await httpHandle({
            url:'/iiot/nodeLevel/getDicts',
            method:'GET'
          })

          localStorage.setItem("bufferDictionaries",JSON.stringify(obj||{}))
        },
        getCode(){
          this.initFunc()
        },
        imageClick(){
          this.custemIPValueNumber=this.custemIPValueNumber+1

          if( this.custemIPValueNumber>=9 ){
            this.custemIPValue=localStorage.getItem("_custemIP")
            this.IPPassword=""
            this.showPicker=true
          }
        },
        cancelFunc(){
          this.showPicker=false
          this.custemIPValueNumber=0
        },
        // 设置IP
        confirmHandle(){

          if( this.IPPassword.trim() !="admin" ){
            showFailToast("管理员密码错误！")
            return
          }

          const _value=this.custemIPValue.trim()
          localStorage.setItem("_custemIP",_value)

          showSuccessToast(`${_value} 设置成功`)
          this.cancelFunc()
        }
    }
  }
</script>
<style lang="scss">
.login-page{
    position: relative;
    padding-top: 15%;
    padding-left: 18px;
    padding-right: 18px;
    left: 0px;
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0px;
    background-image: url('./../assets/shebei.png');
    background-repeat: round;
    background-position: 0px 0px;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;

    .login-btn{
      // background-color: red;
      background: linear-gradient(to right,#005aee,#18FFFF);
      box-shadow: none;
      color: #fff;
      border-radius: 12px;
    }

  .form-container{
      background-color: rgba(24,255,255,0.2);
      border-radius: 26px;
      padding-top: 38px;
      padding-bottom: 28px;

      >div.v-card{
        background-color: initial;
      }
  }
}
.bottom-text-login{

  width: 100%;
  height: 38px;
  // background-color: antiquewhite;
  position: absolute;
  left: 0px;
  bottom: 0px;
  text-align: center;
  margin-bottom: 6px;

  >p{
    margin-bottom: 2px;
    color: #fff;
  }
}
</style>

