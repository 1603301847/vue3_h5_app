<template>
    <v-carousel
        cycle
        :interval="3000"
        :show-arrows="false"
        height="180"
        delimiter-icon="mdi-square"
        hide-delimiter-background
    >
        <v-carousel-item
            v-for="(slide, i) in slides"
            :key="i"
        >
            <v-sheet
                color="#fff"
                height="100%"
                tile
            >
            <div class="d-flex fill-height justify-center align-center">
                <!-- <div class="text-h2">
                {{ slide }} Slide
                </div> -->
                <v-img
                    v-if="i==0"
                    class="mx-auto mb-10"
                    max-height="130"
                    :src="logoImage1"
                ></v-img>

                <v-img
                    v-if="i==1"
                    class="mx-auto mb-10"
                    max-height="130"
                    :src="logoImage2"
                ></v-img>

                <v-img
                    v-if="i==2"
                    class="mx-auto mb-10"
                    max-height="130"
                    :src="logoImage3"
                ></v-img>

            </div>
            </v-sheet>
        </v-carousel-item>
    </v-carousel>
</template>
  
<script>
export default {
    data: () => ({ 

        logoImage1: require("@/assets/home-carouusel1.png"),
        logoImage2: require("@/assets/home-carouusel2.png"),
        logoImage3: require("@/assets/home-carouusel3.png"),



        colors: [
          '#fff',
          'secondary',
          'yellow darken-4',
          'red lighten-2',
          'orange darken-1',
        ],
        slides: [
          'First',
          'Second',
          'Third',
        //   'Fourth',
        //   'Fifth',
        ],
    }),
    methods:{

    },
    props: {


    }
}
</script>
  

  