<template>
    <v-navigation-drawer
        v-model="drawer"
        location="right"
        style="padding: 18px 0px;"
    >
        <!-- <v-list-item
          :prepend-avatar="userImage"
          title="李某某"
        ></v-list-item> -->
        <v-list>
          <v-list-item
            :prepend-avatar="userImage"
            :title="name"
            :subtitle="email"
          >
            <!-- <template v-slot:append>
              <v-btn
                size="small"
                variant="text"
                icon="mdi-menu-down"
              ></v-btn>
            </template> -->
          </v-list-item>

          <v-list-item
            style="min-height:32px;height:32px;"
            :title="`版本: ${appVersion}`"
          />

          <p style="word-wrap:break-word;padding: 0px 14px;">{{ `工位: ${stationText}` }}</p>

        </v-list>

        <v-divider style="padding-bottom:12px;"></v-divider>

        <v-list density="compact" nav>
            <!-- <v-list-item 
                prepend-icon="mdi-view-dashboard" 
                title="Home" 
                value="home"
                active-color="primary"
                rounded="shaped"
            ></v-list-item> -->
            <v-list-item 
                v-for="(item,i) in itemList"
                :key="i"
                :active="false"
                :prepend-icon="item.icon" 
                :title="item.title" 
                :value="item.value"
                active-color="primary"
                rounded="shaped"
                @click="itemHandle(item)"
            ></v-list-item>
        </v-list>
    </v-navigation-drawer>
</template>
  
<script>
    import {httpHandle} from '@/http/http'  // api

import {AppVersion} from '@/config.js'

export default {
    data: () => ({ 
        drawer:false,
        userImage: require("@/assets/user.png"),

        appVersion:"",   // 版本号
        stationText:"",   // 当前工位

        name:"", 
        email:"",

        itemList:[
            {
                icon:"mdi-link-variant",
                title:"绑定工位", 
                value:"station"
            },
            {
                icon:"mdi-lock",
                title:"修改密码", 
                value:"changePassword"
            },
            {
                icon:"mdi-send-outline",
                title:"退出登录", 
                value:"out"
            }
        ]
    }),
    watch: {
        'drawer': { 
            handler(value){
                this.$store.dispatch("changeUserCenter", value ) 
            },
        },
        '$store.state.actionsStore.showUserCenter': { 
            handler(value){
                this.drawer=value
                if(value){
                    this.getStation()
                }
            },
            deep: true, 
            immediate: true, 
        },
    },
    created(){
        this.initFunc()
        this.getStation()
    },
    methods:{
        // 获取 绑定工位
        async getStation(){
          const {code,data=[]}= await httpHandle({
            url:'/iiot/userUloc/getUserUlocByUser',
            method:'GET'
          })

          if(code==200){
            this.stationText= data.map(o=> o.nodeLevelNo).join()
          }
        },

        initFunc(){
            const _bufferUserInfo=JSON.parse(localStorage.getItem("bufferUserInfo")||"{}")

            this.appVersion=AppVersion

            this.name= _bufferUserInfo.userName||''  // 用户名
            this.email= _bufferUserInfo.email||''   // 邮箱

            // const _text=JSON.parse( localStorage.getItem("bufferUserStation")||"{}" )
            // if(_text.nodeLevelNo || _text.nodeLevelName){
            //     this.stationText=`${_text.nodeLevelNo||''}-${_text.nodeLevelName||''}`
            // }

        },
        open(){
            // this.drawer=true
        },
        itemHandle(option){
            const {value}=option

            switch (value) {
                case "out":
                    localStorage.setItem("_token","")
                    this.$router.push("/login");
                    break;
                case "changePassword":
                    this.$router.push("/password");
                    break;      
                case "station":
                    this.$router.push("/center/station");
                    break;                     
                    
                    
                default:
                    break;
            }

            this.$store.dispatch("changeUserCenter", false ) 

        }
    },
    props: {

    }
}
</script>
  

  