<template>
    <div class="home-menu-container-box">
        <!-- <h1>112233</h1> -->
        <div style="height:4px;"></div>
        <v-card
            elevation="1"
            class="card-box-menu"
        >   
            <v-card-item>
                <v-row no-gutters class="text">
                    <v-col cols="12">
                        <v-icon size="16" style="margin-top: 6px;" :color="iconColor" :icon="icon"></v-icon>
                        <span style="position:relative;top:4px;left:6px;">{{ title }}</span>
                    </v-col>
                    <!-- <v-col cols="11">
                        <v-card-title class="menu-card-title font-weight-medium">{{ title }}</v-card-title>
                    </v-col> -->
                </v-row>

            </v-card-item>

            <div class="li-items-box">
                <div v-for="(o,i) in children" :key="i" class="card-li">
                    <v-card 
                        class="pa-2" 
                        outlined 
                        tile
                        shaped
                        elevation="0"
                        @click="cardClick(o)"

                    >
                        <!-- <div style="width:100%;height:100%;text-align:center;margin-bottom:14px;margin-top:10px;">
                        </div> -->
                        <v-icon size="28" :color="o.color" :icon="o.icon"></v-icon>
                    </v-card>
                    <p class="font-weight-medium text">{{ o.text }}</p>

                </div>
            </div>

        </v-card>


        <van-popup 
            v-model:show="showPicker" 
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round 
            closeable
        >
            <div>
                <p style="font-size: 18px;padding: 8px 0px 8px 6px;">选择</p>
                <div style="height:12px"></div>

                <span v-for="(o,i) in qualityMaterialPageList" :key="i">
                    <v-btn block color="primary" @click="qualityMaterialHandle(o)">
                        {{ o.text }}
                    </v-btn>
                    <div style="height:12px"></div>
                </span>

                <div style="height: 22px;"></div>
            </div>
        </van-popup>


    </div>


</template>
  
<script>
export default {
    data: () => ({ 
        showPicker:false,

        qualityMaterialPageList:[],   // 来料检测 页面选择
    }),
    created(){
        this.initFunc()
    },  
    methods:{
        // 初始化
        async initFunc(){
            const _bufferDictionaries=JSON.parse(localStorage.getItem("bufferDictionaries")||"{}")

            // 来料检测 页面选择
            const _selectAttribute=_bufferDictionaries["in_part_model"]||[]   
            this.qualityMaterialPageList=_selectAttribute.map(o=>Object.assign({text:o.lable,value:o.value}))   // 属性数据
        
            // console.log( this.qualityMaterialPageList )
        },
        // 菜单跳转
        cardClick(option){
            const { $emitter } = this.$root
            const {path}=option

            // 来料检测
            // if( path=="/qualityMaterial/index" ){
            //     this.showPicker=true
            //     return
            // }
            
            // 设备保养
            if(path=="/maintain/index"){
                $emitter.emit("update_maintain_page")
            }

            // 设备点检
            if(path=="/examineHistory/index"){
                $emitter.emit("update_examineHistory_page")
            }

            
     
  
            this.$router.push(path)
        },
        // 来料检测 页面跳转
        qualityMaterialHandle(option){
            const {value}=option

            localStorage.setItem("_qualityMaterialPartModel",value)

            this.$router.push({
                path:'/qualityMaterial/index', 
                query:{  }
            })  
        }
    },
    props: {
        title:{
            type: String,
            default: ()=> ""
        },
        icon:{
            type: String,
            default: ()=> ""
        },
        iconColor:{
            type: String,
            default: ()=> ""
        },
        children:{
            type: Array,
            default: ()=> [] 
        }
    }
}
</script>
<style lang="scss">
.layout-container{
    // background-color: aliceblue;
}
.home-menu-container-box{
    // background-color: aquamarine;
    // padding: 12px 6px 12px 6px;
    padding-top: 6px;

    .menu-card-title{
        font-size: 16px;
    }

    .li-items-box{
        padding-left: 6px;
        padding-right: 6px;
    }

    .card-box-menu{
        padding-bottom: 10px !important;
    }

    .card-li{
        width: 80px;
        height: 52px;
        display:block;
        float: left;
        // margin-right: 13px;
        margin-bottom: 46px;
        // margin-right: 12px;
        // margin-bottom: 14px;

        >p{
            text-align: center;
            font-size: 13px;
            margin-top: 6px;
        }
        
        .v-card{
            padding: 0px;
            height: 100%;
            width: 100%;
            text-align: center;
            border-radius: 8px !important;
            padding-top: 10px !important;
        }
    }
}
</style>  

  