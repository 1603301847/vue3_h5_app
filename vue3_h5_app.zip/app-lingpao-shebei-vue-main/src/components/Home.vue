<template>
    <span class="layout-home">
        <AppBarPage />

        <MenuCardComponent
            v-show="hideMenu6"
            title="异常管理"
            icon="mdi-alert"
            iconColor="#FF9800"
            :children="childrenMenu6"
        />

        <MenuCardComponent
            v-show="hideMenu8"
            title="例外转序"
            icon="mdi-gamepad-circle"
            iconColor="#C0CA33"
            :children="childrenMenu8"
        />

        <MenuCardComponent
            v-show="hideMenu5"
            title="过程检测"
            icon="mdi-expansion-card-variant"
            iconColor="#00E5FF"
            :children="childrenMenu5"
        />

        <MenuCardComponent
            v-show="hideMenu1"
            title="设备维修"
            icon="mdi-tools"
            iconColor="#3F51B5"
            :children="childrenMenu1"
        />

        <MenuCardComponent
            v-show="hideMenu3"
            title="设备点检"
            icon="mdi-account-wrench"
            iconColor="#FF9800"
            :children="childrenMenu3"
        />

        <MenuCardComponent
            v-show="hideMenu2"
            title="设备保养"
            icon="mdi-dns"
            iconColor="#8BC34A"
            :children="childrenMenu2"
        />

        <MenuCardComponent
            v-show="hideMenu4"
            title="来料检测"
            icon="mdi-quality-high"
            iconColor="#C0CA33"
            :children="childrenMenu4"
        />

        <MenuCardComponent
            v-show="hideMenu9"
            title="产线检验"
            icon="mdi-sitemap-outline"
            iconColor="#3F51B5"
            :children="childrenMenu9"
        />

        <MenuCardComponent
            v-show="hideMenu7"
            title="备件"
            icon="mdi-atom"
            iconColor="#8BC34A"
            :children="childrenMenu7"
        />

        <MenuCardComponent
            v-show="hideMenu10"
            title="仓储管理"
            icon="mdi-database"
            iconColor="#1DE9B6"
            :children="childrenMenu10"
        />

        <MenuCardComponent
            v-show="hideMenu11"
            title="能源管理"
            icon="mdi-barrel"
            iconColor="#8BC34A"
            :children="childrenMenu11"
        />


        <div style="height: 22px;"></div>
        <p style="text-align: center;" @click="textNumber">-到底了-</p>

        <!-- <v-row class="home-card">
            <v-col cols="6">
                <CardBtnComponent
                    name="service"
                    title="设备维修"
                    icon="mdi-tools"
                    color-icon="#3F51B5"
                    @clickCard="btnCardHandle"
                />
            </v-col>
            <v-col cols="6">
                <CardBtnComponent
                    name="maintain"
                    title="设备保养"
                    icon="mdi-dns"
                    color-icon="#8BC34A"
                    @clickCard="btnCardHandle"
                />
            </v-col>
        </v-row> -->

        <!-- <v-row class="home-card">
            <v-col cols="6">
                <CardBtnComponent
                    name="examine"
                    title="设备点检"
                    icon="mdi-account-wrench"
                    color-icon="#FF9800"
                    @clickCard="btnCardHandle"
                />
            </v-col>
        </v-row> -->

        <!-- <v-row class="home-card">
            <v-col cols="6">
                <CardBtnComponent
                    name="quality"
                    title="质量检测"
                    icon="mdi-quality-high"
                    color-icon="#C0CA33"
                    @clickCard="btnCardHandle"
                />
            </v-col>
            <v-col cols="6">
                <CardBtnComponent
                    name="process"
                    title="过程检测"
                    icon="mdi-expansion-card-variant"
                    color-icon="#00E5FF"
                    @clickCard="btnCardHandle"
                />
            </v-col>
        </v-row> -->

        <!-- <v-row class="home-card">
            <v-col cols="6">
                <CardBtnComponent
                    name="abnormal"
                    title="异常处理"
                    icon="mdi-alert"
                    color-icon="#FF9800"
                    @clickCard="btnCardHandle"
                />
            </v-col>
        </v-row> -->





        <!-- <v-row>
            <v-col cols="4"><v-divider style="position:relative;top:18px"></v-divider></v-col>
            <v-col cols="4" class="text-center"><v-card-title style="font-size:14px;">到底了</v-card-title></v-col>
            <v-col cols="4"><v-divider style="position:relative;top:18px"></v-divider></v-col>
        </v-row> -->

        <!-- <MenuComponent
            ref="menuRef"
        /> -->

        <van-popup
            v-model:show="showPicker"
            :style="{ padding:'12px 12px 4px 12px',width:'80%'}"
            round
            closeable
        >
            <div>
                <p style="font-size: 18px;padding: 8px 0px 8px 6px;">版本更新</p>
                <!-- <div style="height:12px"></div> -->
                <v-list lines="one">
                    <v-list-item
                        title="当前版本"
                        :subtitle="currentVersion"
                    ></v-list-item>
                </v-list>

                <v-list lines="one">
                    <v-list-item
                        title="最新版本"
                        :subtitle="newVersion"
                    ></v-list-item>
                </v-list>

                <div style="height:12px;"></div>
                <v-row no-gutters style="padding: 0px 6px;">
                    <v-col cols="12" class="text-center">
                        <v-btn
                            color="primary"
                            block
                            @click="downloadFunc"
                        >
                            下载最新版本
                        </v-btn>
                    </v-col>
                </v-row>

                <div style="height: 22px;"></div>
            </div>
        </van-popup>



    </span>

</template>

<script>
    import AppBarPage from '@/components/AppBar.vue'
    import CarouselComponent from '@/components/home/Carousel.vue'
    import CardBtnComponent from '@/components/home/CardBtn.vue'
    import MenuCardComponent from '@/components/home/MenuCard.vue'

    import MenuComponent from '@/components/home/MenuComponent.vue'

    import {httpHandle} from '@/http/http'  // api
    import {AppVersion,baseURLApp} from '@/config.js'



export default {
    components:{
        AppBarPage,
        CarouselComponent,
        CardBtnComponent,
        MenuCardComponent,
        MenuComponent,

    },
    data: () => ({
        numberTest:1,

        hideMenu1:true,   // 隐藏菜单1
        hideMenu2:true,   // 隐藏菜单2
        hideMenu3:true,   // 隐藏菜单3
        hideMenu4:true,   // 隐藏菜单4
        hideMenu5:true,   // 隐藏菜单5
        hideMenu6:true,   // 隐藏菜单6
        hideMenu7: true,   // 隐藏菜单7
        hideMenu8: true,   // 隐藏菜单8
        hideMenu9: true,   // 隐藏菜单9
        hideMenu10: true,   // 隐藏菜单10
        hideMenu11: true,   // 隐藏菜单11



        // drawer:true
        showPicker:false,   // 修改版本号

        currentVersion:"",  // 当前版本号
        newVersion:"",    // 最新版本

        // 设备维修 菜单 模块
        childrenMenu1:[
            // {
            //     text: '设备报修',
            //     icon: 'mdi-bullhorn',
            //     color: "#3F51B5",
            //     path: '/equipment'
            // },
            // {
            //     text: '设备维修',
            //     icon: 'mdi-hammer-wrench',
            //     color: "#1DE9B6",
            //     path: '/equipment/maintain'
            // },
            // {
            //     text: '维修确认',
            //     icon: 'mdi-check-bold',
            //     color: "#18FFFF",
            //     path: '/equipment/equipmentAffirm'
            // },
            // {
            //     text: '维修信息',
            //     icon: 'mdi-message-processing',
            //     color:"#FF9800",
            //     path: '/equipmentMessage'
            // },
        ],

        // 设备保养 菜单 模块
        childrenMenu2:[
            // {
            //     text: '设备保养',
            //     icon: 'mdi-dns',
            //     color:'#8BC34A',
            //     path: '/maintain/index'
            // },
            // {
            //     text: '保养信息',
            //     icon: 'mdi-message-processing',
            //     color:"#FF9800",
            //     path: '/maintainMessage/index'
            // }
        ],

        // 设备点检 菜单 模块
        childrenMenu3:[
            // {
            //     text: '点检确认',
            //     icon: 'mdi-checkbox-marked-circle-plus-outline',
            //     color:'#8BC34A',
            //     path: '/examineConfirm/index'
            // },
            // {
            //     text: '巡检创建',
            //     icon: 'mdi-tab-plus',
            //     color:'#3F51B5',
            //     path: '/examineCreation/index'
            // },
            // {
            //     text: '设备巡检',
            //     icon: 'mdi-history',
            //     color:'#455A64',
            //     path: '/examineHistory/index'
            // },
            // {
            //     text: '点检信息',
            //     icon: 'mdi-text-search',
            //     color:'#1DE9B6',
            //     path: '/examineSearch/index'
            // }
        ],

        // 质量检测 菜单 模块
        childrenMenu4:[
            // {
            //     text: '来料检测',
            //     icon: 'mdi-dns',
            //     color:'#8BC34A',
            //     path: '/qualityMaterial/index'
            // },
            // {
            //     text: '不合格处理',
            //     icon: 'mdi-alert-circle',
            //     color:"#E53935",
            //     path: '/qualityMaterialDisqualification/index'
            // }
        ],

        // 过程检测 菜单 模块
        childrenMenu5:[
            // {
            //     text: '过程检测',
            //     icon: 'mdi-dns',
            //     color:'#8BC34A',
            //     path: '/process/index'
            // },
            // {
            //     text: '不合格处理',
            //     icon: 'mdi-alert-circle',
            //     color:"#E53935",
            //     path: '/processDisqualification/index'
            // },
        ],

        // 异常处理 菜单 模块
        childrenMenu6:[
            // { text: '异常处理',path:"/anomalyInitiate/index", color:'warning', icon:'mdi-alert-circle' },
            // { text: '异常转发',path:'/anomalyInitiate/index/transpond', color:'#AFB42B', icon: 'mdi-forwardburger' },
            // { text: '异常指派',path:'/anomalyInitiate/index/appointIndex', color:'#303F9F', icon: 'mdi-clipboard-arrow-left' },
            // { text: '异常处理',path:'/anomalyInitiate/index/disposeIndex',color:'#43A047', icon: 'mdi-monitor-small' },
            // { text: '异常关闭',path:'/anomalyInitiate/index/closeIndex',color:'#E53935', icon: 'mdi-close-circle-outline' },
        ],

        // 备件
        childrenMenu7:[
            // { text: '出入库申请',path:"/outPutApply/index", color:'#43A047', icon:'mdi-import' },
            // { text: '出入库管理',path:"/outPutManage/index", color:'warning', icon:'mdi-export' },
            // { text: '出入库查询',path:"/outPutHistory/index", color:'#1DE9B6', icon:'mdi-text-search' },
        ],

        // 例外转序
        childrenMenu8:[
            // { text: '转序发起',path:"/anomalyInitiateSection/index", color:'#43A047', icon:'mdi-plus' },
            // { text: '转序处理',path:"/anomalyInitiateSection/dispose", color:'warning', icon:'mdi-calendar-edit' },
            // { text: '转序查询',path:"/anomalyInitiateSection/search", color:'#1DE9B6', icon:'mdi-text-search' },
        ],


        // 产线检测
        childrenMenu9:[
            // { text: '产线检验',path:"/processQualifiedProductionLine/index", color:'#43A047', icon:'mdi-sitemap-outline' },
            // { text: '不合格处理',path:"/processProductionLine/index", color:'#E53935', icon:'mdi-alert-circle' },
            // { text: '转序查询',path:"/anomalyInitiateSection/search", color:'#1DE9B6', icon:'mdi-text-search' },
        ],

        // 仓储管理
        childrenMenu10:[
            // { text: '到货签收',path:"/storage/index", color:'#43A047', icon:'mdi-file-sign' },
            // { text: '收货管理',path:"/storageManagement/index", color:'warning', icon:'mdi-account-badge' },
        ],


        // 能源管理
        childrenMenu11:[
            // { text: '电表数据录入',path:"/energy/index", color:'warning', icon:'mdi-file-sign' },
            // { text: '电表数据查询',path:"/energy/search", color:'#43A047', icon:'mdi-text-search' },
        ]
    }),
    created(){
        this.getVersion()
        this.getMenu()
    },
    methods:{
        // 获取 菜单
        async getMenu(){
            const _bufferGlobalMenuList=localStorage.getItem("bufferGlobalMenuList")


            if(_bufferGlobalMenuList){
                this.menuFormat( JSON.parse(_bufferGlobalMenuList) )
                return
            }


            const {code,data=[]}= await httpHandle({
                url:'/system/menu/getRouters/A/6',
                method:'get'
            })

            if(code==200){
                const _menuList=(data[0]||{})["children"]||[]

                // 菜单权限
                this.menuFormat(_menuList)
                localStorage.setItem("bufferGlobalMenuList",JSON.stringify(_menuList))
            }
        },
        // 菜单权限
        menuFormat(_menuList=[]){
            let _bufferBtnPermission={}   // 按钮权限
            // const _bufferPermissions=JSON.parse(localStorage.getItem("bufferPermissions")||"[]")


            // console.log( _menuList )
            // .filter(o=>_bufferPermissions.includes(o.perms))
            // 设备维修 菜单 模块
            const _equipmentMaintain=((_menuList.filter(o=>o.path=="equipmentMaintain")[0]||{})["children"]||[])
            this.childrenMenu1=_equipmentMaintain.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/equipment":
                        _icon='mdi-bullhorn'
                        _color="#3F51B5"
                        break;
                    case "/equipment/maintain":
                        _icon='mdi-hammer-wrench'
                        _color="#1DE9B6"
                        break;
                    case "/equipment/equipmentAffirm":
                        _icon='mdi-check-bold'
                        _color="#18FFFF"
                        break;
                    case "/equipmentMessage":
                        _icon='mdi-message-processing'
                        _color="#FF9800"
                        break;
                    case "/equipmentMessage/analyst":   // 故障分析
                        _icon='mdi-nfc-search-variant'
                        _color="#E53935"
                        break;
                    case "/equipment/leaveOrder":   // 遗留单
                        _icon='mdi-order-alphabetical-ascending'
                        _color="#8BC34A"
                        break;


                    case "/equipmentRecord/index":   // 设备台账
                        _icon='mdi-notebook-outline'
                        _color="#1DE9B6"
                        break;

                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_equipmentMaintain.length){
                this.hideMenu1=false
            }


            // 设备保养 菜单 模块
            const _equipmentUpkeep=((_menuList.filter(o=>o.path=="equipmentUpkeep")[0]||{})["children"]||[])
            this.childrenMenu2=_equipmentUpkeep.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/maintain/index":
                        _icon='mdi-dns'
                        _color="#8BC34A"
                        break;
                    case "/maintainMessage/index":
                        _icon='mdi-message-processing'
                        _color="#FF9800"
                        break;
                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_equipmentUpkeep.length){
                this.hideMenu2=false
            }

            // 设备点检 菜单 模块
            const _equipmentCheck=((_menuList.filter(o=>o.path=="equipmentCheck")[0]||{})["children"]||[])
            this.childrenMenu3=_equipmentCheck.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/examineConfirm/index":
                        _icon='mdi-checkbox-marked-circle-plus-outline'
                        _color="#8BC34A"
                        break;
                    case "/examineCreation/index":
                        _icon='mdi-tab-plus'
                        _color="#3F51B5"
                        break;
                    case "/examineHistory/index":
                        _icon='mdi-history'
                        _color="#455A64"
                        break;
                    case "/examineSearch/index":
                        _icon='mdi-message-processing'
                        _color="#1DE9B6"
                        break;
                    case "/examineQuery/index":
                        _icon='mdi-text-search'
                        _color="#8BC34A"
                        break;


                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_equipmentCheck.length){
                this.hideMenu3=false
            }


            // 质量检测 菜单 模块
            const _qualityCheck=((_menuList.filter(o=>o.path=="qualityCheck")[0]||{})["children"]||[])
            this.childrenMenu4=_qualityCheck.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/qualityMaterial/index":
                        _icon='mdi-database-arrow-left'
                        _color="#8BC34A"
                        break;
                    case "/qualityMaterialDisqualification/index":
                        _icon='mdi-alert-circle'
                        _color="#E53935"
                        break;
                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_qualityCheck.length){
                this.hideMenu4=false
            }
            // 质量检测 不合格 按钮权限
            //_bufferBtnPermission["/qualityMaterialDisqualification/index"]=(_qualityCheck.filter(o=>o.path=="/qualityMaterialDisqualification/index")[0]||{})['children']||[]


            // 过程检测 菜单 模块
            const _processCheck=((_menuList.filter(o=>o.path=="processCheck")[0]||{})["children"]||[])
            this.childrenMenu5=_processCheck.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    // case "/process/index":
                    //     _icon='mdi-transit-connection-variant'
                    //     _color="#8BC34A"
                    //     break;
                    case "/process/index/working":    // 工序检验
                        _icon='mdi-expansion-card-variant'
                        _color="#8BC34A"
                        break;
                    case "/process/index/adjustment":   // 装调检验
                        _icon='mdi-package-variant-closed'
                        _color="#8BC34A"
                        break;
                    case "/process/index/put":   // 入库检验
                        _icon='mdi-warehouse'
                        _color="#8BC34A"
                        break;
                    case "/process/index/self":   // 自制件
                        _icon='mdi-video-input-component'
                        _color="#8BC34A"
                        break;



                    case "/processDisqualification/index":
                        _icon='mdi-alert-circle'
                        _color="#E53935"
                        break;
                    case "/processPreview/index":
                        _icon='mdi-text-search'
                        _color="#ff9800"
                        break;


                    case "/process/remould/index":   // 整改
                        _icon='mdi-hammer-wrench'
                        _color="#1DE9B6"
                        break;


                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_processCheck.length){
                this.hideMenu5=false
            }

            // 过程检测 不合格 按钮权限
            //_bufferBtnPermission["/processDisqualification/index"]=(_processCheck.filter(o=>o.path=="/processDisqualification/index")[0]||{})['children']||[]


            // 异常处理 菜单 模块
            const _anomaly=((_menuList.filter(o=>o.path=="anomaly")[0]||{})["children"]||[])
            this.childrenMenu6=_anomaly.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/anomalyInitiate/index":
                        _icon='mdi-alert-circle'
                        _color="warning"
                        break;
                    case "/anomalyInitiate/index/transpond":
                        _icon='mdi-forwardburger'
                        _color="#AFB42B"
                        break;
                    case "/anomalyInitiate/index/appointIndex":
                        _icon='mdi-clipboard-arrow-left'
                        _color="#303F9F"
                        break;
                    case "/anomalyInitiate/index/disposeIndex":
                        _icon='mdi-monitor-small'
                        _color="#43A047"
                        break;
                    case "/anomalyInitiate/index/closeIndex":
                        _icon='mdi-close-circle-outline'
                        _color="#E53935"
                        break;
                    case "/anomalyInitiate/search":   // 异常查询
                        _icon='mdi-nfc-search-variant'
                        _color="#E53935"
                        break;
                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_anomaly.length){
                this.hideMenu6=false
            }


            // 备件 菜单 模块
            const _replacementPart=((_menuList.filter(o=>o.path=="replacementPart")[0]||{})["children"]||[])
            this.childrenMenu7=_replacementPart.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/outPutApply/index":
                        _icon='mdi-import'
                        _color="#43A047"
                        break;
                    case "/outPutManage/index":
                        _icon='mdi-export'
                        _color="warning"
                        break;
                    case "/outPutHistory/index":
                        _icon='mdi-text-search'
                        _color="#1DE9B6"
                        break;


                    case "/wmsStock/index":
                        _icon='mdi-notebook-outline'
                        _color="#ff9800"
                        break;

                    case "/wmsTrasfer/index":
                        _icon='mdi-transfer'
                        _color="#43A047"
                        break;

                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_replacementPart.length){
                this.hideMenu7=false
            }


            // 备件 菜单 模块
            const _anomalyInitiateSection=((_menuList.filter(o=>o.path=="anomalyInitiateSection")[0]||{})["children"]||[])
            this.childrenMenu8=_anomalyInitiateSection.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/anomalyInitiateSection/index":
                        _icon='mdi-plus'
                        _color="#43A047"
                        break;
                    case "/anomalyInitiateSection/dispose":
                        _icon='mdi-calendar-edit'
                        _color="warning"
                        break;
                    case "/anomalyInitiateSection/search":
                        _icon='mdi-text-search'
                        _color="#1DE9B6"
                        break;

                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_anomalyInitiateSection.length){
                this.hideMenu8=false
            }


            // 产线检验  菜单 模块
            const _processQualifiedProductionLine=((_menuList.filter(o=>o.path=="processQualifiedProductionLine")[0]||{})["children"]||[])
            this.childrenMenu9=_processQualifiedProductionLine.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/processQualifiedProductionLine/index":
                        _icon='mdi-sitemap-outline'
                        _color="#43A047"
                        break;
                    case "/processProductionLine/index":
                        _icon='mdi-alert-circle'
                        _color="#E53935"
                        break;

                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_processQualifiedProductionLine.length){
                this.hideMenu9=false
            }

            // 仓储管理
            const _storage=((_menuList.filter(o=>o.path=="storage")[0]||{})["children"]||[])
            this.childrenMenu10=_storage.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/storage/index":
                        _icon='mdi-file-sign'
                        _color="#43A047"
                        break;
                    case "/storageManagement/index":
                        _icon='mdi-account-badge'
                        _color="warning"
                        break;

                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_storage.length){
                this.hideMenu10=false
            }


            // 能源管理
            const _energy=((_menuList.filter(o=>o.path=="energy")[0]||{})["children"]||[])
            this.childrenMenu11=_energy.map(o=>{
                let _icon=""
                let _color=""
                switch (o.path) {
                    case "/energy/index":
                        _icon='mdi-file-sign'
                        _color="warning"
                        break;
                    case "/energy/search":
                        _icon='mdi-text-search'
                        _color="#43A047"
                        break;

                    default:
                        break;
                }

                return {
                    text: o.menuName||"",
                    icon: _icon,
                    color: _color,
                    path: o.path
                }
            })
            if(!_energy.length){
                this.hideMenu11=false
            }



            // 缓存 按钮权限
            localStorage.setItem("bufferGlobalBtnPermission", JSON.stringify(_bufferBtnPermission) )

        },
        // 获取 版本号
        async getVersion(){
            if (!window.plus) return

            // 本地
            if( window.location.hostname == 'localhost' ){
                return
            }


            const {code,data=""}= await httpHandle({
                url:'/system/config/configKey/app_current_version',
                method:'GET'
            })



            // this.showPicker=true

            if(code==200){

                if(AppVersion!=data){
                    this.showPicker=true
                    this.currentVersion=AppVersion
                    this.newVersion=data
                }

            }
        },
        /**
         * 按钮 card
        */
        btnCardHandle:function(name,title){
            let items=[];

            switch (name) {
                // 设备维修
                case 'service':
                    items=[
                        {
                            text: '设备报修',
                            icon: 'mdi-bullhorn',
                            color: "#3F51B5",
                            path: '/equipment'
                        },
                        {
                            text: '设备维修',
                            icon: 'mdi-hammer-wrench',
                            color: "#1DE9B6",
                            path: '/equipment/maintain'
                        },
                        {
                            text: '维修确认',
                            icon: 'mdi-check-bold',
                            color: "#18FFFF",
                            path: '/equipment/equipmentAffirm'
                        },
                        {
                            text: '维修信息查询',
                            icon: 'mdi-message-processing',
                            color:"#FF9800",
                            path: '/equipmentMessage'
                        },

                    ]
                    break;
                // 设备保养
                case 'maintain':
                    items=[
                        {
                            text: '设备保养',
                            icon: 'mdi-dns',
                            color:'#8BC34A',
                            path: '/maintain/index'
                        },
                        {
                            text: '保养信息查询',
                            icon: 'mdi-clock',
                            color:"#FF9800",
                            path: '/maintainMessage/index'
                        },
                    ]
                    break;
                // 设备点检
                case 'examine':
                    items=[
                        {
                            text: '点检确认',
                            icon: 'mdi-checkbox-marked-circle-plus-outline',
                            color:'#8BC34A',
                            path: '/examineConfirm/index'
                        },
                        {
                            text: '巡检创建',
                            icon: 'mdi-tab-plus',
                            color:'#3F51B5',
                            path: '/examineCreation/index'
                        },
                        {
                            text: '设备点/巡检',
                            icon: 'mdi-history',
                            color:'#455A64',
                            path: '/examineHistory/index'
                        },
                        {
                            text: '点检信息查询',
                            icon: 'mdi-text-search',
                            color:'#1DE9B6',
                            path: '/examineSearch/index'
                        },





                    ]
                    break;


                // 质量检测
                case 'quality':
                    items=[
                        {
                            text: '来料检测',
                            icon: 'mdi-dns',
                            color:'#8BC34A',
                            path: '/qualityMaterial/index'
                        },
                        {
                            text: '来料检测-不合格处理',
                            icon: 'mdi-clock',
                            color:"#FF9800",
                            path: '/qualityMaterialDisqualification/index'
                        },
                    ]
                    break;
                // 质量检测
                case 'process':
                    items=[
                        {
                            text: '过程检测',
                            icon: 'mdi-dns',
                            color:'#8BC34A',
                            path: '/process/index'
                        },
                        {
                            text: '过程检测-不合格处理',
                            icon: 'mdi-clock',
                            color:"#FF9800",
                            path: '/processDisqualification/index'
                        },
                    ]
                    break;
                    // 异常处理
                case 'abnormal':
                    items=[
                        { text: '异常处理',path:"/anomalyInitiate/index", color:'warning', icon:'mdi-alert-circle' },
                        { text: '异常转发',path:'/anomalyInitiate/index/transpond', color:'#AFB42B', icon: 'mdi-forwardburger' },
                        { text: '异常指派',path:'/anomalyInitiate/index/appointIndex', color:'#303F9F', icon: 'mdi-clipboard-arrow-left' },
                        { text: '异常处理',path:'/anomalyInitiate/index/disposeIndex',color:'#43A047', icon: 'mdi-monitor-small' },
                        { text: '异常关闭',path:'/anomalyInitiate/index/closeIndex',color:'#F4511E', icon: 'mdi-close-circle-outline' },
                    ]
                    break;
                // 测试页面
                case 'aaa':
                    items=[
                        {
                            text: '图片上传',
                            icon: 'mdi-message-processing',
                            color:"#FF9800",
                            path: '/test/snackbar'
                        },
                        {
                            text: '扫码',
                            icon: 'mdi-message-processing',
                            color:"#FF9800",
                            path: '/test/saoma'
                        },

                    ]
                    break;
                default:
                    break;
            }
            this.$refs.menuRef.showDrawer(title,items);
        },
        // 下载
        downloadFunc(){
            const that=this

            if(window.plus){
                plus.nativeUI.toast("下载中，请稍后！")
                that.showPicker=false

                var dtask = plus.downloader.createDownload(`http://10.193.134.146/app/download/EAM测试.apk`,{},function (d, status) {
                    if (status == 200) {
                        // plus.nativeUI.toast("下载成功，安装中！")
                        localStorage.setItem("_token","")


                        var path = d.filename  //下载apk
                        plus.runtime.install(path)  // 自动安装apk文件
                    } else {
                        plus.nativeUI.toast('版本更新失败:' + status)
                    }
                })

                dtask.start()

            }

        },
        textNumber(){
            this.numberTest=this.numberTest+1

            if(this.numberTest==13){
                this.$router.push({
                    path:'/test/weixin',
                    query:{}
                })
            }

        }
    }
}
</script>

<style lang="scss">
.layout-home .home-card{
    padding-left: 6px;
    padding-right: 6px;

    margin-top: 8px;
    .v-col{padding:0px;}

    >div:nth-child(1){
        padding-right: 4px;
    }
    >div:nth-child(2){
        padding-left: 4px;
    }
}
</style>


