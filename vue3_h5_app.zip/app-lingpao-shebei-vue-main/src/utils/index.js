import  * as SaimoModule from "./saimo"


export default {
    ...SaimoModule
}