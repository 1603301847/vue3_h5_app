﻿/**
 * 公共方法有的   优先使用公共方法的
 * 公共方法没有的，可自定义函数
 */



// 文本框自动滚动
export function VanFieldFocusToTop(event){
	if(!event) return
	const _height= Math.floor(event.target.getBoundingClientRect().top+window.scrollY) 
	window.scrollTo(0,_height-200)
}


// 按钮权限
export function PermissionButton(key){
	const _list= JSON.parse( localStorage.getItem("bufferPermissions") ||[])
	return _list.includes(key)
}


